"""Mutation runner for Phase 18E `.hardening` — the two U238 probe-acceptance holes and the two
gate inputs the pane/worker emitter used to answer for itself.

Same contract as its siblings: apply one mutation, run one selector, record RED (a test caught it)
or GREEN (nothing did), restore the original bytes, verify the restore is BYTE-IDENTICAL by sha256.
Exit 1 if anything is GREEN or a restore diverges.

This harness matters more than most, because most mutations below RESTORE A SHIPPED BEHAVIOUR:
the `new` string is not an invented defect, it is the code that was on the tree when the operator
armed 18E, and directive §17.2(2) requires both acceptance holes closed BEFORE the first live leg.
If any row here goes GREEN, the closure is decorative.

Three rows are NOT restorations and say so at their own entries: H6 is signature-only (see below),
H9 tests something 18E ADDED, and H10 tests an ordering that never existed before 18E.

  * H1  the echo subtraction runs on the whitespace fold again — six measured shapes of pure echo
        (`Reply with exactly:GROK_PROVIDER_OK`, a dash for the colon, markdown emphasis, a
        letter-spaced instruction …) certify a provider that answered nothing;
  * H2  acceptance reads the BEST-EFFORT extractor again, whose whole-document fallback lets a
        token in any field at all — `{"status":"done","debug":"GROK_PROVIDER_OK"}` — pass;
  * H3  the strict reader grows the same fallback, which is H2 by the other route (the shared
        accessor rather than its caller);
  * H4  the strict reader stops being strict about the KEY, so any string value certifies;
  * H5  `operator_terms_confirmed` becomes a defaulted keyword again — a parameter default
        published as a measured gate (U98's shape; U292(a));
  * H6  `profile_loader` becomes a defaulted keyword again — SIGNATURE ONLY, and that is the honest
        description (spec-audit F5): with `main()` still passing a loader, restoring the body's
        `ProfileLoader(DeploymentProfile("cloud"))` fallback would change no runtime behaviour and
        the row would prove nothing about reachability. H6 pins the SIGNATURE (U91/U283's shape,
        closed at 18C `.probe-path` on the probe surface); H7 is the row that tests the air-gap
        reachability, at the call site where it can actually be defeated;
  * H7  `main()` keeps the required keyword but hands it a manufactured `cloud` loader instead of
        the host's — the closure defeated at the ONE call site that matters, which a signature
        test alone would never see;
  * H8  the token PRESENCE check moves onto the destructive fold, so `GROK-PROVIDER-OK` reads as
        the exact token §17 requires. The strictness added for H1 must not leak into recognition;
  * H9  the two refusal reasons collapse into one, so a document with no response field is reported
        as a prompt echo. The verdict is right and the explanation is wrong, which is the kind of
        defect a green suite keeps;
  * H10 the air-gap gate goes back BEHIND the host enumeration — the ordering spec-audit F2 found.
        The refusal is unchanged and the test that only asserts `refused_by` stays green; what goes
        red is the leg that asserts the enumeration was never reached, because for an OP-12 provider
        that enumeration is an outbound `models` call made to verify a pane invariant 20 forbids
        opening (U303).

Run from the repo root:  py -3.12 tools/mutation/_op18e_hardening_mutations.py
"""
from __future__ import annotations

import hashlib
import pathlib
import signal
import subprocess
import sys

ROOT = pathlib.Path(__file__).resolve().parents[2]
PY = [sys.executable, "-m", "pytest", "-q", "-x"]

RECON = "tools/providers/frontier_provider_recon.py"
COMMON = "adapters/frontier/provider_cli_common.py"
EMITTER = "tools/live/emit_worker_launch.py"

U238_ECHO = "tests/unit/test_frontier_provider_recon.py::TestU238EchoNormalisation"
U238_FIELD = "tests/unit/test_frontier_provider_recon.py::TestU238AcceptanceReadsAResponseFieldOrNothing"
GATE_INPUTS = "tests/unit/test_worker_emitter_gate_inputs.py"

MUTATIONS = [
    ("H1  the echo subtraction runs on the whitespace fold again (U238 hole 1)",
     RECON,
     "    return f_token in f_response.replace(f_prompt, \" \")",
     "    return n_token in n_response.replace(n_prompt, \" \")",
     U238_ECHO + "::test_a_punctuation_or_whitespace_deleting_echo_is_not_an_answer"),
    ("H2  acceptance reads the best-effort extractor again (U238 hole 2)",
     RECON,
     "    response = extract_probe_response_field(stdout)      # strict reader only (U238 hole 2)",
     "    response = extract_probe_text(stdout)",
     U238_FIELD + "::test_a_token_outside_a_recognised_response_field_is_not_an_answer"),
    ("H3  the STRICT reader grows the whole-document fallback",
     COMMON,
     "        for key in PROVIDER_RESPONSE_KEYS:\n"
     "            val = doc.get(key)\n"
     "            if isinstance(val, str) and val.strip():\n"
     "                return val\n"
     "    return \"\"",
     "        for key in PROVIDER_RESPONSE_KEYS:\n"
     "            val = doc.get(key)\n"
     "            if isinstance(val, str) and val.strip():\n"
     "                return val\n"
     "        return json.dumps(doc)\n"
     "    return \"\"",
     U238_FIELD),
    ("H4  the strict reader accepts ANY string value, not a recognised field",
     COMMON,
     "        for key in PROVIDER_RESPONSE_KEYS:\n"
     "            val = doc.get(key)\n"
     "            if isinstance(val, str) and val.strip():\n"
     "                return val\n"
     "    return \"\"",
     "        for val in doc.values():\n"
     "            if isinstance(val, str) and val.strip():\n"
     "                return val\n"
     "    return \"\"",
     U238_FIELD + "::test_a_token_outside_a_recognised_response_field_is_not_an_answer"),
    ("H5  `operator_terms_confirmed` becomes a defaulted keyword again (U292(a))",
     EMITTER,
     "    operator_terms_confirmed: bool,",
     "    operator_terms_confirmed: bool = True,",
     GATE_INPUTS + "::test_the_gate_input_is_a_required_keyword"),
    # Signature-only by design — see the module docstring. H7 is the behavioural half.
    ("H6  `profile_loader` becomes a defaulted keyword again (signature only; U283)",
     EMITTER,
     "    profile_loader: ProfileLoader,\n"
     "    operator_terms_confirmed: bool,",
     "    profile_loader: ProfileLoader | None = None,\n"
     "    operator_terms_confirmed: bool,",
     GATE_INPUTS + "::test_the_gate_input_is_a_required_keyword"),
    # The replacement builds the loader through a fully-qualified inline import rather than a
    # module-level name, because the closure DELETED the `DeploymentProfile` import: a mutation
    # that fell over with `NameError` would score RED without ever testing the guard.
    ("H7  main() hands the gate chain a manufactured `cloud` profile (the call site)",
     EMITTER,
     "            profile_loader=profile_loader_from_host(),",
     '            profile_loader=__import__("control_plane.profiles.loader", fromlist=["x"])'
     '.ProfileLoader(__import__("control_plane.profiles.loader", fromlist=["x"])'
     '.DeploymentProfile("cloud")),',
     GATE_INPUTS + "::test_the_production_path_refuses_a_frontier_pane_on_an_airgapped_host"),
    ("H8  token PRESENCE moves onto the destructive fold (over-strictness leaking into recognition)",
     RECON,
     "    if not n_token or n_token not in n_response:",
     "    if not n_token or fold(token) not in fold(response):",
     U238_ECHO + "::test_the_token_must_still_appear_verbatim_not_only_after_punctuation_folding"),
    # H9 is not a shipped behaviour being restored — it is the one thing 18E ADDED beyond the two
    # holes, and an addition with no guard is a comment. Collapsing the branch reports a document
    # with no response field as "a prompt echo does not count", which sends an operator hunting for
    # an echo in a transcript whose token is sitting in a `debug` field. Same refusal, wrong reason.
    ("H9  the two refusal reasons collapse into one (the no-response-field case reads as an echo)",
     RECON,
     "        if parsed and not response:",
     "        if False:",
     U238_FIELD + "::test_the_two_ways_to_fail_this_condition_are_reported_differently"),
    # H10 deletes the CALL, not the function: the guard stays defined and tested in isolation, which
    # is precisely the shape of defect that survives a green suite. The selector is the leg that
    # asserts SILENCE (no enumeration), because the leg that asserts `refused_by == profile_roster`
    # passes either way — the downstream gate still refuses, just after the egress.
    ("H10 the air-gap gate moves back BEHIND the host enumeration (the F2 ordering, U303)",
     EMITTER,
     "        _assert_profile_permits_verifying(option, loader)\n",
     "",
     GATE_INPUTS + "::test_an_airgapped_host_refuses_a_frontier_pane_without_enumerating"),
]

#: Files this run may have mutated, pinned at import so the signal handler can restore ALL of them
#: even if it fires between the write and the restore. The JS sibling
#: (`pane_input_bypass_mutations.js`) documents this contract; `_op18c_probe_path_mutations.py`
#: still lacks it (U292(b)), and a harness that mutates product files must never be able to leave
#: one mutated because someone pressed Ctrl-C.
_PINNED: dict[pathlib.Path, bytes] = {}
_LOCK = ROOT / ".mutation-lock"


def digest(p: pathlib.Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()


def _restore_all(*_a: object) -> None:
    for path, original in _PINNED.items():
        try:
            path.write_bytes(original)
        except OSError:                                  # pragma: no cover - best effort teardown
            pass
    _LOCK.unlink(missing_ok=True)


def run_one(rel: str, old: str, new: str, target: str) -> tuple[str, str]:
    path = ROOT / rel
    before = _PINNED[path]
    before_hash = digest(path)
    text = before.decode("utf-8")
    if old not in text:
        return "SKIPPED-ANCHOR-MISSING", "unchanged"
    mutated = text.replace(old, new, 1)
    if mutated == text:
        return "SKIPPED-ANCHOR-MISSING", "unchanged"
    path.write_bytes(mutated.encode("utf-8"))
    try:
        proc = subprocess.run(PY + [target], cwd=ROOT, capture_output=True, text=True)
        verdict = "RED" if proc.returncode != 0 else "GREEN (guard does not hold)"
    finally:
        path.write_bytes(before)
    return verdict, ("restored" if digest(path) == before_hash else "RESTORE FAILED")


def main() -> int:
    if _LOCK.exists():
        print(f"another mutation run holds {_LOCK} - refusing to mutate product files concurrently")
        return 1
    _LOCK.write_text(str(__file__), encoding="utf-8")
    for _, rel, _o, _n, _t in MUTATIONS:
        _PINNED.setdefault(ROOT / rel, (ROOT / rel).read_bytes())
    for sig in (signal.SIGINT, signal.SIGTERM):
        signal.signal(sig, lambda *_a: (_restore_all(), sys.exit(130)))

    rows = []
    try:
        for label, rel, old, new, target in MUTATIONS:
            verdict, restore = run_one(rel, old, new, target)
            rows.append((label, verdict, restore))
    finally:
        _restore_all()

    width = max(len(r[0]) for r in rows)
    for label, verdict, restore in rows:
        print(f"{label.ljust(width)}  {verdict:<26} {restore}")
    ok = all(r[1] == "RED" and r[2] == "restored" for r in rows)
    failed = [r[0] for r in rows if r[2] == "RESTORE FAILED"]
    print(f"\n{sum(1 for r in rows if r[1] == 'RED')}/{len(rows)} RED, "
          + ("all restores byte-identical" if not failed
             else "RESTORE FAILED: " + "; ".join(failed)))
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
