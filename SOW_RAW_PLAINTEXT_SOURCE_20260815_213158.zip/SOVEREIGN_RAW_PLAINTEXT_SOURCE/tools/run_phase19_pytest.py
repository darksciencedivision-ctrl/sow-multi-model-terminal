"""Run the committed Phase 19 Python suite contract with its wall-clock ceiling.

This wrapper intentionally uses only the standard library. pytest-timeout is not a repository
dependency and Phase 19 may not install it without a separate operator ruling.
"""
from __future__ import annotations

import argparse
import configparser
import os
from pathlib import Path
import signal
import subprocess
import sys


ROOT = Path(__file__).resolve().parents[1]
CONFIG = ROOT / "pytest.ini"


def _contract() -> tuple[float, list[str]]:
    parser = configparser.ConfigParser()
    if not parser.read(CONFIG, encoding="utf-8") or "pytest" not in parser:
        raise SystemExit(f"Phase 19 pytest contract is unreadable: {CONFIG}")
    section = parser["pytest"]
    ceiling = float(section["phase19_suite_timeout_seconds"])
    paths = [line.strip() for line in section["phase19_focused_paths"].splitlines()
             if line.strip()]
    if ceiling <= 0 or not paths:
        raise SystemExit("Phase 19 pytest contract has an invalid ceiling or empty focused subset")
    return ceiling, paths


def _terminate_tree(process: subprocess.Popen[bytes]) -> None:
    if process.poll() is not None:
        return
    if os.name == "nt":
        subprocess.run(["taskkill", "/PID", str(process.pid), "/T", "/F"],
                       check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    else:
        os.killpg(process.pid, signal.SIGTERM)


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("mode", choices=("focused", "full"))
    ap.add_argument("pytest_args", nargs=argparse.REMAINDER)
    ns = ap.parse_args(argv)
    ceiling, focused = _contract()
    targets = focused if ns.mode == "focused" else ["tests/"]
    extra = ns.pytest_args[1:] if ns.pytest_args[:1] == ["--"] else ns.pytest_args
    command = [sys.executable, "-m", "pytest", *targets, "-q", *extra]
    creationflags = subprocess.CREATE_NEW_PROCESS_GROUP if os.name == "nt" else 0
    process = subprocess.Popen(command, cwd=ROOT, creationflags=creationflags,
                               start_new_session=os.name != "nt")
    try:
        return process.wait(timeout=ceiling)
    except subprocess.TimeoutExpired:
        _terminate_tree(process)
        process.wait()
        print(f"Phase 19 {ns.mode} suite exceeded the committed {ceiling:g}s ceiling",
              file=sys.stderr)
        return 124


if __name__ == "__main__":
    raise SystemExit(main())
