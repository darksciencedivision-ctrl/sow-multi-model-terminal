"""No pytest run may spend a live provider-subscription call (U163).

The mock-first suites already tried to guarantee this, each in its own way — `patch.object(
claude_code_module.subprocess, "run", ...)`, `monkeypatch.setattr(subprocess, "run", forbidden)`.
Those patches stopped intercepting on 2026-07-28, when the frontier adapter moved its spawn from
`subprocess.run` to `run_managed_process` (commit c8af621, the descendant-killing job boundary).
Nothing failed: the calls simply became REAL. Measured on 2026-07-30, `pytest tests/` spent live
`claude` calls in three `test_live_debate_flow` cases and reported a `live` leg for a suite whose
own docstring says `live` must be unreachable in it — the checkpoint was genuine, which is
precisely the problem.

So the seam is no longer allowed to be per-test knowledge. This guard sits at the process boundary
itself and refuses, by executable NAME and argument vector, any BILLABLE spawn of a provider CLI
from inside the test suite:

  * it patches the definition site, so modules imported later bind the guarded function;
  * it patches every already-imported module that holds a `from … import run_managed_process` name;
  * it covers `subprocess.run`/`Popen` too, since a future adapter could route either way.

It does NOT restrict ordinary spawns (node, python, powershell, wsl) — those are how several tests
prove real behaviour. Live provider work belongs to the `tools/live/` smokes and the in-Electron
self-checks, which run outside pytest and record receipts. A test that genuinely must reach a
provider can mark itself `@pytest.mark.live_cli`, and that mark is then visible in the diff.

Nor does it restrict the CREDENTIAL-FREE METADATA calls (U165). Refusing by executable name alone
also refused `codex --version`, `codex login status` and `codex exec --help` — the local probes
Phase 15C `.detect` is built on, which reach no model and cost nothing — and turned nine honest
host-probe tests red the moment the guard landed. The line the guard actually defends is
*spending a subscription call*, so the allowance is drawn there and drawn TIGHT: the WHOLE argv
must equal one of the enumerated forms below. `exec --help` is free; `exec --help <prompt>` is a
model call wearing its clothes, and a bare `codex` opens the interactive session — both refused.

This lives in its own module, not in `conftest.py`, so that a test can import the exception class
and get the SAME object the fixture raises (pytest loads a rootdir conftest under its own module
name, and an importing test would otherwise catch a different class of the same name).
"""
from __future__ import annotations

import subprocess
import sys
from pathlib import Path

# The CLIs OP-6/OP-9/OP-12 authorized for LIVE use. A call to one of these costs the operator's
# real subscription quota, which a unit-test run must never do implicitly.
#
# `grok` and `agy` joined the set at the Phase-18A gate (round-4 gate-validator finding 1). 18A
# added a real spawn seam for them (`frontier_provider_recon.subprocess_runner`), and the
# validator proved by PATH tripwire that no test reaches it today — so this is a defence added
# BEFORE the regression, which is the only useful time. U163 is the reason it exists at all: a
# `pytest tests/` run once spent real `claude` calls while every test stayed green.
LIVE_PROVIDER_CLIS = frozenset({"claude", "codex", "grok", "agy"})

# Argument vectors that make one of those CLIs print its own version, its own help, or the LOCAL
# state of an existing login — and nothing else. No prompt, no session, no token in the output, no
# quota spent. An ALLOWLIST matched whole, never as a prefix: everything not enumerated here is a
# refusal, so a new subcommand is refused until someone establishes it is free and adds it.
CREDENTIAL_FREE_METADATA_ARGV = frozenset({
    ("--version",), ("-V",),
    ("--help",), ("-h",),
    ("exec", "--help"), ("exec", "-h"),   # structural: does `-m/--model` exist (15C `.detect`)
    ("login", "status"),                  # authenticated yes/no; reports state, never the token
})


class LiveProviderCallInTests(RuntimeError):
    """A test tried to spawn a live provider CLI. The seam it patched is not the seam in use."""


def live_provider_name(cmd: object) -> str | None:
    """The provider CLI name this command would execute, or None."""
    first: object
    if isinstance(cmd, (list, tuple)):
        if not cmd:
            return None
        first = cmd[0]
    elif isinstance(cmd, (str, Path)):
        first = cmd
    else:
        return None
    stem = Path(str(first)).stem.lower()
    return stem if stem in LIVE_PROVIDER_CLIS else None


def billable_provider_call(cmd: object) -> str | None:
    """The provider CLI name this command would spend QUOTA on, or None (U165).

    None for a command that is not a provider CLI at all, and for the enumerated credential-free
    metadata forms. Everything else that names a provider CLI — including a bare invocation, which
    opens an interactive session — is billable as far as this guard is concerned. Fail closed:
    an argv shape nobody has established as free is treated as one that costs.
    """
    name = live_provider_name(cmd)
    if name is None:
        return None
    args = tuple(str(a) for a in cmd[1:]) if isinstance(cmd, (list, tuple)) else ()
    return None if args in CREDENTIAL_FREE_METADATA_ARGV else name


def _refuse(name: str, cmd: object) -> LiveProviderCallInTests:
    return LiveProviderCallInTests(
        f"the test suite tried to spawn the live `{name}` CLI ({cmd!r}). A pytest run must not "
        "spend a subscription call: patch the seam the adapter actually uses "
        "(`run_managed_process` in the adapter's own module), or move the leg to a tools/live "
        f"smoke. (Credential-free metadata probes are allowed: {sorted(CREDENTIAL_FREE_METADATA_ARGV)}.)"
    )


def install(monkeypatch) -> None:  # type: ignore[no-untyped-def]
    """Wrap every process boundary a provider CLI could leave through, for one test."""
    from adapters.frontier import process_tree

    real_managed = process_tree.run_managed_process

    def guarded_managed(cmd, **kwargs):  # type: ignore[no-untyped-def]
        name = billable_provider_call(cmd)
        if name:
            raise _refuse(name, cmd)
        return real_managed(cmd, **kwargs)

    monkeypatch.setattr(process_tree, "run_managed_process", guarded_managed)
    # `from … import run_managed_process` copies the object; the copy is what those callers invoke.
    for module in list(sys.modules.values()):
        if getattr(module, "run_managed_process", None) is real_managed:
            monkeypatch.setattr(module, "run_managed_process", guarded_managed, raising=False)

    real_run = subprocess.run
    real_popen = subprocess.Popen

    def guarded_run(cmd, *args, **kwargs):  # type: ignore[no-untyped-def]
        name = billable_provider_call(cmd)
        if name:
            raise _refuse(name, cmd)
        return real_run(cmd, *args, **kwargs)

    class GuardedPopen(real_popen):  # type: ignore[misc, valid-type]
        def __init__(self, cmd, *args, **kwargs):  # type: ignore[no-untyped-def]
            name = billable_provider_call(cmd)
            if name:
                raise _refuse(name, cmd)
            super().__init__(cmd, *args, **kwargs)

    monkeypatch.setattr(subprocess, "run", guarded_run)
    monkeypatch.setattr(subprocess, "Popen", GuardedPopen)
