from __future__ import annotations

from pathlib import Path

import pytest

from control_plane.policy import Identity, SovereignPolicy
from mcp_server.collaboration_service import CollaborationError, CollaborationService
from mcp_server.sovereign_tools import handle_request
from persistence import SovereignStore


@pytest.fixture()
def service(tmp_path: Path):
    store = SovereignStore(tmp_path / "sovereign.db")
    svc = CollaborationService(store, SovereignPolicy())
    yield svc
    store.close()


def identities():
    return (
        Identity("cond-1", "conductor", "proj"),
        Identity("gemini-1", "worker", "proj"),
        Identity("grok-1", "worker", "proj"),
    )


def assigned(service: CollaborationService):
    cond, gemini, grok = identities()
    task = service.create_task(
        cond, objective="independently find integration risks",
        owner_node_ids=[gemini.node_id, grok.node_id], peer_nodes=[gemini.node_id, grok.node_id],
        acceptance_criteria=["publish three risks", "exchange one direct question"],
    )
    return cond, gemini, grok, task


def test_conductor_worker_and_peer_messages_are_persisted_and_scoped(service: CollaborationService) -> None:
    cond, gemini, grok, task = assigned(service)
    first = service.read_messages(cond, task_id=task["task_id"], include_all=True)
    assert first[0]["message_kind"] == "assignment"
    question = service.send_message(
        gemini, task_id=task["task_id"], thread_id=task["thread_id"],
        recipient_node_ids=[grok.node_id], message_kind="question",
        body="Which runtime boundary looks weakest?", evidence_refs=["m-evidence"],
    )
    reply = service.send_message(
        grok, task_id=task["task_id"], thread_id=task["thread_id"],
        recipient_node_ids=[gemini.node_id, cond.node_id], message_kind="answer",
        body="The terminal-to-MCP bridge.", reply_to=question["message_id"],
    )
    visible = service.read_messages(gemini, task_id=task["task_id"])
    assert [m["message_id"] for m in visible][-2:] == [question["message_id"], reply["message_id"]]
    assert service.read_messages(cond, task_id=task["task_id"], include_all=True)[-1]["reply_to"] == question["message_id"]


def test_progress_lifecycle_and_cross_task_access_fail_closed(service: CollaborationService) -> None:
    cond, gemini, grok, task = assigned(service)
    updated = service.update_task(
        gemini, task_id=task["task_id"], status="IN_PROGRESS",
        progress={"completed": "mapped runtime", "what_remains": "rank gaps"},
    )
    assert updated["status"] == "IN_PROGRESS"
    stranger = Identity("worker-other", "worker", "proj")
    with pytest.raises(CollaborationError, match="cross-task"):
        service.get_task(stranger, task["task_id"])
    with pytest.raises(CollaborationError, match="cross-task recipient"):
        service.send_message(
            gemini, task_id=task["task_id"], thread_id=task["thread_id"],
            recipient_node_ids=[stranger.node_id], message_kind="question", body="leak?",
        )


def test_bounded_debate_preserves_evidence_and_dissent(service: CollaborationService) -> None:
    cond, gemini, grok, task = assigned(service)
    debate = service.open_debate(
        cond, task_id=task["task_id"], proposition="MCP connectivity is the top risk",
        participant_node_ids=[gemini.node_id, grok.node_id], evidence_refs=["m-1"], max_rounds=1,
    )
    turn = service.post_debate_turn(
        gemini, debate_id=debate["debate_id"], body="Agree, because nodes lack a callable bridge.",
        evidence_refs=["m-2"],
    )
    service.post_debate_turn(
        grok, debate_id=debate["debate_id"], body="Challenge: readiness is a larger risk.",
        evidence_refs=["m-3"], reply_to=turn["turn_id"],
    )
    with pytest.raises(CollaborationError, match="round limit"):
        service.post_debate_turn(gemini, debate_id=debate["debate_id"], body="second round")
    closed = service.close_debate(
        cond, debate_id=debate["debate_id"], decision="Both are coupled launch risks.",
        agreements=["live connections require readiness"], dissent=["which gap ranks first"],
    )
    assert closed["state"] == "CLOSED"
    assert closed["dissent"] == ["which gap ranks first"]
    assert closed["turns"][0]["evidence_refs"] == ["m-2"]
    assert closed["closure_reason"] == "Both are coupled launch risks."
    assert set(closed["claims"]) == {
        "Agree, because nodes lack a callable bridge.", "Challenge: readiness is a larger risk.",
    }


def test_debate_cannot_close_without_both_participants(service: CollaborationService) -> None:
    cond, gemini, grok, task = assigned(service)
    debate = service.open_debate(
        cond, task_id=task["task_id"], proposition="readiness outranks persistence",
        participant_node_ids=[gemini.node_id, grok.node_id], max_rounds=2,
    )
    service.post_debate_turn(gemini, debate_id=debate["debate_id"], body="readiness first")
    with pytest.raises(CollaborationError, match="every participant"):
        service.close_debate(cond, debate_id=debate["debate_id"], decision="premature")


def _candidate(node_id: str, artifact: str = "sha256:candidate") -> dict:
    return {
        "task_id": "set by caller", "worker_node_id": node_id, "provider": "provider",
        "model": "model", "summary": "ranked risks", "claims": ["risk one"],
        "evidence_refs": ["file.py:1"], "peer_messages_considered": [],
        "debates_considered": [], "limitations": [], "status": "CANDIDATE",
        "artifact_ref": artifact, "content_hash": artifact,
    }


def test_two_candidate_records_survive_and_gate_synthesis(service: CollaborationService) -> None:
    cond, gemini, grok, task = assigned(service)
    with pytest.raises(CollaborationError, match="every worker"):
        service.record_synthesis(cond, task_id=task["task_id"], synthesis={"status": "SYNTHESIS"})
    first = service.record_candidate(gemini, task_id=task["task_id"],
                                     candidate=_candidate(gemini.node_id, "sha256:gemini"))
    assert first["status"] == "IN_PROGRESS"
    second = service.record_candidate(grok, task_id=task["task_id"],
                                      candidate=_candidate(grok.node_id, "sha256:grok"))
    assert second["status"] == "CANDIDATE_READY"
    assert set(second["candidates"]) == {gemini.node_id, grok.node_id}
    completed = service.record_synthesis(
        cond, task_id=task["task_id"], synthesis={"status": "SYNTHESIS", "artifact_ref": "sha256:s"})
    assert completed["status"] == "COMPLETED"


def test_candidate_without_artifact_reference_is_refused(service: CollaborationService) -> None:
    _cond, gemini, _grok, task = assigned(service)
    candidate = _candidate(gemini.node_id, "")
    with pytest.raises(CollaborationError, match="artifact_ref"):
        service.record_candidate(gemini, task_id=task["task_id"], candidate=candidate)


def test_standard_mcp_lists_exact_operational_tools_and_returns_structured_results() -> None:
    class Runtime:
        def call(self, name, args):
            return {"called": name, "arguments": args}

    listed = handle_request(Runtime(), {"jsonrpc": "2.0", "id": 1, "method": "tools/list"})
    names = {tool["name"] for tool in listed["result"]["tools"]}
    required = {
        "list_models", "spawn_worker", "stop_worker", "assign_task", "get_worker_status",
        "send_message", "read_messages", "open_debate", "post_debate_turn", "close_debate",
        "publish_artifact", "read_artifact", "publish_candidate", "publish_synthesis",
    }
    assert required.issubset(names)
    called = handle_request(Runtime(), {"jsonrpc": "2.0", "id": 2, "method": "tools/call",
                                        "params": {"name": "spawn_worker",
                                                   "arguments": {"provider": "grok_build"}}})
    assert called["result"]["structuredContent"]["called"] == "spawn_worker"
    assert called["result"]["isError"] is False
