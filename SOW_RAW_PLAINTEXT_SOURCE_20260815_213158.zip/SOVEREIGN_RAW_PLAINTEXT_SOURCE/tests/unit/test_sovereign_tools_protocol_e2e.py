from __future__ import annotations

from pathlib import Path
from typing import Any

from control_plane.policy import SovereignPolicy
from mcp_server.sovereign_tools import SovereignToolRuntime, TOOLS, handle_request


class FakeApplicationControl:
    """The Electron seam only; persistence, policy and every tool handler remain real."""

    def __init__(self, node_id: str, role: str, provider: str, model: str) -> None:
        self.details = {
            "node_id": node_id,
            "role": role,
            "project_id": "proj",
            "provider_id": provider,
            "model_id": model,
        }
        self.calls: list[tuple[str, dict[str, Any]]] = []

    def identity_details(self) -> dict[str, Any]:
        return dict(self.details)

    def call(self, operation: str, arguments: dict[str, Any] | None = None) -> Any:
        args = arguments or {}
        self.calls.append((operation, args))
        if operation == "list_models":
            return [{"provider_id": "grok_build", "model_id": "grok-4.5"}]
        if operation == "spawn_worker":
            return {"ready": True, "node_id": "worker-spawned"}
        if operation == "stop_worker":
            return {"stopped": True, "node_id": args.get("node_id")}
        if operation == "get_worker_status":
            return [{"node_id": "worker-1", "ready": True}]
        if operation == "assign_task":
            return {"delivered": True, "owners": args["task"]["owner_node_ids"]}
        if operation == "preflight_assignment":
            return {"admitted": list(args["worker_node_ids"])}
        if operation.startswith("notify_"):
            return {"delivered": True, "operation": operation}
        raise AssertionError(f"unexpected application-control operation: {operation}")


def _runtime(root: Path, app: FakeApplicationControl) -> SovereignToolRuntime:
    return SovereignToolRuntime(app, root, policy=SovereignPolicy())


def _call(runtime: SovereignToolRuntime, name: str, arguments: dict[str, Any]) -> dict[str, Any]:
    response = handle_request(runtime, {
        "jsonrpc": "2.0",
        "id": name,
        "method": "tools/call",
        "params": {"name": name, "arguments": arguments},
    })
    assert response is not None
    return response["result"]


def _ok(runtime: SovereignToolRuntime, called: set[str], name: str,
        arguments: dict[str, Any]) -> Any:
    payload = _call(runtime, name, arguments)
    assert payload["isError"] is False, payload["content"]
    assert "structuredContent" in payload
    called.add(name)
    return payload["structuredContent"]


def _candidate_args(task_id: str, evidence: str) -> dict[str, Any]:
    return {
        "task_id": task_id,
        "summary": "protocol candidate",
        "claims": ["the real handler completed"],
        "evidence_refs": [evidence],
        "peer_messages_considered": [],
        "debates_considered": [],
        "limitations": [],
    }


def test_every_declared_handler_executes_through_real_tools_call_protocol(tmp_path: Path) -> None:
    apps = {
        "cond": FakeApplicationControl("cond-1", "conductor", "openai", "codex"),
        "w1": FakeApplicationControl("worker-1", "worker", "grok_build", "grok-4.5"),
        "w2": FakeApplicationControl("worker-2", "worker", "google_antigravity", "gemini"),
    }
    runtimes = {name: _runtime(tmp_path, app) for name, app in apps.items()}
    called: set[str] = set()
    cond, w1, w2 = runtimes["cond"], runtimes["w1"], runtimes["w2"]
    try:
        assert _ok(cond, called, "list_models", {})[0]["provider_id"] == "grok_build"
        assert _ok(cond, called, "spawn_worker", {
            "provider": "grok_build", "role": "reasoning",
        })["ready"] is True
        assert _ok(cond, called, "stop_worker", {"node_id": "worker-spawned"})["stopped"] is True

        assigned = _ok(cond, called, "assign_task", {
            "objective": "exercise every real Sovereign handler",
            "worker_node_ids": ["worker-1", "worker-2"],
            "peer_nodes": ["worker-1", "worker-2"],
            "acceptance_criteria": ["publish both candidates", "publish synthesis"],
        })
        task = assigned["task"]
        task_id, thread_id = task["task_id"], task["thread_id"]
        assert assigned["delivery"]["delivered"] is True

        status = _ok(cond, called, "get_worker_status", {})
        assert status["nodes"][0]["ready"] is True
        assert status["tasks"][0]["task_id"] == task_id

        initial = _ok(w1, called, "read_messages", {"task_id": task_id})
        assert initial["count"] >= 1
        sent = _ok(w1, called, "send_message", {
            "task_id": task_id,
            "thread_id": thread_id,
            "recipient_node_ids": ["worker-2"],
            "message_kind": "question",
            "body": "Did the protocol reach your node?",
        })
        assert sent["notification"]["delivered"] is True
        assert any(message["message_id"] == sent["message"]["message_id"]
                   for message in _ok(w2, called, "read_messages", {"task_id": task_id})["messages"])

        progress = _ok(w1, called, "publish_progress", {
            "task_id": task_id,
            "status": "IN_PROGRESS",
            "working_on": "protocol boundary",
            "what_remains": "candidate",
        })
        assert progress["task"]["status"] == "IN_PROGRESS"

        debate = _ok(cond, called, "open_debate", {
            "task_id": task_id,
            "proposition": "both handlers are reachable",
            "participant_node_ids": ["worker-1", "worker-2"],
            "max_rounds": 1,
        })
        debate_id = debate["debate_id"]
        first_turn = _ok(w1, called, "post_debate_turn", {
            "debate_id": debate_id, "body": "worker one reached the real service",
        })
        _ok(w2, called, "post_debate_turn", {
            "debate_id": debate_id,
            "body": "worker two independently agrees",
            "reply_to": first_turn["turn_id"],
        })
        closed = _ok(cond, called, "close_debate", {
            "debate_id": debate_id,
            "decision": "both protocol paths completed",
            "agreements": ["both workers posted"],
            "disagreements": [],
            "unresolved_points": [],
            "closure_reason": "bounded acceptance complete",
        })
        assert closed["state"] == "CLOSED"

        abandoned = _ok(cond, called, "open_debate", {
            "task_id": task_id,
            "proposition": "aborted debate remains visible",
            "participant_node_ids": ["worker-1", "worker-2"],
            "max_rounds": 1,
        })
        aborted = _ok(cond, called, "abort_debate", {
            "debate_id": abandoned["debate_id"], "reason": "bounded test abort",
        })
        assert aborted["state"] == "ABORTED"

        artifact = _ok(w1, called, "publish_artifact", {
            "task_id": task_id, "content": "real protocol artifact", "media_type": "text/plain",
        })
        read_back = _ok(w2, called, "read_artifact", {"artifact_id": artifact["artifact_id"]})
        assert read_back["content"] == "real protocol artifact"

        first_candidate = _ok(w1, called, "publish_candidate",
                              _candidate_args(task_id, artifact["artifact_id"]))
        second_candidate = _ok(w2, called, "publish_candidate",
                               _candidate_args(task_id, artifact["artifact_id"]))
        assert first_candidate["candidate"]["worker_node_id"] == "worker-1"
        assert second_candidate["candidate"]["worker_node_id"] == "worker-2"

        synthesis = _ok(cond, called, "publish_synthesis", {
            "task_id": task_id,
            "contributions": [
                {"node_id": "worker-1", "contribution": "first protocol proof"},
                {"node_id": "worker-2", "contribution": "second protocol proof"},
            ],
            "points_of_agreement": ["all real handlers were invoked"],
            "points_of_disagreement": [],
            "debate_outcome": "the bounded debate closed",
            "evidence_used": [artifact["artifact_id"]],
            "limitations": ["Electron seam is a deterministic fake"],
            "conductor_judgment": "the JSON-RPC boundary and real persistence agree",
            "recommended_next_action": "retain this acceptance test",
            "debate_ids": [debate_id],
        })
        assert synthesis["synthesis"]["status"] == "SYNTHESIS"
        assert synthesis["synthesis"]["aborted_debate_ids"] == [abandoned["debate_id"]]

        declared = {tool["name"] for tool in TOOLS}
        assert called == declared
    finally:
        for runtime in runtimes.values():
            runtime.close()


def test_publish_role_gates_fail_at_protocol_boundary_before_cas_write(tmp_path: Path) -> None:
    cond = _runtime(tmp_path, FakeApplicationControl("cond", "conductor", "p", "m"))
    try:
        task = _ok(cond, set(), "assign_task", {
            "objective": "gate candidate and synthesis writes",
            "worker_node_ids": ["worker"],
            "peer_nodes": ["worker"],
        })["task"]
    finally:
        cond.close()

    cas = tmp_path / "cas"
    before = sorted(path.relative_to(cas) for path in cas.rglob("*") if path.is_file()) if cas.exists() else []

    conductor = _runtime(tmp_path, FakeApplicationControl("cond", "conductor", "p", "m"))
    worker = _runtime(tmp_path, FakeApplicationControl("worker", "worker", "p", "m"))
    try:
        candidate = _call(conductor, "publish_candidate", _candidate_args(task["task_id"], "e"))
        assert candidate["isError"] is True
        assert "only an assigned worker may publish a candidate" in candidate["content"][0]["text"]

        synthesis = _call(worker, "publish_synthesis", {
            "task_id": task["task_id"],
            "contributions": [{"node_id": "worker", "contribution": "complete"}],
            "points_of_agreement": ["complete"],
            "points_of_disagreement": [],
            "debate_outcome": "none",
            "evidence_used": ["e"],
            "limitations": [],
            "conductor_judgment": "complete",
            "recommended_next_action": "none",
            "debate_ids": [],
        })
        assert synthesis["isError"] is True
        assert "only conductor/operator may publish synthesis" in synthesis["content"][0]["text"]
    finally:
        conductor.close()
        worker.close()

    after = sorted(path.relative_to(cas) for path in cas.rglob("*") if path.is_file()) if cas.exists() else []
    assert after == before


def test_assignment_refusal_preflights_before_append_only_task_creation(tmp_path: Path) -> None:
    class RefusingApplication(FakeApplicationControl):
        def call(self, operation: str, arguments: dict[str, Any] | None = None) -> Any:
            if operation == "preflight_assignment":
                raise RuntimeError("worker stale before task creation")
            return super().call(operation, arguments)

    runtime = _runtime(tmp_path, RefusingApplication("cond", "conductor", "p", "m"))
    try:
        result = _call(runtime, "assign_task", {
            "objective": "must not create a blocked row",
            "worker_node_ids": ["worker"],
        })
        assert result["isError"] is True
        assert "worker stale before task creation" in result["content"][0]["text"]
        assert runtime.collaboration.list_tasks(runtime.identity) == []
    finally:
        runtime.close()
