"""The suite-wide no-live-provider guard, tested at the seam it exists to defend (U163).

Measured on 2026-07-30: `pytest tests/` spent real `claude` subscription calls, because the
adapter's spawn had moved from `subprocess.run` (which three tests patched) to
`run_managed_process` (which nothing patched). The tests kept passing; one of them — the case whose
whole purpose is proving a `live` leg is unreachable in a mock-first suite — reported `live`.

These checks fail if the guard is deleted, weakened, or routed around.
"""
from __future__ import annotations

import subprocess
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from adapters.frontier.claude_code import ClaudeCliBackend  # noqa: E402
from tests.live_call_guard import LiveProviderCallInTests  # noqa: E402


def test_the_real_adapter_cannot_spawn_the_provider_cli_from_a_test() -> None:
    """The path the three drifted tests took, through the adapter's own `generate`."""
    backend = ClaudeCliBackend()
    with pytest.raises(LiveProviderCallInTests) as caught:
        backend.generate("this must never reach the operator's subscription", max_tokens=1)
    assert "run_managed_process" in str(caught.value)


def test_a_direct_subprocess_call_to_a_provider_cli_is_refused_too() -> None:
    for cmd in (["claude", "hello"], ["codex", "exec", "hello"],
                [r"C:\Program Files\nodejs\claude.cmd", "-p", "hi"]):
        with pytest.raises(LiveProviderCallInTests):
            subprocess.run(cmd, capture_output=True)
        with pytest.raises(LiveProviderCallInTests):
            subprocess.Popen(cmd)


def test_a_credential_free_metadata_probe_is_allowed_through(tmp_path: Path) -> None:
    """U165. The guard exists so a pytest run never SPENDS a subscription call — and
    `codex --version` / `login status` / `exec --help` spend nothing: they are exactly how
    `.detect` proves the CLI is present, and refusing them by name alone turned nine honest
    host-probe tests red. The binary here is provider-NAMED and deliberately absent, so the
    FileNotFoundError proves the guard handed the spawn on rather than refusing it — while
    still reaching no real CLI.
    """
    fake = tmp_path / "codex.exe"
    for args in (["--version"], ["login", "status"], ["exec", "--help"], ["--help"]):
        with pytest.raises(FileNotFoundError):
            subprocess.run([str(fake), *args], capture_output=True)


def test_a_metadata_form_carrying_anything_else_is_still_refused(tmp_path: Path) -> None:
    """The allowance is by WHOLE argv, not by prefix: a prompt smuggled after a benign
    subcommand is a model call, and a bare invocation (which opens the interactive session)
    is refused as well. Fail closed on anything not enumerated."""
    fake = tmp_path / "codex.exe"
    for args in (["exec", "--help", "and now actually do this"], ["exec", "hi"],
                 ["--version", "hi"], ["login"], []):
        with pytest.raises(LiveProviderCallInTests):
            subprocess.run([str(fake), *args], capture_output=True)


def test_ordinary_spawns_are_untouched() -> None:
    """The guard discriminates by provider name; it is not a blanket ban on child processes —
    several suites prove real behaviour by running node/python/powershell."""
    done = subprocess.run([sys.executable, "-c", "print('ok')"], capture_output=True, text=True)
    assert done.returncode == 0 and done.stdout.strip() == "ok"


def test_the_managed_boundary_still_runs_a_non_provider_command() -> None:
    from adapters.frontier import process_tree

    done = process_tree.run_managed_process(
        [sys.executable, "-c", "print('managed')"], timeout=60.0, env=None,
        stdin=subprocess.DEVNULL)
    assert done.returncode == 0 and "managed" in done.stdout
