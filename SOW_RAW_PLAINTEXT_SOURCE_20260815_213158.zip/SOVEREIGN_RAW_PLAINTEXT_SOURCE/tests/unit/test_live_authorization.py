"""Phase 15A .liveauth: the enforced LIVE_OPERATION_AUTHORIZED gate, rewritten for the OP-6
two-provider live scope (directive §10.1/§11; register OP-6). Deterministic, fail-closed
permission logic — never model output.

The gate must EXIST and be enforced BEFORE any live path is wired ("enforcement-by-absence
ends the moment a live path exists"). These tests pin its fail-closed behaviour under the
OP-6 scope `{providers: [claude_code, openai_codex_cli], terminals_per_subscription: 2}`:
  - no config present               -> DENIED (enforcement-by-absence), not authorized
  - flag explicitly false           -> DENIED
  - malformed / bad version (1.0)   -> raise (never silently authorize)
  - wrong register row (not OP-6)   -> raise (only OP-6 authorizes the two-provider scope)
  - provider outside the OP-6 set   -> raise (a THIRD provider needs new authorization)
  - terminals_per_subscription > 2  -> raise (OP-6 cap); < 1 -> raise; True -> raise (bool guard)
  - valid OP-6 config               -> authorizes BOTH providers, terminals_per_subscription == 2
  - "codex" shorthand alias         -> normalized to the schema id openai_codex_cli
and the profile-loader enforcement: a REAL subscription-backed frontier adapter cannot pass
startup unless live operation is authorized for its provider.
"""
from __future__ import annotations

import json
from pathlib import Path

import pytest

from adapters.base.contract import AdapterCapability
from control_plane.profiles.live_authorization import (
    LiveAuthorization,
    LiveAuthorizationError,
    load_live_authorization,
)
from control_plane.profiles.loader import DeploymentProfile, ProfileLoader, ProfileViolation


def _write(tmp_path: Path, obj: object) -> Path:
    p = tmp_path / "live_operation.json"
    p.write_text(json.dumps(obj), encoding="utf-8")
    return p


# canonical OP-6 config: both providers, 2 terminals/subscription, cites OP-6
_VALID = {
    "config_version": "1.1",
    "live_operation_authorized": True,
    "register_row": "OP-6",
    "scope": {"providers": ["claude_code", "openai_codex_cli"], "terminals_per_subscription": 2},
}


# ---- enforcement-by-absence: the safe default ----------------------------------------

def test_absent_config_is_denied_not_authorized(tmp_path: Path) -> None:
    auth = load_live_authorization(path=tmp_path / "does_not_exist.json")
    assert auth.authorized is False
    assert auth.providers == frozenset()
    assert "absence" in auth.reason.lower()


def test_denied_default_gate_refuses_every_provider(tmp_path: Path) -> None:
    auth = load_live_authorization(path=tmp_path / "nope.json")
    assert auth.is_provider_live("claude_code") is False
    assert auth.is_provider_live("openai_codex_cli") is False
    with pytest.raises(LiveAuthorizationError):
        auth.assert_provider_live("claude_code")
    with pytest.raises(LiveAuthorizationError):
        auth.assert_provider_live("openai_codex_cli")


def test_flag_explicitly_false_is_denied(tmp_path: Path) -> None:
    p = _write(tmp_path, {**_VALID, "live_operation_authorized": False})
    auth = load_live_authorization(path=p)
    assert auth.authorized is False
    with pytest.raises(LiveAuthorizationError):
        auth.assert_provider_live("claude_code")


# ---- malformed / out-of-scope: fail closed by RAISING (never authorize) --------------

def test_malformed_json_raises(tmp_path: Path) -> None:
    p = tmp_path / "live_operation.json"
    p.write_text("{ not json", encoding="utf-8")
    with pytest.raises(LiveAuthorizationError):
        load_live_authorization(path=p)


def test_old_1_0_config_version_raises(tmp_path: Path) -> None:
    # the OP-4 single-provider shape is superseded; a 1.0 config fails closed, never authorizes
    p = _write(tmp_path, {"config_version": "1.0", "live_operation_authorized": True,
                          "register_row": "OP-4", "scope": {"provider": "claude_code", "terminals": 1}})
    with pytest.raises(LiveAuthorizationError):
        load_live_authorization(path=p)


def test_bad_config_version_raises(tmp_path: Path) -> None:
    p = _write(tmp_path, {**_VALID, "config_version": "9.9"})
    with pytest.raises(LiveAuthorizationError):
        load_live_authorization(path=p)


def test_non_bool_flag_raises(tmp_path: Path) -> None:
    p = _write(tmp_path, {**_VALID, "live_operation_authorized": "yes"})
    with pytest.raises(LiveAuthorizationError):
        load_live_authorization(path=p)


def test_wrong_register_row_raises(tmp_path: Path) -> None:
    # an authorization not backed by the recorded operator ruling is refused; OP-4 no longer
    # authorizes the two-provider scope (only OP-6 does)
    for row in ("OP-4", "OP-9", None):
        p = _write(tmp_path, {**_VALID, "register_row": row})
        with pytest.raises(LiveAuthorizationError):
            load_live_authorization(path=p)


def test_third_provider_is_refused(tmp_path: Path) -> None:
    # OP-6 authorizes exactly two providers; a third needs a NEW operator authorization
    p = _write(tmp_path, {**_VALID,
               "scope": {"providers": ["claude_code", "openai_codex_cli", "gemini_cli"],
                         "terminals_per_subscription": 2}})
    with pytest.raises(LiveAuthorizationError):
        load_live_authorization(path=p)


def test_unknown_provider_alone_is_refused(tmp_path: Path) -> None:
    p = _write(tmp_path, {**_VALID,
               "scope": {"providers": ["some_future_frontier"], "terminals_per_subscription": 1}})
    with pytest.raises(LiveAuthorizationError):
        load_live_authorization(path=p)


def test_empty_providers_list_is_refused(tmp_path: Path) -> None:
    p = _write(tmp_path, {**_VALID, "scope": {"providers": [], "terminals_per_subscription": 2}})
    with pytest.raises(LiveAuthorizationError):
        load_live_authorization(path=p)


def test_non_string_provider_is_refused(tmp_path: Path) -> None:
    p = _write(tmp_path, {**_VALID,
               "scope": {"providers": ["claude_code", 7], "terminals_per_subscription": 2}})
    with pytest.raises(LiveAuthorizationError):
        load_live_authorization(path=p)


def test_more_than_two_terminals_is_refused(tmp_path: Path) -> None:
    # OP-6 cap: at most 2 terminals/subscription; a config can NARROW but never widen past 2
    p = _write(tmp_path, {**_VALID,
               "scope": {"providers": ["claude_code", "openai_codex_cli"], "terminals_per_subscription": 3}})
    with pytest.raises(LiveAuthorizationError):
        load_live_authorization(path=p)


def test_zero_terminals_is_refused(tmp_path: Path) -> None:
    p = _write(tmp_path, {**_VALID,
               "scope": {"providers": ["claude_code"], "terminals_per_subscription": 0}})
    with pytest.raises(LiveAuthorizationError):
        load_live_authorization(path=p)


def test_bool_terminals_cannot_masquerade_as_one(tmp_path: Path) -> None:
    # True == 1 in Python; the isinstance-bool guard must reject it (fail closed)
    p = _write(tmp_path, {**_VALID,
               "scope": {"providers": ["claude_code"], "terminals_per_subscription": True}})
    with pytest.raises(LiveAuthorizationError):
        load_live_authorization(path=p)


@pytest.mark.parametrize("missing", ["register_row", "scope", "live_operation_authorized"])
def test_missing_required_field_raises(tmp_path: Path, missing: str) -> None:
    obj = {k: v for k, v in _VALID.items() if k != missing}
    p = _write(tmp_path, obj)
    with pytest.raises(LiveAuthorizationError):
        load_live_authorization(path=p)


# ---- valid authorization: scoped to the two OP-6 providers, up to 2 terminals --------

def test_valid_config_authorizes_both_op6_providers(tmp_path: Path) -> None:
    p = _write(tmp_path, _VALID)
    auth = load_live_authorization(path=p)
    assert auth.authorized is True
    assert auth.providers == frozenset({"claude_code", "openai_codex_cli"})
    assert auth.terminals_per_subscription == 2
    assert auth.register_row == "OP-6"
    assert auth.is_provider_live("claude_code") is True
    assert auth.is_provider_live("openai_codex_cli") is True
    auth.assert_provider_live("claude_code")       # does not raise
    auth.assert_provider_live("openai_codex_cli")  # does not raise
    # scope holds: a provider OUTSIDE the OP-6 set is still refused even when live is authorized
    assert auth.is_provider_live("gemini_cli") is False
    with pytest.raises(LiveAuthorizationError):
        auth.assert_provider_live("gemini_cli")


def test_codex_shorthand_alias_normalizes_to_schema_id(tmp_path: Path) -> None:
    # the operator/directive shorthand "codex" maps to the frozen schema id openai_codex_cli
    p = _write(tmp_path, {**_VALID, "scope": {"providers": ["codex"], "terminals_per_subscription": 1}})
    auth = load_live_authorization(path=p)
    assert auth.providers == frozenset({"openai_codex_cli"})
    assert auth.is_provider_live("codex") is True
    assert auth.is_provider_live("openai_codex_cli") is True
    assert auth.terminals_per_subscription == 1  # a narrower config is honoured


def test_config_may_narrow_to_one_provider(tmp_path: Path) -> None:
    # authorizing fewer than the full OP-6 set is a narrowing (safe), not a widening
    p = _write(tmp_path, {**_VALID,
               "scope": {"providers": ["claude_code"], "terminals_per_subscription": 2}})
    auth = load_live_authorization(path=p)
    assert auth.providers == frozenset({"claude_code"})
    assert auth.is_provider_live("openai_codex_cli") is False


def test_env_override_path_is_read(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    p = _write(tmp_path, _VALID)
    monkeypatch.setenv("SOVEREIGN_LIVE_OPERATION_CONFIG", str(p))
    auth = load_live_authorization()  # no explicit path -> env override wins
    assert auth.authorized and auth.is_provider_live("claude_code")


# ---- profile-loader enforcement: a real live frontier cap needs authorization --------

def _live_frontier(adapter: str) -> AdapterCapability:
    return AdapterCapability(
        adapter=adapter, node_class="worker_reasoning", locality="frontier",
        offline_profile_eligible=False, requires_network=True, local_runtime=False,
        capabilities=("reasoning",), subscription_backed=True)


_LIVE_CLAUDE = _live_frontier("claude_code")
_LIVE_CODEX = _live_frontier("openai_codex_cli")
_MOCK_FRONTIER = AdapterCapability(
    adapter="mock", node_class="worker_reasoning", locality="frontier",
    offline_profile_eligible=False, requires_network=True, local_runtime=False,
    capabilities=("reasoning",), subscription_backed=True)


def test_startup_refuses_live_frontier_without_authorization() -> None:
    loader = ProfileLoader(DeploymentProfile("cloud"))
    denied = LiveAuthorization.denied("test: no config")
    with pytest.raises(ProfileViolation):
        loader.assert_startup([_LIVE_CLAUDE], live_auth=denied)


def test_startup_refuses_live_frontier_when_live_auth_omitted() -> None:
    loader = ProfileLoader(DeploymentProfile("cloud"))
    with pytest.raises(ProfileViolation):
        loader.assert_startup([_LIVE_CLAUDE])


def test_startup_permits_both_op6_frontiers_with_authorization(tmp_path: Path) -> None:
    loader = ProfileLoader(DeploymentProfile("cloud"))
    auth = load_live_authorization(path=_write(tmp_path, _VALID))
    loader.assert_startup([_LIVE_CLAUDE, _LIVE_CODEX], live_auth=auth)  # does not raise


def test_startup_allows_mock_frontier_without_authorization() -> None:
    loader = ProfileLoader(DeploymentProfile("cloud"))
    loader.assert_startup([_MOCK_FRONTIER])  # does not raise
    loader.assert_startup([_MOCK_FRONTIER], live_auth=LiveAuthorization.denied("x"))


def test_startup_refuses_unknown_future_frontier_provider(tmp_path: Path) -> None:
    """Fail-closed DENYLIST, not an allowlist: a subscription-backed adapter that is NOT the
    reserved mock sentinel — e.g. a provider added to the enum later — requires authorization
    and is refused when the (OP-6) authorization does not cover it."""
    future = _live_frontier("gemini_cli")
    loader = ProfileLoader(DeploymentProfile("cloud"))
    auth = load_live_authorization(path=_write(tmp_path, _VALID))
    with pytest.raises(ProfileViolation):
        loader.assert_startup([future], live_auth=auth)
    with pytest.raises(ProfileViolation):
        loader.assert_startup([future])
