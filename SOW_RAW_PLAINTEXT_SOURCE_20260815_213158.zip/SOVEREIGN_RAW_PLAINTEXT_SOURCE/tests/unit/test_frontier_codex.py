"""Phase 15C .adapter (unit): the live `openai_codex_cli` frontier backend + governed spawn gates.

Deterministic, no-subprocess proofs. The load-bearing invariants are (§2.2) — the real backend
must build a command and a child env carrying NO provider secret and no auth-passing/sandbox-bypass
flag, and cannot fall back to an API-key path — and (T2) — the sandbox is explicit and never
`danger-full-access`. `generate()` on the real backend is never called here (it would spawn
`codex`); only its pure command/env builders are tested.
"""
from __future__ import annotations

import os

import pytest

from adapters.base.backend import BackendAuthPause
from adapters.base.contract import AdapterContext, NakedLaunchRefused
from adapters.frontier.codex import (
    CODEX_ADAPTER,
    CODEX_CODING_NODE_CLASS,
    CODEX_REASONING_NODE_CLASS,
    SANDBOX_READ_ONLY,
    SANDBOX_WORKSPACE_WRITE,
    CodexAuthError,
    CodexCliBackend,
    MockCodexCliBackend,
    build_codex_adapter,
    codex_roster_descriptor,
    resolve_codex_model_ref,
)
from control_plane.profiles.live_authorization import LiveAuthorization
from control_plane.profiles.loader import DeploymentProfile, ProfileLoader, ProfileViolation
from node_runtime.supervisor.codex_spawn import (
    LiveTermsNotConfirmed,
    attempt_codex_live_smoke,
    capability_for_codex,
    spawn_codex_terminal,
)
from node_runtime.supervisor.subscription_governor import SubscriptionGovernor


def _supervised_ctx(node_id: str = "n1") -> AdapterContext:
    return AdapterContext(node_id=node_id, role="worker", project_id="proj",
                          permission_profile_id="pp", mcp_credential_id="ref",
                          subscription_ref="codex-sub", spawned_by_supervisor=True)


# ---- capability shape: a REAL live frontier the profile/live gate recognises --------------

def test_capability_is_live_codex_frontier() -> None:
    cap = capability_for_codex("reasoning")
    assert cap.adapter == "openai_codex_cli" and cap.adapter == CODEX_ADAPTER
    assert cap.subscription_backed is True and cap.locality == "frontier"
    assert cap.requires_network is True and cap.offline_profile_eligible is False
    assert cap.node_class == CODEX_REASONING_NODE_CLASS
    # the descriptor names openai_codex_cli, not the reserved "mock" sentinel -> a real live path
    loader = ProfileLoader(DeploymentProfile("cloud"))
    with pytest.raises(ProfileViolation):  # no authorization -> refused (fail closed)
        loader.assert_startup([cap], live_auth=LiveAuthorization.denied("unit"))


def test_coding_role_maps_to_coding_specialist_node_class() -> None:
    cap = capability_for_codex("coding")
    assert cap.node_class == CODEX_CODING_NODE_CLASS
    assert "coding" in cap.capabilities


def test_adapter_holds_no_credential_and_refuses_naked_launch() -> None:
    adapter = build_codex_adapter(_supervised_ctx(), mcp_client=object(),
                                  backend=MockCodexCliBackend(), role="reasoning")
    assert adapter.holds_provider_credential() is False
    assert adapter.capability().adapter == "openai_codex_cli"
    naked = AdapterContext(node_id="n", role="worker", project_id="proj",
                           permission_profile_id="pp", mcp_credential_id="ref",
                           spawned_by_supervisor=False)  # not supervisor-issued
    with pytest.raises(NakedLaunchRefused):
        build_codex_adapter(naked, mcp_client=object(), backend=MockCodexCliBackend())


# ---- mock backend: deterministic, spawns nothing ------------------------------------------

def test_mock_backend_is_deterministic() -> None:
    b = MockCodexCliBackend()
    a1 = b.generate("hello world")
    a2 = b.generate("hello world")
    assert a1 == a2 and b.calls == 2
    assert b.generate("different") != a1


# ---- CREDENTIAL INVARIANT (§2.2): the real backend transmits no secret --------------------

def test_real_backend_command_carries_no_credential_or_bypass() -> None:
    cmd = CodexCliBackend(executable="codex", model="5.5").build_command("summarise this")
    assert cmd[0] == "codex" and "exec" in cmd and "-m" in cmd and "5.5" in cmd
    assert "--sandbox" in cmd and SANDBOX_READ_ONLY in cmd  # reasoning role default
    joined = " ".join(cmd).lower()
    for forbidden in ("--with-api-key", "--with-access-token", "--api-key", "api_key", "token",
                      "--dangerously-bypass-approvals-and-sandbox",
                      "--dangerously-bypass-hook-trust", "danger-full-access", "--full-auto"):
        assert forbidden not in joined, forbidden


def test_coding_role_command_is_workspace_write_and_worktree_scoped() -> None:
    cmd = CodexCliBackend(executable="codex", model="5.5", role="coding",
                          workdir="/work/wt").build_command("edit the file")
    assert "--sandbox" in cmd and SANDBOX_WORKSPACE_WRITE in cmd
    assert "--cd" in cmd and "/work/wt" in cmd  # worktree isolation for the coding role (T2)
    assert "danger-full-access" not in " ".join(cmd)


def test_default_model_omits_model_flag() -> None:
    """No requested model -> no `-m` (CLI default, recorded roster fallback), never a fabricated slug."""
    cmd = CodexCliBackend(executable="codex").build_command("hello")
    assert "-m" not in cmd
    slug, note = resolve_codex_model_ref(None)
    assert slug is None and "fallback" in note.lower()
    slug2, note2 = resolve_codex_model_ref("5.5 Sol")
    assert slug2 == "5.5 Sol" and "unverified" in note2.lower()


def test_danger_full_access_sandbox_refused() -> None:
    with pytest.raises(ValueError):
        CodexCliBackend(executable="codex", sandbox_mode="danger-full-access")


def test_coding_role_without_worktree_refused_fail_closed() -> None:
    """T2 / Phase 10: a coding (workspace-write) backend with no isolated worktree is refused at
    construction — write access is NEVER granted unscoped (it would run at cwd=None = the
    supervisor's dir). A reasoning read-only backend needs no worktree."""
    with pytest.raises(ValueError):
        CodexCliBackend(executable="codex", role="coding")  # workspace-write, no --cd scope
    with pytest.raises(ValueError):  # same refusal if a read-only role is forced to write with no scope
        CodexCliBackend(executable="codex", role="reasoning", sandbox_mode=SANDBOX_WORKSPACE_WRITE)
    # a properly worktree-scoped coding backend is accepted and carries --cd
    cmd = CodexCliBackend(executable="codex", role="coding", workdir="/work/wt").build_command("edit")
    assert "--cd" in cmd and "/work/wt" in cmd and SANDBOX_WORKSPACE_WRITE in cmd
    CodexCliBackend(executable="codex", role="reasoning")  # read-only, no worktree needed: fine


def test_real_backend_env_scrubs_all_credential_and_endpoint_vars() -> None:
    """Even if the host env holds keys/tokens/endpoint overrides, the child env must NOT — the
    subscription OAuth store (host-native `~/.codex/auth.json`, not env) is the only auth path left
    (§2.2). CODEX_HOME (the config/auth dir pointer, not a secret) is preserved."""
    base = {
        "PATH": os.environ.get("PATH", ""), "HOME": "/home/x", "HTTP_PROXY": "http://p:8080",
        "LANG": "en_US.UTF-8", "TEMP": "/tmp", "CODEX_HOME": "/home/x/.codex",  # kept: not a secret
        "OPENAI_API_KEY": "sk-strip", "OPENAI_BASE_URL": "https://evil",
        "OPENAI_ORG_ID": "org-strip", "CODEX_API_KEY": "codex-strip",
        "AZURE_OPENAI_API_KEY": "az-strip", "AZURE_OPENAI_ENDPOINT": "https://evil2",
        "AWS_SECRET_ACCESS_KEY": "aws-secret", "ANTHROPIC_API_KEY": "ant-strip",
        "GOOGLE_APPLICATION_CREDENTIALS": "/g.json",
        "SOME_FUTURE_API_KEY": "future-strip", "VENDOR_SECRET": "vsecret",  # substring rule
        "MY_ACCESS_TOKEN": "tok-strip", "APP_CREDENTIAL": "cred-strip", "RANDOM_KEY": "key-strip",
    }
    env = CodexCliBackend(executable="codex").build_env(base)
    for stripped in ("OPENAI_API_KEY", "OPENAI_BASE_URL", "OPENAI_ORG_ID", "CODEX_API_KEY",
                     "AZURE_OPENAI_API_KEY", "AZURE_OPENAI_ENDPOINT", "AWS_SECRET_ACCESS_KEY",
                     "ANTHROPIC_API_KEY", "GOOGLE_APPLICATION_CREDENTIALS", "SOME_FUTURE_API_KEY",
                     "VENDOR_SECRET", "MY_ACCESS_TOKEN", "APP_CREDENTIAL", "RANDOM_KEY"):
        assert stripped not in env, stripped
    for kept in ("PATH", "HOME", "HTTP_PROXY", "LANG", "TEMP", "CODEX_HOME"):
        assert kept in env, kept
    # no secret VALUE survives anywhere in the child env
    joined = "".join(env.values())
    for secret in ("sk-strip", "org-strip", "codex-strip", "az-strip", "aws-secret", "ant-strip",
                   "future-strip", "vsecret", "tok-strip", "cred-strip", "key-strip", "evil"):
        assert secret not in joined, secret


def test_auth_markers_classify_as_auth_error() -> None:
    b = CodexCliBackend(executable="codex")
    assert b._classify("Error: Please run `codex login` to authenticate") is True
    assert b._classify("HTTP 401 Unauthorized") is True
    assert b._classify("You have hit your usage limit for this month") is True
    assert b._classify("insufficient_quota: add credits") is True
    # specific-enough markers: an ordinary result mentioning a word is NOT auth
    assert b._classify("some ordinary model text about compare-and-swap keys in a b-tree") is False


def test_codex_auth_error_is_a_backend_auth_pause() -> None:
    assert issubclass(CodexAuthError, BackendAuthPause)


# ---- spawn gate: R8 operator-terms confirmation is enforced at the real entrypoint --------

def test_spawn_refuses_when_operator_terms_unconfirmed(tmp_path) -> None:
    """Even with a valid live authorization, an unconfirmed R8 §6 [OPERATOR] terms item blocks the
    live spawn (fail closed) — and does not leak a subscription terminal."""
    import json
    from control_plane.profiles.live_authorization import load_live_authorization
    cfg = tmp_path / "live_operation.json"
    cfg.write_text(json.dumps({"config_version": "1.1", "live_operation_authorized": True,
                               "register_row": "OP-6",
                               "scope": {"providers": ["claude_code", "openai_codex_cli"],
                                         "terminals_per_subscription": 2}}), encoding="utf-8")
    auth = load_live_authorization(path=cfg)
    gov = SubscriptionGovernor()
    with pytest.raises(LiveTermsNotConfirmed):
        spawn_codex_terminal(
            mcp_client=object(), governor=gov, subscription_ref="codex-sub", node_id="n1",
            permission_profile_id="pp", live_auth=auth,
            profile_loader=ProfileLoader(DeploymentProfile("cloud")),
            operator_terms_confirmed=False, backend=MockCodexCliBackend())
    assert gov.active_count("codex-sub") == 0  # no terminal acquired on the refused path


# ---- NIT-2 (15C .gate): the recorded model-ref fallback is SURFACED in a roster descriptor ---

def test_roster_descriptor_surfaces_cli_default_fallback() -> None:
    """No requested model ⇒ the descriptor records the CLI-default fallback explicitly (directive
    §11 15C, "never silent"): resolved_slug None, is_fallback True, verified False, note recorded."""
    d = codex_roster_descriptor("reasoning", None)
    assert d["adapter"] == CODEX_ADAPTER and d["node_class"] == CODEX_REASONING_NODE_CLASS
    assert d["locality"] == "frontier" and d["subscription_backed"] is True
    assert d["capability_descriptors"] and all("capability" in c for c in d["capability_descriptors"])
    mr = d["model_ref"]
    assert mr["requested"] is None and mr["resolved_slug"] is None
    assert mr["is_fallback"] is True and mr["verified"] is False
    assert "fallback" in mr["note"].lower()
    # the resolver is the single source of the slug/note the descriptor surfaces
    slug, note = resolve_codex_model_ref(None)
    assert mr["resolved_slug"] == slug and mr["note"] == note


def test_roster_descriptor_surfaces_requested_slug_unverified() -> None:
    """A requested operator label is carried verbatim, marked NOT a fallback and NOT yet verified
    (accepted-id only confirmed by a live smoke) — no fabricated CLI slug."""
    d = codex_roster_descriptor("coding", "5.5 Sol")
    assert d["node_class"] == CODEX_CODING_NODE_CLASS
    mr = d["model_ref"]
    assert mr["requested"] == "5.5 Sol" and mr["resolved_slug"] == "5.5 Sol"
    assert mr["is_fallback"] is False and mr["verified"] is False
    assert "unverified" in mr["note"].lower()


def test_roster_descriptor_unknown_role_refused() -> None:
    with pytest.raises(ValueError):
        codex_roster_descriptor("overseer", None)


def test_roster_descriptor_capabilities_are_independent_copies() -> None:
    """Mutating a returned descriptor's nested requirements must not write back into the shared
    module-level constants (immutability hygiene)."""
    d1 = codex_roster_descriptor("reasoning", None)
    d1["capability_descriptors"][0]["requirements"]["min_context"] = 1
    d2 = codex_roster_descriptor("reasoning", None)
    assert d2["capability_descriptors"][0]["requirements"]["min_context"] != 1


def test_live_smoke_outcome_surfaces_model_resolution_even_on_skip(tmp_path) -> None:
    """A skip-with-record outcome (unconfirmed operator terms) STILL surfaces the model resolution,
    so which model / CLI-default fallback would have run is never silent (directive §11 15C)."""
    import json
    from control_plane.profiles.live_authorization import load_live_authorization
    cfg = tmp_path / "live_operation.json"
    cfg.write_text(json.dumps({"config_version": "1.1", "live_operation_authorized": True,
                               "register_row": "OP-6",
                               "scope": {"providers": ["claude_code", "openai_codex_cli"],
                                         "terminals_per_subscription": 2}}), encoding="utf-8")
    auth = load_live_authorization(path=cfg)
    gov = SubscriptionGovernor()
    outcome = attempt_codex_live_smoke(
        objective_entry_id="e1", task_id="t1", mcp_client=object(), governor=gov,
        subscription_ref="codex-sub", node_id="n1", permission_profile_id="pp", live_auth=auth,
        profile_loader=ProfileLoader(DeploymentProfile("cloud")),
        operator_terms_confirmed=False, model=None, backend=MockCodexCliBackend())
    assert outcome.ran is False and outcome.skipped_with_record is True  # no live call
    assert outcome.model_resolution is not None                          # never silent
    assert outcome.model_resolution["model_ref"]["is_fallback"] is True
    assert gov.active_count("codex-sub") == 0                            # no leaked terminal


def test_generate_never_inherits_the_parent_stdin(monkeypatch) -> None:
    """Parity with `ClaudeCliBackend` (validator R6 — the claude fix shipped tested, this one did
    not, and an untested parity change is the kind that silently reverts).

    A CLI that reads piped stdin blocks forever on a supervisor's never-EOF stdin; the prompt
    travels in argv, so handing the child a closed stdin loses nothing.
    """
    import subprocess

    from adapters.frontier import codex as mod

    seen: dict[str, object] = {}

    def _fake_run(cmd, **kwargs):
        seen.update(kwargs)
        return subprocess.CompletedProcess(cmd, 0, stdout="codex-cli 1.0.0", stderr="")

    monkeypatch.setattr(mod.subprocess, "run", _fake_run)

    # (a) the PROBE transport (`CodexCli._run`) - version/auth checks
    probe = mod.CodexCli()
    probe.executable = "codex"            # it refuses before spawning when unset
    probe._run(["--version"])             # noqa: SLF001 - the shared transport for every probe
    assert seen.get("stdin") is subprocess.DEVNULL, (
        "the codex probe inherited the parent stdin and can block forever waiting on it")

    # (b) the LIVE call path (`CodexCliBackend.generate`)
    seen.clear()
    backend = CodexCliBackend()
    backend.executable = "codex"
    try:
        backend.generate("hello")
    except Exception:                     # the fake stdout is not the CLI's real envelope
        pass
    assert seen.get("stdin") is subprocess.DEVNULL, (
        "the codex live call inherited the parent stdin and can block forever waiting on it")
