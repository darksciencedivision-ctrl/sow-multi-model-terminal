"""Task-scoped operational collaboration over Sovereign's existing durable store.

Same contract as `memory_service.py`, and for the same reason: **every ROLE OR SCOPE decision
is asked of `control_plane.policy` (I-M2 delegation, invariant 7 — MCP is access, not
authority).** This module makes no role or scope decision of its own: it validates shapes,
enforces lifecycle legality, persists, and raises whatever reason the policy hands back. The
rules about *who* live one package over, where the operator can change them once for this package.
(Not once for the product: `apps/desktop/main.js` holds a fourth, DIVERGENT copy for the Electron
control surface — stricter in one place, ungated in another — U345, which no Phase-19 unit owns.)

Until Phase 19 unit 2 that was not true here. The policy was accepted in the constructor and
never read, while fifteen role/scope decisions were made inline (cold audit finding B1 named
twelve of them; U326) — a second copy of the authority, free to diverge from the one memory
operations obey.

Phase 19 unit 5 changed HOW those writes reach the store, not who may make them (U330). Every
writer that reads a record and writes a successor now computes that successor inside the store's
`BEGIN IMMEDIATE` boundary, from the row read there, through `mutate_operational_task` /
`mutate_operational_debate`; the two creators use `create_operational_*`, which refuse to
overwrite. Five of the seven used to build a successor from a Python-side snapshot and blind-write
it back, so two live workers posting to one debate lost a turn with no error and no conflict
record. The rules that depend on record CONTENT — the bounded-round ceiling, the close quorum —
moved inside the fence with the write they guard, and each asks the policy again on the row it
actually acts on.

One consequence, stated because the mutation harness measured it rather than assumed it: the
`state != "OPEN"` checks that remain BEFORE each debate transaction are early guards, not the
guarantee. Deleting one changes no observable refusal — the in-fence check raises the same
sentence — so they are graded by nothing on their own. They are kept for message ORDER (a caller
sending a malformed decision to a closed debate still hears "debate is not open" first, as it
always did) and because refusing before opening a write transaction is cheaper. The load-bearing
copy is the one inside the mutator, and the racing tests in
`tests/unit/test_operational_write_path.py` §2 are what hold it there.

What is deliberately still here, because it is legality rather than authority — the same split
`memory_service.py` has always had with `mcp_server/lifecycle.py`: the bounded-debate round
limit and budget range, the "a debate may not close without a turn from every participant"
quorum, the "synthesis requires candidates from every worker" completeness rule, the
`debate is not open` state gate, the referential checks that a candidate names only messages
and debates that exist, and the CANDIDATE-status check. They are recorded as U344 so the
boundary is argued in the open rather than assumed; none of them asks who the caller is. The
CANDIDATE-status check is the closest call and U344 says so: it is the SHAPE half of a rule
whose *who* half lives at `control_plane/policy.py:authorize_publish` ("workers may publish
only CANDIDATE entries"), so it can drift from its twin even though it never reads a caller.
"""
from __future__ import annotations

import secrets
from datetime import datetime, timezone
from typing import Any

from control_plane.policy import Identity, SovereignPolicy, Verdict
from persistence import SovereignStore


TASK_STATES = (
    "CREATED", "ASSIGNED", "ACCEPTED", "IN_PROGRESS", "WAITING_FOR_PEER", "BLOCKED",
    "CANDIDATE_READY", "UNDER_REVIEW", "COMPLETED", "FAILED", "CANCELLED",
)
MESSAGE_KINDS = (
    "assignment", "question", "answer", "progress", "blocker", "challenge", "debate_turn",
    "decision", "artifact_notice", "completion",
)
#: A debate is OPEN until it reaches one of two terminal states: CLOSED (a decision was reached
#: with a turn from every participant) or ABORTED (U416 — it can no longer reach one, because a
#: participant cannot answer). The distinction is load-bearing downstream: only CLOSED counts as
#: a considered deliberation in the synthesis gate ON THE `sovereign_tools` TOOL PATH
#: (`SovereignToolRuntime._considered_debates`) — `record_synthesis` below performs no debate check
#: of its own (U410), so the defence is as wide as that single caller. This is the FOURTH site of
#: the same unqualified sentence; the 19.6 repair enumerated three and this one is 250 lines above
#: it in this file (spec-auditor MEDIUM-5). Deliberately NOT exported as a constant: an
#: exported tuple nothing consults is drift waiting to happen (round-1 gate-validator MINOR-1 —
#: unlike MESSAGE_KINDS/TASK_STATES, which are validated against on every write, it would have
#: been decorative). The states are pinned by the tests that exercise each transition.


class CollaborationError(ValueError):
    pass


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _new(prefix: str) -> str:
    return f"{prefix}-{secrets.token_hex(8)}"


def _strings(value: Any, field: str, *, nonempty: bool = True) -> list[str]:
    if not isinstance(value, list) or not all(isinstance(v, str) and v.strip() for v in value):
        raise CollaborationError(f"{field} must be a list of non-empty strings")
    out = list(dict.fromkeys(v.strip() for v in value))
    if nonempty and not out:
        raise CollaborationError(f"{field} must not be empty")
    return out


class CollaborationService:
    def __init__(self, store: SovereignStore, policy: SovereignPolicy) -> None:
        self._store = store
        self._policy = policy

    @staticmethod
    def _require(verdict: Verdict) -> None:
        """The only place this module turns an authority verdict into a refusal. It never
        computes one."""
        if not verdict.allow:
            raise CollaborationError(verdict.reason)

    def create_task(self, identity: Identity, *, objective: str, owner_node_ids: list[str],
                    scope: dict[str, Any] | None = None, constraints: list[str] | None = None,
                    expected_output: str | None = None, acceptance_criteria: list[str] | None = None,
                    peer_nodes: list[str] | None = None, task_id: str | None = None,
                    thread_id: str | None = None) -> dict[str, Any]:
        self._require(self._policy.authorize_task_create(identity))
        if not isinstance(objective, str) or not objective.strip():
            raise CollaborationError("objective must be non-empty")
        owners = _strings(owner_node_ids, "owner_node_ids")
        now = _now()
        tid = (task_id or _new("t")).strip()
        thread = (thread_id or _new("thread")).strip()
        task = {
            "task_id": tid, "thread_id": thread, "project_id": identity.project_id,
            "objective": objective.strip(), "scope": scope or {},
            "constraints": list(constraints or []), "expected_output": expected_output or "candidate result",
            "acceptance_criteria": list(acceptance_criteria or []),
            "peer_nodes": list(peer_nodes or owners), "owner_node_ids": owners,
            "status": "ASSIGNED", "created_by_node_id": identity.node_id,
            "created_at": now, "updated_at": now,
        }
        self._store.create_operational_task(task)
        self.send_message(
            identity, task_id=tid, thread_id=thread, recipient_node_ids=owners,
            message_kind="assignment", body=objective.strip(), evidence_refs=[], artifact_refs=[],
        )
        return task

    def update_task(self, identity: Identity, *, task_id: str, status: str,
                    progress: dict[str, Any] | None = None) -> dict[str, Any]:
        if status not in TASK_STATES:
            raise CollaborationError(f"unknown task status {status!r}")
        if progress is not None and not isinstance(progress, dict):
            raise CollaborationError("progress must be an object")
        task = self._require_task(identity, task_id)
        self._require(self._policy.authorize_task_update(identity, task))

        def apply(current: dict[str, Any]) -> dict[str, Any]:
            # The successor is built from `current` — the row read inside the fence — not from
            # the snapshot above (U330). `{**task, "status": ...}` was how a status update erased
            # a candidate a worker had just published through `mutate_operational_task`.
            # The authority is asked AGAIN on that row: the record a verdict was computed against
            # may be one commit old by the time the transaction opens, and this module's rule is
            # that it asks rather than assumes (invariant 7).
            self._require(self._policy.authorize_task_update(identity, current))
            updated = {**current, "status": status, "updated_at": _now()}
            if progress is not None:
                updated["latest_progress"] = {**progress, "node_id": identity.node_id, "at": _now()}
            return updated

        return self._store.mutate_operational_task(identity.project_id, task_id, apply)

    def get_task(self, identity: Identity, task_id: str) -> dict[str, Any]:
        return self._require_task(identity, task_id)

    def list_tasks(self, identity: Identity) -> list[dict[str, Any]]:
        tasks = self._store.list_operational_tasks(identity.project_id)
        return [t for t in tasks if self._policy.authorize_task_read(identity, t).allow]

    def send_message(self, identity: Identity, *, task_id: str, thread_id: str | None,
                     recipient_node_ids: list[str], message_kind: str, body: str,
                     evidence_refs: list[str] | None = None, artifact_refs: list[str] | None = None,
                     reply_to: str | None = None) -> dict[str, Any]:
        if message_kind not in MESSAGE_KINDS:
            raise CollaborationError(f"unknown message kind {message_kind!r}")
        if not isinstance(body, str) or not body.strip():
            raise CollaborationError("message body must be non-empty")
        recipients = _strings(recipient_node_ids, "recipient_node_ids")
        task = self._require_task(identity, task_id)
        self._require(self._policy.authorize_send_message(identity, task, recipients))
        msg = {
            "message_id": _new("msg"), "thread_id": thread_id or task["thread_id"],
            "task_id": task_id, "project_id": identity.project_id,
            "sender_node_id": identity.node_id, "recipient_node_ids": recipients,
            "message_kind": message_kind, "body": body.strip(),
            "evidence_refs": list(evidence_refs or []), "artifact_refs": list(artifact_refs or []),
            "reply_to": reply_to, "created_at": _now(), "delivery_state": "persisted",
        }
        self._store.append_operational_message(msg)
        return msg

    def read_messages(self, identity: Identity, *, task_id: str,
                      include_all: bool = False) -> list[dict[str, Any]]:
        self._require_task(identity, task_id)
        messages = self._store.list_operational_messages(identity.project_id, task_id)
        if include_all and self._policy.authorize_read_task_transcript(identity).allow:
            return messages
        return [m for m in messages if self._policy.authorize_message_read(identity, m).allow]

    def open_debate(self, identity: Identity, *, task_id: str, proposition: str,
                    participant_node_ids: list[str], evidence_refs: list[str] | None = None,
                    artifact_refs: list[str] | None = None, max_rounds: int = 3,
                    budget_units: int = 1000) -> dict[str, Any]:
        # caller authority first, before this node learns anything about the task — the order the
        # inline check had. `authorize_open_debate` asks it again together with the task scope;
        # the policy is pure, so asking twice costs nothing and keeps the ordering visible here.
        self._require(self._policy.authorize_debate(
            identity, {"caller_node": identity.node_id,
                       "participants": list(participant_node_ids or ())}))
        task = self._require_task(identity, task_id)
        participants = _strings(participant_node_ids, "participant_node_ids")
        self._require(self._policy.authorize_open_debate(identity, task, participants))
        if not isinstance(max_rounds, int) or not 1 <= max_rounds <= 5:
            raise CollaborationError("max_rounds must be in 1..5")
        if not isinstance(budget_units, int) or budget_units < 1:
            raise CollaborationError("budget_units must be positive")
        if not isinstance(proposition, str):  # .strip() below would raise AttributeError instead
            raise CollaborationError("proposition must be non-empty")
        debate = {
            "debate_id": _new("d"), "task_id": task_id, "thread_id": task["thread_id"],
            "project_id": identity.project_id, "opened_by_node_id": identity.node_id,
            "participant_node_ids": participants, "proposition": proposition.strip(),
            "evidence_refs": list(evidence_refs or []), "artifact_refs": list(artifact_refs or []),
            "max_rounds": max_rounds, "budget_units": budget_units, "turns": [],
            "state": "OPEN", "created_at": _now(), "updated_at": _now(),
            "agreements": [], "dissent": [], "decision": None,
        }
        if not debate["proposition"]:
            raise CollaborationError("proposition must be non-empty")
        self._store.create_operational_debate(debate)
        return debate

    def post_debate_turn(self, identity: Identity, *, debate_id: str, body: str,
                         evidence_refs: list[str] | None = None,
                         reply_to: str | None = None) -> dict[str, Any]:
        debate = self._require_debate(identity, debate_id)
        if debate["state"] != "OPEN":
            raise CollaborationError("debate is not open")
        self._require(self._policy.authorize_debate_turn(identity, debate))
        if not isinstance(body, str) or not body.strip():
            raise CollaborationError("debate turn body must be non-empty")
        posted: dict[str, Any] = {}

        def apply(current: dict[str, Any]) -> dict[str, Any]:
            # Everything that depends on the debate's CONTENT is decided here, against the row
            # read inside the transaction: the two-worker case is the ordinary one, and appending
            # to the snapshot's turn list silently dropped whichever turn committed first (U330).
            # The round ceiling (invariant 14) moves with it — counted on a snapshot, a node's
            # last turn could be admitted twice under contention.
            if current["state"] != "OPEN":
                raise CollaborationError("debate is not open")
            self._require(self._policy.authorize_debate_turn(identity, current))
            turns = list(current["turns"])
            round_no = 1 + sum(1 for t in turns if t["node_id"] == identity.node_id)
            if round_no > current["max_rounds"]:
                raise CollaborationError("bounded debate round limit reached")
            posted["turn"] = {
                "turn_id": _new("turn"), "node_id": identity.node_id, "round": round_no,
                "body": body.strip(), "evidence_refs": list(evidence_refs or []),
                "reply_to": reply_to, "created_at": _now(),
            }
            return {**current, "turns": [*turns, posted["turn"]], "updated_at": _now()}

        self._store.mutate_operational_debate(identity.project_id, debate_id, apply)
        turn = posted["turn"]
        self.send_message(
            identity, task_id=debate["task_id"], thread_id=debate["thread_id"],
            recipient_node_ids=[n for n in debate["participant_node_ids"] if n != identity.node_id],
            message_kind="debate_turn", body=body, evidence_refs=evidence_refs or [],
            artifact_refs=[], reply_to=reply_to,
        )
        return turn

    def close_debate(self, identity: Identity, *, debate_id: str, decision: str,
                     agreements: list[str] | None = None, dissent: list[str] | None = None,
                     disagreements: list[str] | None = None,
                     unresolved_points: list[str] | None = None,
                     closure_reason: str | None = None) -> dict[str, Any]:
        debate = self._require_debate(identity, debate_id)
        self._require(self._policy.authorize_debate_close(identity, debate))
        if debate["state"] != "OPEN":
            raise CollaborationError("debate is not open")
        if not isinstance(decision, str) or not decision.strip():
            raise CollaborationError("decision must be non-empty")
        disagreements = list(disagreements if disagreements is not None else (dissent or []))

        def apply(current: dict[str, Any]) -> dict[str, Any]:
            # A closing debate is the worst case for a stale snapshot: `claims` and
            # `turn_evidence_refs` ARE the record of what was argued, and they feed the acceptance
            # packet. Both the quorum rule and the transcript are therefore taken from the row
            # inside the fence — a turn that landed a millisecond ago is part of this debate.
            if current["state"] != "OPEN":
                raise CollaborationError("debate is not open")
            self._require(self._policy.authorize_debate_close(identity, current))
            turns = current.get("turns", [])
            represented = {turn["node_id"] for turn in turns}
            missing = [n for n in current["participant_node_ids"] if n not in represented]
            if missing:
                raise CollaborationError("debate cannot close without a turn from every participant: "
                                         + ", ".join(missing))
            return {
                **current, "state": "CLOSED", "decision": decision.strip(),
                "claims": [turn["body"] for turn in turns],
                "turn_evidence_refs": list(dict.fromkeys(
                    ref for turn in turns for ref in turn.get("evidence_refs", []))),
                "agreements": list(agreements or []), "dissent": disagreements,
                "disagreements": disagreements, "unresolved_points": list(unresolved_points or []),
                "closure_reason": (closure_reason or decision).strip(),
                "closed_by_node_id": identity.node_id, "closed_at": _now(), "updated_at": _now(),
            }

        return self._store.mutate_operational_debate(identity.project_id, debate_id, apply)

    def abort_debate(self, identity: Identity, *, debate_id: str, reason: str) -> dict[str, Any]:
        """End a debate that can no longer reach a decision (U416).

        Closure requires a turn from every participant, so a participant whose pane dies leaves
        the debate OPEN permanently — its peers accumulating stall timers, and any caller that
        gates on open debates blocked behind a node that will never answer. ABORTED is that
        debate's terminal state. It is not a quiet deletion: the turns that were posted stay,
        `decision` stays None because none was reached, and the reason is recorded and surfaced.

        SCOPE, said exactly ([[U425]](b), unit 19.6): the "synthesis gate" both sentences above
        referred to is `SovereignToolRuntime._considered_debates` in `mcp_server/sovereign_tools.py`
        — the TOOL path a conductor CLI reaches. It is that gate, not this service, which refuses
        to publish while a debate on the task is open and which reports aborted debates separately.
        `record_synthesis` in this class performs no debate check of its own ([[U410]]), so a caller
        that reaches it by another route gets no such protection, and an unqualified sentence here
        described a defence this file does not provide. The round-2 scoping repair fixed two sites
        and missed this one; it is the only one of the three in live product code.
        """
        debate = self._require_debate(identity, debate_id)
        self._require(self._policy.authorize_debate_abort(identity, debate))
        if debate["state"] != "OPEN":
            raise CollaborationError("debate is not open")
        if not isinstance(reason, str) or not reason.strip():
            raise CollaborationError("abort reason must be non-empty")

        def apply(current: dict[str, Any]) -> dict[str, Any]:
            if current["state"] != "OPEN":
                raise CollaborationError("debate is not open")
            self._require(self._policy.authorize_debate_abort(identity, current))
            return {
                **current, "state": "ABORTED", "abort_reason": reason.strip(),
                "claims": [turn["body"] for turn in current.get("turns", [])],
                "aborted_by_node_id": identity.node_id, "aborted_at": _now(), "updated_at": _now(),
            }

        return self._store.mutate_operational_debate(identity.project_id, debate_id, apply)

    def record_candidate(self, identity: Identity, *, task_id: str, candidate: dict[str, Any]) -> dict[str, Any]:
        task = self._require_task(identity, task_id)
        self._require(self._policy.authorize_publish_candidate(identity, task))
        required = ("provider", "model", "summary", "claims", "evidence_refs",
                    "peer_messages_considered", "debates_considered", "limitations",
                    "artifact_ref", "content_hash")
        missing = [key for key in required if candidate.get(key) in (None, "")]
        if missing:
            raise CollaborationError("candidate missing required fields: " + ", ".join(missing))
        if candidate.get("status") != "CANDIDATE":
            raise CollaborationError("candidate status must be CANDIDATE")
        messages = {m["message_id"] for m in self._store.list_operational_messages(
            identity.project_id, task_id)}
        unknown_messages = set(candidate["peer_messages_considered"]) - messages
        if unknown_messages:
            raise CollaborationError("candidate names unknown peer messages")
        known_debates = {d["debate_id"] for d in self._store.list_operational_debates(
            identity.project_id, task_id)}
        if set(candidate["debates_considered"]) - known_debates:
            raise CollaborationError("candidate names an unknown debate")

        def apply(current: dict[str, Any]) -> dict[str, Any]:
            candidates = dict(current.get("candidates") or {})
            candidates[identity.node_id] = candidate
            complete = set(current["owner_node_ids"]).issubset(candidates)
            return {**current, "candidates": candidates,
                    "status": "CANDIDATE_READY" if complete else "IN_PROGRESS", "updated_at": _now()}

        return self._store.mutate_operational_task(identity.project_id, task_id, apply)

    def record_synthesis(self, identity: Identity, *, task_id: str,
                         synthesis: dict[str, Any],
                         contribution_bindings: list[dict[str, Any]] | None = None
                         ) -> dict[str, Any]:
        # existence + read authority before the write — the one write path that skipped it.
        # SHADOWED FOR AUTHORITY (U343), and the round-3 gate-validator was right that the unit
        # owed this the same analysis it gave the update and sender rules: only the directing
        # roles pass `authorize_publish_synthesis`, and neither is in `_SCOPED_ROLES`, so
        # `authorize_task_read` can refuse here on project/existence and never on authority.
        # It is not decorative — deleting it changes an observable verdict, which
        # `test_synthesis_asks_task_read_before_it_publishes` and mutation row P26 pin.
        self._require_task(identity, task_id)
        self._require(self._policy.authorize_publish_synthesis(identity))

        def apply(current: dict[str, Any]) -> dict[str, Any]:
            candidates = current.get("candidates") or {}
            missing = [node for node in current["owner_node_ids"] if node not in candidates]
            if missing:
                raise CollaborationError("synthesis requires candidates from every worker: "
                                         + ", ".join(missing))
            canonical = synthesis
            if contribution_bindings is not None:
                stated = {row.get("node_id"): row for row in contribution_bindings
                          if isinstance(row, dict)}
                candidate_nodes = sorted(candidates)
                omitted = [node for node in candidate_nodes if node not in stated]
                invented = sorted(node for node in stated if node not in candidates)
                if omitted:
                    raise CollaborationError(
                        "synthesis must report every candidate committed inside the write fence; missing: "
                        + ", ".join(omitted))
                if invented:
                    raise CollaborationError(
                        "synthesis reports nodes with no candidate inside the write fence: "
                        + ", ".join(invented))
                changed = [node for node in candidate_nodes
                           if stated[node].get("candidate_content_hash")
                           != candidates[node].get("content_hash")]
                if changed:
                    raise CollaborationError(
                        "synthesis contribution is not bound to the committed candidate content_hash: "
                        + ", ".join(changed))
                canonical = {**synthesis, "candidate_node_ids": candidate_nodes,
                             "contributions": [stated[node] for node in candidate_nodes]}
            return {**current, "synthesis": canonical, "status": "COMPLETED", "updated_at": _now()}

        return self._store.mutate_operational_task(identity.project_id, task_id, apply)

    def list_debates(self, identity: Identity, task_id: str | None = None) -> list[dict[str, Any]]:
        if task_id is not None:
            self._require_task(identity, task_id)
        rows = self._store.list_operational_debates(identity.project_id, task_id)
        return [d for d in rows if self._policy.authorize_debate_read(identity, d).allow]

    def get_debate(self, identity: Identity, debate_id: str) -> dict[str, Any]:
        return self._require_debate(identity, debate_id)

    def _require_task(self, identity: Identity, task_id: str) -> dict[str, Any]:
        task = self._store.get_operational_task(identity.project_id, task_id)
        if task is None:
            raise CollaborationError("no such task in this project")
        self._require(self._policy.authorize_task_read(identity, task))
        return task

    def _require_debate(self, identity: Identity, debate_id: str) -> dict[str, Any]:
        """Read authority BEFORE anything is disclosed about the debate — the ordering
        `_require_task` already had, and which `post_debate_turn` did not: it reported "debate is
        not open" to callers the policy would refuse. Existence within the caller's own project
        is still disclosed by the lookup itself; the store is keyed by (project, id), so that
        much is unavoidable without a second index."""
        debate = self._store.get_operational_debate(identity.project_id, debate_id)
        if debate is None:
            raise CollaborationError("no such debate in this project")
        self._require(self._policy.authorize_debate_read(identity, debate))
        return debate


__all__ = ["CollaborationError", "CollaborationService", "MESSAGE_KINDS", "TASK_STATES"]
