"""Standard stdio MCP adapter for live Sovereign conductor and worker nodes.

The Electron supervisor issues one opaque loopback capability per admitted node.  This
process resolves that capability to the real node identity, exposes the application tools,
and stores collaboration state in the existing Sovereign SQLite/CAS substrate.
"""
from __future__ import annotations

import base64
import json
import os
import sys
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any, Callable

from control_plane.policy import Identity, SovereignPolicy, Verdict
from mcp_server.collaboration_service import CollaborationService
from mcp_server.memory_service import MemoryService
from persistence import ContentAddressedStore, SovereignStore


PROTOCOL_VERSION = "2025-06-18"
SERVER_NAME = "sovereign"
INSTRUCTIONS = (
    "Sovereign is the authoritative application-control and node-collaboration server. "
    "Worker creation, termination, task assignment, status, node messages, artifacts, and debates "
    "must use these tools. Never launch provider workers with shell commands or external terminals. "
    "Wait for spawn_worker to report ready before claiming a worker exists. Workers should publish "
    "progress and candidate results through these tools, not only terminal output."
)


class ToolError(RuntimeError):
    pass


class AppControlClient:
    def __init__(self, port: int, token: str, *, timeout: float = 180.0) -> None:
        if port <= 0 or not token:
            raise ToolError("Sovereign app-control capability is unavailable")
        self._base = f"http://127.0.0.1:{port}/v1"
        self._token = token
        self._timeout = timeout

    def call(self, operation: str, arguments: dict[str, Any] | None = None) -> Any:
        body = json.dumps({"operation": operation, "arguments": arguments or {}}).encode("utf-8")
        req = urllib.request.Request(
            self._base + "/tools/call", data=body, method="POST",
            headers={"Authorization": f"Bearer {self._token}", "Content-Type": "application/json"},
        )
        try:
            with urllib.request.urlopen(req, timeout=self._timeout) as response:
                payload = json.loads(response.read().decode("utf-8"))
        except (OSError, urllib.error.URLError, json.JSONDecodeError) as exc:
            raise ToolError(f"Sovereign app-control channel failed: {exc}") from exc
        if not payload.get("ok"):
            raise ToolError(str(payload.get("error") or "application operation failed"))
        return payload.get("result")

    def identity(self) -> Identity:
        result = self.identity_details()
        try:
            return Identity(result["node_id"], result["role"], result["project_id"])
        except (KeyError, TypeError) as exc:
            raise ToolError("application returned a malformed node identity") from exc

    def identity_details(self) -> dict[str, Any]:
        result = self.call("identity")
        if not isinstance(result, dict):
            raise ToolError("application returned a malformed node identity")
        return result


class SovereignToolRuntime:
    def __init__(self, app: AppControlClient, store_root: Path, *,
                 policy: SovereignPolicy) -> None:
        # `policy` is a REQUIRED keyword, not a manufactured default (the U292(a) closure): the
        # authority is supplied by the caller, so it can be replaced with one that disagrees and
        # the delegation is falsifiable behaviourally rather than by reading the source.
        self.app = app
        self.identity_details = app.identity_details()
        self.identity = Identity(self.identity_details["node_id"], self.identity_details["role"],
                                 self.identity_details["project_id"])
        self.store = SovereignStore(store_root / "sovereign.db")
        self.cas = ContentAddressedStore(store_root / "cas")
        self.policy = policy
        self.memory = MemoryService(self.store, self.cas, self.policy)
        self.collaboration = CollaborationService(self.store, self.policy)

    def close(self) -> None:
        self.store.close()

    def call(self, name: str, args: dict[str, Any]) -> Any:
        handlers: dict[str, Callable[[dict[str, Any]], Any]] = {
            "list_models": lambda a: self.app.call("list_models", a),
            "spawn_worker": lambda a: self.app.call("spawn_worker", a),
            "stop_worker": lambda a: self.app.call("stop_worker", a),
            "get_worker_status": lambda a: self._worker_status(a),
            "assign_task": self._assign_task,
            "send_message": self._send_message,
            "read_messages": self._read_messages,
            "publish_progress": self._publish_progress,
            "open_debate": self._open_debate,
            "post_debate_turn": self._post_debate_turn,
            "close_debate": self._close_debate,
            "abort_debate": self._abort_debate,
            "publish_artifact": self._publish_artifact,
            "read_artifact": self._read_artifact,
            "publish_candidate": self._publish_candidate,
            "publish_synthesis": self._publish_synthesis,
        }
        handler = handlers.get(name)
        if handler is None:
            raise ToolError(f"unknown Sovereign tool {name!r}")
        if not isinstance(args, dict):
            raise ToolError("tool arguments must be an object")
        return handler(args)

    def _worker_status(self, args: dict[str, Any]) -> dict[str, Any]:
        live = self.app.call("get_worker_status", args)
        return {"nodes": live, "tasks": self.collaboration.list_tasks(self.identity)}

    def _assign_task(self, args: dict[str, Any]) -> dict[str, Any]:
        # Refuse stale/missing owners before appending a task. The application repeats this check
        # immediately before delivery, closing both U436 costs: no routine BLOCKED row and no first
        # owner half-delivered when a later owner is unavailable.
        self.app.call("preflight_assignment", {
            "worker_node_ids": args.get("worker_node_ids", []),
        })
        task = self.collaboration.create_task(
            self.identity, objective=args.get("objective", ""),
            owner_node_ids=args.get("worker_node_ids", []), scope=args.get("scope"),
            constraints=args.get("constraints"), expected_output=args.get("expected_output"),
            acceptance_criteria=args.get("acceptance_criteria"), peer_nodes=args.get("peer_nodes"),
        )
        try:
            delivery = self.app.call("assign_task", {"task": task})
        except Exception as exc:
            task = self.collaboration.update_task(
                self.identity, task_id=task["task_id"], status="BLOCKED",
                progress={"blockers": [str(exc)], "what_remains": "deliver assignment to live pane"},
            )
            raise ToolError(f"task persisted but pane delivery failed: {exc}") from exc
        return {"task": task, "delivery": delivery}

    def _send_message(self, args: dict[str, Any]) -> dict[str, Any]:
        message = self.collaboration.send_message(
            self.identity, task_id=args.get("task_id", ""), thread_id=args.get("thread_id"),
            recipient_node_ids=args.get("recipient_node_ids", []),
            message_kind=args.get("message_kind", "question"), body=args.get("body", ""),
            evidence_refs=args.get("evidence_refs"), artifact_refs=args.get("artifact_refs"),
            reply_to=args.get("reply_to"),
        )
        notification = self.app.call("notify_message", {"message": message})
        return {"message": message, "notification": notification}

    def _read_messages(self, args: dict[str, Any]) -> dict[str, Any]:
        messages = self.collaboration.read_messages(
            self.identity, task_id=args.get("task_id", ""),
            include_all=bool(args.get("include_all", False)),
        )
        return {"messages": messages, "count": len(messages)}

    def _publish_progress(self, args: dict[str, Any]) -> dict[str, Any]:
        status = args.get("status", "IN_PROGRESS")
        progress = {
            "completed": args.get("completed", ""), "working_on": args.get("working_on", ""),
            "what_remains": args.get("what_remains", ""), "blockers": args.get("blockers", []),
            "questions": args.get("questions", []), "evidence_refs": args.get("evidence_refs", []),
            "artifact_refs": args.get("artifact_refs", []), "estimated_next_action": args.get("estimated_next_action", ""),
        }
        task = self.collaboration.update_task(
            self.identity, task_id=args.get("task_id", ""), status=status, progress=progress,
        )
        kind = "blocker" if status == "BLOCKED" else "completion" if status in ("CANDIDATE_READY", "COMPLETED") else "progress"
        body = args.get("body") or progress["completed"] or progress["working_on"] or status
        recipients = args.get("recipient_node_ids") or [task["created_by_node_id"]]
        message = self.collaboration.send_message(
            self.identity, task_id=task["task_id"], thread_id=task["thread_id"],
            recipient_node_ids=recipients, message_kind=kind, body=body,
            evidence_refs=progress["evidence_refs"], artifact_refs=progress["artifact_refs"],
        )
        self.app.call("notify_message", {"message": message, "task": task})
        return {"task": task, "message": message}

    def _open_debate(self, args: dict[str, Any]) -> dict[str, Any]:
        debate = self.collaboration.open_debate(
            self.identity, task_id=args.get("task_id", ""), proposition=args.get("proposition", ""),
            participant_node_ids=args.get("participant_node_ids", []),
            evidence_refs=args.get("evidence_refs"), artifact_refs=args.get("artifact_refs"),
            max_rounds=args.get("max_rounds", 2), budget_units=args.get("budget_units", 1000),
        )
        self.app.call("notify_debate", {"debate": debate})
        return debate

    def _post_debate_turn(self, args: dict[str, Any]) -> dict[str, Any]:
        debate = self.collaboration.get_debate(self.identity, args.get("debate_id", ""))
        turn = self.collaboration.post_debate_turn(
            self.identity, debate_id=args.get("debate_id", ""), body=args.get("body", ""),
            evidence_refs=args.get("evidence_refs"), reply_to=args.get("reply_to"),
        )
        self.app.call("notify_debate_turn", {"debate_id": args.get("debate_id"), "turn": turn,
                      "participant_node_ids": debate["participant_node_ids"]})
        return turn

    def _abort_debate(self, args: dict[str, Any]) -> dict[str, Any]:
        """U416: the terminal state for a debate whose participant can no longer answer. Reachable
        as a tool because the node that notices a dead peer is a live node, not a test."""
        return self.collaboration.abort_debate(
            self.identity, debate_id=args.get("debate_id", ""), reason=args.get("reason", ""))

    def _close_debate(self, args: dict[str, Any]) -> dict[str, Any]:
        return self.collaboration.close_debate(
            self.identity, debate_id=args.get("debate_id", ""), decision=args.get("decision", ""),
            agreements=args.get("agreements"), dissent=args.get("dissent"),
            disagreements=args.get("disagreements"),
            unresolved_points=args.get("unresolved_points"),
            closure_reason=args.get("closure_reason"),
        )

    def _authorize(self, verdict: Verdict) -> None:
        """U326: the tool layer asks `control_plane.policy` too. It used to carry its own copies
        of the candidate/synthesis role rules — a third place authority could drift to."""
        if not verdict.allow:
            raise ToolError(verdict.reason)

    def _publish_candidate(self, args: dict[str, Any]) -> dict[str, Any]:
        # ask the authority BEFORE writing the candidate artifact into CAS, using the real rule
        # (assigned worker), not a coarse approximation of it
        self._authorize(self.policy.authorize_publish_candidate(
            self.identity, self.collaboration.get_task(self.identity, args.get("task_id", ""))))
        provider = str(self.identity_details.get("provider_id") or "")
        model = str(self.identity_details.get("model_id") or "")
        if args.get("provider") and args["provider"] != provider:
            raise ToolError("candidate provider does not match authenticated node identity")
        if args.get("model") and args["model"] != model:
            raise ToolError("candidate model does not match authenticated node identity")
        task_id = args.get("task_id", "")
        candidate = {
            "task_id": task_id, "worker_node_id": self.identity.node_id,
            "provider": provider, "model": model, "summary": args.get("summary", "").strip(),
            "claims": _nonempty_strings(args.get("claims"), "claims"),
            "evidence_refs": _nonempty_strings(args.get("evidence_refs"), "evidence_refs"),
            "peer_messages_considered": _string_list(args.get("peer_messages_considered"),
                                                        "peer_messages_considered"),
            "debates_considered": _string_list(args.get("debates_considered"), "debates_considered"),
            "limitations": _string_list(args.get("limitations"), "limitations"),
            "status": "CANDIDATE", "published_at": _iso_now(),
        }
        artifact = self.memory.put_artifact(
            self.identity, content=json.dumps(candidate, sort_keys=True).encode("utf-8"),
            media_type="application/vnd.sovereign.candidate+json", task_id=task_id,
        )
        candidate["artifact_ref"] = artifact["artifact_id"]
        candidate["content_hash"] = artifact["artifact_id"]
        task = self.collaboration.record_candidate(
            self.identity, task_id=task_id, candidate=candidate)
        message = self.collaboration.send_message(
            self.identity, task_id=task_id, thread_id=task["thread_id"],
            recipient_node_ids=[task["created_by_node_id"]], message_kind="completion",
            body=f"CANDIDATE published by {self.identity.node_id}: {candidate['summary']}",
            evidence_refs=candidate["evidence_refs"], artifact_refs=[artifact["artifact_id"]],
        )
        self.app.call("notify_message", {"message": message, "task": task})
        return {"candidate": candidate, "artifact": artifact, "task": task, "message": message}

    def _publish_synthesis(self, args: dict[str, Any]) -> dict[str, Any]:
        self._authorize(self.policy.authorize_publish_synthesis(self.identity))
        task_id = args.get("task_id", "")
        task = self.collaboration.get_task(self.identity, task_id)
        debate_ids, aborted_ids = self._considered_debates(task_id, args.get("debate_ids"))
        synthesis = {
            "task_id": task_id, "conductor_node_id": self.identity.node_id,
            "provider": self.identity_details.get("provider_id"),
            "model": self.identity_details.get("model_id"),
            "operator_objective": task["objective"],
            "contributions": self._contributions(task, args.get("contributions")),
            "points_of_agreement": _string_list(args.get("points_of_agreement"), "points_of_agreement"),
            "points_of_disagreement": _string_list(args.get("points_of_disagreement"), "points_of_disagreement"),
            "debate_outcome": args.get("debate_outcome", "").strip(),
            "evidence_used": _nonempty_strings(args.get("evidence_used"), "evidence_used"),
            "limitations": _string_list(args.get("limitations"), "limitations"),
            "conductor_judgment": args.get("conductor_judgment", "").strip(),
            "recommended_next_action": args.get("recommended_next_action", "").strip(),
            "candidate_node_ids": sorted((task.get("candidates") or {}).keys()),
            "debate_ids": debate_ids, "aborted_debate_ids": aborted_ids,
            "status": "SYNTHESIS", "published_at": _iso_now(),
        }
        required_text = ("debate_outcome", "conductor_judgment", "recommended_next_action")
        if any(not synthesis[key] for key in required_text):
            raise ToolError("synthesis is missing a required narrative field")
        artifact = self.memory.put_artifact(
            self.identity, content=json.dumps(synthesis, sort_keys=True).encode("utf-8"),
            media_type="application/vnd.sovereign.synthesis+json", task_id=task_id,
        )
        synthesis["artifact_ref"] = artifact["artifact_id"]
        synthesis["content_hash"] = artifact["artifact_id"]
        task = self.collaboration.record_synthesis(
            self.identity, task_id=task_id, synthesis=synthesis,
            contribution_bindings=synthesis["contributions"])
        return {"synthesis": synthesis, "artifact": artifact, "task": task,
                "operator_instruction": "Present this synthesis in the conductor pane now."}

    def _contributions(self, task: dict[str, Any], raw: Any) -> list[dict[str, str]]:
        """Every worker's contribution, keyed by NODE ID and cross-checked against the task (U333).

        What this replaces: two hardcoded fields, `gemini_contribution` and `grok_contribution`,
        both required. A task worked by any other set of nodes — two Codex workers, a Claude worker
        beside a local Ollama one, one worker, three — could not be synthesised, and the only way
        to comply was to file a node's work under a vendor name that was not its own. Work is
        dispatched by capability descriptor and reported by node identity (I-SC1); a fixed pair of
        vendor slots is neither.

        The cross-check runs in both directions, mirroring the closed-debate gate above, because
        the two-slot form could fail in neither: a contribution naming a node that published no
        candidate is refused (invented work), and a candidate node the caller left out is refused
        (dropped work). Both refusals name the node, because a conductor that must guess which one
        it got wrong will guess.

        Returned in candidate order, so the record is stable for the CAS hash regardless of the
        order the conductor listed them in.
        """
        if not isinstance(raw, list) or not raw:
            raise ToolError(
                "synthesis requires a contributions list naming every candidate node on the task")
        stated: dict[str, str] = {}
        for entry in raw:
            if not isinstance(entry, dict):
                raise ToolError("each contribution must be an object with node_id and contribution")
            node_id = entry.get("node_id")
            text = entry.get("contribution")
            if not isinstance(node_id, str) or not node_id.strip():
                raise ToolError("each contribution must name the node_id whose work it reports")
            if not isinstance(text, str) or not text.strip():
                raise ToolError(f"the contribution for {node_id.strip()} is empty")
            if node_id.strip() in stated:
                raise ToolError(f"node {node_id.strip()} is named twice in contributions")
            stated[node_id.strip()] = text.strip()
        candidate_records = task.get("candidates") or {}
        candidates = sorted(candidate_records.keys())
        unknown = sorted(n for n in stated if n not in candidates)
        if unknown:
            raise ToolError(
                "synthesis names contributions from nodes that published no candidate on this "
                f"task: {', '.join(unknown)}")
        missing = [n for n in candidates if n not in stated]
        if missing:
            raise ToolError(
                "synthesis must report a contribution for every candidate node; missing: "
                f"{', '.join(missing)}")
        return [{"node_id": n,
                 "candidate_content_hash": candidate_records[n]["content_hash"],
                 "contribution": stated[n]} for n in candidates]

    def _considered_debates(self, task_id: str, raw: Any) -> tuple[list[str], list[str]]:
        """The closed-debate gate, computed from the TASK's debates rather than from the caller's
        list (U332).

        The gate used to be `for debate_id in debate_ids: ...` — a loop over an argument, so an
        empty list satisfied it vacuously and a conductor could publish a synthesis over a debate
        that was still being argued simply by not mentioning it. Naming a CLOSED debate from a
        different task passed too, because `get_debate` is project-scoped. Four rules replace it,
        and the first is the one U332 is about:

          * no debate on this task may still be OPEN — named or not;
          * every id the caller names must belong to this task, and be CLOSED;
          * every CLOSED debate on this task must be named — omission was the bypass;
          * ABORTED debates (U416) are reported separately, from the store, so a deliberation that
            never concluded cannot be presented as one that did, and cannot block the task forever.

        `_nonempty_strings` therefore applies exactly when there is something to skip. A task that
        never needed a debate stays synthesisable; nothing is being waived, because the
        cross-check — not the list's length — is what closes the hole.

        One coupling, recorded rather than hidden (U411): the debates are read through
        `list_debates`, which filters by `authorize_debate_read`. That is correct — the tool layer
        must not read past the authority — and today it is exhaustive, because only the directing
        roles reach here and `_SCOPED_ROLES` does not contain them. If debate-read scoping ever
        narrows for a directing role, an unreadable debate becomes an invisible one, and this gate
        weakens silently.
        """
        known = {d["debate_id"]: d for d in self.collaboration.list_debates(self.identity, task_id)}
        still_open = sorted(d for d, rec in known.items() if rec.get("state") == "OPEN")
        if still_open:
            raise ToolError("synthesis requires every debate on this task to be concluded; "
                            "still open: " + ", ".join(still_open))
        closed_ids = sorted(d for d, rec in known.items() if rec.get("state") == "CLOSED")
        aborted_ids = sorted(d for d, rec in known.items()
                             if rec.get("state") not in ("OPEN", "CLOSED"))
        debate_ids = (_nonempty_strings(raw, "debate_ids") if closed_ids
                      else _string_list(raw, "debate_ids"))
        foreign = [d for d in debate_ids if d not in known]
        if foreign:
            raise ToolError("synthesis names a debate that does not belong to this task: "
                            + ", ".join(sorted(foreign)))
        not_closed = [d for d in debate_ids if known[d].get("state") != "CLOSED"]
        if not_closed:
            raise ToolError("synthesis requires every considered debate to be closed; not closed: "
                            + ", ".join(sorted(not_closed)))
        unnamed = [d for d in closed_ids if d not in debate_ids]
        if unnamed:
            raise ToolError("synthesis must name every closed debate on this task; missing: "
                            + ", ".join(unnamed))
        return debate_ids, aborted_ids

    def _publish_artifact(self, args: dict[str, Any]) -> dict[str, Any]:
        content = args.get("content")
        if not isinstance(content, str):
            raise ToolError("artifact content must be text")
        return self.memory.put_artifact(
            self.identity, content=content.encode("utf-8"),
            media_type=args.get("media_type", "text/plain; charset=utf-8"), task_id=args.get("task_id"),
        )

    def _read_artifact(self, args: dict[str, Any]) -> dict[str, Any]:
        result = self.memory.get_artifact(self.identity, args.get("artifact_id", ""))
        raw = base64.b64decode(result.pop("content_b64"))
        try:
            result["content"] = raw.decode("utf-8")
        except UnicodeDecodeError:
            result["content_b64"] = base64.b64encode(raw).decode("ascii")
        return result


def _schema(properties: dict[str, Any], required: list[str] | None = None) -> dict[str, Any]:
    return {"type": "object", "properties": properties, "required": required or [], "additionalProperties": False}


S = {"type": "string"}
SA = {"type": "array", "items": S}
# U333: one entry per candidate node, keyed by node id. The schema a live CLI reads is where the
# vendor shape was most contagious — a required `gemini_contribution` teaches every conductor that
# contributions ARE vendors, whatever the runtime then checks.
CONTRIBUTIONS = {"type": "array", "minItems": 1, "items": {
    "type": "object",
    "properties": {"node_id": S, "contribution": S},
    "required": ["node_id", "contribution"],
}}

def _string_list(value: Any, field: str) -> list[str]:
    if value is None:
        return []
    if not isinstance(value, list) or not all(isinstance(item, str) and item.strip() for item in value):
        raise ToolError(f"{field} must be a list of non-empty strings")
    return list(dict.fromkeys(item.strip() for item in value))


def _nonempty_strings(value: Any, field: str) -> list[str]:
    result = _string_list(value, field)
    if not result:
        raise ToolError(f"{field} must not be empty")
    return result


def _iso_now() -> str:
    from datetime import datetime, timezone
    return datetime.now(timezone.utc).isoformat()

TOOLS = [
    {"name": "list_models", "description": "List registered, available conductor/worker models from the live Sovereign picker.", "inputSchema": _schema({}), "annotations": {"readOnlyHint": True}},
    {"name": "spawn_worker", "description": "Create one governed provider worker inside Electron. Never use shell commands for this. provider and model_id must be the exact identifiers returned by list_models; the runtime has no hidden vendor aliases or model defaults.", "inputSchema": _schema({"provider": S, "model_id": S, "role": S}, ["provider", "model_id", "role"])},
    {"name": "stop_worker", "description": "Stop a governed worker and release its process tree and subscription lease.", "inputSchema": _schema({"node_id": S, "provider": S})},
    {"name": "assign_task", "description": "Create a scoped shared task and deliver it to live worker panes.", "inputSchema": _schema({"objective": S, "worker_node_ids": SA, "scope": {"type": "object"}, "constraints": SA, "expected_output": S, "acceptance_criteria": SA, "peer_nodes": SA}, ["objective", "worker_node_ids"])},
    {"name": "get_worker_status", "description": "Read live node/process/MCP/lease state and task progress.", "inputSchema": _schema({"node_id": S, "provider": S}), "annotations": {"readOnlyHint": True}},
    {"name": "send_message", "description": "Persist and deliver a task-scoped node-to-node message.", "inputSchema": _schema({"task_id": S, "thread_id": S, "recipient_node_ids": SA, "message_kind": {"type": "string", "enum": ["assignment", "question", "answer", "progress", "blocker", "challenge", "debate_turn", "decision", "artifact_notice", "completion"]}, "body": S, "evidence_refs": SA, "artifact_refs": SA, "reply_to": S}, ["task_id", "recipient_node_ids", "message_kind", "body"])},
    {"name": "read_messages", "description": "Read messages visible to this node within one task.", "inputSchema": _schema({"task_id": S, "include_all": {"type": "boolean"}}, ["task_id"]), "annotations": {"readOnlyHint": True}},
    {"name": "publish_progress", "description": "Update task lifecycle and publish structured progress/blocker/completion to peers.", "inputSchema": _schema({"task_id": S, "status": {"type": "string", "enum": ["ACCEPTED", "IN_PROGRESS", "WAITING_FOR_PEER", "BLOCKED", "CANDIDATE_READY", "UNDER_REVIEW", "COMPLETED", "FAILED", "CANCELLED"]}, "completed": S, "working_on": S, "what_remains": S, "blockers": SA, "questions": SA, "evidence_refs": SA, "artifact_refs": SA, "estimated_next_action": S, "body": S, "recipient_node_ids": SA}, ["task_id", "status"])},
    {"name": "open_debate", "description": "Open a persisted, bounded task debate. For live acceptance use max_rounds=2 (two turns per worker).", "inputSchema": _schema({"task_id": S, "proposition": S, "participant_node_ids": SA, "evidence_refs": SA, "artifact_refs": SA, "max_rounds": {"type": "integer", "minimum": 1, "maximum": 5}, "budget_units": {"type": "integer", "minimum": 1}}, ["task_id", "proposition", "participant_node_ids"])},
    {"name": "post_debate_turn", "description": "Post one evidence-bearing turn to an open bounded debate.", "inputSchema": _schema({"debate_id": S, "body": S, "evidence_refs": SA, "reply_to": S}, ["debate_id", "body"])},
    {"name": "close_debate", "description": "Close a debate only after every participant has posted; preserve agreements, disagreements, unresolved points, evidence, and closure reason.", "inputSchema": _schema({"debate_id": S, "decision": S, "agreements": SA, "dissent": SA, "disagreements": SA, "unresolved_points": SA, "closure_reason": S}, ["debate_id", "decision"])},
    {"name": "abort_debate", "description": "End a debate that can no longer reach a decision — a participant's pane died, or its budget is spent. Preserves the turns already posted, records no decision, and states the reason. Conductor/operator only.", "inputSchema": _schema({"debate_id": S, "reason": S}, ["debate_id", "reason"])},
    {"name": "publish_artifact", "description": "Publish a task artifact into Sovereign CAS with node provenance.", "inputSchema": _schema({"task_id": S, "content": S, "media_type": S}, ["task_id", "content"])},
    {"name": "read_artifact", "description": "Read a project-scoped artifact by reference.", "inputSchema": _schema({"artifact_id": S}, ["artifact_id"]), "annotations": {"readOnlyHint": True}},
    {"name": "publish_candidate", "description": "Publish a validated final CANDIDATE artifact. Raw terminal text or IN_PROGRESS messages do not qualify.", "inputSchema": _schema({"task_id": S, "provider": S, "model": S, "summary": S, "claims": SA, "evidence_refs": SA, "peer_messages_considered": SA, "debates_considered": SA, "limitations": SA}, ["task_id", "summary", "claims", "evidence_refs", "peer_messages_considered", "debates_considered", "limitations"])},
    {"name": "publish_synthesis", "description": "Publish the conductor synthesis only after every assigned worker candidate exists and every debate on the task has concluded, then present it visibly to the operator. contributions must carry one entry per candidate node, keyed by that node's id — not by provider or model name. debate_ids must name every CLOSED debate on the task; a debate still open blocks publication, and an aborted one is reported separately.", "inputSchema": _schema({"task_id": S, "contributions": CONTRIBUTIONS, "points_of_agreement": SA, "points_of_disagreement": SA, "debate_outcome": S, "evidence_used": SA, "limitations": SA, "conductor_judgment": S, "recommended_next_action": S, "debate_ids": SA}, ["task_id", "contributions", "points_of_agreement", "points_of_disagreement", "debate_outcome", "evidence_used", "limitations", "conductor_judgment", "recommended_next_action", "debate_ids"])},
]


def handle_request(runtime: SovereignToolRuntime, request: dict[str, Any]) -> dict[str, Any] | None:
    method = request.get("method")
    rid = request.get("id")
    if method and method.startswith("notifications/"):
        return None
    if rid is None:
        return None
    if method == "initialize":
        return {"jsonrpc": "2.0", "id": rid, "result": {"protocolVersion": PROTOCOL_VERSION,
                "capabilities": {"tools": {"listChanged": False}},
                "serverInfo": {"name": SERVER_NAME, "version": "1.0.0"}, "instructions": INSTRUCTIONS}}
    if method == "ping":
        return {"jsonrpc": "2.0", "id": rid, "result": {}}
    if method == "tools/list":
        return {"jsonrpc": "2.0", "id": rid, "result": {"tools": TOOLS}}
    if method == "tools/call":
        params = request.get("params") or {}
        try:
            result = runtime.call(params.get("name", ""), params.get("arguments") or {})
            payload = {"content": [{"type": "text", "text": json.dumps(result, ensure_ascii=False)}],
                       "structuredContent": result, "isError": False}
        except Exception as exc:  # fail closed and keep the MCP process alive for later calls
            payload = {"content": [{"type": "text", "text": f"{type(exc).__name__}: {exc}"}],
                       "isError": True}
        return {"jsonrpc": "2.0", "id": rid, "result": payload}
    return {"jsonrpc": "2.0", "id": rid, "error": {"code": -32601, "message": f"method not found: {method}"}}


def main() -> int:
    try:
        app = AppControlClient(int(os.environ.get("SOVEREIGN_CONTROL_PORT", "0")),
                               os.environ.get("SOVEREIGN_CONTROL_TOKEN", ""))
        root = Path(os.environ.get("SOVEREIGN_STORE_ROOT") or ".sovereign_store").resolve()
        runtime = SovereignToolRuntime(app, root, policy=SovereignPolicy())
    except Exception as exc:
        print(f"sovereign MCP startup refused: {type(exc).__name__}: {exc}", file=sys.stderr, flush=True)
        return 2
    try:
        for line in sys.stdin:
            if not line.strip():
                continue
            try:
                request = json.loads(line)
                response = handle_request(runtime, request)
            except Exception as exc:
                response = {"jsonrpc": "2.0", "id": None,
                            "error": {"code": -32700, "message": f"{type(exc).__name__}: {exc}"}}
            if response is not None:
                sys.stdout.write(json.dumps(response, ensure_ascii=False) + "\n")
                sys.stdout.flush()
    finally:
        runtime.close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
