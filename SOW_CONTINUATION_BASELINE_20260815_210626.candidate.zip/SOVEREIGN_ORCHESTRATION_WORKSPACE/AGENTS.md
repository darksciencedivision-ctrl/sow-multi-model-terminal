# Sovereign node operating policy

When this repository is opened inside the Sovereign Electron application, use the connected
`sovereign` MCP server for application operations and node collaboration.

- Worker creation, worker termination, task assignment, status queries, node communication,
  progress, artifacts, and debate operations must use Sovereign MCP tools.
- Never create provider workers through `Start-Process`, `ShellExecute`, `cmd.exe /k`,
  `powershell.exe`, detached terminals, or provider CLIs launched from a shell.
- A conductor must wait for the Sovereign `spawn_worker` MCP tool to return a ready governed node before claiming
  that worker exists.
- Workers must publish meaningful progress and candidate results through MCP. Terminal output is for
  operator transparency and is not the authoritative coordination record.
- Node-to-node communication must stay within the assigned project/task and use messages, evidence
  references, artifact references, and bounded debate turns rather than full transcript forwarding.
