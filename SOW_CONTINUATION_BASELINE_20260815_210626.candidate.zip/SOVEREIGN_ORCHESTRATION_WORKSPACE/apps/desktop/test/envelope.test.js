"use strict";
const { test } = require("node:test");
const assert = require("node:assert");
const crypto = require("node:crypto");
const env = require("../ipc/envelope");

const KEY = Buffer.from("0".repeat(64), "hex");

test("canonicalization is key-order independent (matches Python sort_keys)", () => {
  const a = env.canonicalPayload({ op: "ping", nonce: "x", z: 1 });
  const b = env.canonicalPayload({ z: 1, nonce: "x", op: "ping" });
  assert.strictEqual(a.toString("utf8"), b.toString("utf8"));
  assert.strictEqual(a.toString("utf8"), '{"nonce":"x","op":"ping","z":1}');
});

test("nested objects and arrays canonicalize deterministically", () => {
  const s = env.canonicalPayload({ b: [3, { y: 1, x: 2 }], a: "s" }).toString("utf8");
  assert.strictEqual(s, '{"a":"s","b":[3,{"x":2,"y":1}]}');
});

test("integrity is a 64-hex hmac-sha256 over the canonical payload", () => {
  const payload = { op: "ping", nonce: "abc" };
  const tag = env.computeIntegrity(KEY, payload);
  assert.match(tag, /^[0-9a-f]{64}$/);
  const expected = crypto.createHmac("sha256", KEY)
    .update('{"nonce":"abc","op":"ping"}').digest("hex");
  assert.strictEqual(tag, expected);
});

test("verifyIntegrity accepts a good tag and rejects a tampered payload (fail-closed)", () => {
  const e = env.makeEnvelope({
    fromNode: "shell", to: ["control-plane"], msgType: "control_event",
    payload: { op: "ping", nonce: "n1" }, nodeCredential: "tok", scope: "project", key: KEY,
  });
  assert.strictEqual(env.verifyIntegrity(KEY, e), true);
  e.payload.nonce = "tampered";
  assert.strictEqual(env.verifyIntegrity(KEY, e), false);
});

test("a wrong key does not verify", () => {
  const e = env.makeEnvelope({
    fromNode: "shell", to: ["control-plane"], msgType: "control_event",
    payload: { op: "ping" }, nodeCredential: "tok", scope: "project", key: KEY,
  });
  assert.strictEqual(env.verifyIntegrity(crypto.randomBytes(32), e), false);
});

test("makeEnvelope produces a schema-shaped envelope@1.0", () => {
  const e = env.makeEnvelope({
    fromNode: "shell", to: ["control-plane"], msgType: "control_event",
    payload: { op: "ping" }, nodeCredential: "tok", scope: "project", key: KEY, taskId: null,
  });
  assert.strictEqual(e.schema, "envelope@1.0");
  assert.match(e.msg_id, /^[0-9a-f-]{36}$/);
  assert.match(e.payload_schema, /^[a-z_]+@[0-9]+\.[0-9]+$/);
  assert.deepStrictEqual(e.to, ["control-plane"]);
  assert.deepStrictEqual(Object.keys(e.auth).sort(), ["node_credential", "scope"]);
  assert.match(e.integrity, /^[0-9a-f]{64}$/);
});
