"use strict";

const { test } = require("node:test");
const assert = require("node:assert/strict");

const { assignmentRefusal } = require("../control/assignment-gate");
const {
  createApplicationControl, requireControlRole, taskPrompt,
} = require("../control/application-control");

const CONDUCTOR = { node_id: "cond-1", role: "conductor" };
const WORKER = { node_id: "w-1", role: "worker" };

function record(nodeId, paneId, provider) {
  return {
    nodeId, paneId, state: "running", operationalState: "READY", nodeAttested: true,
    chrome: { provider, model_slug: `${provider}-model` }, readiness: {},
  };
}

function harness(overrides = {}) {
  const records = new Map([
    ["w-1", record("w-1", "pane-2", "google_antigravity")],
    ["w-2", record("w-2", "pane-3", "grok_build")],
  ]);
  const calls = { spawns: [], writes: [], states: [], chrome: [], kills: [], notices: [], logs: [] };
  const timers = [];
  let picker = null;
  const io = {
    repoRoot: "C:/repo",
    workerTaskSoftDeadlineMs: 10,
    workerTaskHardDeadlineMs: 20,
    peerResponseDeadlineMs: 30,
    debateTurnDeadlineMs: 40,
    setTimeout: (fn, ms) => {
      const timer = { fn, ms, cleared: false, unref() {} };
      timers.push(timer);
      return timer;
    },
    clearTimeout: (timer) => { if (timer) timer.cleared = true; },
    workerRecordFor: (args = {}) => records.get(args.node_id) || null,
    workerRecordForPane: (paneId) => [...records.values()].find((r) => r.paneId === paneId) || null,
    liveWorkerRecords: () => [...records.values()],
    readinessFailure: (_rec, stage) => ({ stage }),
    setWorkerOperationalState: (paneId, state, patch) => {
      calls.states.push({ paneId, state, patch });
      const rec = [...records.values()].find((r) => r.paneId === paneId);
      if (rec) Object.assign(rec, { operationalState: state }, patch);
      return rec;
    },
    notifyNode: async (nodeId, prompt) => {
      calls.notices.push({ nodeId, prompt });
      return { written: true };
    },
    conductorNodeId: () => "cond-1",
    updateWorkerRecord: (paneId, patch) => {
      const rec = [...records.values()].find((r) => r.paneId === paneId);
      Object.assign(rec, patch);
      return rec;
    },
    pushConductor: () => {},
    fetchPickerModel: async () => ({ ok: true, picker: { options: [{
      provider: "google_antigravity", adapter: "antigravity", model_slug: "gemini-3.6-flash-low",
      label: "Gemini", roles: ["reasoning"], available: true, registered: true,
    }] } }),
    setPickerModel: (model) => { picker = model; },
    pickerModel: () => picker,
    runWorkerReadiness: async (paneId) => ({ ready: true, paneId }),
    operationalNodeStatus: (rec) => ({ node_id: rec.nodeId, pane_id: rec.paneId,
      provider_id: rec.chrome.provider, ready: rec.operationalState === "READY", mcp_state: "connected" }),
    spawnFromSelection: async (selection) => {
      calls.spawns.push(selection);
      const rec = record("w-new", "pane-4", selection.option.provider);
      records.set(rec.nodeId, rec);
      return { launched: true, target: rec.paneId };
    },
    chromeFor: (paneId) => ([...records.values()].find((r) => r.paneId === paneId) || {}).chrome,
    setChrome: (paneId, chrome) => {
      calls.chrome.push({ paneId, chrome });
      const rec = [...records.values()].find((r) => r.paneId === paneId);
      if (rec) rec.chrome = chrome;
    },
    persistLayoutSnapshot: () => {},
    sendPaneChrome: () => {},
    killPane: (paneId) => calls.kills.push(paneId),
    assignmentRefusal,
    mcpState: () => ({ state: "connected", fresh: true }),
    writePanePrompt: async (paneId, prompt) => {
      calls.writes.push({ paneId, prompt });
      return true;
    },
    log: (line) => calls.logs.push(line),
    ...overrides,
  };
  return { control: createApplicationControl(io), io, records, calls, timers };
}

test("role enforcement is executable without Electron", () => {
  assert.doesNotThrow(() => requireControlRole(CONDUCTOR, "conductor"));
  assert.throws(() => requireControlRole(WORKER, "conductor"), /requires conductor role/);
  assert.throws(() => requireControlRole(null, "worker", "operator"), /worker\|operator/);
});

test("the assignment prompt carries the collaboration protocol rather than terminal-only work", () => {
  const prompt = taskPrompt({ task_id: "t-1", thread_id: "th-1", objective: "review",
    owner_node_ids: ["w-1"], peer_nodes: ["w-2"] });
  assert.match(prompt, /SOVEREIGN MCP ASSIGNMENT/);
  assert.match(prompt, /publish_progress/);
  assert.match(prompt, /publish_candidate/);
  assert.match(prompt, /Do not leave the result only in terminal scrollback/);
});

test("spawn_worker behaviorally routes through the shared governed launcher and readiness", async () => {
  const { control, calls } = harness({ liveWorkerRecords: () => [] });
  const result = await control.handlers.spawn_worker(CONDUCTOR,
    { provider: "google_antigravity", model_id: "gemini-3.6-flash-low", role: "research" });
  assert.equal(result.duplicate, false);
  assert.equal(calls.spawns.length, 1);
  assert.deepEqual(calls.spawns[0], {
    option: calls.spawns[0].option, role: "reasoning", mode: "attended", targetPaneId: null,
  });
  assert.equal(calls.spawns[0].option.provider, "google_antigravity");
  assert.equal(result.readiness.ready, true);
  assert.equal(result.node.node_id, "w-new");
});

test("spawn_worker has no name aliases or hidden model default", async () => {
  const { control, calls } = harness({ liveWorkerRecords: () => [] });
  await assert.rejects(
    control.handlers.spawn_worker(CONDUCTOR, { provider: "gemini", role: "research" }),
    /exact provider_id and model_id/);
  await assert.rejects(
    control.handlers.spawn_worker(CONDUCTOR,
      { provider: "gemini", model_id: "gemini-3.6-flash-low", role: "research" }),
    /not an available registered worker option/);
  assert.equal(calls.spawns.length, 0);
});

test("assignment preflights every owner before the first pane write", async () => {
  let checks = 0;
  const { control, calls } = harness({
    assignmentRefusal: ({ nodeId }) => {
      checks += 1;
      return nodeId === "w-2" ? { code: "mcp_unverified", reason: "second stale" } : null;
    },
  });
  await assert.rejects(control.handlers.assign_task(CONDUCTOR, { task: {
    task_id: "t-1", thread_id: "th-1", objective: "review", owner_node_ids: ["w-1", "w-2"],
  } }), /second stale/);
  assert.equal(checks, 2);
  assert.equal(calls.writes.length, 0, "the first worker must not be half-assigned");
  assert.equal(calls.states.length, 0);
});

test("the pre-create assignment preflight is callable without a durable task", () => {
  const { control, calls } = harness();
  const admitted = control.handlers.preflight_assignment(CONDUCTOR, {
    worker_node_ids: ["w-1", "w-2"],
  });
  assert.deepEqual(admitted.map(({ nodeId }) => nodeId), ["w-1", "w-2"]);
  assert.equal(calls.writes.length, 0);
  assert.equal(calls.states.length, 0);
});

test("a successful assignment writes each pane, updates chrome and schedules bounded work", async () => {
  const { control, calls, timers } = harness();
  const result = await control.handlers.assign_task(CONDUCTOR, { task: {
    task_id: "t-1", thread_id: "th-1", objective: "review", owner_node_ids: ["w-1", "w-2"],
  } });
  assert.deepEqual(result.delivered.map((d) => d.node_id), ["w-1", "w-2"]);
  assert.equal(calls.writes.length, 2);
  assert.equal(calls.states.filter((s) => s.state === "BUSY").length, 2);
  assert.deepEqual(timers.map((t) => t.ms), [10, 20, 10, 20]);
});

test("deadline callbacks report structured failure and the controller can clear all node timers", async () => {
  const { control, calls, timers } = harness();
  await control.handlers.assign_task(CONDUCTOR, { task: {
    task_id: "t-1", thread_id: "th-1", objective: "review", owner_node_ids: ["w-1"],
  } });
  timers.find((t) => t.ms === 10).fn();
  timers.find((t) => t.ms === 20).fn();
  assert.equal(calls.states.at(-1).state, "STALLED");
  assert.equal(calls.states.at(-1).patch.structuredFailure.stage, "worker_task_hard_deadline");
  control.deadlines.clearNodeDeadlines("w-1");
  assert.deepEqual(control.deadlines.pendingCounts(), { workers: 0, peers: 0, debates: 0 });
});

test("message/debate handlers enforce caller identity and notify only intended nodes", async () => {
  const { control, calls } = harness();
  await assert.rejects(control.handlers.notify_message(WORKER, { message: {
    message_id: "m-1", task_id: "t-1", sender_node_id: "forged", recipient_node_ids: ["w-2"],
  } }), /sender identity mismatch/);
  const message = await control.handlers.notify_message(WORKER, { message: {
    message_id: "m-2", task_id: "t-1", sender_node_id: "w-1", recipient_node_ids: ["w-2"],
  } });
  assert.equal(message.deliveries.length, 1);
  const turn = await control.handlers.notify_debate_turn(WORKER, {
    debate_id: "d-1", participant_node_ids: ["w-1", "w-2"], turn: { node_id: "w-1" },
  });
  assert.equal(turn.deliveries.length, 1);
  assert.deepEqual(calls.notices.map((n) => n.nodeId), ["w-2", "w-2"]);
});
