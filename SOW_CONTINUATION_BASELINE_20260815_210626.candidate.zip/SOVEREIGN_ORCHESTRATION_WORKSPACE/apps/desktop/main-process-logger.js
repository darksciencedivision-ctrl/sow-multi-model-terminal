"use strict";

const fs = require("fs");
const path = require("path");

function isEpipe(error) {
  return Boolean(error && error.code === "EPIPE");
}

/**
 * Durable-first main-process logging.
 *
 * stdout/stderr are inherited pipes during self-checks. Their consumer is allowed to disappear;
 * that makes EPIPE a terminal detachment, not an application failure. Other stream failures retain
 * normal fatal visibility by being re-thrown on the next microtask unless a test observer is
 * explicitly supplied.
 */
function createMainProcessLogger({
  file,
  stdout = process.stdout,
  stderr = process.stderr,
  rendererSink = () => {},
  onNonEpipeError = null,
} = {}) {
  if (!file) throw new Error("main-process logger requires a persistent file");
  fs.mkdirSync(path.dirname(file), { recursive: true });

  let consoleAttached = true;
  let pendingWrites = 0;
  const settledWaiters = new Set();
  const observedErrors = new WeakSet();

  const settle = () => {
    if (pendingWrites !== 0) return;
    for (const resolve of settledWaiters) resolve();
    settledWaiters.clear();
  };

  const persist = (line) => {
    fs.appendFileSync(file, `${line}\n`, "utf8");
  };

  const observeNonEpipe = (error, streamName) => {
    if (error && typeof error === "object") {
      if (observedErrors.has(error)) return;
      observedErrors.add(error);
    }
    persist(`[shell] ${streamName} stream error: ${error && error.stack ? error.stack : String(error)}`);
    if (typeof onNonEpipeError === "function") {
      onNonEpipeError(error, streamName);
      return;
    }
    queueMicrotask(() => { throw error; });
  };

  const onStreamError = (streamName) => (error) => {
    if (isEpipe(error)) {
      consoleAttached = false;
      pendingWrites = 0;
      settle();
      return;
    }
    observeNonEpipe(error, streamName);
  };

  // Narrow stream handlers: EPIPE is consumed; every other stream error is surfaced.
  stdout.on("error", onStreamError("stdout"));
  stderr.on("error", onStreamError("stderr"));

  const writeConsole = (line) => {
    if (!consoleAttached) return;
    pendingWrites += 1;
    try {
      stdout.write(`${line}\n`, (error) => {
        pendingWrites = Math.max(0, pendingWrites - 1);
        if (error) onStreamError("stdout")(error);
        settle();
      });
    } catch (error) {
      pendingWrites = Math.max(0, pendingWrites - 1);
      if (isEpipe(error)) consoleAttached = false;
      else observeNonEpipe(error, "stdout");
      settle();
    }
  };

  return {
    file,
    log(message) {
      const line = `[shell] ${message}`;
      persist(line);
      rendererSink(line);
      writeConsole(line);
      return line;
    },
    async flushAndDetach() {
      if (pendingWrites > 0) {
        await new Promise((resolve) => settledWaiters.add(resolve));
      }
      consoleAttached = false;
    },
    detachConsole() { consoleAttached = false; },
    isConsoleAttached() { return consoleAttached; },
  };
}

module.exports = { createMainProcessLogger, isEpipe };
