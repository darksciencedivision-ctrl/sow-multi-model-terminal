"use strict";
/**
 * Node mirror of control_plane/ipc/envelope.py — the shell side of the D-IPC-01 contract.
 *
 * The Python reference is authoritative; this file exists ONLY so the desktop shell
 * (a Node/Chromium main process) computes byte-identical envelopes and integrity tags.
 * Two independent checks must pass before anything acts on a message (fail-closed):
 *   1. structural: it is a well-formed envelope@1.0 (the gateway re-validates against
 *      schemas/message.schema.json — we build to that shape, never trust our own claim);
 *   2. integrity: integrity === hmac_sha256(shared_key, canonical(payload)).
 *
 * Canonicalization matches Python's json.dumps(payload, sort_keys=True,
 * separators=(",",":"), ensure_ascii=False) for the payloads this channel actually carries:
 * objects with string keys and string/bool/int-or-null values (control ops). It is verified
 * byte-for-byte against the real Python gateway by the round-trip test (a Node-signed
 * envelope is accepted, and the gateway's reply verifies under the same key).
 *
 * Known, deliberately-unrelied-on edges where JS and Python could differ — and where the
 * difference is SAFE because it only makes a signature fail to verify (fail-closed): floats
 * (Python emits "1.0", JS "1") and astral-plane object keys (UTF-16 vs code-point sort).
 * This channel sends neither; if a future op needs them, add a cross-language numeric test
 * before relying on the tag rather than trusting these two encoders to agree.
 */
const crypto = require("node:crypto");

/** Deterministic canonical form the HMAC is taken over. Mirrors Python's sorted-key,
 *  compact, UTF-8 encoding exactly (recursively sorted object keys). */
function canonicalPayload(payload) {
  return Buffer.from(_canonicalize(payload), "utf8");
}

function _canonicalize(value) {
  if (value === null || typeof value !== "object") return JSON.stringify(value);
  if (Array.isArray(value)) return "[" + value.map(_canonicalize).join(",") + "]";
  const keys = Object.keys(value).sort();
  return "{" + keys.map((k) => JSON.stringify(k) + ":" + _canonicalize(value[k])).join(",") + "}";
}

function computeIntegrity(key, payload) {
  return crypto.createHmac("sha256", key).update(canonicalPayload(payload)).digest("hex");
}

/** Constant-time verification — a wrong signature cannot advance (mirrors hmac.compare_digest). */
function verifyIntegrity(key, envelope) {
  const expected = computeIntegrity(key, envelope.payload);
  const got = String(envelope.integrity || "");
  if (expected.length !== got.length) return false;
  return crypto.timingSafeEqual(Buffer.from(expected, "utf8"), Buffer.from(got, "utf8"));
}

/** Build a fully-signed envelope. integrity is computed here, never by callers. */
function makeEnvelope({ fromNode, to, msgType, payload, nodeCredential, scope, key,
                        taskId = null, payloadSchema = "control_event@1.0" }) {
  return {
    msg_id: crypto.randomUUID(),
    ts: new Date().toISOString(),
    schema: "envelope@1.0",
    from_node: fromNode,
    to,
    type: msgType,
    task_id: taskId,
    payload_schema: payloadSchema,
    payload,
    auth: { node_credential: nodeCredential, scope },
    integrity: computeIntegrity(key, payload),
  };
}

module.exports = { canonicalPayload, computeIntegrity, verifyIntegrity, makeEnvelope };
