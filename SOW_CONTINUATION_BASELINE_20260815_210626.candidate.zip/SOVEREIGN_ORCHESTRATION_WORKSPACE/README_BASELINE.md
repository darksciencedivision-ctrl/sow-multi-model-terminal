# Sovereign Orchestration Workspace continuation baseline

This archive is a continuation baseline and context carrier, not a customer distribution. It captures the current working-tree bytes, including accepted but uncommitted Phase 19.10 material, without Git metadata or operator-private runtime state.

## Restore and start

1. Extract the single `SOVEREIGN_ORCHESTRATION_WORKSPACE` directory to a writable location.
2. From `apps/desktop`, run `npm ci` to restore Node dependencies from `package-lock.json`.
3. From that same directory, run `npm.cmd start`. On the observed Windows host, PowerShell execution policy blocks bare `npm`, so use `npm.cmd`.
4. Use `py -3.12` for Python. Restore development dependencies from `requirements-dev.txt`; `jsonschema` and `pytest` are required, and several tests are gated on Python 3.12 and skip under other interpreters.

The external runtime dependencies are the host's own already-authenticated provider CLIs: `codex`, `claude`, `grok`, and `agy`. None is bundled. No credentials are included or required by the package itself.

Live operation is **denied by absence** because `config/live_operation.json` is intentionally excluded. Only the operator may create or edit that authorization switch, using `config/live_operation.example.json` as the starting point.

Mutable runtime state is created on first start under `.sovereign_store/` and the gitignored `apps/desktop/.*` runtime directories. Operator conversation, lease, node, and model-probe history are not included. The empty model-probe ledger means Claude selections report `source: unprobed` until probes repopulate it. The one known host mapping, `fable-5 -> claude-fable-5`, is therefore not carried by this package. `unprobed` is current behavior, not evidence of fail-closed model validation; see finding F3 in `STATE_OF_THE_WORKSPACE.md`.

Read `STATE_OF_THE_WORKSPACE.md` first for the authoritative continuation position. `WORKTREE_PROVENANCE.patch` records the tracked delta from the stated HEAD for provenance only; never apply it blindly. The untracked Phase 19.10 evidence file is packaged directly and is not represented by that patch.
