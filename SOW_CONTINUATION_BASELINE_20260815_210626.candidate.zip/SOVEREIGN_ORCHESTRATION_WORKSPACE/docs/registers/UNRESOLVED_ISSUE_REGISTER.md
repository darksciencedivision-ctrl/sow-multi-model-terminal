# UNRESOLVED-ISSUE REGISTER — Sovereign Orchestration Workspace
Seeded at Phase 0 (2026-07-16) from Architecture Plan v1.0.1 §14.3 (U1–U12). These are
**empirical unknowns**, each owned by the phase that can actually measure it. None blocks
Phase 0. Entries are never deleted; resolution appends a dated note + evidence ref.

| # | Issue | Owner phase | State |
|---|---|---|---|
| U1 | Parakeet streaming latency + VRAM under concurrency (Track G) | P12 spike | OPEN |
| U2 | Windows mic capture → WSL bridge design + PTT trigger mechanism | P12 spike | OPEN |
| U3 | Codex automation/ToS constraints for programmatic session launch | P6 / R4+R8 | OPEN |
| U4 | CC-BY-4.0 attribution mechanics if product ships | P12 | OPEN |
| U5 | Provider per-account concurrency allowances (only if raising I-X3 above 1) | R8 | OPEN |
| U6 | MCP transport final choice per profile | P3A / R6 | OPEN |
| U7 | Conflict mechanism confirmation (D-MCP-03) | P3A | OPEN |
| U8 | Conductor-file schema/versioning + per-file write authority | P0→P3A | **FIRST PASS DONE P0** — see docs/CONDUCTOR_FILES_WRITE_AUTHORITY.md; refine at P3A when MCP resources exist |
| U9 | ConPTY behavior hosting full-screen TUIs (OpenCode) in panes | P1 | OPEN — spike scenario included in rig |
| U10 | NTFS ACL granularity vs worktree churn; per-process egress deny on Windows | R7/P10 | OPEN |
| U11 | Succession snapshot cadence tuning (event set + interval) | P11 | OPEN (default: major events + 5 min) |
| U12 | Framework RAM envelope at 8+ panes (Electron vs Tauri) | P1 | OPEN — measured by operator's Windows run |

## Build-environment notes (not product issues; recorded for traceability)

| # | Note | Impact | Mitigation |
|---|---|---|---|
| E1 | Cowork Linux-sandbox mount corrupts git lock/rename writes; deletes required explicit permission | Build-session git only | git-dir sandbox-local during sessions; `.git/` mirrored by plain copy after gate commits; `git fsck` verification; native Windows git unaffected |
| E2 | ConPTY/Electron cannot execute in the Linux sandbox | P1 metrics cannot be self-run | Rig + one-command runner + metrics capture delivered; **operator runs on Windows host**; headless logic tests run in sandbox |
| E3 | Sandbox Python is 3.10 (plan target 3.12) | None at P0 (manifest tooling is 3.10-compatible) | Record; control-plane phases target 3.12 on the operator host |

**U9 update (2026-07-16, P1 autorun):** OPEN-QUALIFIED — ConPTY delivers resizes correctly and
immediately (mode-con proof); Node-child tty (columns/getWindowSize) stays stale under ConPTY
(diagnostics: tools/spike_compositor/test/manual_*.js); rig TUI now queries mode con. A real
console-subsystem coding TUI (OpenCode) still unexercised — re-verify at P6/P10.

**U12 update (2026-07-16, P1 autorun):** MEASURED on Electron — peak RSS 470 MB @6 panes,
587 MB @8 panes, CPU ≤1.5% (docs/evidence/PHASE1_SPIKE_REPORT_20260717T022713Z.json).
Tauri comparison not required (no kill criterion triggered); reopen only if a later phase
surfaces an Electron disqualifier.

**E4 (build-environment note, 2026-07-16):** Electron postinstall on the operator host failed
silently (dist/ contained only locales/); binary extracted manually from the intact npm cache
zip; node-pty win32-x64 prebuilds present. Product impact: none (rig tooling only).

**U10 update (2026-07-17, P3):** node runtime containment landed at two layers —
ENFORCED: Job Object process-tree kill (KILL_ON_JOB_CLOSE) + runtime-API workspace path
containment (absolute/dotdot/junction/device-name/ADS/drive-relative all refused+logged).
NOT ENFORCED (stays OPEN for P10): OS-level fs/network denial for a raw-syscall bypass;
assign-after-spawn race (product pattern CREATE_SUSPENDED->assign->resume). Evidence:
docs/evidence/PHASE3_EVIDENCE_REPORT.md.

**U13 (new, 2026-07-17, P3):** local gate `claims_cite_evidence` verifies evidence-ref
PRESENCE, not that refs RESOLVE to real entries; `no_placeholders` is substring-based.
Owner phase P3A (ref resolution needs the MCP CAS/memory) / P8 (gate service). State: OPEN.

**U6 update (2026-07-17, P3A):** MCP transport RESOLVED-FOR-NOW as a stdlib newline-JSON
loopback protocol (mcp_server/protocol.py) — the official MCP SDK is not installable (pip
out of the build's permitted network scope). Registered in .mcp.json with the caveat.
Swapping to the MCP SDK later is an adapter change behind mcp_server. State: OPEN (SDK
adoption deferred), transport functional.

**U14 (new, 2026-07-17, P3A):** memory@1.0 provenance SHAPE is enforced, but timestamp
FORMAT (date-time) is not — jsonschema needs rfc3339-validator (pip, out of scope) to check
the date-time format; format_checker is currently inert for date-time. Owner: whenever the
validator lib becomes available. State: OPEN (low risk; shape enforced).

**U15 (new, 2026-07-17, P3A):** invariant 18 ("no node solely judges its own work") is not
structurally enforced at the memory layer — a gate/operator identity can promote an entry it
authored (policy does not compare approver to provenance.author_node). Owner phase: P7
(Debate Service) / P8 (Gate engine), where independent judgment is the core concern. State: OPEN.

**U16 (new, 2026-07-17, P4):** Plan §12.2 "broker mediation (out-of-profile action blocked +
logged)" conformance leg not exercised at P4 (it is a Node-Runtime-supervisor concern). Owner
phase: P5 (conductor + workers) / P10 (coding worktree). State: OPEN.

**U17 (new, 2026-07-17, P4):** MockReasoningBackend decision seeds on conductor-file NAMES,
not their content — the mock decision does not vary with file content. Acceptable for the
Phase-4 mock; revisit when a real backend replaces it. State: OPEN (mock-quality note).

**U16 CLOSED (2026-07-17, P5):** §12.2 broker-mediation conformance leg re-checked at Phase 5
— every worker action (get_content/publish/transition) transits control_plane.policy; no
bypass. Closed.

**U18 (new, 2026-07-17, P5):** scheduler ranking uses benchmark_score placeholder (default
0.5) until Phase 6 Track E/R10 real benchmarks; resolver locality enforces only local_only
(any/frontier_ok both permit, which is correct). Owner phase: P6. State: OPEN (placeholder).

**U19 (new, 2026-07-17, P6):** full Track E/R9/R10 offline-roster freeze deferred — the light
roster probe (docs/evidence/PHASE6_ROSTER_PROBE.json) is real but minimal; static capability
descriptors (min_context/tool_use/structured_output) are asserted, not verified against the
bound model. Full benchmark (multi-task, tool-call reliability, long-context, VRAM sizing,
24B+ scale path) is GPU-heavy, out of the loop budget. benchmark_score stays 0.5 placeholder
(resolver rank-by-benchmark inert; selection is by hard-requirement filter). Owner: operator
Track E campaign. State: OPEN (deferred).

**U15 CLOSED (2026-07-17, P7):** invariant 18 (no node solely judges its own work) enforced
in the Debate Service — the resolved participant set must include a node other than the caller
or the request is refused. Note: the memory-layer approver!=author check (a gate promoting an
entry it authored) remains a P8 concern for the gate engine.

**U20 (new, 2026-07-17, P7):** when a per-debate budget is clamped to the caller's remaining
quota, the frozen debate@1.0 record (additionalProperties:false) cannot carry a separate
effective-budget field; it is conveyed via outcome + cost_actual. Owner: schema-owner if a
future debate@1.1 adds effective_budget. State: OPEN (observability nicety).

**U15 FULLY CLOSED (2026-07-17, P8):** invariant 18 (no node solely judges its own work) now
enforced on BOTH halves — the Debate Service (P7: caller != sole judge) and the memory layer
(P8: a gate may not promote via transition NOR publish its own work product into a promoted
state; operator exempt as human final authority).

**U21 (new, 2026-07-17, P8):** the plan references an operator state-force override path
("only the operator may force a state, logged"); it is NOT implemented — the task state
machine is currently absolute for all callers and recovery from a gate FAIL is redo-and-repass.
Owner phase: P11 (persistence/recovery) or an operator-console phase. State: OPEN (design note).

**U22 (new, 2026-07-17, P9):** the scoped ContextCompiler is proven as a capability (real
worker MCP client in tests) but not yet wired into the live conductor->worker dispatch loop
(conductor_prototype still passes an objective entry ref directly). Owner phase: a later
integration pass. State: OPEN (capability complete, live wiring deferred).

**U10 update (2026-07-17, P10):** worktree isolation ENFORCED at git-worktree separation +
API-layer path containment + controlled-merge gating. NOT enforced: OS-level fs/git-ref denial
between SAME-USER node processes (shared .git object/ref store; a raw-syscall/own-git bypass is
possible) - needs restricted tokens/separate accounts/admin. Owner phase: P13 hardening. State:
OPEN (API-layer complete, OS-layer deferred, disclosed).

**U11 CLOSED (2026-07-17, P11):** succession cadence finalized = major events (task-graph
mutation, gate verdict, debate close, node spawn/terminate, memory-head advance, profile change)
+ bounded interval (default 5 min, tunable) via should_snapshot(). Snapshot is an immutable MCP
entry with integrity hash.

**U23 (new, 2026-07-17, P11):** the succession event-tail check assumes memory_heads is the
COMPLETE set of ACCEPTED head refs the conductor tracks; if the project holds ACCEPTED entries
not tracked as memory-heads, reconstruct flags event_tail_current=False with no real
post-snapshot activity (a false positive that fails SAFE toward reconciliation, never silent
loss). Confirm/tune the comparison basis before real multi-entry projects. Owner: integration
pass. State: OPEN (fail-safe).

**U1/U2 update (2026-07-17, P12):** voice adapter shipped with MockSTT behind the I-A1
interface (host has NVIDIA GPU + WSL but NeMo absent; pip out of scope). Real Parakeet
integration - streaming latency, VRAM under concurrency (U1), Windows mic->WSL bridge + PTT
trigger (U2) - remains OPEN-FOR-HARDWARE (Track G).

**U24 (new, 2026-07-17, P12):** voice command classification keys on the VERB; real command
dispatch is not wired (control events are logged, not executed) - add a target-scope check when
dispatch lands. Real-audio buffer-free transcribe-then-discard (T12) proven only at the
ref-counter level with MockSTT; a real-audio buffer-free path is a Track G integration test.
State: OPEN.

**U25 (new, 2026-07-18, P14A):** the shell<->control-plane IPC bridge (`McpControlSurface`,
`control_plane/ipc/gateway.py`) authenticates the IPC node per-connection but forwards to MCP
under a single pre-configured MCP credential, so MCP currently sees ONE identity for all IPC
nodes. Safe today because the bridge exposes only read-only diagnostics (`health`,
`read_status`). Before this surface (or any IPC bridge) may carry WRITE ops, an IPC->MCP
per-node credential broker is required so MCP applies policy to the real node identity
(preserves per-node scoping I-8/I-9). Owner: a later 14A/14E sub-step. State: OPEN
(read-only-bounded).

**U26 (new, 2026-07-18, P14A.shell):** OS-level containment is not yet wired from the desktop
shell's Node process. The shell (`apps/desktop/`) enforces the GOVERNANCE gate — a ConPTY
session is only admitted while the shell holds a verified authenticated control-plane channel
(`apps/desktop/supervisor.js`), every lifecycle event is reported, and all sessions are torn
down on channel loss (no naked sessions, invariant 2, fail-closed) — but it does NOT yet assign
the PTY pid to the Node Runtime's Windows Job Object (`node_runtime/supervisor/containment.py`,
kill-on-job-close, invariant 29). That pid->job handoff needs the IPC surface to carry a WRITE
op, which is blocked on the U25 per-node credential broker. Until then, kernel-level
kill-on-close containment remains the Node Runtime's (exercised in Phase 3/10), NOT the shell's.
Honestly recorded in `apps/desktop/supervisor.js` and the P14A.shell evidence report. Owner: a
later 14A sub-step (after U25). State: OPEN (governance-gated, OS-containment-deferred).


**U27 (new, 2026-07-18, P14A.inspector):** `gate@1.0` structured verdict records are computed by
`control_plane/gates/engine.py` (`GateEngine.evaluate`) to drive the in-memory `TaskGraph`, then
DISCARDED — there is no store table and no MCP/IPC read op that returns a `gate@1.0` record
(verified: `mcp_server/server.py` dispatch has none). Durably, a gate decision surfaces only as a
`kind:"decision"` memory entry (`control_plane/orchestration/conductor_prototype.py`) and a stage
promotion stamps `provenance.gate_result` (`mcp_server/memory_service.py`). The §10.3 inspector
therefore RECONSTRUCTS the gate chain from decision entries + `gate_result`, marking every row
`derived:true` (never presented as a native verdict; `verdict` null when `gate_result` absent).
A durable `gate@1.0` store + read op would let the inspector show native gate verdicts instead of
derived rows. Owner: a later phase (gate persistence). State: OPEN (derived-read-honest).

**U5 update (2026-07-18, P14B.r8tos):** R8 ToS/concurrency verification recorded for the one
authorized live provider, **Claude Code** (`docs/evidence/R8_TOS_VERIFICATION_CLAUDE_CODE.md`).
**No publicly documented per-account concurrent-session allowance** for consumer subscription auth;
usage is bounded by rolling usage limits, not a published concurrency count. Per §18.3 ("never
raises concurrency on inference or silence"), `verified_concurrency_allowance(claude_code)` STAYS
the fail-closed default **1** (I-X3, matches OP-4/OP-5 `terminals:1`); `SubscriptionGovernor` is
unchanged. Raising above 1 needs a provider **support confirmation** (`[OPERATOR]`, deferred to
`.adapter`). State: OPEN (verified-at-1; raise-branch moot for this build).

**U3 note (2026-07-18, P14B.r8tos):** Codex is **NOT** an authorized live provider (only Claude
Code is, register OP-5); its automation/ToS R8 is **out of scope** for Phase 14 and is not
performed. State: OPEN (out of scope — no Codex live path exists or is authorized).

**U3 update (2026-07-19, P15A.r8):** SUPERSEDED by register **OP-6** (directive §11) — Codex
(`openai_codex_cli`) is now one of **two** authorized live providers. Its R8 ToS/automation record
is **RECORDED**: `docs/evidence/R8_TOS_VERIFICATION_OPENAI_CODEX.md` (Codex CLI is OpenAI's
first-party agentic CLI, non-interactive `codex exec` is its intended mode under a ChatGPT
subscription OAuth login; wrapped-orchestrator interpretation is the residual `[OPERATOR]` live-terms
item at 15C; `AGENTS.md`/`~/.codex` config treated as node-controlled untrusted input T2, to be
pinned at 15C like U30). No live call, no credential handling this sub-step. State: **RECORDED
(under OP-6)** — remaining `[OPERATOR]` live-terms retrieval verified at the 15C live smoke.

**U5 update (2026-07-19, P15A.r8):** R8 record ADDED for the second OP-6 provider **Codex**
(above). Concurrency basis for the governor allowance **2** documented in
`docs/evidence/R8_OP6_CONCURRENCY_BASIS_NOTE.md`: **no verified per-account concurrency number for
EITHER provider** (both empirically **verified-at-1**, fail-closed); the effective allowance `2` is
**operator-ordered (OP-6 §11(b)), governor-capped at 2, reversible** — operator *authority*, NOT an
inferred R8 concurrency *finding*. `MAX_ALLOWANCE=2` + config clamp `[1,2]` + spawn-gate reads
`live_auth.terminals_per_subscription` keep `1 ≤ allowance ≤ 2` structurally (landed at
`phase-15a.governor`, unchanged here). State: OPEN (verified-at-1; the `2` is an operator ceiling,
not a verified allowance — a support-confirmed number would be a new `[OPERATOR]` update, still
capped at 2).

**U28 (new, 2026-07-18, P14A.inspector):** the "context routed" dimension of the §10.3 inspector
has NO read path. `ContextCompiler.compile` (`control_plane/routing/context_compiler.py`) returns a
`ScopedContext` dataclass that is never serialized, stored, or returned by any op — it exists only
in-process for the duration of an assignment. The inspector reports `routingReadable:false` and
`routes:[]` (it does NOT fabricate a bundle); `provenance.source_artifacts` on artifact rows is the
only readable need-to-know trace and is not presented as the scoped bundle. Serializing/exposing
`ScopedContext` (or persisting a routing record per assignment) would let "context routed" show the
real scoped bundle and `routingReadable` go true. Owner: a later phase (routing persistence).
State: OPEN (unreadable-declared-honest).

**Live-smoke deferral note (2026-07-18, P14B.adapter):** the live `claude_code` adapter and its
fail-closed supervised spawn path are built and mock-proven end-to-end, but the **single live
`claude` subprocess call was NOT exercised this session** — skip-with-record (directive §10.4):
`config/live_operation.json` is absent by design (the loop must not write it, inv 1) and the R8 §6
`[OPERATOR]` dated live-terms retrieval + concurrency support-confirmation are unmet in a
non-interactive session. The real `ClaudeCliBackend.generate` path is therefore proven only at the
pure command/env layer (credential invariant §2.2 tested). The `.gate` sub-step (high-stakes,
mandatory gate-validator + subscription-governor deep re-inspection) and/or an operator-authorized
run MUST discharge the `[OPERATOR]` items and run the one live smoke before any live-capability
claim. State: OPEN (live path built + gated + mock-proven; one live call owed to `.gate`/operator).

**U29 (new, 2026-07-18, P14B.gate):** the Claude Code adapter's `build_env` credential scrub
(`adapters/frontier/claude_code.py`) keys its substring family on `API_KEY`/`APIKEY`, not a bare
`_KEY` suffix (gate/phase-14b validator reservation R2). This is **not a §2.2 transmission vector
for this adapter** — the `claude` CLI consults only its documented `ANTHROPIC_*`/`CLAUDE_CODE_*`
vars, all of which are prefix-scrubbed, plus `*TOKEN*`/`*SECRET*`/`*API_KEY*` — so a hypothetical
secret named only `*_KEY` survives scrubbing but is never read/transmitted by the CLI. Owner: a
future adapter-hardening pass (defence-in-depth). State: OPEN (recorded, non-blocking; see
`docs/HARDENING_BACKLOG.md` U29).

**U30 (new, 2026-07-18, P14C.harness):** OpenCode reads provider configuration from its own config
file (`opencode.json` / `OPENCODE_CONFIG`), not only environment variables (spec-auditor note). The
credential env scrub (`adapters/coding/opencode/harness.py`) does not reach that file, so the §2.3
no-paid-path guarantee ultimately rests on the enforced local-model pin (`_require_local_model`
fail-closes any non-`ollama/*` model) plus the non-loopback `OLLAMA_HOST` drop — both now in code
and tested. A host `opencode.json` defining a cloud provider cannot cause a paid call because the
driven command is refused unless the model is `ollama/*`. Owner: `phase-14c.worktree` should
additionally pin/scope the OpenCode config (or run `--pure`) as defence-in-depth. State: **DISCHARGED
2026-07-18 (P14C.worktree)** — `adapters/coding/opencode/driver.py` writes a SESSION-LOCAL
`opencode.json` (loopback Ollama provider only) and points `OPENCODE_CONFIG` at it (set AFTER the
credential scrub so it is not itself dropped); `write_scoped_opencode_config` refuses a non-loopback
baseURL and a non-`ollama/` provider-qualified model. Config isolation no longer rests on the model
pin alone. Verified by a real live drive using the scoped config (see PHASE14C_WORKTREE_EVIDENCE_REPORT).

**U31 (new, 2026-07-18, P14C.worktree):** a small LOCAL coder model reliably COMPLETING a
multi-step, schema-correct file edit headlessly through OpenCode's Ollama/OpenAI-compatible tool
path was **not producible this session** (~10 real drives across `qwen2.5-coder:7b`,
`devstral-small-2:latest`, `qwen3-coder:30b` and several prompt strategies: tool JSON emitted as
text, `read`/`edit` called with wrong argument names / absolute paths, single-turn stops,
acknowledge-and-stop). This is a **model-quality** limitation of local coders, NOT a
harness/governance/isolation defect — OpenCode's real drive + real tool EXECUTION (a captured
`{"type":"tool","tool":"read",...}` event) + worktree confinement + U30 config isolation are all
proven, deterministically and live. Owner: `phase-14c.gate` / 14E — a landed live edit needs a
better agentic local model, tool-schema shaping, or a multi-turn budget; `.gate` must NOT claim a
live landed edit / live controlled merge unless a real model edit is actually produced and shown
(gate-validator reservation). State: OPEN (non-blocking; deterministic path proves the
modification-detection + tests-run legs; see `docs/HARDENING_BACKLOG.md` U31).
**Update 2026-07-18 (P14C.gate, iter 26):** the `.gate` phase gate HONORED the reservation — it did
NOT claim a live landed edit or live merge. The live `.gate` chain again spawned OpenCode for real
(`ollama/qwen2.5-coder:7b`, cost 0, confined) but the local coder landed no edit
(`edit_completed=False`), so the CANDIDATE→node-local-gate→publish→controlled-merge→ACCEPTED chain was
proven with a **deterministic seeded edit** recorded as `from_live_model=False`
(`adapters/coding/opencode/candidate.py`, `tests/integration/test_opencode_candidate_live.py`). The
governed path is the system under test and is fully proven; a live landed edit is NOT required for the
14C gate. Re-owner: 14E (assembled run) and hardening. State stays OPEN (non-blocking).

**U1/U2 update (2026-07-18, P14D — FAILED ENTRY ATTEMPT, skip-with-record):** Phase 14D (Real
Parakeet/NeMo, directive §9/§10.3) was NOT executable in this non-interactive session. Decisive host
probe (`adapters/voice_parakeet/engine.detect_voice_stack()` under `py -3.12`):
`{nvidia_gpu:true, wsl:true, nemo:false}` ⇒ `real_parakeet_available()=False` — the REAL NeMo engine
is not installed (not importable). WSL itself is inaccessible to this loop: every `wsl.exe` call is
approval-denied (non-interactive, no approver), so the operator-authorized (OP-4/OP-5, §10.3) WSL
pip/NeMo install cannot be performed here, `nvidia-smi` inside WSL cannot be checked, and no real
transcription can run. **U1** (Parakeet streaming latency + VRAM under concurrency) and **U2** (Windows
mic→WSL bridge design + PTT) therefore stay **OPEN-FOR-HARDWARE** — measurable ONLY in an operator-run
Windows+WSL2+GPU session that installs NeMo, downloads the CC-BY-4.0 checkpoint, and drives a live-audio
mic bridge; a headless loop has no live audio input to measure. Nothing was faked or synthesized; the
Phase-12 MockSTT path (gate/phase-12) is NOT a valid substitution for 14D's real-engine requirement
(§6). Owner: Track G / operator hardware run. State: OPEN (14D skip-with-record; see
docs/evidence/PHASE14D_EVIDENCE_REPORT.md).

**U4 note (2026-07-18, P14D):** the CC-BY-4.0 Parakeet checkpoint was **never downloaded** this session
(WSL/NeMo install not executable), so CC-BY-4.0 attribution mechanics are not yet exercised and §10.3's
checksum/source-URL recording is moot (recorded as unused). U4 stays OPEN — required only if/when the
real checkpoint is fetched in an operator-run session. State: OPEN.

**P14E.run note (2026-07-19, phase-14e.run — PASS, sub-step, no gate tag):** The assembled
end-to-end scenario (`tools/assembled/run.py`) was proven over a real loopback MCP server: governed
coding CANDIDATE→gate→merge→ACCEPTED (promoted by a different node, inv 18 — now also proven live by a
negative self-promotion test), one bounded debate (≤5 rounds, dissent preserved, non-conductor caller),
conductor replacement into a different mock model (zero loss), and a full MCP process restart + zero-loss
recovery over the same durable store. 471/471 pytest green. **U31** (a live local-coder LANDED edit)
stays **OPEN** — the coding edit is a deterministic seeded stand-in (`from_live_model=False`), never
claimed as a live model edit. gate-validator PASS with two **non-blocking** reservations owed to
`.gate`: **(R1, low)** a latent `roster_report` label edge — if OpenCode were absent but a coder model
present, `coding_worker` would read `LIVE` while the run's edit is always seeded; it does NOT manifest on
this host (OpenCode detected ⇒ `DETERMINISTIC_SUBSTITUTE`, correctly excluded from `live_roles`) — the
`.gate` reviewer should confirm the label/edit-origin distinction stays honest. **(R2, informational)**
the one genuinely-live leg is the roster Ollama smoke receipt, not an end-to-end live governed pipeline;
the report states this plainly. Owner: `.gate` reviewer. State: OPEN (both reservations non-blocking).

**2026-07-19 — `phase-14e.gate`: R1 and R2 RESOLVED (both non-blocking, confirmed at the phase gate).**
**R1 (roster label edge):** confirmed it does NOT manifest on this host — OpenCode `1.17.13` is
detected, so `roster_report.assembled_roster` takes the `if have_opencode and coder_model:` branch
and classifies `coding_worker=DETERMINISTIC_SUBSTITUTE`, correctly EXCLUDED from `live_roles`
(receipt: `live_roles=['local_reasoning_worker']`). The latent `elif coder_model:` LIVE-direct edge
(a host with a local coder but no OpenCode binary) is honest for THAT host — a real single-shot
Ollama coder produces the output — and even there the assembled run's merged edit stays a seeded
stand-in (`from_live_model=False`); the label describes the backend that produces the role's
governed output, edit-origin is reported separately. No overclaim in either case. The mandatory
gate-validator independently re-verified this branch. **R2 (one live leg is a receipt):** stated
plainly in both `FINAL_PRODUCT_REPORT.md` §2 and `PHASE14E_EVIDENCE_REPORT.md` — the single
genuinely-live model execution is the item-7 Ollama smoke receipt (`qwen2.5:7b-instruct`,
`generated=true`), NOT an end-to-end live governed pipeline; every other leg is mock/deterministic
by design or prohibition. Both closed at `gate/phase-14e` (PASS_WITH_RESERVATIONS). Owed items that
remain OPEN (tracked here + HARDENING_BACKLOG): the single live `claude` frontier smoke, U31
(no live local-coder LANDED edit), U1/U2/U4 (open-for-hardware, 14D), U5/U29 (non-blocking).

**U32 (new, 2026-07-19, P15C.adapter):** the live Codex adapter (`adapters/frontier/codex.py`)
preserves `CODEX_HOME` in the child env of `codex exec` — deliberately, because relocating it and
copying `auth.json` would BE credential handling (§2.2), and the OAuth path the subscription mode
depends on lives under that dir. The residual surface is a host `~/.codex/config.toml` (pointed to
by `CODEX_HOME`) that could declare an MCP server, a hook, or a `model_provider` base URL the
adapter's CLI flags (`--sandbox`, `-m`, `--cd`) do not override. This is **host-operator-sourced
`os.environ`, NOT node-controlled** input (distinct from the node-controlled `AGENTS.md`/workspace
config, which the explicit sandbox flags DO contain — T2), and it is already recorded in-code
(codex.py `.adapter` header) as a live-run item. The preserved `HTTP(S)_PROXY`/CA-bundle vars are
the same host-trust surface, inherited verbatim from the gated `claude_code` template. Owner:
`phase-15c.gate` / the live-run egress review — pin/scope or audit the host `config.toml` (e.g. a
session-local `CODEX_HOME` populated ONLY by pointing at the existing auth dir, or a documented
egress check) before the first real `codex exec`. State: OPEN (non-blocking; no secret transmission
— the env scrub removes every credential/endpoint var, and no live call is made this session).

## U33 — Conductor selection label vs executing checkpoint id: no mapping exists yet

Opened 2026-07-19 (`phase-15d.selection`). The operator's conductor SELECTION is an interface label
(`fable-5`, invariant 3); a live `claude` reply reports a full checkpoint id (e.g.
`claude-fable-5-<date>`). `ConductorBinding.label_mismatch()` therefore reads **true on a correct
live run** — it surfaces the label/checkpoint pair for the operator rather than adjudicating it,
because no label→checkpoint mapping is established anywhere. The mapping is a fact the FIRST live
smoke supplies (owed with the R8 §6 `[OPERATOR]` live-terms item). Fail-safe direction: it
over-reports; an unverified value is never reported as a mismatch. Owner: `phase-15d.gate` / the
first live conductor smoke — record the observed checkpoint id for each operator-named model and
decide whether the mapping belongs in the roster descriptor or stays deliberately un-adjudicated.
State: OPEN (non-blocking; nothing is fabricated and both values are recorded).

## U34 — A restored conductor selection is indistinguishable from a fresh operator choice

Opened 2026-07-19 (`phase-15d.selection`, spec-audit F4). After a succession, restoring the
operator's selection writes `reason: "operator_selected"` — but the restore is performed by the
software, with no operator act in that loop. The frozen `checkpoint@1.0` enum offers only
`{operator_selected, offline_mode, succession}`, so there is no `restored` value to write and this
cannot be fixed in code without touching a frozen schema (out of scope, `docs/canonical/` and
`schemas/` are frozen @1.0). Related: `control_plane/recovery/succession.py` stamps the successor's
`since` with `_now_iso()`, ignoring an injected `reconstruct(now=...)`, so under a test clock the
record's `since` disagrees with the staleness checks computed from `now`. Owner: `phase-15d.gate` —
either record the restore explicitly in the decision register at the moment it happens (operator
authority is then traceable outside the enum), or raise a schema-amendment decision. Also carried:
**F1** — the published CANDIDATE decision writes the selection label into its `model` field when
nothing executed (`model_verified: false` and `model_selection` sit beside it, so it is not silent),
and `ConductorAdapter` provenance sets `model` unconditionally with no verified flag; pre-existing
to 15D and the last place the `.selection` MAJOR-2 shape survives. State: OPEN (non-blocking; no
value is fabricated and every record carries its verification flag).

## U35 — Per-task scoped context is not delivered to workers

Opened 2026-07-19 (`phase-15d.flow`, spec-audit MINOR-7). The conductor's decomposition drives the
task graph, the declared ordering and the capability routing — all real and tested. But every
assigned worker is handed the **objective** entry as its context ref
(`LiveGovernedFlow._run_wave`: `worker.adapter.assign(a.task_id, objective_entry)`), not a per-task
scoped entry carrying `DecomposedTask.description`. `LocalWorkerAdapter.execute` therefore emits
`"Result for {task_id}"` and every task artifact is identical modulo task id: the decomposition is
consumed for **routing and ordering**, not for the **work content**.

This does not violate invariant 8 — context is still an MCP reference, correctly scoped by
reference and never a forwarded transcript — and nothing is fabricated. It is a completeness gap,
and the module docstring states it explicitly rather than letting the headline claim ("the
decomposition is actually consumed") stand unqualified.

Owner: `phase-15d.gate` or later. Fix shape: publish a per-task scoped context entry (description
plus the objective ref) at assignment time and hand the worker that ref, so a CANDIDATE artifact
reflects the subtask the conductor actually proposed. Blocks nothing today; it does bound how much
the mock-first proof says about real multi-model division of labour.
State: OPEN (non-blocking; disclosed in code, not papered over).

## U36 — `control_plane/orchestration/live_flow.py` imports vendor adapters at module scope

Opened 2026-07-19 (`phase-15d.flow`, gate-validator round 2 R6). The module hard-imports
`adapters.frontier.claude_code` and `node_runtime.supervisor.conductor_spawn.spawn_claude_code_conductor`,
and the **mock** factory calls `resolve_claude_model_ref`. This is structurally the same shape the
`.selection` audit raised as MAJOR-1 ("vendor adapter welded into the generic selection layer"),
which was fixed there with an injectable resolver — reintroduced one directory over.

Mitigating and verified: the **governed path** (`LiveGovernedFlow`) takes an injected
`ConductorHandle` and contains no vendor branch; the coupling is confined to the two convenience
factories (`mock_conductor_handle`, `live_conductor_handle`). The import has no cloud side effect
and the suite is green. Both the validator and the spec-auditor judged the carry defensible for
this sub-step. Invariants 3/4/20. Owner: `phase-15d.gate` — either inject the resolver and the
spawn callable the way `control_plane/conductor/selection.py` does, or record why this module is
legitimately allowed the direct dependency.
State: OPEN (non-blocking; no runtime breach, architectural drift only).

## U37 — Debate participant capability descriptors are DECLARED, not Scheduler-resolved

Opened 2026-07-20 (`phase-15d.debate`). `DebaterSpec.capability` names each participant by capability
descriptor (invariant 4 / I-SC1 — never by node or vendor name), and the frozen `debate@1.0` schema
enforces the shape. But the descriptor is supplied by the CALLER and matched against no roster: every
debater binds to the same `claude_code` reasoning terminal, so a descriptor saying `coding` records
what was ASKED FOR, not a capability-matched selection. Descriptor-based *selection* — what
`live_flow` does through the Scheduler — is not wired here. Disclosed in the dataclass docstring.
Owner: `phase-15d.gate` or later.
State: OPEN (non-blocking; the invariant-4 shape holds, the selection semantics do not).

## U38 — Invariant 18 distinctness is by node id and backend object identity only

Opened 2026-07-20 (`phase-15d.debate`). "No node solely judges its own work" is enforced by unique
debater node ids, a refusal when two specs share ONE backend instance, and the `DebateService`'s own
`participants - {caller}` check. Two SEPARATE instances of the same model remain indistinguishable,
so a debate between two identical backends passes every check. Combined with U44 that is the expected
shape of a live 15D debate today. Fix shape: compare resolved model refs, not object identity.
Owner: `phase-15d.gate` or later.
State: OPEN (non-blocking; disclosed in code at the guard site).

## U39 — `cost_actual` is a synthetic governed unit, not provider metering

Opened 2026-07-20 (`phase-15d.debate`). The per-round charge is a fixed governed unit (`round_cost`),
so the debate request declares `budget: {usage_units: N}` rather than `tokens` — an immutable record
saying `cost_actual: {"tokens": 100}` would misstate what the number is. `cost_actual` bounds the
debate deterministically; it is NOT a spend figure. Real provider-token metering needs the CLI to
report usage and the backend to surface it. Relatedly `max_tokens` is accepted by
`ClaudeCliBackend.generate` and IGNORED (`build_command` emits no output-length flag), so the debate's
own token ceiling is not enforced at the provider. Owner: live metering work.
State: OPEN (non-blocking; the record says what the number is, so nothing is misread).

## U40 — Two published `@1.0` envelopes have no schema in `schemas/`

Opened 2026-07-20 (`phase-15d.debate`; applies equally to `phase-15d.flow`). `debate_report@1.0`
(this unit) and `acceptance_packet@1.0` (`.flow`) are published as shared MCP entries and carry a
`schema` field, but neither has a file in `schemas/`, which CLAUDE.md declares the single source of
truth for envelopes. Both are guarded instead by a pinned key-set constant checked at build time
(`DEBATE_REPORT_KEYS`, `ACCEPTANCE_PACKET_KEYS`). Recorded as ONE item covering both so it cannot be
discharged by fixing only the newer one. The frozen set is `@1.0` and adding to it is a gate-level
decision, which is why it was not done inline. Owner: `phase-15d.gate`.
State: OPEN (non-blocking; key sets are enforced, but not by the declared source of truth).

## U41 — Debate evidence is resolved through the CALLER's MCP client, not each debater's

Opened 2026-07-20 (`phase-15d.debate`). The `EvidenceManager` resolves citations over the caller's
client, so `SUPPORTED` means "a ref the caller can resolve", not "a ref this debater was scoped to
read". Harmless today because all debaters share one `allowed_evidence` set by construction; it
becomes blocking the moment per-debater scopes diverge — which a genuinely scoped debate needs
(invariant 8). Owner: whichever unit introduces per-debater evidence scopes.
State: OPEN (non-blocking today, blocking for scoped debate).

## U42 — `_extract_json_object` is duplicated between `live_debate` and the vendor adapter, and has DIVERGED

Opened 2026-07-20 (`phase-15d.debate`). `control_plane/orchestration/live_debate.py` keeps a local
copy rather than importing the adapter's private helper (layering). The copies have already drifted:
the adapter strips a leading json language tag explicitly while this one splits on the first newline;
candidate ORDER is inverted (whole-string first here, fenced first there); and this copy accepts any
JSON value while the adapter requires a dict. Neither divergence is currently harmful — both fail
closed to "no parse" — but two parsers for one wire format will keep drifting. Fix shape: promote one
to a shared vendor-neutral helper. Owner: `phase-15d.gate` or later.
State: OPEN (non-blocking; both fail closed).

## U43 — A `live` leg trusts caller-supplied backend instrumentation

Opened 2026-07-20 (`phase-15d.debate`), after two independent reviewers refuted this unit's original
non-spoofability claim. `verification_for` now requires EXACT type (`type(b) is ClaudeCliBackend`, not
`isinstance` — a subclass overriding `generate` was previously packaged as `live`), a non-blank string
checkpoint the CLI reported, an int stamp (`reported_model_at_call`) strictly greater than a bind-time
`calls` snapshot, and evidence a call was spent. That rules out every ACCIDENTAL and every mock-SHAPED
route: subclasses, duck types, renamed classes, attribute injection, stale checkpoints from an earlier
debate, unstamped checkpoints, bool/int confusion.

It does NOT rule out deliberate falsification by the caller, and cannot: exact type constrains an
object's CLASS, not its behaviour. Three routes remain open and are accepted, not closed —
(a) forging `reported_model` + `reported_model_at_call` on a genuine backend; (b) reassigning
`__class__` so a mock reports the real type; (c) replacing `generate` on a genuine instance.

The symmetric UNDER-report vector is recorded here too: the vocabulary rests on the backend's own
`calls` counter, so a backend that spends a call without incrementing it classifies `skipped` —
under-reporting spend, the direction §6 names dishonest. `ClaudeCliBackend` counts BEFORE the
transport, so the real path is safe; `DebaterSpec.backend` is caller-supplied and unconstrained.
`live` is trustworthy exactly as far as the caller is. Owner: standing limitation.
State: OPEN (accepted limitation; stated in code, not claimed away).

## U44 — A live debate on one subscription is structurally limited to two participants

Opened 2026-07-20 (`phase-15d.debate`). Every debater acquires a terminal on the SAME
`subscription_ref`, and `SubscriptionGovernor.MAX_ALLOWANCE` is a hard cap of 2 under OP-6. So
`attempt_live_debate` supports exactly two participants against one subscription; a third always
degrades to skip-with-record. The `debaters: Sequence[DebaterSpec]` signature and the `>= 2` check
imply an N-party debate the governed path cannot deliver on one subscription. Combined with U38 (all
live specs bind `backend=None` to the same model), a live 15D debate today is necessarily one model
arguing with itself under two node ids. Owner: `phase-15d.gate` — either spread participants across
subscriptions/providers, or state the two-party limit in the API. Invariants 18/22.
State: OPEN (non-blocking; bounds what the live debate leg can demonstrate).

## U45 — `live_flow` and the conductor selection path retain the pre-fix live-classification defect

Opened 2026-07-20 (`phase-15d.debate`), raised by the spec-auditor as MAJOR. **Highest-consequence
open item from this unit.** The exact defect `.debate` fixed is still present in already-gated code
one directory over, on a path with greater consequence:

- `control_plane/orchestration/live_flow.py:_leg_for_backend` still uses subclass-permissive
  `isinstance`, so a `ClaudeCliBackend` subclass that overrides `generate` and never spawns a process
  is classified `live`.
- `control_plane/conductor/selection.py:bind_conductor_selection` sets `executing_verified` from
  `isinstance(reported_model, str) and bool(reported_model.strip())` — no type check, no freshness
  scoping, and it accepts a caller-supplied `reported_model` outright.
- `adapters/frontier/claude_code.py:ClaudeCodeConductorBackend.propose_plan` sets `model_verified`
  from `reported_model` with no freshness check — the staleness weakness 15D just fixed for debate.

Consequence: the resulting `acceptance_packet@1.0` is the artifact the gate engine can promote to
ACCEPTED, so an unverified run can carry a `live` claim further than the debate report can. NOT fixed
in this unit because `live_flow` is `.flow`-gated and `selection.py` / `propose_plan` are 15B-gated;
changing them re-opens two closed gates and exceeds one work unit (directive §3.6). `live_flow.py` is
byte-unchanged by this unit, verified. The false claim that these paths applied "the same
non-spoofable rule" has been withdrawn from this unit's tests and comments. Fix shape:
`reported_model_at_call` already exists on `ClaudeCliBackend`; apply exact-type + freshness at all
three sites, mirroring `live_debate.verification_for`. Owner: `phase-15d.gate` — MUST be discharged
there, before the phase gate closes.
State: OPEN (BLOCKING for `gate/phase-15d`; not blocking this sub-step).

---

## U46 — the successor's MODEL is never exercised in a succession

Opened 2026-07-20 (`phase-15d.succession`). `LiveGovernedFlow._synthesize` builds the acceptance
packet deterministically from MCP reads and gate records; it never calls the conductor's backend.
So the successor conducts (loads its 12 files from MCP, reads the ACCEPTED set, publishes, is
gated) while spending ZERO model calls, and its leg reads `skipped` — accurately, since the leg
vocabulary reports model SPEND, not activity.

Consequence: this unit proves the governed HANDOVER end to end; it does not prove a successor's
MODEL producing a synthesis. Closing it needs a decomposition cycle on the successor.
State: OPEN. Owner: the first live succession smoke (`phase-15d.gate` / 15E).

## U47 — the acceptance packet and the succession report state different spend for the same conductor

Opened 2026-07-20 (`phase-15d.succession`). The packet's `legs.conductor` comes from
`ConductorHandle.leg` (hard-coded `"mock"` by the mock helpers) and describes the conductor
accompanying its selection record, which after a swap is the SUCCESSOR. The succession report
classifies that same successor with the HARDENED evidence-based classifier, which reads `skipped`
(zero calls spent). Two artifacts from one run therefore disagree about one conductor.

Both are individually defensible — one reports a configured binding, the other measured spend —
but an operator reconciling them has no stated rule. Additionally the packet alone under-reports a
run in which the PREDECESSOR spent live calls before being killed; `run_spend_leg` in the
succession report is the only field that merges spend across both conductors, and the packet does
not cite the report (the packet is built first).
State: OPEN. Must be closed before a live succession, where the divergence involves real spend.

## U48 — a succession replaces the CONDUCTOR, not the run; orchestration state is not proven MCP-resident

Opened 2026-07-20 (`phase-15d.succession`), raised by the spec-auditor as MAJOR against an earlier
draft that claimed the opposite. What is replaced across the kill is the conductor (adapter +
backend + MCP session + node identity). What deliberately SURVIVES in-process is the orchestration
harness: `LiveGovernedFlow`, its `TaskGraph`, `Scheduler`, `CapabilityRegistry`, the worker adapters
and `_RunState`. That is the intended design — a successor takes over the SAME governed run
(invariant 28 / I-CN1) rather than starting a new one.

Consequence, now stated in the module rather than contradicted by it: the `task_states` half of the
zero-loss comparison reads the surviving in-process graph on BOTH sides, so it compares that object
against itself and cannot detect graph loss. It is retained as a regression detector for the
successor's wave execution, not as evidence. The LOAD-BEARING evidence is the content-hash
comparison of ACCEPTED entries, which is genuinely read back from MCP and hashed from stored bytes.
Proving conductor-side orchestration state is rebuildable from MCP requires tearing down the flow
itself and reconstructing it from the snapshot.
State: OPEN. Owner: `phase-15d.gate` (scope decision) / 15E.

## U49 — the zero-loss anti-vacuity guard is far weaker than it reads

Opened 2026-07-20 (`phase-15d.succession`), raised by the spec-auditor as MAJOR. The rule
`pre_kill_accepted_count > 0` was presented as preventing a clean verdict having risked nothing.
But bootstrap publishes the 12 conductor files with `status="ACCEPTED"`, plus the objective entry,
so a real run's pre-kill accepted set is never empty and the guard can only fire against a project
this runner cannot construct. `ok=True` alone is therefore satisfiable by preserving 12 read-only
files.

MITIGATED IN THIS UNIT, not closed: `compare_zero_loss` now emits `work_advanced` (did the accepted
set actually GROW across the succession?) and the durable claim is gated on
`earns_zero_loss_claim(report)` = `ok AND work_advanced`, pinned by mutation. The residual is that
`work_advanced` is a COUNT comparison, so it cannot distinguish "the successor completed the
remaining tasks" from "some unrelated entry was accepted concurrently".
State: OPEN (mitigated). Owner: `phase-15d.gate`.

## U50 — "resume on a DIFFERENT backend" is a label-difference refusal, not structural proof

Opened 2026-07-20 (`phase-15d.succession`), found independently by the gate-validator and the
spec-auditor against a module header claiming it was "structurally provable". The refusal in
`build_succession_report` fires only when BOTH `adapter` and `model_name` match. Neither half is
strong:

- `ConductorAdapter.capability()` returns the hard-coded literal `adapter="conductor_fable5"`
  (`adapters/conductor/adapter.py:51`) for every instance, so that half NEVER discriminates.
- `model_name` is an attribute `_mock_handle` ASSIGNS onto the backend object.

The validator demonstrated two identical `MockReasoningBackend` objects accepted as "different
backends", and a report built from caller-chosen strings with no backend object in existence. The
refusal is retained (it catches the degenerate identical-configuration case, and its mutant is
KILLED) but the module, the test docstrings and the evidence report now describe it as a
label-difference refusal. What the mock run genuinely demonstrates is a handover between two
separately-constructed adapters on two MCP sessions with two node ids — real and MCP-verifiable —
NOT interchangeability of model backends, since both are the same class.
State: OPEN. Closing it requires a succession between two genuinely different backends, which
means a live leg.

## U51 — this unit has NO live path at all, and the mock helpers must not be given a vendor backend

Opened 2026-07-20 (`phase-15d.succession`). Unlike `live_flow.attempt_live_flow` and
`live_debate.attempt_live_debate`, `live_succession` has no `attempt_live_*` entry point, no
`LiveAuthorization` consultation, no supervised spawn and no skip-with-record path keyed to unmet
live terms. A live succession is OWED, not merely un-run, and the earlier module header implying a
gated live path existed has been corrected.

Partially guarded in this unit: `_mock_handle` now REFUSES a backend whose class name is a known
vendor backend, because the helpers hard-code `leg="mock"` and mutate `model_name` — passing a real
`ClaudeCliBackend` would have recorded a genuine subscription spend as mock. The guard matches by
name (no vendor import in a control-plane module, the U36 shape) and is an accident guard, not a
security boundary; the U43 falsification limit applies unchanged.

PARTIALLY DISCHARGED 2026-07-20 (`phase-15d.succession` LIVE re-run, OP-9). A live succession is now
WITNESSED: `tools/live/run_15d_succession_live_smoke.py` (an operator-run driver, the Phase-1-spike
substitution pattern, NOT collected by `pytest tests/`) composes `LiveConductorSuccession` through
its existing `predecessor_factory` / `successor_factory` injection points, injecting a real
`ClaudeCliBackend` predecessor via `live_flow.live_conductor_handle` (which routes through the full
governed live-spawn gate set). Builder-witnessed this iteration: predecessor `leg=live`, verified
checkpoint `claude-opus-4-8[1m]`, `calls_spent=1`, killed mid-run, `zero_loss.ok=true` (15→16,
`work_advanced=true`), `handoff_order=[release, acquire]`, report gated PASS by a separate node. The
live path lives in the operator-run driver BY DESIGN — `live_succession.py` itself still has no
internal `attempt_live_*` entry point, so the "no live path in the module" observation stands as an
architectural note. `_mock_handle`'s vendor-backend refusal is unchanged (the driver uses
`live_conductor_handle`, not the mock helper, for the live predecessor).
State: OPEN (module has no internal live path — architectural, by design; a live succession is no
longer un-witnessed). Owner: `phase-15d.gate` / 15E.

## U52 — `restored_selection` records a restored SELECTION, not a re-bound conductor

Opened 2026-07-20 (`phase-15d.succession`), raised by the spec-auditor as MAJOR. `run()` calls
`restore_operator_selection`, which yields `{model: fable-5, reason: operator_selected, adapter:
claude_code}` and writes it into the durable, gate-promoted succession report. Nothing is re-bound:
no conductor on that model is started, and the conductor executing at the end of the succession is
the SUCCESSOR. An operator reading the field alone would conclude a `claude_code` conductor
finished the run — in a run that spawned no vendor CLI at all.

MITIGATED, not closed: the report now carries `restored_selection_note` stating plainly that the
selection record was restored and no conductor was re-bound (pinned by mutation). The underlying
modelling question — whether "restore the selection" in directive §11 15D means re-binding a
conductor or only re-recording the operator's choice — is a register decision, and interacts with
U34 (a restored selection is stamped `operator_selected` with no operator act, and the frozen
`checkpoint@1.0` enum has no `restored` value).
State: OPEN (mitigated). Owner: `phase-15d.gate`.

## U53 — a closed conductor retains MCP publish capability, and a closed MCP client silently reconnects

Opened 2026-07-20 (`phase-15d.succession`), raised by the gate-validator. Two facts that the
"the predecessor is dead" claim rests on, neither enforced by construction:

- `McpClient.call` auto-reconnects (`mcp_server/protocol.py:66-68`: `if self._sock is None:
  self.connect()`), so closing the predecessor's client is not a durable kill — the same token
  re-establishes a session on the next call.
- `ConductorAdapter.read_accepted` and `publish_acceptance_packet` do NOT check `_started`, unlike
  `run_cycle`. A closed conductor can therefore still publish over MCP.

The kill holds in this unit by the runner's discipline (it never touches the predecessor again) and
is now REFUSED if `is_active` survives `close()` — but it is not structurally impossible for a
corpse to act. Pre-existing adapter/protocol behaviour, load-bearing for this unit's central claim,
previously undisclosed.
State: OPEN. Owner: `phase-15d.gate` (adapter-side `_started` checks are a small, contained fix).

## U40 — AMENDMENT (2026-07-20, `phase-15d.succession`)

U40 records that `debate_report@1.0` and `acceptance_packet@1.0` have no schema file in `schemas/`,
and states it was "recorded as ONE item covering both so it cannot be discharged by fixing only the
newer one". `phase-15d.succession` adds a THIRD such envelope, `succession_report@1.0`, whose key
set is pinned in code (`SUCCESSION_REPORT_KEYS`) and asserted by test but which has no schema file
either. Appended rather than edited (registers are append-only, §2.6): **U40 now covers three
envelopes**, and the same non-partial-discharge rule applies to all three. An earlier comment in
`live_succession.py` claiming the gap was "already recorded as U40" was inaccurate at the time it
was written — the third envelope was not in scope until this amendment — and has been corrected.

---

## U45 — AMENDMENT (2026-07-20, `phase-15d.gate`): DISCHARGED

The three sites named in U45 now apply one rule, defined once in
`adapters/frontier/claude_code.py` and imported everywhere:

- `is_live_cli_backend` — exact type (`type(x) is ClaudeCliBackend`), not `isinstance`.
- `bind_calls_snapshot` / `verify_reported_checkpoint` — four conditions: exact vendor class
  (resolving a `ClaudeCodeConductorBackend` one level, by TYPE), a call spent since a bind-time
  snapshot, a non-blank checkpoint the CLI itself reported, and a stamp strictly after that
  snapshot. `calls_before=None` and an unreadable counter both fail CLOSED.

Site fixes: (a) `live_flow._leg_for_backend` uses exact type; (b) `selection.bind_conductor_selection`
verifies ONLY from an `ExecutingEvidence` — a bare `reported_model` string is inert and is recorded
as `reported_unverified`, never as `executing.model`; (c) `ClaudeCodeConductorBackend.propose_plan`
snapshots before `generate` and verifies per-call. `live_flow._rebind` and
`conductor_spawn.attempt_live_conductor_smoke` both build evidence instead of passing the raw
property. `live_debate` now delegates to the single definition.

A FOURTH site was found during review and fixed here: `live_succession` took its bind-time snapshots
with a local `_calls_or_zero` that read `.calls` un-unwrapped, so for a conductor wrapper the
snapshot (the wrapper's `propose_plan` tally) and the freshness check (the inner backend's lifetime
CLI counter) measured different counters — making a stale checkpoint verifiable. Latent, since a
live succession is owed (U51), but the same defect shape. Snapshots there now go through
`bind_calls_snapshot`.

12 mutants of the guards (builder) + 22 (validator) run; all builder mutants killed, validator
survivors addressed. Provenance added: `ExecutingEvidence.rule` names the verification and is
carried to the record as `executing.verified_by` (invariant 11) — a flat `verified: true` whose only
account of itself lived in a code comment was gating the packet's `live` leg.

**STATED LIMIT, unchanged (U43):** exact-type constrains an object's CLASS, not its behaviour. The
validator confirmed by direct probe that a genuine `ClaudeCliBackend` with `generate` replaced still
reaches `legs.conductor == "live"` with zero processes spawned — and that this unit's own positive
tests use exactly that technique, because it is the only way to exercise the verified path in a
mock-first suite. **The `live` claim is not machine-enforceable in-process.** Every accidental and
mock-shaped route is refused; a caller determined to falsify its own evidence is not.
State: **DISCHARGED** for the named sites. U43/U54 remain OPEN and bound what `live` means.

## U53 — AMENDMENT (2026-07-20, `phase-15d.gate`): PARTIALLY discharged, NOT closed

U53 records TWO facts. Only one is fixed: `ConductorAdapter.read_accepted` and
`publish_acceptance_packet` now raise `ConductorNotReady` when `_started` is False, before any MCP
call (pinned by `tests/unit/test_closed_conductor_refuses.py`, both guards mutation-killed). The
second fact — `McpClient.call` auto-reconnects (`mcp_server/protocol.py:66-68`), so closing a
client is not a durable kill — is UNCHANGED and untouched.

Following the U40 amendment's precedent (a multi-fact item cannot be discharged by fixing one
fact), U53 stays OPEN. The adapter now declines to act; the transport does not make acting
impossible.
State: OPEN (transport half). Owner: 15E / the first live succession.

## U54 — the `live` leg is not machine-enforceable, and this build's tests rely on that

Opened 2026-07-20 (`phase-15d.gate`), raised by the gate-validator as a direct probe result. Split
out of U43 because it names a consequence U43 does not: the ONLY way this mock-first suite can
exercise a verified `live` path is the U43 falsification technique itself (a genuine
`ClaudeCliBackend` with `generate` replaced). So the positive `live` contract is proven by a method
that, applied adversarially, defeats the rule.

Defence in depth exists and was verified independently: `_assert_legs_honest` (publish time) and
`LiveGovernedFlow._synthesize`'s degradation both re-require a verified checkpoint. But none of
these is a barrier against the caller. The honest statement is: `live` records what a governed
caller asserted under a rule that refuses every accidental and mock-shaped route. Only an actual
live smoke, with the process observable on the host, converts that into an observation.
State: OPEN. Owner: the first live smoke (blocked on the R8 §6 `[OPERATOR]` terms).

## U55 — the suite DOES spawn real provider CLIs; "no live call" needs scoping

Opened 2026-07-20 (`phase-15d.gate`), raised by the gate-validator. Running the full suite under a
`subprocess.Popen` hook recorded **493 spawns, zero `claude`** — but not zero providers:
`codex --version` / `exec --help` / `login status` (detection only, ×3 each), `opencode --version`
(×8), and **two real `opencode run` invocations against local Ollama (`qwen2.5-coder:7b`)**. These
are pre-existing 14C/15C tests, not this unit.

Previous evidence reports (including `.debate` and `.succession`) stated "NO live call" without
this scoping. The precise claim is: **no frontier-subscription call is made by the suite; local
model calls via OpenCode/Ollama are made and always have been** (which §2.4 permits — Ollama
involves no credentials). Also correcting a claim in this unit's own drafting:
`config/live_operation.json` is **present** on disk (667 bytes, mtime 2026-07-19, untracked and
gitignored), not absent — it was not written by this unit, and its presence is material to whether
the live legs are "unavailable" (see U56).
State: OPEN as a reporting-accuracy item; carry the scoped wording into `FINAL_LIVE_REPORT.md`.

## U56 — `gate/phase-15d` is NOT earned; §6 substitution does not reach the live 15D criteria

Opened 2026-07-20 (`phase-15d.gate`), raised by the gate-validator as a FAIL and accepted by the
builder without softening. **This is why no `gate/phase-15d` tag was applied.**

Tally against `AUTONOMOUS_BUILD_DIRECTIVE.md` §11 track 15D — **1 of 5 met**:

| Criterion | State |
|---|---|
| Conductor runs on the LIVE Anthropic backend, `model_ref` = fable-5 | NOT met (mock) |
| `current_conductor` recorded; selection preserved when executing differs | **MET** (`.selection`) |
| Full governed loop with LIVE models → CANDIDATE → gates → synthesis | governed path proven, MOCK |
| One bounded LIVE debate, budgets enforced with real tokens | NOT met |
| LIVE conductor succession on a different backend | NOT met |

§13 (OP-8), explicitly a 15D/15E exit criterion — **0 of 5 met**. The validator walked every
`.js`/`.html`/`.css` under `apps/desktop/`: the strings `conductor`, `voice` and `parakeet` appear
**zero times**. The interactive ConPTY conductor pane, the live operator↔conductor conversation,
file/context injection, orchestrate-while-conversing and voice-in are not built, not substituted,
and not skipped-with-record — absent.

**Why §6 does not apply.** §6 substitutes for criteria assuming something *prohibited* or *absent*.
Here neither holds: §11(a) explicitly LIFTED §2.4 for `claude_code` and `codex`, and the CLIs are
present on this host (the suite's own spawn log proves `codex` and `opencode` execute; OP-5's
rationale for choosing Claude Code was that it is "already installed and authenticated"). Invoking
§6 to substitute for something authorized and present, merely un-run, inverts the rule — and §6's
closing line is "never present a substituted result as the real-provider result", which tagging the
phase would do. Tagging would additionally be an invariant-16 conductor override of a gate.

The real obstacle is narrower and genuine: `docs/evidence/R8_TOS_VERIFICATION_CLAUDE_CODE.md` §6
carries `[OPERATOR]` confirmation items that are explicit entry conditions for any live smoke, and
item 2 ("confirm nothing in the current terms prohibits running the first-party `claude` CLI under
the operator's own subscription from a supervising process") is an operator determination. The loop
reading the terms and then acting on its own reading would be self-authorization of a protected
action (invariant 1) — precisely what the delegation ruling in §1 does NOT cover (R8 live-terms are
absent from its delegated list).
State: OPEN — **the reason the build is BLOCKED**. Owner: the operator.

## U56 — AMENDMENT (2026-07-20, `phase-15d.flow` LIVE re-run, OP-9): unblocked, first live leg met

OP-9 discharged the R8 §6 item-2 [OPERATOR] determination (recorded in
`R8_TOS_VERIFICATION_CLAUDE_CODE.md` §6, appended 2026-07-19). The block named above is cleared,
and 15D re-runs LIVE. **Progress against the 5-of-5 tally, this sub-step only:** row 1 (*conductor
runs on the LIVE Anthropic backend, `model_ref` = fable-5*) is now **MET** — a real host `claude`
call with `--model claude-fable-5` produced `legs.conductor="live"`, `executing.model="claude-fable-5"`,
`verified=true` through the full governed loop (`PHASE15D_FLOW_LIVE_EVIDENCE_REPORT.md`). Row 3's
governed loop now ran with a LIVE conductor (workers still local — see U58). Rows 4 (live debate),
5 (live succession) and §13/OP-8 (conductor pane, voice-in) remain OWED to `.debate`/`.succession`/
15E. The high-stakes `gate/phase-15d` stays UNTAGGED until `.gate` closes it on live evidence with
the mandatory gate-validator.

## U54 — AMENDMENT (2026-07-20, `phase-15d.flow` LIVE re-run): first live smoke produced

U54 said the positive `live` contract was proven only by the U43 falsification technique, and that
"only an actual live smoke, with the process observable on the host, converts that into an
observation." That live smoke has now happened for the CONDUCTOR leg: `run_15d_flow_live_smoke.py`
spawned a real host `claude` process (exit 0, `subprocess.run`, torn down within the unit) whose
JSON response reported `claude-fable-5`, independently reconciled by `extract_reported_model`. The
observation is recorded; U54's underlying limit (the rule constrains class not behaviour, so a
determined in-process falsifier is not barred) is UNCHANGED — this converts the conductor leg from
asserted to observed, it does not make the rule a barrier. Worker legs remain asserted-only (U58).
State: PARTIALLY discharged (conductor leg observed live); OPEN for worker legs.

## U57 — the executing checkpoint is reconciled from `modelUsage` by COST DOMINANCE, not a labelled field

Opened 2026-07-20 (`phase-15d.flow` LIVE re-run). The real `claude -p --output-format json` response
carries NO top-level `model` string; the executing checkpoint lives in `modelUsage`, a
`model_id → {…, costUSD, …}` map that on a real call holds MORE THAN ONE key (the primary model plus
the CLI's auxiliary fast-model helper, e.g. `claude-haiku-4-5-*`). `extract_reported_model` now
selects the strictly cost-dominant model (money compared as `Decimal`), fail-closed on a tie /
missing / non-numeric / non-finite cost / non-string key. This is a RECONCILIATION, not a field the
CLI labels "primary": it is correct for the observed shape (a primary that dwarfs a cheap helper) and
fails closed when it cannot tell, but a hypothetical future config in which a helper outspends the
primary would be misattributed. Mitigation: `reported_models(payload)` surfaces the FULL id set for
auditability, and the cost-dominance choice can NEVER convert a mock/degraded run to `live` — it only
selects WHICH id string is recorded once `verify_reported_checkpoint` has already established a real
call was spent (spec-auditor confirmed this separation). A related NIT (a future top-level `model`
echoing the requested slug could re-enter as executing) is inert against the observed shape and
recorded here. State: OPEN (a labelled-primary field or a per-host label→checkpoint map would close it).

## U58 — the LIVE `.flow` proves a live CONDUCTOR, not live WORKERS

Opened 2026-07-20 (`phase-15d.flow` LIVE re-run). `attempt_live_flow`'s only frontier-subscription
call is the conductor's decomposition; the worker pool is the deterministic `LocalWorkerAdapter`
(`legs.workers="mock"`, honest). Directive §11 15D also wants LIVE worker nodes (Anthropic / Codex /
local Ollama) publishing CANDIDATE. `_assert_legs_honest` makes a `live`/`attempted` WORKER leg
UNREPRESENTABLE without its own evidence record, so nothing here can be mistaken for a live-worker
result — but the live-worker legs are OWED. State: OPEN. Owner: a later 15D live sub-step / `.gate`.

**Update 2026-07-24 (`phase-16c.dispatch`) — NARROWED, still OPEN.** The govern-born conductor's
DISPATCH is now WIRED into the shell and proven end-to-end: `tools/live/emit_conductor_dispatch.py`
runs the REAL governed flow (`control_plane.orchestration.live_flow`: decompose → assign BY
DESCRIPTOR → CANDIDATE over MCP → real gate engine → conductor synthesis into an acceptance packet),
folds it into `conductor_dispatch_feed@1.0`, and the shell sources + renders it fail-closed
(`control_plane/orchestration/conductor_dispatch.py`, `apps/desktop/conductor/dispatch-source.js`,
`terminal/compositor/conductor-dispatch.js`; in-Electron receipt `PHASE16C_DISPATCH_SELFCHECK.json`).
This closes U58 **as far as the non-interactive evidence allows** (directive §15): the dispatch
MACHINERY is proven and operator-visible. It is run MOCK-first (`legs.conductor=mock`,
`legs.workers=mock`) so it makes NO live model call, and `_assert_legs_honest` still makes a live
worker leg UNREPRESENTABLE — the feed carries an explicit `live_workers_owed` record (this issue).
What REMAINS OWED (unchanged): actual LIVE worker CANDIDATE publication (Anthropic/Codex/Ollama)
with its own evidence record — the operator-run assembled run (**gate 16F**). State: OPEN. Owner: 16F.

## U59 — LIVE debaters receive scoped evidence REF IDs, not the resolved evidence BODIES

Opened 2026-07-20 (`phase-15d.debate` LIVE re-run). `BackendDebater.argue` forwards the scoped
`allowed_evidence` **ref ids** into the debate prompt (invariant 8 — scoped, not blanket) but NOT the
resolved CONTENT of those entries. A live model with no MCP-read tool of its own therefore cannot
inspect the evidence body: in the witnessed run some debaters cited the ref (which resolved in MCP ⇒
SUPPORTED) while others, lacking the body, failed closed to UNSUPPORTED. The governed machinery
around the debate (rounds/budget/dissent/publication/leg-honesty) is fully exercised and is what the
sub-step proves; giving live debaters a SCOPED read of the cited bodies (still invariant-8 bounded)
is OWED. State: OPEN. Owner: `.gate` / 15E / debate-service hardening.

## U60 — transient loopback-MCP flakiness under multi-minute LIVE timing (caller-channel keep-alive owed)

Opened 2026-07-20 (`phase-15d.debate` LIVE re-run). Across three live runs the loopback
`caller_client` socket proved unreliable while the ~2–4 minutes of sequential live `claude` calls
ran: one run aborted in the publish tail (`WinError 10053`, "connection aborted by host software"),
reported HONESTLY as `skipped_with_record` with the debate un-published (the governed path's
fail-closed degrade — never a false PASS), and even a successful run showed INTERMITTENT evidence
resolution (the same ref resolved for one debater but not another). This is an environmental/
robustness limit of the loopback transport under live latency — the standing transport item is **U6**
— NOT a governance defect: no un-verified leg was ever labelled `live`, and a failed publish degraded
honestly. A keep-alive / auto-reconnect hardening for the caller channel across long live calls is
OWED. State: OPEN. Owner: transport hardening (U6) / `.gate`.

## U61 — the LIVE `.debate` used two instances of the SAME model, not two distinct models

Opened 2026-07-20 (`phase-15d.debate` LIVE re-run). Invariant 18 is satisfied at the level the code
enforces — two separate `ClaudeCliBackend` OBJECTS, a shared instance refused, distinct node ids,
non-conductor caller — but both debaters requested the CLI default and both resolved to the identical
checkpoint `claude-opus-4-8[1m]`, so the live leg was ONE model arguing under two node labels, not two
distinct reasoners. The code already records this as owed (`live_debate.py`: "two separate instances
of the same model remain indistinguishable here — recorded as owed, not claimed away"). A live debate
between DIFFERENT models (e.g. Anthropic vs. a live Codex/GPT worker, or a local Ollama reasoner) is
OWED; nothing in this sub-step should be read as a two-distinct-model disagreement. Relatedly, the
"two opposed, mutually-SUPPORTED positions held to the round cap" shape was NOT exercised live (the
final-round classifications were UNSUPPORTED, so `DISSENT_PRESERVED` followed from non-convergence +
U59, not from held-apart evidenced disagreement) — that path remains proven mock-first. State: OPEN.
Owner: `.gate` / 15E (different-model live debate).

## U62 — in the LIVE succession record, the predecessor party's echoed `selection.executing` lags its `verification`

Opened 2026-07-20 (`phase-15d.succession` LIVE re-run). In the builder-witnessed live run the
predecessor party record shows `selection.executing.verified=false` / `selection.executing.model=null`
(with `note: "per-node model 'fable-5' (accepted-id unverified until live smoke)"`) while the SAME
party's own `verification` field shows `verified=true` / `model=claude-opus-4-8[1m]` and `leg=live`.
This is a composition artifact, NOT a false claim: `LiveGovernedFlow.begin()` rebinds `flow._handle`
with a post-CLI `selection_record` (its `_rebind` computes `verify_reported_checkpoint` after the
live call), but `LiveConductorSuccession.run()` keeps the PRE-rebind handle on
`self.predecessor_handle` and `_party` reads `handle.selection_record` for the `selection` field
while computing `verification` FRESH from the backend. The load-bearing fields — the leg `live` and
the `verification` record — are correct and independently computed; only the party's echoed
`selection.executing` mirror is stale. Not a live-claim honesty defect (the leg is not derived from
the stale field; `build_succession_report` refuses a `live` leg with no `verification` record, and
the `verification` record is present and correct).

FIX (owed to `.gate`): have `run()` refresh its stored predecessor handle after `flow.begin()`
(read `flow._handle` back) so `_party` reads the rebound `selection_record`, OR have `_party` take
the executing mirror from the rebound handle. Small, contained; touches `.flow`-gated `live_flow`
only if the rebound handle is not otherwise exposed. State: OPEN. Owner: `phase-15d.gate`.

## U62 — AMENDMENT (2026-07-24, `phase-15d.gate` LIVE close): DISCHARGED

Fixed by the first option. `LiveGovernedFlow` now exposes the rebound handle via a public
`conductor_handle` property (`control_plane/orchestration/live_flow.py`), and
`LiveConductorSuccession.run()` refreshes `handle = flow.conductor_handle` +
`self.predecessor_handle = handle` immediately after `flow.begin(objective)`, so `_party` reads the
REBOUND `selection_record`. The adapter/backend are identical across a rebind (the rebind sets
`adapter=self._conductor`), so the kill/death-evidence/teardown uses of `handle` are unaffected; on
the mock path (`rebind is None`) the refresh is an exact identity no-op.

Pinned by `tests/integration/test_live_succession.py::test_predecessor_party_reports_the_REBOUND_selection_record_not_the_pre_call_one`
(mutation-verified: FAILS with the two-line refresh reverted). Confirmed LIVE this unit
(`docs/evidence/live/phase15d_gate_succession_live.json`): the predecessor party's
`selection.executing` now reads `{model: claude-opus-4-8[1m], verified: true, verified_by:
claude_code.verify_reported_checkpoint@1}`, AGREEING with its `verification` field. The change touches
only handle plumbing — no honesty gate weakened (spec-auditor CLEAN; `_party` still derives `leg`/
`verification` directly from the backend via the hardened classifier, never from the echoed mirror).
State: **DISCHARGED**.

## U63 — a local CODING node reserves/badges the picker-SELECTED tag, but OpenCode auto-resolves its own coder model (they can diverge)

Opened 2026-07-24 (`phase-15e.spawn`, spec-audit MINOR-2). For a local coding selection,
`node_runtime/supervisor/pane_node_spawn.py::_spawn_local` reserves VRAM for and badges
`selection.option["model_slug"]` (the tag the operator picked), but `spawn_opencode_harness` is
called WITHOUT that tag — OpenCode's actual coder model is whatever `probe.coder_model` /
`detect.pick_model(...)` resolves (`node_runtime/supervisor/opencode_spawn.py:71-75`), never
cross-checked against the selection. In the mock-first proof they coincide because the injected
`HarnessProbe(coder_model=...)` is hand-set to match; on the real path the reserved/badged model and
the model OpenCode drives can diverge, so the pane chrome and the VRAM reservation can both name a
model the coding node is not running. Not a name-inference violation (I-SC1 is enforced on the
role), and not a live-claim defect (this sub-step is mock-first, no live model runs), but it
overstates residency/badge fidelity for the coding role. Relatedly, local option `roles` are today a
coarse uniform menu (`reasoning|coding`, `control_plane/nodes/pane_picker.py`) rather than a
per-model capability descriptor. FIX (owed to the coding-integration follow-up): thread the selected
tag into the harness so OpenCode drives it (`--model ollama/<selected>`) — or, after probing, refuse
fail-closed on `probe.coder_model` ≠ selection — and reserve residency for the model actually run;
add a real per-model local capability descriptor. State: OPEN. Owner: 15E coding-integration /
`.gate`.

## U64 — a QUEUED/LOADING (non-resident) local node is returned as a live handle with no residency-completion gate before `execute()`

Opened 2026-07-24 (`phase-15e.spawn`, spec-audit NIT-2). When `request_load` returns `scheduled=False`
(QUEUED) or `LOADING`, `_spawn_local` still constructs the worker/harness and returns a live
`GovernedSpawn`; `node_state` honestly reads `queued_for_vram`/`loading` (visible, invariant 22), but
nothing structurally prevents the caller from invoking `handle.execute()` before residency reaches
RESIDENT — a real local backend would then generate on a non-resident model. Latent for this
mock-first sub-step (the mock `LocalWorkerAdapter.execute` ignores residency, and residency is at
least visible in chrome), but there is no gate coupling execution to `RESIDENT`. FIX (owed): expose
the residency handle on `GovernedSpawn` (or a `ready()` predicate) so a later sub-step / the shell
blocks `execute()` until `RESIDENT`, and drive the visible swap via `mark_idle`/`complete_load`.
State: OPEN. Owner: 15E node-lifecycle / `.gate`.

## U65 — the shell renders the CONDUCTOR pane badge from local selection literals, not the governed selection over IPC

Opened 2026-07-24 (`phase-15e.conductor-pane`, spec-audit MINOR-1); propagated into this register
2026-07-24 (`phase-15e.objective`, closing the gate-validator R1 register-honesty reservation). The
shell (`apps/desktop/main.js`) renders pane-1's model badge from a local `CONDUCTOR_SELECTION_RECORD`
literal that MUST mirror `control_plane/conductor/selection.OPERATOR_SELECTED_CONDUCTOR`. It matches
today (⇒ the badge is honest now), but the honest fix is to SOURCE the governed selection/chrome over
the read-only IPC channel exactly as `inspector:`/`statusbar:` do, so the two can never drift. FIX
(owed): deliver the governed conductor selection over the read-only feed. State: OPEN. Owner: 15E
live conductor wiring / `.gate`.

**U65 update (2026-07-24, `phase-16c.selection`) — RESOLVED.** The hand-maintained literals
`CONDUCTOR_SELECTION_RECORD` / `CONDUCTOR_SUCCESSION_AFFORDANCE` are **gone** from
`apps/desktop/main.js`. The shell now SOURCES pane-1's CONDUCTOR badge + Resume→Select succession from
the ONE Python authority (`control_plane/conductor/selection.OPERATOR_SELECTED_CONDUCTOR` +
`node_runtime/supervisor/conductor_pane_spawn.conductor_succession_affordance`) via a bounded read-source
(`apps/desktop/conductor/source.js` → `tools/live/emit_conductor_selection.py --emit-conductor-selection`,
schema `conductor_selection_feed@1.0`) and renders it VERBATIM — the badge can no longer drift from the
operator's authority. This mirrors the already-gated 16B picker read-source pattern (a bounded `py -3.12`
subprocess emitter rather than the WebSocket IPC channel — a faithful substitution for a pure operator
record; recorded honestly, same as `picker:`). **Fail-closed** (invariant 3 / invariant 20 spirit): a
timeout / non-zero exit / non-JSON / malformed feed yields the UNKNOWN feed (`selection.model: null`),
which `conductorBadge` renders "(unknown selection)" — never a fabricated "fable-5". Pre-launch honesty
holds: `executing.model` None, `verified` False (nothing has executed; the live-spawn checkpoint is a
later 16C sub-step). Proven in-runtime by the D-P16-0 self-check (`docs/evidence/receipts/PHASE16C_SELFCHECK.json`,
`ok:true`, `selection_sourced:true`, `rendered_model_matches_feed:true`) + anti-drift unit tests
(`tests/unit/test_emit_conductor_selection.py`, `apps/desktop/test/conductor-source.test.js`), independently
re-run by the gate-validator (PASS). State: **RESOLVED**. (Defense-in-depth follow-up on the emitter's
transitive import graph tracked as [[U71]].)

## U66 — the shell returns an honest EMPTY approval drawer and only RECORDS the operator's decide request; the governed queue is not yet wired over IPC

Opened 2026-07-24 (`phase-15e.objective`). The operator command surface's authority + queue live
Python-side (`control_plane/orchestration/operator_surface.ApprovalQueue.resolve` — operator-only,
invariant 1; a gate-failed plan is not approvable, invariant 16). The shell today (`apps/desktop/main.js`
`approvals:fetch`/`approvals:decide`) returns an honest EMPTY `approval_drawer@1.0` snapshot (never a
fabricated pending item) and the decide handler only RECORDS the operator's approve/reject request —
it self-authorizes nothing (invariant 1 held), exactly as `conductor:succeed` records a succession
request without performing it. Not yet wired: delivering the live in-process `ApprovalQueue.drawer_model()`
snapshot over the read-only IPC channel, and routing the operator's decision back to the governed
`ApprovalQueue.resolve` / `ObjectiveIntake.approve|reject` / `CommandBroker`. This is the same owed
live-feed pattern as U65 (conductor selection) and the statusbar governor feed. FIX (owed): wire the
live queue feed + decision routing with the live conductor path. State: OPEN. Owner: 15E live conductor
wiring / `.gate`.

**NARROWED 2026-07-24 (`phase-16d.approvals`, work `2be353f`).** The READ path + the resolve
AUTHORITY are now CLOSED. `apps/desktop/main.js` `approvals:fetch` SOURCES the REAL in-process
`ApprovalQueue.drawer_model()` over a bounded `py -3.12` read-source
(`apps/desktop/approvals/drawer-source.js` → `tools/live/emit_approval_drawer.py`, built by
`control_plane/orchestration/approval_feed.py` from the REAL governed producers — plan via
`LiveGovernedFlow.begin` + the real gate engine, protected action + clarification via the real
`CommandBroker`); the hardcoded empty `approvalSnapshot()` is REMOVED. `approvals:decide` now ROUTES
the operator's Approve/Reject back to the governed `ApprovalQueue.resolve` via
`emit_approval_decision.py` (operator-only, inv 1; approve of a non-approvable item REFUSED, inv 16, no
override) — the shell self-authorizes nothing (`selfAuthorized:false`). Proven in-Electron
(`docs/evidence/receipts/PHASE16D_APPROVALS_SELFCHECK.json`, `ok:true`; the emitter-sourcing is
load-bearing — empirically falsified by the validator). STILL OWED to **16F** (why this stays OPEN):
the queue is rebuilt FRESH per emit, so a resolve does not PERSIST across fetches and its downstream
SIDE-EFFECT (`apply_protected_decision`/`ObjectiveIntake.approve` running the flow / `CommandBroker`
execution) does not FIRE, and the operator identity is PRESUMED from local shell context (authenticated
per-node binding owed) — all recorded on every feed as `live_queue_owed`/`live_effect_owed`. State:
OPEN (read + authority done; persistence + side-effect + authenticated identity owed to 16F).

## U67 — the shell records a push-to-talk request but does not yet route captured audio through the ConductorVoiceBridge over IPC

Opened 2026-07-24 (`phase-15e.voice`). The conductor voice-IN ROUTING lives Python-side
(`voice_bridge/conductor_voice.ConductorVoiceBridge` over the real `CommandBroker`): a transcript is
transcribed-then-discarded, then routed deterministically — ordinary chat delivered verbatim to the
conductor's input, a protected/destructive action proposed→queued for operator approval (never
executed, invariant 25), a low-confidence transcript clarified. The shell today
(`apps/desktop/main.js` `voice:state`/`voice:propose`) holds no STT engine and drives no conductor
session (mock-first, §2.4/§10.4): the `voice:propose` handler only RECORDS that the operator held PTT
— it self-authorizes nothing (invariant 25 held) and delivers no text — and `voice:state` renders the
mic affordance with the SAME pure core the JS tests cover (`terminal/compositor/voice-indicator`,
`speechOut:false` — no TTS, I-V2/D-VOICE-02). Not yet wired: capturing operator audio, running the
live STT engine (mock unless the GPU+WSL+NeMo stack is present), routing the transcript through the
`ConductorVoiceBridge`, and writing the resulting chat text into the interactive conductor ConPTY
(an operator-run surface, directive §6). This is the same owed live-feed pattern as U65 (conductor
selection) / U66 (approval queue). FIX (owed): wire the live STT → bridge → conductor-write path with
the live conductor wiring. State: OPEN. Owner: 15E live conductor wiring / `.gate`.

**NARROWED 2026-07-25 (`phase-16e.engine`).** The READ half is closed. New
`control_plane/orchestration/conductor_voice_feed.py` + `tools/live/emit_conductor_voice.py` route ONE
captured utterance through the REAL `ConductorVoiceBridge` over a REAL `CommandBroker` (mock-first, no
live call) and fold the outcome into `conductor_voice_feed@1.0`: an HONESTLY engine-SELECTED transcript
(mock STT on this host — `nemo` absent — surfaced as a VISIBLE "mock engine", never a claimed real
engine), the three routing outcomes as the shell feed (CHAT delivered / protected+destructive QUEUED
never delivered, invariant 25 / low-confidence CLARIFY), `tts:False` (I-V2), transcribe-then-discard
(invariant 26), all fail-closed. `terminal/compositor/voice-indicator.voiceEngineIndicator` renders the
VISIBLE mock/real indicator (real ONLY when `mock:false` AND `real_available:true`).
`apps/desktop/voice/voice-source.js` is the bounded `py -3.12` read-source glue (headlessly tested; not
yet imported by the running shell). REMAINING (owed to `.wire`): the shell talk button (`voice:propose`)
sourcing this feed and DELIVERING a CHAT transcript into the conductor session via the `pane:input` /
`SessionManager.write` path, the in-Electron D-P16-0 self-check receipt, and
`docs/OPERATOR_NEMO_INSTALL.md`. State: OPEN (read half done). Owner: `phase-16e.wire`.

## U68 — the reconstructed layout snapshot carries per-pane worker chrome only for the conductor; worker panes snapshot with model/role unpopulated until the node-launcher feeds them

Opened 2026-07-24 (`phase-15e.recovery`). Conductor-first LAYOUT recovery
(`terminal/recovery/layout-reconstruct.buildLayoutSnapshot` / `reconstructLayout`, wired in
`apps/desktop/main.js`) rebuilds the pinned CONDUCTOR pane 1 and reattaches the worker panes across a
full shell restart, fail-closed (no naked re-spawn, invariant 2; nothing admitted until the channel
re-verifies). The fold's per-pane fields for a worker (which model it runs, role, attended vs
autonomous) come from `paneMeta(id)`, which today only carries governed chrome for the conductor
pane; worker panes are created by `createPaneWithSession` before the live node-launcher UI feeds
per-pane model/role, so they snapshot honestly as role `worker` / model null (never a fabricated
model — invariant 3). The layout-recovery contract already carries the fields; the recovered
structure (pane order, pinned, session disposition, needs-relaunch) is complete and correct now. Not
yet wired: sourcing per-pane worker model/role from the live node-launcher into `paneMeta` so a
restored worker pane shows its exact model badge. Same owed live-feed pattern as U65 (conductor
selection) / U66 (approval queue) / U67 (voice). FIX (owed): populate `paneMeta` from the live
node-launcher's per-pane model/role. Same owed live-feed pattern as U65 (conductor selection) /
U66 (approval queue) / U67 (voice).

**RESOLVED 2026-07-24 (`phase-16d.recovery`).** `paneMeta(id)` in `apps/desktop/main.js` now sources
per-pane worker chrome from a `paneChrome` Map that `spawnFromSelection` (the governed picker intent)
RECORDS when a selection targets a live pane, and `terminal/recovery/layout-reconstruct.js` gains a
deterministic `_chromeSnapshot` whitelist so `buildLayoutSnapshot` persists the badge and
`reconstructLayout` re-sanitizes it across a restart. A restored worker pane repaints its EXACT model
badge from the reconstructed chrome (proven in the in-Electron self-check
`PHASE16D_RECOVERY_SELFCHECK.json`, `ok:true`), while a pane with no recorded selection stays
`chrome:null`/`model:null` (invariant 3) and a recovered worker is still `reattach:false`/
`admitted:false` (invariant 2 — no naked re-spawn). The remaining half — the live governed worker
SPAWN from a selection (a recorded badge becoming an actually-running governed node) — is owed to
operator-run 16F and tracked under **U70**. State: RESOLVED (record/read half; live spawn → U70/16F).

## U69 — physical-keyboard end-to-end (browser keydown on the focused xterm textarea → onData → echo) is validated only in its two halves by the automated self-check; confirm the full physical chain at gate 16F

Opened 2026-07-24 (`gate/phase-16a`). The Phase 16A pane-I/O fix is exercised inside the packaged
Electron runtime by an autorun self-check (`apps/desktop/selfcheck/`, D-P16-0). The self-check proves
the operator's "cannot type" defect is fixed in its two constituent halves: (a) the focus fix lands
DOM focus on the xterm textarea (`active_element:"xterm-helper-textarea"` in the receipt), and (b)
the real renderer input wiring round-trips — `term.input(data,true)` fires the exact
`term.onData → S.input → pane:input → manager.write → PTY → echo → render` path a physical key uses,
and the echo renders (`echo_xterm_seen:true`). The ONE micro-link NOT auto-exercised is the browser
delivering a focused textarea's keydown to xterm's `onData` handler: synthetic OS keystrokes via
`webContents.sendInputEvent` do not reliably drive xterm's input path under an automated/background
window (`echo_dom_seen:false`, recorded honestly). That link is xterm library + Electron internals,
not shell code. FIX (owed, non-blocking — the shell wiring it depends on is proven): confirm the full
physical-keyboard chain in the operator-run visible validation at gate 16F. State: OPEN. Owner: 16F.

## U70 — live governed worker spawn from a picker selection (+ attended/autonomous mode toggle in the picker UI) is deferred to operator-run/16F; the selection is recorded + previewed now

Opened 2026-07-24 (`gate/phase-16b`). Phase 16B wires the VISIBLE per-pane model picker (live host
enumeration rendered, greyed-with-reason, residency chips, model badge + n/2) and routes a selection
through the governed path — but the WRITE side (an actual live governed worker spawn) is an IPC write
gated by **U25** (the per-node IPC→MCP credential broker) and a live model process (mock-first,
§2.4/§10.4). So `pane:spawnFromSelection` runs the same fail-closed selection guard the Python
dispatcher (`node_runtime/supervisor/pane_node_spawn.spawn_node_from_selection`, already gated at 15E
`.spawn`) enforces, **RECORDS** the governed selection, and returns the pane chrome preview
(`governed:false`, `node_state:"selected_awaiting_governed_spawn"`) — it self-authorizes nothing
(invariant 1) and starts no session (invariant 2). Two owed refinements, both non-blocking: (a) the
live governed worker spawn/drive from a picker selection is operator-run / gate **16F** (the assembled
run where it is operator-visible; U25 gates the IPC write); (b) the picker UI hardcodes an
`autonomous` preview — the attended/autonomous mode toggle (OP-7 §12.3; mode is a chrome/routing
label, NOT an authority grant) is not yet a picker control. State: OPEN. Owner: 16F (spawn) / 16E-F
(mode toggle).

## U71 — relocate the pure conductor-succession-affordance builder to a leaf module (defense-in-depth for the fail-closed read feed)

Opened 2026-07-24 (`phase-16c.selection`). The 16C read-source `tools/live/emit_conductor_selection.py`
imports `conductor_succession_affordance` — a **pure dict builder** — from
`node_runtime/supervisor/conductor_pane_spawn.py`, whose transitive import graph pulls in the adapter /
profile-loader / subscription-governor chain. Import-time purity is **verified today** (the executed
read path makes no model call, no credential access, no network — proven by the live emitter run and
`test_emit_conductor_selection.py`), so this is **not** a violation and the fail-closed guarantee holds
now (spec-auditor NIT-2, 2026-07-24, accepted non-blocking). The defense-in-depth concern: if any
transitive module ever gained an import-time side effect (env read / credential / socket), this
read-only feed's §2.2/§2.4 purity could silently regress. FIX (owed, non-blocking): site the pure
`conductor_succession_affordance` builder in a leaf module free of adapter imports, mirroring how
`control_plane/conductor/selection.py` deliberately imports no adapter, and have both
`conductor_pane_spawn` and the emitter import it from there. State: OPEN. Owner: a later 16C sub-step
or 16-phase hardening.

## U72 — decision-register naming collision: the hypothetical-TTS "OP-9" vs the recorded live-terms OP-9

Opened 2026-07-24 (`phase-16c.spawn`). `docs/registers/DECISION_REGISTER.md` uses "would be OP-9"
**hypothetically** for a possible future operator reversal of the TTS prohibition (I-V2/D-VOICE-02),
while the **actually-recorded** OP-9 (`AUTONOMOUS_BUILD_DIRECTIVE.md` §14, 2026-07-19) is the
LIVE-TERMS-CONFIRMED ruling that discharges the R8 §6 operator-terms gate. The 16C `.spawn` code cites
the CORRECT (recorded, live-terms) OP-9 — `emit_conductor_spawn.py` passes `operator_terms_confirmed=True`
on that basis (invariant 1: the operator made the determination, not the loop) — so this is a
**docs-hygiene risk, not a code defect** (spec-auditor NIT-3, 2026-07-24, accepted non-blocking). FIX
(owed, docs-only): rename the hypothetical TTS reversal to the next free register row (e.g. OP-11) so
"OP-9" unambiguously denotes the recorded live-terms ruling everywhere. State: OPEN. Owner: 16-phase
docs hardening / the operator-TTS-decision unit if/when it lands.

## U73 — `pane:resize` fires a null-`manager` TypeError against the sessionless conductor placeholder

Opened 2026-07-24 (`phase-16c.dispatch`; gate-validator R1). During every shell/self-check startup the
main process logs `Error occurred in handler for 'pane:resize': TypeError: Cannot read properties of
null (reading 'resize')` at `apps/desktop/main.js:451` — the renderer sends an early `pane:resize` for
the govern-born pane-1 CONDUCTOR PLACEHOLDER (`sessionId:null`, no PTY) before/without a supervised
session, and `manager.resize(id, …)` dereferences a session that does not exist. It is **transient and
non-fatal**: the Electron IPC layer catches it, the pane-I/O and conductor self-checks still PASS
(exit 0) with clean teardown, and it touches NO 16C criterion. It is **pre-existing** — NOT introduced
by `.dispatch` (the diff touches conductor-dispatch wiring, not `pane:resize`); it is adjacent to the
16A pane-I/O surface (`.spawn`/`.selection` created the same sessionless placeholder). FIX (owed,
non-blocking): guard the `pane:resize` handler (and/or `SessionManager.resize`) to no-op fail-closed
when the pane has no live session. State: OPEN. Owner: shell / pane-I/O owner (16A-adjacent) / 16F.

## AUDIT ADDENDUM 2026-07-25 — U67 closure backfill + U66 wording note (product/usable audit)

**U67 — RESOLVED (audit backfill).** The `.engine` narrowing was U67's last recorded update, but the
closure landed without being written back: `.wire` (084303d — talk button → capture → STT → bridge →
conductor input; in-Electron receipt PHASE16E_VOICE_SELFCHECK.json) and `.real` (7684496 — WSL-probed
detection + WslParakeetSTT adapter; real host transcription receipt PHASE16E_REAL_PARAKEET_SMOKE.json,
"Testing 1234" conf 1.0) closed the read, write, and real-engine halves under `gate/phase-16e`
(ca08f33). Remaining voice scope is NOT U67: real microphone PCM into a live conductor session and
real-STT confidence calibration live on the 16F owed list. State: RESOLVED (2026-07-25, audit
backfill). Owner: —.

**U66 — wording note (state unchanged: OPEN, narrowed).** The 16d decision-register row says "closed
U66"; this register's own description (read + resolve-authority halves done; persistence, side-effect,
and identity halves owed) is the honest one and remains authoritative. No state change.

## U75 — the durable I-X3 lease is keyed to the conductor NODE id, not to a session

Opened 2026-07-25 (`phase-17a.lease`; spec-audit F1). `TerminalLeaseLedger.acquire` is idempotent per
`(subscription_ref, node_id)` and `emit_conductor_launch.CONDUCTOR_NODE_ID` is the constant
`conductor-pane-1`, so re-issuing a launch ticket returns the SAME lease while an earlier authorized
session may still be running: N real interactive sessions for pane 1 would count as ONE terminal on
any allowance (`spawn_conductor_pane`'s governor gate is likewise a no-op on the second pass, since
the seeded active set already contains the node id). Idempotence is correct for a re-run of one
governed spawn and wrong for two real sessions. **Latent today** — nothing in the product path spawns
yet — and **load-bearing the moment `.pty` lands**. FIX: key the lease to the ConPTY session identity
(child pid / session id), keeping node-id idempotence only for the not-yet-launched case.
State: OPEN. Owner: `phase-17a.pty`.

## U76 — one real subscription, three `subscription_ref` spellings; the visible n/2 will lie

Opened 2026-07-25 (`phase-17a.lease`; spec-audit F4). The durable lease uses `claude-sub` (inherited
from `emit_conductor_spawn`, 16C), the always-visible status-bar feed
(`tools/live/emit_subscription_status.py`) uses `sub-claude_code`, and the 15D live smokes use
`sub-anthropic`. The I-X3 cap is enforced PER REF, so the operator's single Anthropic subscription can
hold 2 + 2 concurrently, each bucket "at allowance". Worse for invariant 27: once 17A holds a durable
lease, the status bar — which builds a fresh in-process governor under a ref the ledger never writes —
will display `0/2` while a terminal is genuinely held. FIX: one canonical ref, and source the status
bar from the durable ledger. State: OPEN. Owner: `phase-17a.pty` (must close before a held lease is
ever operator-visible).

## U77 — an undelivered launch ticket leaves an orphan lease

Opened 2026-07-25 (`phase-17a.lease`; gate-validator R1, proven empirically by mutation). The durable
lease is acquired Python-side BEFORE the ticket is parsed by the shell. If the JS strict shape check
refuses the payload, or `runEmitter` hits its 25 s timeout, `child.kill()` cannot un-acquire a lease
`py` already wrote: 1 of 2 terminals is consumed by a session that does not exist. Bounded, not
permanent — dead holders are reaped and `acquire` is idempotent per node so a retry re-adopts the
orphan — but a live shell that does not retry stays down one terminal. No test covers this path.
FIX: release-on-parse-failure (release by node), or move the durable acquire behind a shell
acknowledgement. State: OPEN. Owner: `phase-17a.pty`.

## U78 — a launch ticket is an authorization, not containment (plus three smaller gaps)

Opened 2026-07-25 (`phase-17a.lease`; spec-audit F6/F7/F11/F14). The ticket now DISCLOSES this
(`containment.supervisor_bound:false`, `owed_to:"17A .pty"`) rather than implying otherwise, but the
work is owed: (a) **containment** — the process `.pty` will spawn has no permission-profile binding,
no supervisor session registration, no cwd/workspace binding, no job object or ACL and no heartbeat
(contrast `frontier_spawn`'s `AdapterContext`); invariant 2/29 is satisfied only once `.pty` binds it.
(b) **§2.2 scrub is fail-open by inheritance** — credential var NAMES are resolved in the emitter's
`os.environ` and applied to the shell's, correct only because the child inherits the parent env, an
assumption stated nowhere; the ticket should carry the classifier RULE (prefixes/substrings from
`is_credential_env_key`) as well as the resolved names, and the shell should apply both.
(c) **OP-9 terms have no revocable artifact** — `operator_terms_confirmed=True` is a hardcoded literal
riding a genuinely recorded operator ruling (consistent with every sibling emitter), while live
operation is fenced by a file the operator can delete; the operator cannot revoke the terms gate
without a code change. (d) **`--release-lease` performs no ownership check** — any local process can
zero the durable count, so the cap binds cooperating callers, not a hostile one.
State: OPEN. Owner: `phase-17a.pty` for (a); 17D/hardening for (b)–(d).

## Register notes 2026-07-25 (`phase-17a.lease`, spec-audit F17/F18 — recommendations, not violations)

* The lease ledger keeps **current state only**: there is no record of who held a terminal when, only
  the instantaneous count. Directive §4 ("everything observable") would be better served by an
  append-only lease-EVENT log alongside the current-state file. (Invariant 12/13 are not violated: a
  mutable runtime counting file is not project state/memory — no provenance semantics, no artifacts,
  no CANDIDATE/ACCEPTED lifecycle, gitignored under `.sovereign_store/`.)
* `terminal_lease_ledger@1.0` has **no file in `schemas/`**. Consistent with every existing shell-feed
  emitter (all pin schema strings in code), so not new drift — but this one is PERSISTED state rather
  than a transient feed, which is closer to CLAUDE.md's "JSON Schemas in `schemas/` are the single
  source of truth" than the feed schemas are.

## Register update 2026-07-25 (`phase-17a.pty`) — U75/U76/U77 RESOLVED, U78 NARROWED, U79/U80 opened

**U75 — RESOLVED.** The durable lease is keyed to `(subscription_ref, node_id, session_id)`
(`terminal_lease_ledger@1.1`): two real interactive sessions of the constant `conductor-pane-1` are
two counted terminals, a third is refused at allowance 2, and `seed_governor` projects by LEASE KEY
so the governor's node-keyed `active` set cannot collapse them either. A `@1.0` ledger is read as
sessionless (never declared corrupt), and a sessionless lease held by the SAME pid for the same node
is UPGRADED in place rather than duplicated — one real session mid-upgrade must not consume 2 of 2.
Another process's sessionless lease is never adopted. Evidence:
`docs/evidence/PHASE17A_PTY_EVIDENCE_REPORT.md` §3 row 5; `tests/unit/test_terminal_lease.py`.

**U76 — RESOLVED.** One canonical spelling (`canonical_subscription_ref(provider)` →
`sub-claude_code`) across all three product paths — the launch ticket, the 16C governed spawn feed
(`emit_conductor_spawn`, which runs on every shell start and was the last holdout) and the
always-visible status feed — and the status bar's `in_use` is now seeded from the DURABLE ledger, so
a genuinely held terminal reads `1/2` instead of `0/2`. A ledger the emitter cannot read yields
`status:null` (the em-dash unknown) rather than a readable-looking zero: "0 is a claim". The 15D live
smokes' `--subscription` default was moved to the same helper. Proven in-runtime through the SAME
function the product IPC uses: receipt `statusbar_row {ref:"sub-claude_code", label:"1/2",
state:"active"}`. The regression tests compare the PRODUCT constants to each other (the first drafts
compared a constant to the function that defines it and would have passed while a third module
drifted — gate-validator finding 4).

**U77 — RESOLVED.** `--release-session <id>` reclaims by the key the SHELL chooses before it asks, so
a ticket the shell never parses (shape refusal, emitter timeout) no longer strands a terminal; an
empty key matches nothing (never a wildcard). The shell releases on: undelivered ticket, spawn/
admission failure, session exit, session kill, and quit (bounded blocking release). Proven live by the
gate-validator's mutation (a ticket for a different session gives `RELEASED (ticket undelivered)` and
a failed receipt), not only by test.

**U78 — NARROWED, still OPEN.** (a) **partly delivered**: supervised session registration and
workspace/cwd binding are enforced and OBSERVED in the receipt (the cwd node-pty was handed AND the
workspace the child itself prints); **still owed** — the **permission-profile binding** (the ticket
carries `permission_profile_id`; nothing applies it) and the per-node heartbeat, now named explicitly
in the ticket's `containment.still_owed` so they cannot vanish between registers; OS job-object/ACL
containment remains U25 (unchanged for every shell session). (b)/(d) unchanged. (c) unchanged in
substance but **higher exposure**: `operator_terms_confirmed=True` is still a code literal, and it now
rides a path that runs automatically at every shell start — the operator's only revocation is deleting
`config/live_operation.json` (which the gate chain re-reads per launch, so it does work) or setting
`SOW_CONDUCTOR_AUTOLAUNCH=0`, both now documented in `apps/desktop/RUN_ON_WINDOWS.md`. Owner:
17D/hardening.

## U79 — a refused conductor relaunch is reported to the console, not to the operator's eye

Opened 2026-07-25 (`phase-17a.pty`; gate-validator finding 3, partially fixed). The relaunch itself is
fixed (`SessionRegistry.forget` drops an ENDED record — never a live one — so pane 1 is no longer
wedged for the life of the shell), and every refusal now RECORDS its reason, logs it, and pushes
conductor state so the live-launch button's tooltip carries it. What is still missing is an immediate
visible message: the renderer's click handler only `console.warn`s, so an operator who clicks and sees
nothing must hover the button to learn why. State: OPEN (cosmetic-but-real). Owner: `phase-17a.close`
or the 17E chrome pass.

## U80 — vendor-CLI specifics live in the shell layer

Opened 2026-07-25 (`phase-17a.pty`; spec-audit observation). `BANNED_FLAGS` in
`apps/desktop/conductor/launch-source.js` and the `argv[0] === "claude"` assertion in the `.pty`
self-check encode claude-CLI knowledge in the shell. Not an I-SC1 violation today — the conductor pane
is claude_code-bound by `conductor_pane_spawn`, and both are refusal-side checks that can only make the
shell stricter — but they must move behind the capability descriptor when the conductor runtime becomes
genuinely selectable (I-03/I-04). State: OPEN (design debt). Owner: whichever track makes the conductor
backend selectable.

## U81 — a model-probe verdict has no expiry and no in-shell re-ask

Opened 2026-07-25 (`phase-17a.roundtrip`; gate-validator R4, spec-audit m3). The probe caches a
CONCLUSIVE verdict on the host indefinitely: an accepted slug survives a CLI upgrade that renames it,
and a conclusive `model_unavailable` (text-matched against the CLI's own wording) becomes a durable
demotion to the CLI default. The only reversal is
`py -3.12 tools/live/probe_conductor_model.py --emit-model-probe --reprobe`, a command line the shell
does not expose. Bounded by honesty, not by correctness: every launch that used a fallback SAYS so, in
the badge, the ticket and the receipt. Wanted: a recorded CLI version in the record so an upgrade
invalidates it, plus a re-probe control on the conductor chrome. State: OPEN. Owner: `phase-17a.close`
or the 17E chrome pass.

## U82 — the roster and the per-pane picker are still model-probe-blind

Opened 2026-07-25 (`phase-17a.roundtrip`; spec-audit m4). The probe resolves the slug for the CONDUCTOR
launch and the conductor badge. `CLAUDE_CANDIDATE_MODEL_REFS` and `claude_code_roster_descriptor`'s
`model_ref` still carry the operator labels as unverified provisional slugs, so a WORKER pane that
selects `fable-5` would reproduce exactly the defect this sub-step fixed for pane 1 (a live session
that answers every prompt with "There's an issue with the selected model"). Honesty direction is safe
today — the roster under-claims (`verified:false`) — but the fix belongs where worker panes actually
spawn. State: OPEN. Owner: `phase-17b` (picker spawn, U70).

## U83 — probe spend is not aggregated into the cost instrumentation

Opened 2026-07-25 (`phase-17a.roundtrip`; spec-audit m9). The probe's live calls surface only as a
per-invocation boolean (`spent_live_call`) and a `ClaudeCliBackend.calls` counter discarded with the
backend. Buildout §4 asks for cost-to-accepted-output instrumentation from day one, and this is a real
(small, one-off per host) subscription spend that no ledger totals. State: OPEN. Owner: `phase-17e`
(the report that totals usage) or the evaluation harness.

## U84 — the probe ledger is written without a lock

Opened 2026-07-25 (`phase-17a.roundtrip`; spec-audit m8). `ModelProbeLedger.write` is an unlocked
read-modify-write over one JSON file, unlike its sibling `TerminalLeaseLedger`, which takes an
exclusive lock. Two concurrent writers (the shell's startup probe and a manual `--reprobe`) can drop
one another's entries. The write itself is atomic (temp + `os.replace`), so no reader ever sees a
half-record, and a lost entry costs one re-probe rather than any incorrect verdict — this is a host
CACHE, not shared project truth (I-13 applies in spirit only). State: OPEN (low). Owner: whoever adds
the second label to the ledger.

## U85 — the supervision heartbeat and the session-event reports share one sequential channel

Opened 2026-07-25 (`phase-17a.roundtrip`; gate-validator R2 — destructive symptom FIXED in-unit). One
of three live self-check runs died when the 5 s health heartbeat collided with a `notify()`
session-event report on the strictly-sequential control channel: the collision was scored
`ready=false`, the recovery machine went SUPERVISED→DEGRADED on a single miss, and every session —
including the operator's live conductor — was torn down. Fixed where it matters: a busy channel now
raises a distinct `IpcBusy`, which the supervisor treats as a SKIPPED BEAT (a busy channel is evidence
the channel is ALIVE), bounded at `MAX_BUSY_SKIPS = 3` so "busy forever" is still fail-closed, with
four tests pinning it. What remains OPEN is the contention itself — the inspector got its own channel
in 16D and the session-event path did not — so a collision still costs a heartbeat. State: OPEN
(design debt; the destructive symptom is closed). Owner: whichever track next touches the IPC client's
concurrency.

## U86 — an uncaught node-pty console-detach fault during teardown

Opened 2026-07-25 (`phase-17a.roundtrip`; gate-validator R2, second observation). During the same
torn-down run, `apps/desktop/node_modules/node-pty/lib/conpty_console_list_agent.js:13` threw
`Error: AttachConsole failed` from a helper child spawned by the vendored node-pty during ConPTY
teardown. It did not affect the receipt (the run had already failed for the supervision reason) and it
is vendor code on a teardown path, but an uncaught fault in a helper process is not something to leave
undescribed. Wanted: reproduce deterministically (kill a session while another is starting) and, if it
recurs, guard the teardown path. State: OPEN (low). Owner: `phase-17a.close` or 17E.

## U87 — neither entry point named in the 17A exit criterion is receipt-covered

Opened 2026-07-25 (`phase-17a.close`; gate-validator R1). The criterion says the governed conductor
spawn runs "on launch (and via an explicit pane-1 control)". All three in-Electron self-checks call
`launchConductorSession` directly through the self-check ctx (`apps/desktop/main.js:1200`), so what is
receipt-proven is the launch FUNCTION, not either operator-facing trigger: the on-launch branch
(`main.js:1150-1153`) is explicitly skipped whenever `SHELL_SELFCHECK` is set, and the `> live` control
(`preload.js:57` -> `ipcMain.handle("conductor:launch")`, `main.js:835`) has no self-check and no unit
test. Both legs are single unconditional calls into the same gated path and the `live`-gating logic
reads correct by inspection, so the risk is low — but "on launch AND via an explicit control" is
currently ASSERTED, not evidenced. Wanted: the assembled 17E receipt drives the real auto-launch (no
`SHELL_SELFCHECK` short-circuit) and the real button IPC. State: OPEN. Owner: `phase-17e`.

## U88 — the recovery banner never refreshes after supervision goes READY

Opened 2026-07-25 (`phase-17a.close`; gate-validator R2). `sendRecovery()` (`apps/desktop/main.js:260`)
runs once in bootstrap, BEFORE the supervisor verifies its channel; neither `onSupervisionRestored`
(`main.js:1025`) nor the successful-launch path (`main.js:660-663`) pushes a fresh `shell:recovery`, so
`interruptedNotice` (`apps/desktop/renderer/renderer.js:349-361`) keeps rendering
`admission SHUT (awaiting a verified channel)` for the life of the shell — including while a live
conductor is answering in pane 1. The direction is fail-closed (the banner can never falsely read OPEN,
so invariant 2 and the criterion's "SHUT ends only on a genuinely admitted governed session" both
hold), and the banner code is untouched by this track — but it is stale operator-facing text on the
exact surface 17A is about. Wanted: re-push the recovery view on supervision-restored and on a
successful conductor launch. State: OPEN. Owner: `phase-17d` (defect closure) or the 17E chrome pass.

## U89 — the conductor badge's fallback lags one shell start

Opened 2026-07-25 (`phase-17a.close`; spec-audit F-1). `apps/desktop/main.js:1127` sources the conductor
selection feed ONCE, before the probe runs (`main.js:607`, inside `launchConductorSession`), and never
re-sources it. `.roundtrip` put the probe verdict into `tools/live/emit_conductor_selection.py:72-75`,
but the rendered badge reads `conductorFeed` (`main.js:90` -> `renderer.js:186`, `b.isFallback`); the
launch state does carry `modelProbe` to the renderer (`main.js:406,608,654`) yet `renderer.js:198-206`
draws only `l.state`/`l.reason`. Consequence: on the ONE run in which the probe first records a
CLI-default fallback, the badge reads `CONDUCTOR - fable-5` with no `(fallback)` while pane 1 runs the
vendor default; it self-corrects on the next shell start. Benign on this host today (the verdict is
ACCEPTED -> `claude-fable-5`, so no fallback exists to hide), but it is a one-run silence in the
direction invariant 3 and directive §16 17A forbid. **Correction of record:** the `.roundtrip` evidence
report §4 criterion 5 records badge-fallback surfacing as PASS without this timing caveat; reports are
append-only, so the caveat is recorded HERE and in the 17A track report §6, not by editing that file.
State: OPEN. Owner: `phase-17b`/`phase-17d`.

## U90 — `conductor_launch_ticket@1.0` was never bumped through two breaking field additions

Opened 2026-07-25 (`phase-17a.close`; spec-audit F-2). `tools/live/emit_conductor_launch.py:109` and
`apps/desktop/conductor/launch-source.js:37` both still pin `conductor_launch_ticket@1.0`, but `.pty`
added REQUIRED fields (`launch.cwd`, `launch.executable`, `identity.session_id`, `lease.session_id`,
`lease.durable` — hard-enforced at `launch-source.js:84-98`) and `.roundtrip` added `model_probe`
(`emit_conductor_launch.py:308`). The sibling ledger schema was bumped correctly for a strictly smaller
change, with an explicit read-compat set (`terminal_lease.py:61-66`, `terminal_lease_ledger@1.1` +
`READABLE_LEDGER_SCHEMAS`). Practical risk is low (producer and consumer ship in one repo and a shape
mismatch fails closed to `launch_unavailable`), but the version string now misdescribes the contract and
a real drift would surface to the operator as "malformed payload" rather than "version drift". State:
OPEN. Owner: whichever track next edits the ticket (expected `phase-17b`).

## U91 — the model probe skips the profile-eligibility gate, and both emitters hard-code the `cloud` profile

Opened 2026-07-25 (`phase-17a.close`; spec-audit F-3; invariant 20 / I-D2). `tools/live/probe_conductor_model.py:9-11`
claims it runs "the SAME live-gate chain the conductor launch runs"; `build_model_probe` (`:130-146`)
runs provider-live -> terms -> CLI-present -> I-X3 but omits `ProfileLoader.assert_startup([cap], live_auth)`
— gate (1) of `node_runtime/supervisor/conductor_pane_spawn.py:212` and the only call site of
`check_eligible` (`control_plane/profiles/loader.py:52-58`), which is where the air-gap invariant is
enforced. Under an `offline_airgapped` profile the probe would still spend a live `claude` call given a
present `live_operation.json`. Broader, and pre-existing: `emit_conductor_launch.py:223` hard-codes
`ProfileLoader(DeploymentProfile("cloud"))` (inherited verbatim from 16C `emit_conductor_spawn.py:166`),
so the air-gap branch is structurally unreachable in the product path and the deployment profile is
sourced from no operator artifact at all. 17A is the first track where that gate would fence an
AUTOMATICALLY executed live session, which is why it is registered now. Not covered by U78 (terms, not
profile). State: OPEN. Owner: `phase-17d`.

## U92 — the launch self-check's D-LOOP-1 assertion is blind on the ticket-undelivered branch

Opened 2026-07-25 (`phase-17a.close`; gate-validator R5, observed during its F1 mutation). When the
ticket is refused/malformed, `conductor-launch-selfcheck.js` records `lease_released:false` and
`in_use_after_release:null` — it never learns a lease id and never exercises `--release-session` on that
path. The PRODUCT path does release (`apps/desktop/main.js:618`,
`releaseConductorTerminal(sessionId, "ticket undelivered")`, U77) and the scratch ledger file is deleted,
so nothing leaked in any observed run; what is missing is the receipt's ability to SEE it. Wanted: assert
the release on the refusal branch too. State: OPEN (low). Owner: `phase-17d`/`phase-17e`.

## U93 — the ConPTY child starts before admission is granted

Opened 2026-07-25 (`phase-17a.close`; spec-audit F-5; invariants 2/29). `terminal/conpty/session-manager.js:63`
starts the child, then requests admission at `:70`, killing it at `:76` and transitioning to `REFUSED` if
supervision denies. Correct and fail-closed, and pre-existing manager behaviour — but 17A is the first
track to route a real live FRONTIER CLI session through it, so for the duration of the admission
round-trip a vendor process exists un-admitted. Invariant 29 says never trust the harness; the honest
statement is that containment here is start-then-verify, not verify-then-start. Wanted: admit first, or
start suspended. State: OPEN. Owner: `phase-17d` / the U25 OS-containment work.

## U94 — an empty credential-scrub list is indistinguishable from a producer bug (sharpens U78(b))

Opened 2026-07-25 (`phase-17a.close`; spec-audit F-4). `apps/desktop/conductor/launch-source.js:81`
accepts `env_scrub_names: []` as well-formed and `scrubbedLaunchEnv` (`:281-286`) deletes exactly what it
is told, with no independent classifier of its own; meanwhile `launch.env_credential_scrubbed:true` is set
unconditionally at `tools/live/emit_conductor_launch.py:289`. A producer bug emitting `[]` therefore looks
identical to a legitimately clean host — and the `.pty` report §5 correctly says `env_scrub_count` is
host-dependent and may legitimately be 0. The `.pty` receipt catches this BEHAVIOURALLY (it measures the
child's actual key set), but the runtime contract does not. Also NIT: `SOW_TERMINAL_LEASE_LEDGER`
(`node_runtime/supervisor/terminal_lease.py:77-83`) and `SOW_MODEL_PROBE_LEDGER`
(`adapters/frontier/claude_model_probe.py:320-328`) accept an arbitrary path with no repo-root
containment check — a self-check affordance, not a product path, so §2.5 is held by convention rather
than by code there. State: OPEN. Owner: `phase-17d`.

## Ownership corrections recorded at `phase-17a.close` (2026-07-25; gate-validator R6)

`.close` adds no product code — it re-verifies, reviews, reports and tags — so three rows that pointed at
it are re-owned rather than left dangling:
- **U79** (a refused conductor relaunch is reported to the console, not to the operator's eye) -> owner
  `phase-17e` chrome pass (was "`phase-17a.close` or the 17E chrome pass").
- **U81** (no probe-verdict expiry; no in-shell re-probe control) -> owner `phase-17e` chrome pass (same
  original wording).
- **U86** (uncaught node-pty console-detach fault during teardown) -> owner `phase-17e` (was
  "`phase-17a.close` or 17E").
No text above is edited; this block is the append-only correction.


## U95 — a CODING worker pane (frontier or local) is refused: this authorization has no isolated worktree to give

Opened 2026-07-26 (`phase-17b.ticket`). `node_runtime/supervisor/worker_pane_spawn.authorize_worker_pane`
refuses `role="coding"` on BOTH localities, with the route named rather than a fake capability offered:
a frontier coding pane would write with the model's own hands inside the project workspace (the ticket's
`cwd`), and Phase 10 gives a coding node its own git worktree precisely so that cannot happen (T2); a
local coding pane is the supervised OpenCode-harness path (14C), not a bare `ollama run`. The per-pane
picker still OFFERS the coding role — the enumeration is a coarse uniform menu for local models (U63) and
an adapter fact for frontier ones — so an operator selecting it gets a fail-closed refusal that says
"deferred, not unavailable". FIX (owed): route a coding selection through a per-node worktree allocation
(the Phase 10 machinery already exists) and, for local, through `spawn_opencode_harness`, then authorize
the interactive pane bound to that worktree. State: OPEN. Owner: `phase-17b.spawn` (surface the refusal in
the picker UI) / post-17 coding integration.

## U96 — the local pane's VRAM governance is an ADMISSION rule against a stand-in budget, not a proven fit, and is not durable across processes

Opened 2026-07-26 (`phase-17b.ticket`; gate-validator B1/R2 + spec-audit MAJOR-3, across three validation
passes). 17B promoted the `ResidencyPlanner` from a display chip (16B) into an AUTHORIZATION gate, which
exposed three honest limits — now disclosed in the ticket itself rather than implied away:
1. **The budget is not a GPU query.** `tools/live/enumerate_pane_picker._host_residency` uses
   `SOW_VRAM_BUDGET_MB` when set, else a STAND-IN 12 GiB FLOOR. (The pre-17B rule was
   `total = sum(running size_vram)` — the budget INVERTED, so free VRAM was structurally 0 whenever the
   daemon had anything loaded and every local pane was refused for an artifact of the heuristic; fixed.)
   Every case carries `estimate:true` and a `budget_source` string, and the worker ticket carries that
   dict verbatim in `residency.budget`. Even an env-supplied value is `estimate:true` — nothing here
   verifies it against the card.
2. **The planner cannot see mid-generation.** The host seeding marks models resident but never sets
   `generating`, so "never mid-generation eviction" (invariant 22) could not be enforced against it. This
   build therefore refuses to displace ANYTHING: `_assert_fits_without_displacing` decides from the
   planner's read-only snapshot BEFORE `request_load` mutates it (so a refusal leaves no phantom
   LOADING/evicted entry in the operator's residency view), and the post-decision check remains as
   defence in depth.
3. **The reservation is per-process.** It dies with the emitter, unlike the durable terminal LEASE — the
   authoritative VRAM allocator on this host is the Ollama daemon itself, so two tickets issued in quick
   succession do not see each other's reservations.
FIX (owed): a real GPU-capacity query (or an operator-recorded budget in config), a `generating` signal
sourced from the daemon, and — if local concurrency ever needs bounding across processes — a durable
residency ledger mirroring `terminal_lease`. State: OPEN. Owner: `phase-17b.spawn` (surface the budget
provenance on the pane badge) / post-17 hardening.

## U97 — a codex worker pane's `-m` model id is UNVERIFIED: there is no offline codex model probe

Opened 2026-07-26 (`phase-17b.ticket`; spec-audit MINOR-7). 17A built the `claude` model probe after the
`.roundtrip` defect (a live session that answered every prompt with "there's an issue with the selected
model"), and the worker ticket reads its verdict offline for `claude_code`. The Codex CLI publishes no
model list (recorded at 15C `.detect`), so an operator label ("5.5", "5.5 Sol") reaches `-m` carried
verbatim and unverified — the same failure mode is NOT excluded for a codex pane. The ticket does not hide
it: `model_probe.source = "unprobed-codex"`, `model_available: null`, plus a note naming this row, and
`chrome.model_verified` stays false. FIX (owed): a codex equivalent of
`tools/live/probe_conductor_model.py` (one minimal `codex exec` per candidate, accepted only on a reply
that is not the CLI's own model-unavailable message), or surface "unprobed" on the pane badge so the
operator sees it before typing. State: OPEN. Owner: `phase-17b.spawn` (badge) / post-17 (probe).

## U98 — the R8 §6 operator-terms gate cannot refuse on the worker path either (extends U78(c))

Opened 2026-07-26 (`phase-17b.ticket`; spec-audit MINOR-4).
`tools/live/emit_worker_launch.build_worker_launch_ticket` defaults `operator_terms_confirmed=True` on the
recorded OP-9 basis and `main()` never passes it, so `gates["operator_terms_confirmed"]` is always true and
`LiveTermsNotConfirmed` is unreachable outside tests — exactly the condition U78(c) records for the
conductor path, now extended to every worker pane. The gate is real code on a real chain (the tests prove
it refuses when the flag is false); what is missing is a PRODUCT input that can turn it off, i.e. the
operator's terms determination living in config (alongside `live_operation.json`) rather than in a Python
default. Related: both emitters still hard-code `ProfileLoader(DeploymentProfile("cloud"))`, so the
invariant-20 air-gap branch is likewise unreachable in the product path (U91). State: OPEN. Owner:
`phase-17d`.

## U99 — `worker_launch_ticket@1.0` is pinned in code with no file in `schemas/` (same gap as U90)

Opened 2026-07-26 (`phase-17b.ticket`; spec-audit NIT-8). CLAUDE.md makes `schemas/` the single source of
truth for envelope shapes, and both the producer (`tools/live/emit_worker_launch.py`) and the consumer
(`apps/desktop/picker/launch-source.js`) pin `worker_launch_ticket@1.0` as a string constant with the shape
enforced by a hand-written JS predicate — the same gap U90 records for `conductor_launch_ticket@1.0`. The
consumer's checks are strictly STRONGER than a JSON Schema would be (they cross-read locality against the
executable actually being launched, the lease's subscription against the identity's, and the argv against
per-provider one-shot shapes), so this is a single-source-of-truth gap rather than a validation gap. FIX
(owed): add both ticket schemas to `schemas/` and validate against them in addition to the semantic checks.
State: OPEN. Owner: `phase-17d`.

## U100 — a worker terminal is counted for a ticket the shell never receives (emitter timeout after `acquire`)

Opened 2026-07-26 (`phase-17b.ticket-revalidate`; gate-validator MINOR-5, 2026-07-26).
`tools/live/emit_worker_launch.build_worker_launch_ticket` takes the DURABLE lease (`led.acquire`) before it
finishes building the ticket, deliberately: the session the ticket authorizes outlives the emitter, and the
lease is keyed on the session id the shell chose BEFORE asking precisely so it stays reclaimable (U75/U77).
The window this row records is the other half — if the emitter is killed by the caller's timeout, or the JSON
never reaches the shell, the terminal stays counted against the operator's I-X3 allowance until someone calls
`--release-session`. `apps/desktop/selfcheck/worker-launch-selfcheck.js` does that in a `finally`; nothing in
this sub-step obliges a PRODUCT caller to, because no product caller exists yet — the picker click is not
wired to a ticket until `.spawn`. U77 covers the conductor path's equivalent and is marked RESOLVED; it does
not cover the worker path's undelivered-ticket branch. FIX (owed): `.spawn` must release by session id on
every path where the ticket does not become a running session (timeout, parse failure, spawn failure,
renderer teardown), with an in-Electron receipt leg proving `in_use` returns to its prior value. Dead-holder
reaping remains the backstop, not the mechanism. State: OPEN. Owner: `phase-17b.spawn`.

## U101 — `refused_by` was added to `worker_launch_ticket@1.0` without a version bump (the defect U90 named, in the track U90 named)

Opened 2026-07-26 (`phase-17b.ticket-revalidate`; spec-audit MINOR-6).
This pass added `refused_by` (the machine-readable gate id) to every ticket, and `phase-17b.ticket` earlier
added `residency.budget` — two additive fields under an unchanged `@1.0` pin. U90 records exactly this defect
for `conductor_launch_ticket@1.0` and names its owner as "whichever track next edits the ticket (expected
`phase-17b`)": this IS that track, and it added fields rather than bumping. Both additions are
additive-OPTIONAL and no consumer requires the older shape, so nothing breaks today — this is a
versioning/disclosure defect, not a compatibility one. It is recorded rather than fixed in-unit because the
bump belongs with the `schemas/` files U99 owes (a pin that is only a string constant cannot be versioned
meaningfully), and because renumbering mid-track would invalidate the receipts this sub-step is about to be
re-validated on. FIX (owed): bump to `worker_launch_ticket@1.1` / `conductor_launch_ticket@1.1` together with
the `schemas/` files, following the `terminal_lease_ledger@1.1 + READABLE_LEDGER_SCHEMAS` precedent (accept a
set of readable versions, produce the newest). State: OPEN. Owner: `phase-17d`.

## U102 — the disclosed `running_vram_mb` is not the number the VRAM gate enforced

Opened 2026-07-26 (`phase-17b.ticket-revalidate`; gate-validator reservation 4).
In `tools/live/enumerate_pane_picker._host_residency` the budget dict's `running_vram_mb` sums the daemon's
`size_vram` values, while the planner is seeded from MERGED footprints (`size_vram` where the daemon supplies
one, else the on-disk `/api/tags` size). A model the daemon reports running with `size_vram: 0` —
CPU-offloaded — therefore contributes 0 to the disclosed figure and its full on-disk footprint to
`planner.used_vram_mb()`. The field also carries a different quantity on the falsified row (the merged
`resident_vram`, so the message can name what contradicted the budget) than on the healthy row. The GATE is
unaffected: it decides from the planner's own snapshot, and the discrepancy errs toward under-reporting free
VRAM, i.e. fail-closed. What is wrong is the DISCLOSURE (invariant 27): a ticket states a number that is not
the one its authorization was decided against. FIX (owed): disclose `used_vram_mb` from the planner snapshot
and keep `running_vram_mb` strictly as "what `/api/ps` reported", named so. State: OPEN. Owner: `phase-17d`.

## U103 — the ticket shape contract's metacharacter/frontier-token rules can refuse a legitimate host

Opened 2026-07-26 (`phase-17b.ticket-revalidate`; gate-validator reservation 5).
`apps/desktop/picker/launch-source.js` now refuses any argv element or executable containing a shell
metacharacter, and widened the frontier-token boundary to accept whitespace/quotes as well as path
separators. Both are deliberate fail-closed guards (validator MINOR-4), and both can fire on a legitimate
host: a repo path containing `&`, `;` or `|` (e.g. `D:\R&D\project`, which reaches argv through codex's
`--cd`), or an Ollama tag whose name matches the frontier boundary (`claude-ish:8b`,
`hf.co/x/claude-clone:q4`). The operator would see the generic `unavailableWorkerTicket` shape-drift error
rather than a governed refusal with a reason — fail-closed, but opaque. Not reproducible on THIS host
(checked: all 43 Ollama tags and both resolved CLI paths pass cleanly). FIX (owed): scope the metacharacter
rule to the argument POSITIONS that can carry a model tag/path rather than the whole vector, and surface a
specific reason ("the ticket's argv was refused by the shell shape contract: <which rule>") instead of the
generic unavailable shape. State: OPEN. Owner: `phase-17d`.

---

## Append-only CORRECTIONS to U96 (2026-07-26, `phase-17b.ticket-revalidate`)

Registers are append-only, so U96's text above is left as written and corrected here. It was accurate when
recorded and is now stale in four ways, all found by the gate-validator's independent re-validation:

1. **The rule it describes is not the rule that ships.** U96 item 1 describes the pre-17B rule as
   `total = sum(running size_vram)` and the fix as a "STAND-IN 12 GiB **FLOOR**". The committed `.ticket`
   state was `max(running, 12288)` — and that formulation was itself the BLOCKING-1 defect: above the floor
   the running set defines the budget AND consumes it, so free VRAM was structurally 0 on a busy host (a
   24 GB card serving 16 GB refused every local pane with 8 GB genuinely free). The shipped rule is a
   CONSTANT, fixed before the host's residency is read and never derived from it.
2. **Falsification is new and unrecorded.** When the host reports more resident than the budget claims
   exists, the budget is not gated on at all: no planner, `established:false`, and a `budget_source` naming
   the contradiction and the one-line fix. The local authorization repeats that reason, so "could not
   establish a budget" is never rendered as "your model does not fit".
3. **`established` is new**, and the local gate refuses on `established is not True` as well as on a missing
   planner — an authorization is never granted against a budget nobody vouched for.
4. **The stand-in's usability cost stands, and U96 should be read as carrying it.** With no
   `SOW_VRAM_BUDGET_MB`, a host with more than 12 GiB resident gets an honest fail-closed refusal on every
   local pane. The arithmetic artifact is gone; the consequence of guessing the capacity is not. A real
   capacity signal (a GPU query) is the remaining fix and is NOT built — this session could not execute
   `nvidia-smi` to verify one, and shipping an unverifiable host probe into an authorization gate was
   judged worse than the honest stand-in. Owner: `phase-17d`.

## Append-only CORRECTION to the residency-display family (2026-07-26, `phase-17b.ticket-revalidate`)

The degraded-residency branch introduced by the BLOCKING-1b fix, and fixed in the same unit, is worth
recording against U63/U64: when no planner could be built, the enumeration returned an EMPTY residency map,
and `control_plane/nodes/pane_picker` defaults an absent model to `not_loaded` — so a model the Ollama daemon
was actively serving was shown to the operator as not in VRAM. A missing fact was rendered as a false one,
contradicting invariant 27 and `residency_planner`'s own "no fabricated residency state ever reaches the UI"
(gate-validator FAIL-1 / spec-audit MAJOR-2). Fixed in-unit: the enumeration returns `None` (no view) rather
than an empty map, `build_pane_picker(residency=None)` renders the new `UNKNOWN` state for every local model,
and the two states are pinned apart by
`tests/unit/test_host_residency_budget.py::test_no_residency_view_renders_unknown_never_not_loaded`.

---

## U104 - a third governed cross-process envelope pinned in code with no file in `schemas/`

**Opened:** 2026-07-26, `phase-17b.ticket-revalidate2` (spec-audit MAJOR-1). **Owner:** `phase-17d`.

`host_residency@1.0` is produced by `tools/live/enumerate_pane_picker.HOST_RESIDENCY_SCHEMA` and consumed
by `apps/desktop/picker/source.isWellFormedResidency`. Like `worker_launch_ticket@1.0` (U99/U101) and the
`terminal_lease_*` envelopes (U90), it is a versioned contract that crosses a process boundary and has NO
schema file, so CLAUDE.md's "JSON Schemas in `schemas/` are the single source of truth, frozen `@1.0`" does
not actually cover it. Registered rather than fixed for the same reason as U90/U99: `schemas/` is inside
the Phase-0 FROZEN set, so adding a file there is a manifest-affecting act belonging to the unit that fixes
the whole family, not to a sub-step whose scope is one picker selection.

**What is NOT deferred, because the audit was right that the precedent did not transfer.** U99's mitigation
was that the JS predicate is STRONGER than a schema would be. `isWellFormedResidency` as first written
checked only the schema string and that `budget` is an object, while the in-Electron self-check does
load-bearing arithmetic on `snapshot.used_vram_mb` and `snapshot.models[].footprint_mb`. Those fields are
now validated by the predicate itself, so the consumer refuses a payload it would otherwise have computed a
VRAM budget from. The registered gap is the missing FILE and the single-source-of-truth rule - not an
unvalidated payload.

**Residual (honest):** three envelopes now share this gap. The right fix is ONE unit that writes
`schemas/{worker_launch_ticket,terminal_lease,host_residency}.schema.json`, validates both producers and
both consumers against them, and records the manifest change - not three more code-side pins.

---

## U105 - the credential scrub list is measured in the EMITTER's environment and applied to the SHELL's

**Opened:** 2026-07-26, `phase-17b.ticket-revalidate3` (spec-audit MINOR-2). **Owner:** `phase-17b.spawn`.

`node_runtime/supervisor/worker_pane_spawn.worker_env_scrub_names()` builds the scrub list by reading
`os.environ` of the PYTHON EMITTER; `apps/desktop/conductor/launch-source.scrubbedLaunchEnv` then deletes
those NAMES from the ELECTRON SHELL's base env before spawning the child. The rule is sound only while the
two environments hold the same credential-bearing variables. That was safe while the emitter was always a
direct child of the shell - and 17B itself made divergence reachable by adding per-child `opts.env`
(`conductor/launch-source.js`, `picker/source.js`), which the in-Electron self-check already uses.

**The fail-open direction:** a credential variable present in the SHELL's environment but absent from the
emitter's is never listed, so it is never scrubbed, and it survives into the launched live session. Nothing
today exercises that divergence on the product path - the emitter still inherits the shell's env - which is
why this is registered rather than fixed. The fix belongs with `.spawn`, where the shell actually performs
the spawn: the scrub set should be the UNION of the emitter's measurement and the shell's own scan of its
base env against the same name rules, so neither side's blindness can decide the result. §2.2 is not
violated by this build (no value is ever read, stored or transmitted; only NAMES cross the boundary), but
the guarantee the ticket implies is narrower than it reads. Related: U78(b), U94.

---

## U106 - the shell holds a second source of truth for each adapter's binary name

**Opened:** 2026-07-26, `phase-17b.ticket-revalidate3` (spec-audit MINOR-5). **Owner:** the U104 fix unit.

`apps/desktop/picker/launch-source.ADAPTER_EXECUTABLE` maps `claude_code -> claude`, `openai_codex_cli ->
codex`, `ollama_local -> ollama`. It is the load-bearing half of the binary ALLOWLIST (validator FINDING 1
/ B2) and is correct today, but it duplicates a fact OWNED Python-side by `adapters/detect.py` and the
adapter modules. A rename, or a legitimate wrapper on the operator's host, yields the generic
`unavailableWorkerTicket` shape-drift error with no named reason - the same opacity U103 registers for the
metacharacter and frontier-token rules, on a rule U103 does not cover.

Deliberately NOT fixed by having the ticket declare its own expected binary: a ticket that names the
executable it is allowed to launch is a self-report, and disbelieving the ticket about itself is the entire
point of this contract. The right fix travels with U104's schema unit - the allowlist becomes part of the
declared, versioned envelope emitted by the side that resolves binaries, and the shell validates against it.

---

## U107 - the headless dispatcher does NOT carry the worker path's invariant-22 no-displacement rule

**Opened:** 2026-07-26, `phase-17b.ticket-revalidate3` (spec-audit MINOR-3). **Owner:** `phase-17b.legs`.

`node_runtime/supervisor/worker_pane_spawn._assert_fits_without_displacing` refuses any local pane that
would only fit by evicting or awaiting-eviction of another model, because the planner's "evict only idle
models" rule is evaluated against a `generating` flag the host seeding never sets. The sibling headless
dispatcher `node_runtime/supervisor/pane_node_spawn.spawn_node_from_selection` still calls
`residency_planner.request_load(model)` UNGUARDED and will act on such a decision. The two paths share
`assert_selection_spawnable` and used to share `_RESIDENCY_NODE_STATE`, so the asymmetry is invisible at the
call sites. No product caller reaches the dispatcher today (`spawn_node_from_selection` is exercised only by
tests), so this is latent, not exploitable.

**Append-only CORRECTION to U96 (2026-07-26).** U96 states "This build therefore refuses to displace
ANYTHING". That is true of the worker-pane authorization path and NOT of the dispatcher, as above. Read
U96's claim as scoped to `worker_pane_spawn`. The `.legs` sub-step drives the dispatcher for real and is
where the rule must either be shared or the difference deliberately justified.

**Also corrected here:** `_RESIDENCY_NODE_STATE` is no longer imported by `worker_pane_spawn` at all. The
worker path reports `launch_authorized` on BOTH localities (spec-audit MAJOR-1, fixed 2026-07-26 - a
residency status is a fact about a MODEL and an already-resident one was being reported as a `ready` NODE).
The dispatcher keeps the table because it has genuinely spawned an adapter handle by that point. The two
paths now differ on this deliberately, which is why it is recorded rather than left to be rediscovered.

---

## U108 - `CLAUDE.md`'s documented test command does not run on this host

**Opened:** 2026-07-26, `phase-17b.ticket-revalidate3` (gate-validator MINOR-3). **Owner:** operator-facing;
raise at `finalize`.

`CLAUDE.md` documents `python -m pytest tests/ -q`. On this host the default `python` is 3.14.6 and that
command produces `71 errors in 3.15s` / `ModuleNotFoundError: No module named 'jsonschema'`; only
`py -3.12 -m pytest tests/ -q` runs the suite. Likewise `terminal/` has no `package.json`, so `npm test`
there fails with ENOENT - that suite is `node --test`. Neither is a product defect, but a reviewer following
`CLAUDE.md` literally reads a red suite as a build failure, and the round-4 gate-validator hit exactly that.

NOT fixed by editing `CLAUDE.md`: it is the operator's own instruction file and this loop does not rewrite
the operator's instructions to match the machine. Recorded so the next reader knows, and flagged for the
final report as a one-line operator correction.



---

## U109 - the shell does not verify that a ticket's `node_id` relates to the pane it authorizes

**Opened:** 2026-07-26, `phase-17b.spawn` (gate-validator MINOR-5). **Owner:** the schema unit that carries
U104/U106 (17D).

`fetchWorkerLaunchTicket` fails closed on a ticket for a different `session_id` or `pane_id` than the one
about to be spawned (our reclaim key would free someone else's terminal), and `isWellFormedWorkerTicket`
requires a non-empty `node_id` - but nothing checks that the node id BELONGS to that pane. The in-Electron
receipt asserts `node_id === "worker-<pane>"` on both legs; the product path does not.

DELIBERATELY NOT FIXED. `worker-<pane>` is minted by `worker_identity` in Python, and re-implementing that
rule in the shell is precisely the duplicated-fact class U106 was opened for (`ADAPTER_EXECUTABLE`): two
copies of one Python-owned fact, one of which will drift. The shape contract's job is to disbelieve the
ticket about things the shell can check independently (what binary runs, which session is counted); the
naming convention is not one of them. If the schema unit gives `worker_launch_ticket@1.x` a file in
`schemas/`, the relationship belongs there as a constraint both sides validate against.

---

## U110 - a worker pane whose session ended has no per-pane relaunch control

**Opened:** 2026-07-26, `phase-17b.spawn`. **Owner:** 17E (operator surface).

When a governed worker session exits or is killed, `main.js` revises the pane's chrome to
`session_exited`/`session_killed` with `governed:false` and pushes it to the renderer, so the badge stops
reading `live` (spec-audit MAJOR-1, fixed in-unit). What the pane does NOT get is a relaunch affordance of
its own: the operator re-opens the picker and selects again, which runs the identical governed path (the
launcher forgets the ended session record first, exactly as pane 1 does). So nothing is blocked - the
ergonomics are simply thinner than the conductor pane's dedicated control. Recorded rather than built,
because a per-pane control is 17E surface work and inventing one here would be a second, less-tested spawn
entry point.

---

## U111 - the in-Electron live legs consume a real subscription terminal against a SCRATCH ledger

**Opened:** 2026-07-26, `phase-17b.spawn` (spec-audit MINOR-8). **Owner:** 17E. **Inherited from** 17A
`.pty`, now applied to a second live session class (the worker pane).

The `.spawn` receipt starts a real interactive `claude` worker while `SOW_TERMINAL_LEASE_LEDGER` points at
a per-pid scratch file. For that session's lifetime a live frontier terminal exists on the operator's
subscription that the REAL durable ledger does not count - the I-X3 governor is, for that window,
deliberately not the one enforcing the cap. The receipt now DISCLOSES this (`scope_note_live_terminal`).

The redirection is not gratuitous: against the real ledger the check would adopt, count against, and then
release terminals the operator's own running conductor holds, and its "in_use is 0 again" assertion would
be false on any host whose conductor is legitimately running. The honest fix is a governor that can tell a
DIAGNOSTIC holder from a product one and count both - owed to 17E, where the assembled run needs exactly
that distinction anyway. Window today: one bounded session per receipt run, killed in the same run.

---

## Register update 2026-07-26 (`phase-17b.spawn-revalidate`) — STATE corrections + U112–U114 opened

The independent re-validation of the `.spawn` state found the register drifting in the direction this
file is least suspected of: **understating progress**. Three rows still read as OPEN/owed while the
`.spawn` evidence report claimed them closed or fixed, so the two documents told a reader different
stories (gate-validator MINOR-3). Corrected here, append-only — the original rows stand unedited.

**U70 — spawn half RESOLVED 2026-07-26 (`phase-17b.spawn`); mode-toggle half still OPEN.**
The row's "State: OPEN. Owner: 16F (spawn) / 16E-F (mode toggle)" was written when a picker selection
recorded a preview and started nothing. It now performs the governed live spawn:
`apps/desktop/picker/worker-spawn.js` executes an ISSUED `worker_launch_ticket@1.0` in the pane's
ConPTY through the supervised SessionManager under the Python-minted node identity, or records a
refusal that starts nothing and names its gate. Proven in-runtime by
`docs/evidence/receipts/PHASE17B_SPAWN_SELFCHECK.json` (a real `ollama run qwen3:8b` and a real
`claude --model claude-fable-5` in real panes). **Half (b) is unchanged and still OPEN**: the picker UI
still hardcodes an `autonomous` preview and has no attended/autonomous toggle — owner 17E.

**U100 — RESOLVED 2026-07-26 (`phase-17b.spawn`).** The row's "FIX (owed): `.spawn` must release by
session id on every path where the ticket does not become a running session" is done. The session key
is chosen BEFORE the ask, so it is reclaimable even when no ticket arrives; the undelivered, refused,
scrub-abort and spawn-failure paths each release under it; exit/kill/quit release the running one.
Pinned headlessly (`apps/desktop/test/worker-spawn.test.js`). **The disclosed limit stands:** the
release is proven by the headless suite and NOT in-runtime — forcing a mid-flight emitter failure
inside Electron would prove the corruption rather than the release — and the receipt's scope note says
so. Dead-holder reaping remains the backstop, not the mechanism.

**U105 — RESOLVED 2026-07-26 (`phase-17b.spawn`).** The row's closing line ("which is why this is
registered rather than fixed") is stale: it was fixed in the same sub-step, and it was a REAL fail-open
on this host rather than tidiness. `worker_env_scrub_names(shell_env_names=…)` now classifies the UNION
of the emitter's environment and the NAMES the shell holds, under the ONE Python rule; the shell sends
names only (a `name=value` entry is refused outright, its own gate id) and its leftover guard matches
case-insensitively. The divergence is real here because Python's `os.environ` upper-cases every key on
Windows while Node keeps the created case and deletes by exact spelling, so a mixed-case credential var
was named in the ticket under a spelling the shell could not delete by — and reached the child.
Reverting the fix turns the in-Electron receipt RED (`shell_only_name_absent_from_child:false`).

**U109 — the RATIONALE is corrected; the disposition is unchanged.** The row declines to check
`node_id === worker-<pane>` on the grounds that duplicating a Python-owned naming rule is the U106
class. That reason is not the rule this file actually follows (spec-audit MINOR-8): `launch-source.js`
already hard-codes the `sub-<adapter>` subscription-ref rule and the whole `ADAPTER_EXECUTABLE` map,
both of which are Python-owned facts duplicated deliberately. The honest statement of the posture is
narrower: the shell duplicates a Python fact when disbelieving the ticket about ITSELF is the point
(which binary runs, which subscription is counted — an attacker-controlled ticket cannot be its own
witness), and declines to when the check would only restate a naming convention that decides nothing
the shell enforces. `node_id` is in the second class TODAY because nothing in the shell branches on its
shape. The disposition therefore stands, but it rests on "this check buys nothing enforceable", not on
"the shell never duplicates a Python rule" — which is false of the file as written. Owner unchanged
(the schema unit, 17D), where a `schemas/worker_launch_ticket@1.x` file would let both sides validate
the relationship instead of either side asserting it.

**Also closed in this pass (recorded for completeness, no row of their own):** the shape contract now
validates `launch.cwd` against the governed workspace the shell asked from — it previously accepted any
non-empty string, so "the ConPTY is bound to the governed workspace" rested on the producer plus one
in-runtime assertion (spec-audit MINOR-8, second half).

---

## U112 - OpenCode is absent from the governed picker→launch path (invariant 23)

**Opened:** 2026-07-26, `phase-17b.spawn-revalidate` (gate-validator MINOR-6). **Owner:** 17E, or a new
operator-authorized track. **Pre-existing since 16B — NOT introduced by `.spawn`.**

Directive §16's 17B track text reads "local via the host runtime (**Ollama/OpenCode**)", and invariant
23 makes OpenCode first-class ("coding harnesses interchangeable behind one contract"). The governed
launch path admits three adapters only — `claude_code`, `openai_codex_cli`, `ollama_local`
(`node_runtime/supervisor/worker_pane_spawn.authorize_worker_pane`) — and
`tools/live/enumerate_pane_picker.py` never enumerates opencode, so the picker cannot offer it and the
operator cannot select it.

It FAILS CLOSED (an unenumerated option is refused by `host_enumeration` with a named reason, exactly
like a fabricated one), so this is a coverage gap and not a hole. What makes it register-worthy is that
the `.spawn` evidence report's "Explicitly does NOT claim" list did not mention it: a reader comparing
the track text against the receipt would reasonably conclude both local runtimes were exercised, and
only Ollama was. 14C proved OpenCode live in its own track; the PICKER path has never offered it.

---

## U113 - the in-Electron receipt runs are polluted by a node-pty helper crash

**Opened:** 2026-07-26, `phase-17b.spawn-revalidate` (gate-validator observation). **Owner:** 17E.
**Pre-existing node-pty behaviour — not introduced here.**

Every `selfcheck/run.js worker-spawn` run prints, after the check's real work is done:
`node_modules\node-pty\lib\conpty_console_list_agent.js:13  Error: AttachConsole failed`.
It is a DETACHED helper process; the shell still exits 0 and the receipt is written and valid. The
defect is evidentiary, not functional: raw Node stack noise in the one artefact an operator reads to
judge a live run would happily camouflage a REAL crash, and a reader cannot tell at a glance which
class they are looking at. Fix options (unevaluated): pin/patch the helper, suppress the detached
agent, or have the runner classify and label known-benign teardown noise rather than pass it through.

---

## U114 - `pane:new` still accepts a renderer-supplied `file`/`args`, so a supervised-but-UNTICKETED model process is reachable

**Opened:** 2026-07-26, `phase-17b.spawn-revalidate` (spec-audit, "pre-existing, not introduced here").
**Owner:** 17E. **Pre-existing — outside the `.spawn` diff, recorded because `.spawn` bounds a claim
that a reader will now read more strongly.**

`sanitizeRendererSpec` strips the two governance-bearing fields a renderer must never set (`env`, `cwd`
— added at 17A when they started carrying the credential scrub and the workspace binding), but
`pane:new` still passes `file` and `args` through to `createPaneWithSession`. A renderer that asked for
`{file: "claude.exe", args: [...]}` would get a SUPERVISED session (admission is enforced, invariant 2
holds) under the shell's own node id, with no launch ticket, no I-X3 lease, and no credential scrub —
i.e. an uncounted live frontier terminal reachable from the least-trusted surface (invariant 29).

This bounds a claim `.spawn` makes: `worker-spawn.js` is the only place the shell executes a launch
TICKET, which is true, and is NOT the same as "the only place the shell starts a model process". The
honest fix is to make `pane:new` mint an ordinary local shell only (no caller-chosen binary), and route
every model process through the ticket path. Not done here: `pane:new` is the operator's own terminal
affordance and changing what it may spawn is a product-surface decision, not a review fix.

---

## U115 - the live OpenCode worktree integration test is not robust to concurrent local-model load

**Opened:** 2026-07-26, `phase-17b.spawn-revalidate` (gate-validator, self-reported interference).
**Owner:** 17D (test hygiene).

`tests/integration/test_opencode_worktree_live.py::test_live_opencode_drives_local_model_in_isolated_worktree`
FAILED once during the re-validation, in a pytest run the validator executed while its own in-Electron
self-check was holding a live `ollama run qwen3:8b`. It passes in isolation (`1 passed in 5.66s`) and
the clean serial full run is 1338 passed. So the suite total is honest and no product defect is
implied — but a test that fails on host contention rather than on code is a test that will eventually
be believed when it is wrong, in either direction. It should either serialize against the local-model
resource explicitly or state its precondition and skip-with-record when the daemon is already loaded.
Recorded rather than fixed here: this unit's scope is the `.spawn` review findings, and changing a
live integration test's gating deserves its own pass.


---

## Register update 2026-07-26 (`phase-17b.legs`) — U58 worker half RESOLVED, U60 root-caused + RESOLVED, U116-U119 opened

Append-only. Earlier entries are left exactly as written; the corrections below are additive.

### U58 — STATE CHANGE: the worker half is RESOLVED (the conductor half is unchanged)

The entry above (§862) records that the governed dispatch was proven **mock-first** and that
"a LIVE worker leg is unrepresentable without its own evidence record", with the live worker
CANDIDATE publication owed to the operator-run assembled run (16F). That is **superseded for the
worker leg**: `phase-17b.legs` made it representable and then produced it.

Receipt: `docs/evidence/live/PHASE17B_LEGS_DISPATCH_FEED.json` — `legs.workers = live`,
`worker:worker-claude-live = live`, evidence row `verified:true` with the CLI-reported checkpoint
`claude-opus-5[1m]` dated to a call spent in that run, stage gate PASS 1/1, acceptance PASS,
`accepted_count 1`, `live_workers_owed.owed = false` (DERIVED from the packet's own evidence, never
asserted by a caller), `torn_down:true`. Reproduced three times independently (254 s, 318 s, 277 s).

**Still owed, and not to be read as closed by the above:** the dispatch's CONDUCTOR leg is still
`mock` on this path (`legs.conductor = mock`) — a live conductor session is 17A/17C territory. The
`live_workers_owed` note text on a mock-first feed still points at 16F and is correct for that path:
an app launch runs the emitter with no flag and must never spend the operator's subscription.

### U60 — STATE CHANGE: root-caused and RESOLVED (the recorded diagnosis was wrong)

The entry above (§896) calls this "transient loopback-MCP flakiness" and an
"environmental/robustness limit — NOT a governance defect". **Both halves of that are withdrawn.**
It is deterministic and it is ours: `mcp_server/server.py` gives each connection handler
`timeout = 60` (an F6 guard — idle handler threads must not linger). A live `claude` worker call
runs longer than that, so while the model is thinking the SERVER reaps the caller's connection.
Writing into that socket then SUCCEEDS (the FIN is unread and the bytes land in the local send
buffer) and the failure surfaces on the READ as `WinError 10053` — where retrying is forbidden,
because a delivered request may already have been applied. The send-side retry therefore never
fired, and two live dispatches died on it.

Fixed by checking liveness BEFORE the write (`McpClient._drop_if_peer_closed`), which is what makes
the recovery safe rather than a guess: nothing has been sent, so re-establishing cannot re-apply
anything. Buffered or unrequested bytes are a channel desync and fail closed instead of
reconnecting. Pinned by `tests/integration/test_mcp_client_reconnect.py`, whose reap test drives the
server's real idle-reap path and reproduces the exact `WinError 10053` when the fix is disabled.

**Narrowed, not eliminated (recorded):** a reap landing between the check and the `sendall` restores
the old behaviour — the write succeeds into a FIN'd socket and the read fails closed. That outcome
is correct but unrecovered. And structurally, a 420 s live worker call against a 60 s handler
timeout means EVERY live dispatch is reaped at least once and relies on this reconnect. That is a
workaround for a timeout mismatch, not a resolution of it.

### U116 — a live worker exchange has no enforceable token bound; only a wall clock bounds it

`LIVE_WORKER_MAX_TOKENS` is threaded through the adapter contract to
`ClaudeCliBackend.generate(max_tokens=...)` and then **cannot be applied**: `claude -p` accepts no
such flag, so the value is inert. The only bound that actually binds one live exchange is
`LIVE_WORKER_TIMEOUT_S` (420 s). Smoke-scale is currently guaranteed by CONSTRUCTION — the governed
loop routes exactly one `reasoning` subtask to the single live node — not by a cost ceiling. The
comment claiming the token ceiling "keeps that exchange minimal" was false and has been corrected in
place; the underlying gap is recorded here rather than papered over. Owner: whichever track first
needs multi-exchange live work, where construction stops being the bound.

### U117 — cost-to-accepted-output is not instrumented at the first site that spends on a WORKER

Buildout §4 requires cost-to-accepted-output instrumentation from day one. The new
`worker_evidence` rows record `executed` / `spent` / `verified` / `model` — whether a call happened,
not what it cost. `claude -p --output-format json` already returns `total_cost_usd` and a
`modelUsage` block, and `extract_reported_model` parses that same payload two functions away, so the
magnitude is available and simply not carried. Raised by the spec-auditor (MINOR-4). Not fixed here:
adding a spend field to the evidence row changes the acceptance packet's validated shape, which
deserves its own pass rather than riding on the leg work.

### U118 — `worker_legs`, `worker_evidence` and `node_refusals` reach no UI surface

`apps/desktop/main.js` forwards `live_workers_owed` from the dispatch feed; the per-node worker legs,
the evidence rows they are derived from, and the node refusals added by this sub-step are not
forwarded, so the operator cannot see WHICH worker was live or what a failed one objected to without
reading the JSON. Invariant 27 (the orchestra is visible) is partially met at the feed and not at the
surface. Owner: 17D/17E, where the operator-visible surfaces are the work.

### U119 — the live-run receipt cannot, by itself, distinguish a live run from a stubbed one

The gate-validator demonstrated this directly: stubbing `subprocess.run` inside the claude backend
(equivalent to shadowing `claude` on PATH) produced a feed matching the committed receipt in every
field but the content-addressed packet id, in about two seconds with no spend. It then corroborated
the real run from filesystem evidence OUTSIDE the artifact (a terminated CLI session log written
312 ms before the durable lease release, 810 ms before the receipt).

This is the U43 STATED LIMIT applied to the receipt rather than to the code: instrumentation on a
caller-supplied object constrains its class, not its behaviour, so `live` is trustworthy exactly as
far as the caller that mints the handle is. Partially narrowed here — the receipt now carries a
`live_run` block (real `run_ts`, measured `elapsed_s`, `cli_present`, `repo_live_config_exists`,
requested model, the bounds in force) and the packet is stamped with the real clock instead of the
mock path's replayable `DISPATCH_TS`, so the run at least dates itself and records what it depended
on. None of that PROVES liveness, and it is recorded as a limit rather than claimed as proof.


---

## Register update 2026-07-26 (`phase-17b.close`) — whole-track close, U120–U132 opened

Both mandatory reviews ran foreground in the `.close` unit against the committed track
(`gate/phase-17a..81c098a`): **gate-validator PASS_WITH_RESERVATIONS** (five load-bearing
falsifications, all RED, all restored byte-identically; it re-ran every suite and both in-Electron
receipts itself) and **spec-auditor PROHIBITED DRIFT: NONE** (3 MAJOR / 11 MINOR, no BLOCKING),
aimed at the **composition** of `.ticket` + `.spawn` + `.legs` rather than at each alone.

Two findings were factual errors in the close report itself and were **corrected there** (validator
M-4: three D-LOOP-1 keys claimed for "every receipt" when the `.ticket` receipt carries none of them;
M-5: the real lease ledger called "untouched" when `.legs` acquires and releases a durable lease by
design). One was **discharged with a real run** (M-7: `conductor-dispatch-selfcheck.js` was edited by
`.legs` and never re-run — re-run in-Electron at `.close`, `ok:true`). The rest are recorded here.

**Product code was deliberately NOT changed after validation.** Fixing in this unit would have voided
the five falsifications and the receipt comparisons the gate rests on — the reasoning recorded at
`phase-17a.close` §5. Nothing below is softened; each entry carries the failure scenario that makes it
real and an owner.

### U120 — a `live` worker aggregate is derivable for a run that was partly MOCK

**Opened:** 2026-07-26, `phase-17b.close` (spec-audit MAJOR-1). **Owner:** 17D/17E — wherever a mixed
pool first becomes likely.

`LiveGovernedFlow._worker_evidence` (`control_plane/orchestration/live_flow.py:1182-1213`) emits an
evidence row **only for injected `WorkerHandle`s**; the historical `LocalWorkerAdapter` pool spawned
from `worker_ids` produces none — a deliberate choice, documented at `:1185-1188`, so that adding the
handle path could not flip the aggregate of every pre-existing mock run. `_synthesize` then computes
`legs.update(derive_worker_legs(worker_evidence))` over the injected handles alone, and
`_assert_legs_honest` compares the declared legs against **that same derivation** — so it cannot see
the pool's contribution at all.

**Failure scenario.** `LiveGovernedFlow(srv, manifest, worker_ids=("worker-A","worker-B"),
worker_handles=(live_handle,))`. `LocalWorkerAdapter` serves `reasoning` and `review`
(`adapters/local/worker.py:40-45`), so worker-A and worker-B execute, publish, pass the gates and land
in `accepted`. The packet declares `legs.workers = "live"`, `live_workers_owed.owed = false`, and a
`worker_legs` map naming only the live node. An operator reading it cannot tell that most of the
accepted set was mock-produced — and `derive_worker_legs`'s own docstring (`:456-464`) says the MIXED
case must be `attempted`, "not `mock` … some of this pool's work came from a mock". That rule is
enforced for injected mock handles and not for the pool.

**Unreachable on every shipped path today** — `emit_conductor_dispatch.emit()` passes
`worker_ids=() if live_workers else …` (`tools/live/emit_conductor_dispatch.py:187`) — which is exactly
the problem worth recording: the honesty of the headline leg rests on a **caller argument** rather than
on the derivation, and removing that dependence is the whole purpose of `_assert_legs_honest`. Every
test in `tests/integration/test_live_worker_legs.py` passes `worker_ids=()`, including
`test_a_mixed_pool_reports_attempted_not_mock_and_not_live`, which mixes *injected* handles only. The
composition of the new handle path with the pre-existing pool is untested.

**The fix, when taken:** emit a `mock` row for every pool node that executed, so the mixed case derives
`attempted` from evidence rather than from a caller's argument. A pure-pool run then derives `mock` —
unchanged — and a pure-handle run is untouched.

### U121 — a crash of the live dispatch emitter orphans a live `claude` child while its I-X3 lease is reaped as dead

**Opened:** 2026-07-26, `phase-17b.close` (spec-audit MAJOR-2). **Owner:** the track that takes U25
(OS-level containment).

`tools/live/emit_conductor_dispatch.py:111-119` takes the durable lease with
`holder_pid=os.getpid()` — the short-lived emitter — and the live call itself is a bare
`subprocess.run([claude, "-p", …], timeout=420)` (`adapters/frontier/claude_code.py:451-452`): no job
object, no supervisor registration, no lifecycle event. On Windows, killing the Python parent does not
kill the child.

**Failure scenario.** The emitter is hard-killed (Ctrl-C, `taskkill`, host sleep, loop cancellation)
during a 254–420 s exchange. The `claude` child keeps running and keeps spending the operator's
subscription; `pid_is_alive(holder_pid)` is now False, so the next `live()`/`acquire()`/`reap()` on the
ledger (`node_runtime/supervisor/terminal_lease.py:451-459`) drops the lease as a dead holder. The
terminal is **live and uncounted** — the exact state I-X3 exists to prevent.

The shell's analogue is disclosed (`containment.os_job_object:false`, `still_owed:[… os_job_object_or_acl
(U25)]` in `emit_worker_launch.py:499-526`); **this path made no such disclosure** — the `.legs`
report's limitations list five items, none of them containment or holder death.

### U122 — an unknown VRAM footprint is refused as "does not fit"

**Opened:** 2026-07-26, `phase-17b.close` (spec-audit MINOR-1). **Owner:** 17D.

`_assert_fits_without_displacing` (`node_runtime/supervisor/worker_pane_spawn.py:479-481`) returns
early when the model is absent from the snapshot and defers to `request_load`, which raises
`ResidencyError("model … not registered (unknown footprint)")`. The caller stamps that
`GATE_VRAM_ADMISSION` with the text "*does not fit the host VRAM budget*" (`:592-598`).
`GATE_VRAM_FOOTPRINT` exists (`:134-137`) precisely because "we could not tell" is not "it does not
fit" — the split was applied to the footprint-present-but-non-int branch and not to the model-absent
one. Reachable: `enumerate_pane_picker.py:195-197` records models skipped from residency (no `size` in
`/api/tags`) that the picker still enumerates. The operator is told to free VRAM for a model whose size
was never known, and a receipt leg asserting `vram_admission` goes green on a provenance fault.

### U123 — the MCP reconnect is invisible to every artifact

**Opened:** 2026-07-26, `phase-17b.close` (spec-audit MINOR-2). **Owner:** 17D/17E.

`mcp_server/protocol.py:97-158` closes and re-establishes the connection silently. U60's own entry
records that **every** live dispatch is reaped at least once and relies on this reconnect — yet no
reconnect appears in the flow trace, the acceptance packet, the dispatch feed or any log. An operator
reading `PHASE17B_LEGS_DISPATCH_FEED.json` cannot tell the shared-memory channel was re-established
mid-run (invariant 27, Buildout §4 "everything observable"). The `.legs` limitations record the
residual race but not the unobservability.

### U124 — the orphan-CANDIDATE rejection leaves no gate record pointing at the entry

**Opened:** 2026-07-26, `phase-17b.close` (spec-audit MINOR-3). **Owner:** 17D.

`control_plane/orchestration/live_flow.py:994-1024`. The comment justifies the rejection by saying the
alternative "would strand an unreviewable CANDIDATE in shared memory with no gate record pointing at
it (validator R5)". After the fix the entry is REJECTED — but the verdict is built with
`task_id=a.task_id` and **no** `evidence=[orphan]` (`:1015-1018`), and `_node_refusals` carries no
`entry_id` (`:1035-1038`). There is still no gate record pointing at that entry; only free-text in a
`reviewer_note`. Certainty inflation in a comment documenting an invariant-16 path.

### U125 — `torn_down` is a self-report, not a measurement

**Opened:** 2026-07-26, `phase-17b.close` (spec-audit MINOR-5). **Owner:** 17E.

`conductor_dispatch.py:320` sets `torn_down` unconditionally after its `finally` block. `.spawn`'s
receipt, by contrast, **measures** the equivalent claim (`real_ledger_unchanged` is a byte comparison,
`surviving_pids` is a process read). The `.legs` exit-criterion row "D-LOOP-1 teardown in-unit | MET |
`torn_down:true`; lease ledger `{}` and `in_use 0` after every run" therefore rests on a producer's
own word, and the "lease ledger `{}` after every run" half appears in no committed receipt at all.

### U126 — the `.spawn` self-check derives its pinned VRAM budget FROM the resident set

**Opened:** 2026-07-26, `phase-17b.close` (spec-audit MINOR-6). **Owner:** 17D (receipt hygiene).

`apps/desktop/selfcheck/worker-spawn-selfcheck.js:217-222` computes
`pinnedBudget = max(24576, used_vram_mb + biggest + 1024)` and injects it via `SOW_VRAM_BUDGET_MB` —
feeding the operator-budget channel a number derived from what is resident, the exact derivation
`enumerate_pane_picker.py:111-115` documents as forbidden. It is deliberate (it is what makes the fit
gate reachable in a test), and `scope_note_substitutions` does disclose that it is not real capacity —
but the note describes it neutrally rather than naming it as the forbidden shape used knowingly.
Consequence: the `.spawn` local leg can never fail admission, and that receipt carries no VRAM-refusal
leg; the real refusal lives in the `.ticket` receipt (`local_budget_squeezed_mb` →
`local_budget_refused_by:"vram_admission"`), which is why this is MINOR.

### U127 — an operator-visible log line states U58 status as a literal

**Opened:** 2026-07-26, `phase-17b.close` (spec-audit MINOR-7). **Owner:** 17C/17E (whichever wires
live dispatch into the shell — the line becomes FALSE at that moment).

`apps/desktop/main.js:171` interpolates the legs from the feed and then hard-codes
"live workers OWED (U58)" beside them. True today — this unit's own `conductor-dispatch` receipt shows
`legs mock/mock · U58 owed=true`, and `conductor-dispatch-source.test.js:95` pins the shell to
mock-first — but it is a governance claim written as a literal in a file that elsewhere insists such
lines be sourced. `conductorDispatchSummary` (`main.js:426`) derives it correctly; this line does not.

### U128 — a launched local pane's residency chip is frozen at authorization time (the visible residue of U64)

**Opened:** 2026-07-26, `phase-17b.close` (spec-audit MINOR-8). **Owner:** 17E.

`worker_pane_spawn.py:624` stamps `residency=decision.status` once; `main.js:1107-1109` and
`renderer.js:159` render it as the badge tail. A pane authorized while the model is loading shows
`· loading` for the life of the pane — nothing refreshes it when `ollama run` completes. The error is
in the under-claiming direction (never "ready" when it is not), so it is not a false-live claim, but it
is a stale operator-visible state (invariant 27) and it is exactly what **U64** (no residency-completion
gate before execute) looks like on screen. Recorded here because the 17B track text asks for
"residency honesty (U63/U64 narrowed as far as real evidence allows)" and no sub-step report named
either item; the `.close` report §6 now carries the explicit disposition (U63 narrowed, U64 open).

### U129 — the `.ticket` receipt asserts scratch-ledger scoping where `.spawn` measures it

**Opened:** 2026-07-26, `phase-17b.close` (gate-validator M-6). **Owner:** 17D (receipt hygiene).

`PHASE17B_SPAWN_SELFCHECK.json` carries `real_ledger_unchanged` and `scratch_ledger_removed`;
`PHASE17B_TICKET_SELFCHECK.json` carries neither, so its scratch scoping is a claim rather than a
measurement. Empirically fine — the builder and the validator both verified the real ledger and the
lease directory after five in-Electron runs across this unit — but the two receipts should assert the
same class of fact the same way.

### U130 — the live worker leg is proven for ONE vendor

**Opened:** 2026-07-26, `phase-17b.close` (spec-audit MINOR-10). **Owner:** 17E (or the first track
needing a live codex worker).

`tools/live/emit_conductor_dispatch.py:73` pins `LIVE_WORKER_NODE_ID = "worker-claude-live"` and `:102`
`canonical_subscription_ref("claude_code")`; there is no codex live-worker factory, though codex is in
OP-6 scope, is enumerated by the picker, and has full stdin/env parity in the adapter. Invariant 4's
"workers interchangeable behind adapter contracts" is therefore demonstrated for one adapter. The
`.legs` report says "No new provider"; it never says "one provider", and it should have. Sibling gap:
**U112** (OpenCode absent from the picker→launch path).

### U131 — the live run's shared memory was a tempdir, discarded on exit

**Opened:** 2026-07-26, `phase-17b.close` (spec-audit MINOR-11). **Owner:** 17E (assembled run against
the durable store).

`tools/live/emit_conductor_dispatch.py:182` runs the whole live dispatch against a
`tempfile.TemporaryDirectory` store. The CANDIDATE, its ACCEPTED promotion, the acceptance packet entry
`m-beb6b01c38a28413` and the append-only history that carried them **no longer exist**; the only
surviving record is the JSON feed. This is correct under D-LOOP-1 and exactly what a smoke-scale live
check should do — but "U58 worker half RESOLVED" must not be read as "the project's shared memory now
contains that CANDIDATE and its promotion". It does not.

### U132 — `emit_conductor_dispatch.py` cites prohibition §2.5 backwards

**Opened:** 2026-07-26, `phase-17b.close` (gate-validator M-8). **Owner:** any track touching the file.

`tools/live/emit_conductor_dispatch.py:180-182` justifies the temp store as "created UNDER the OS temp
root (never in the repo, §2.5)". §2.5 prohibits modifying or deleting things **outside** the repo root;
it is not a rule against writing inside it. The behaviour (create-and-remove a temp dir) is the
long-standing pattern and is harmless — the citation is inverted. Comment-only; not fixed in `.close`
because product code was not touched after validation.

## Register update 2026-07-26 (`phase-17c.probe`) — U74 RESOLVED, U133–U139 opened

Both mandatory reviews ran foreground in the unit. The gate-validator returned PASS_WITH_RESERVATIONS;
the spec-auditor returned PROHIBITED DRIFT: NONE with 1 BLOCKING / 6 MAJOR / 12 MINOR. Both
independently found the SAME headline defect, which this unit had introduced. Everything they found is
either fixed in the unit or opened below with the failure scenario that makes it real.

### U74 — RESOLVED (opened 2026-07-25 as OP-11 first-use finding F1; it had no register section — m-11)

**The claim:** the shell badged the STT engine "mock engine" on a host where WSL Parakeet is installed
and verified (this repo's own `PHASE16E_REAL_PARAKEET_SMOKE.json` is a real transcription from this
machine). **The causes, measured 2026-07-26 on this host** (and independently re-measured by the
gate-validator): the probe ran `import nemo`, a ~0.04 s namespace-package import that says nothing about
whether ASR works; the budget was 8.0 s while the import transcription actually performs
(`from nemo.collections.asr.models import ASRModel`) costs **17.91 s cold / 7.02 s warm**; and
`lru_cache(maxsize=1)` pinned one cold miss for the life of the process. A fourth cause, found during
the unit and absent from the original diagnosis: the engine state was only ever learned as a side effect
of a CAPTURE, so raising the budget alone would have traded a lie for a stall.

**Resolved by:** probing the import transcription actually performs; a 90 s budget (directive floor
≥60 s) set from the cold measurement; a TTL cache (positive 900 s / negative 30 s) that is re-taken
rather than pinned; `SOW_NEMO_PROBE_TIMEOUT_S` / `SOW_NEMO_TRANSCRIBE_TIMEOUT_S` honoured end-to-end
(the Python budget AND the JS ceilings derive from them); a non-blocking shell-side probe owner with a
fourth indicator state "probing…"; and the engine badge made the operator's re-probe control. Proven
in-Electron on this host (`PHASE17C_VOICE_PROBE_SELFCHECK.json`, 20/20 checks, badge "probing…" →
"parakeet-wsl ready" with no operator action) and falsified twice: budget → 3.0 s, and the indicator's
`probing` forced false, each turning the badge back into the operator's exact "mock engine" and the
receipt red. **State: RESOLVED (2026-07-26, `phase-17c.probe`).** Owner: —.

**Recorded honest negative:** mutating the budget back to the ORIGINAL 8.0 s did *not* fail the check,
because WSL was warm and the probe finished in 7.3 s; two of the validator's five warm measurements
(8.05 s, 8.25 s) exceeded 8.0 s. 8 s sat inside this host's noise band — which is why the operator's
symptom looked intermittent rather than absolute. The diagnosis stands on the cold measurements.

### U133 — a talk press has no in-progress affordance

**Opened:** 2026-07-26 (validator R3 / spec-audit M-5, residual). **Owner:** 17C `.mic`.
`voiceState()` reports `capturing:false` unconditionally, so while the renderer awaits `voice:capture`
nothing in the chrome changes. `.probe` removed the probe from that path (the capture emitter no longer
probes), so the wait is now the bridge/broker only — but once `.mic` wires a real WSL transcription it
returns at seconds-to-minutes scale. **Failure scenario:** the operator holds talk, speaks, and sees a
completely static badge; with nothing distinguishing "working" from "hung", the natural response is to
press again. State: OPEN.

### U134 — `--cached-only` is a constant function across processes

**Opened:** 2026-07-26 (spec-audit m-4). **Owner:** whoever needs a cross-process probe cache.
The Python probe cache is module state in an emitter process that exits after one emission, so the
"instant read" can only ever return `unprobed` in production; only the in-process shell owner benefits
from a cache. **Failure scenario:** a future caller reads `--cached-only` expecting the shell's
established answer, gets `unprobed`, and — if it forgets the `nemo_state` distinction — renders "mock
engine": U74 again. Documented in the emitter; kept rather than removed because `.mic` may want a real
cross-process cache. State: OPEN.

### U135 — the probe's WSL grandchild is not tree-killed on Windows

**Opened:** 2026-07-26 (spec-audit m-1, residual after the teardown fix). **Owner:** shell / D-LOOP-1.
`teardown()` now disposes the probe, and both `dispose()` and the timeout path kill the `py.exe` child —
but killing a process on Windows does not reap the `wsl.exe` grandchild it spawned. **Failure scenario:**
quitting the shell during the 7–22 s launch probe leaves a NeMo import running inside the WSL VM. It is
bounded (it exits on its own within the probe budget) and consumes no VRAM (MEASURED:
`torch.cuda.is_initialized()` False, `nvidia-smi` unchanged at 2240 MiB across the import), but it is not
reaped by us. State: OPEN, bounded.

### U136 — the self-check's reference probe forwards the full parent environment

**Opened:** 2026-07-26 (spec-audit m-8). **Owner:** 17C `.mic` / self-check hygiene.
`voice-probe-selfcheck.js` spawns its reference probe with `env: { ...process.env, SOW_… }`, while the
repo has `scrub_credential_env` for exactly this boundary and applies it on the pane-spawn path.
**Failure scenario:** a credential-bearing variable in the build shell's environment is handed to a local
`py` child and, via `WSLENV`, potentially into the WSL VM. Diagnostic path, local processes, no model
call — low risk, but an explicit widening in a unit that crosses into WSL. State: OPEN.

### U137 — no leg establishes that a green probe implies a successful transcription

**Opened:** 2026-07-26 (validator R2 / spec-audit M-6). **Owner:** 17C `.mic`.
The probe establishes exactly one fact: the NeMo ASR import returns 0 in the venv.
`ASRModel.from_pretrained` is never exercised. The self-check's "independent reference" is independent of
the probe **budget** only — it shares `PROBE_IMPORT` and the config — so it cannot falsify a wrong probe
*question*, which is the very half of U74 that made `import nemo` useless. The receipt now states this
limit in `reference_scope`, and the indicator hint was narrowed from "transcribes your live speech" to
what was established. **Failure scenario:** uncached weights, a broken CUDA/driver pairing, or
insufficient VRAM leave the import green while transcription fails; the operator is badged
"parakeet-wsl ready" and the first real capture fails. Fail-closed at capture time (a real adapter that
cannot initialise falls back to the visible mock), so this is an honesty gap, not an authority gap.
State: OPEN until `.mic` transcribes a fixture WAV.

### U138 — `detection.nemo:false` alongside `nemo_state:"unprobed"` is an F1-shaped trap

**Opened:** 2026-07-26 (validator R7). **Owner:** any new consumer of `detect_voice_stack`.
`nemo` is fail-closed by design (True only for a positive probe), so on a non-blocking read it is `false`
while `nemo_state` is `"unprobed"`. Every current consumer reads `nemo_state` or
`real_parakeet_available` and is correct. **Failure scenario:** a future consumer reads `detection.nemo`
alone, renders "no real engine", and reconstructs F1 exactly. State: OPEN (shape risk, no live defect).

### U139 — `voice_probe_feed@1.0` has no file in `schemas/`

**Opened:** 2026-07-26 (validator note). **Owner:** schema custodian.
The new probe envelope is validated by `isWellFormedProbeFeed` on the consumer side only, matching the
existing status of `conductor_voice_feed@1.0`. Not new drift — the canonical `schemas/` set is frozen
`@1.0` and these are shell-internal envelopes — but two feeds now sit outside it. **Failure scenario:** a
third producer emits a near-miss shape that the hand-written guard accepts. State: OPEN.

---

## Register update 2026-07-26 (`phase-17c.mic`) — U133/U134/U136/U137 RESOLVED, U140–U143 opened

Work `cfb9b5c` (capture path) + `ce0e831` (every review finding), evidence
`docs/evidence/PHASE17C_MIC_EVIDENCE_REPORT.md`, receipt
`docs/evidence/receipts/PHASE17C_MIC_SELFCHECK.json` (27/27). No tag — `.mic` is a sub-step.

### U137 — RESOLVED

**Closed 2026-07-26 by `phase-17c.mic`.** The gap was that the probe established exactly one fact (the
NeMo ASR stack imports in the WSL venv) while nothing had ever exercised `ASRModel.from_pretrained` —
so uncached weights, a broken CUDA/driver pairing or insufficient VRAM would leave the badge green and
the first real utterance dead. Real PCM now goes through the production path end to end on this host:
`engine.mock === false`, `name = parakeet-wsl`, transcript *"The conductor should summarize the build
status."* against the spoken fixture. Reproduced by the gate-validator independently, both inside
Electron and via the emitter directly. Falsifiable: forcing `for_capture=False` yields
`engine=mock-stt, transcript=null` and six failing checks.

### U133 — RESOLVED

**Closed 2026-07-26 by `phase-17c.mic`.** `voiceState().control.capturing` is true while a capture is
genuinely in flight (the render model already had `capturing`/`listening`; only main's hard-coded
`false` kept it dark). The receipt observes it DURING the round trip and clear after. Falsified:
reverting to `capturing: false` fails exactly one check.

### U134 — RESOLVED

**Closed 2026-07-26 by `phase-17c.mic`.** `seed_probe_result` + the emitter's `--engine-state` carry the
shell's established probe answer across the process seam, so a real capture pays for no second WSL NeMo
import. Measured: transcription fell from 44.2 s unseeded to 20–24 s seeded. The seed can only skip a
redundant import — the WSL round trip still fails closed, verified by the validator with a fabricated
"available" against a nonexistent WAV (result: an honest `VoiceEngineError`, never a transcript). Trust
runs one way: any value but the literal `available` is discarded and a real blocking probe runs, so a
negative can never suppress the real engine. Provenance rides in `SEEDED_REASON_PREFIX`.

### U136 — RESOLVED

**Closed 2026-07-26 by `phase-17c.mic`, on the second attempt.** The self-check's reference probe and
the capture emitter were scrubbed in `cfb9b5c` — but the gate-validator found (MAJOR-2) that the
**launch probe** (`apps/desktop/voice/probe.js`), the first item on `env-scrub.js`'s own list and the
one that runs on every shell start, still inherited `process.env` wholesale. Fixed in `ce0e831` and
pinned by test. The JS classifier mirrors `adapters/frontier/claude_code.is_credential_env_key`, pinned
to it by a test that parses the Python source — for the three name lists AND for the rule shape, so a
future fourth family cannot leave the mirror silently weaker.

### U140 — a confidently-wrong transcription is indistinguishable from a correct one

**Opened:** 2026-07-26 (`.mic`, carried forward and sharpened from 16E `.real`). **Owner:** voice.
NeMo's hypothesis score is a log-probability, not a 0..1 confidence; feeding it to the
`ConductorVoiceBridge`'s threshold would route EVERY real utterance to CLARIFY. So confidence is derived
from recognition — non-empty ⇒ 1.0, empty ⇒ 0.0. That was a sound trade while transcripts were mock;
`.mic` makes it operator-facing. **Failure scenario:** the engine mishears a protected verb as an
ordinary one, or vice versa, and the routing layer has no signal to hesitate on — the clarify path
protects against silence, not against mishearing. A calibrated confidence needs per-token scores
`WSL_TRANSCRIBE_SRC` does not emit. State: OPEN.

### U141 — the capture path uses the deprecated `ScriptProcessorNode`

**Opened:** 2026-07-26 (`.mic`). **Owner:** shell.
`apps/desktop/renderer/mic.js` uses `createScriptProcessor` rather than `AudioWorklet` (a worklet needs
a separately fetched module file, friction on a `file://` origin). The renderer console logs the
deprecation on every capture. **Failure scenario:** a future Chromium removes it and push-to-talk stops
working with a console warning as the only clue. Bounded — the node runs only while the operator holds
the button. State: OPEN, known trade.

### U142 — the self-check launcher can report success for a shell that wrote no receipt

**Opened:** 2026-07-26 (`.mic`, observed twice; the gate-validator hit the same flake once).
**Owner:** self-check harness.
`node-pty`'s `conpty_console_list_agent` intermittently dies with `AttachConsole failed`. Observed here
AFTER the receipt was written (cosmetic), but `selfcheck/run.js` mirrors the child's exit code and knows
nothing about the receipt, so the same crash BEFORE the receipt would print a stack trace and still exit
0. **Failure scenario:** a run that never checked anything is read as a pass — the "no receipt is not a
green receipt" rule that D-P16-0 exists to enforce, defeated by the launcher. Fix: have the launcher
require a receipt newer than the run's start. State: OPEN.

### U143 — `wirePushToTalk` has no unit test

**Opened:** 2026-07-26 (`.mic`). **Owner:** shell.
The function that carried this unit's BLOCKING defect lives in the monolithic `renderer/renderer.js`,
which exports nothing and cannot be required. Its only coverage is three in-Electron receipt legs
(`stray_release_routes_nothing`, `press_without_a_mic_routes_nothing`, `device_not_left_hot_after_a_tap`)
— real, but they run once per receipt rather than on every `npm test`. `mic.js` by contrast is a module
with nine unit tests. **Failure scenario:** a renderer edit reintroduces a routing fallback and no
headless test notices; it is caught only when someone next runs the `.mic` receipt. State: OPEN.

---

## Register update 2026-07-27 (`phase-17c.close`, CHECKPOINT — no gate) — U144–U148 opened

Work `3a488cd` (the live spoken round trip + every finding from both mandatory reviews), evidence
`docs/evidence/PHASE17C_CLOSE_EVIDENCE_REPORT.md`, receipt
`docs/evidence/receipts/PHASE17C_CLOSE_SELFCHECK.json` (33/33). **No tag** — `gate/phase-17c` is withheld
until `phase-17c.close-revalidate` re-reviews the FIXED tree, because both mandatory reviews reported
against the pre-fix tree and the spec-auditor's verdict was "do not tag on this tree" (2 BLOCKING, both
real, both fixed here).

### U144 — the protected-verb gate is LEADING-WORD-ONLY, and it now points at a model that can act

**Opened:** 2026-07-27 (`.close`; spec-audit BLOCKING-2/MAJOR-3, validator D-8/R3). **Owner:** voice.
`voice_bridge/spoken_verbs.split_spoken_command` classifies `words[0]` and nothing else — no stemming, no
paraphrase handling — and `conductor_voice._route` delivers everything else **verbatim**. That was a
disclosed, safe-direction trade while a delivered CHAT reached a recording stand-in. `.close` points that
channel at a live `claude` session whose tool use is gated by the **vendor harness's own prompts**, not by
the `CommandBroker` (U78/U25 open). **Failure scenario:** a perfectly transcribed *"Please delete the
lease ledger"* or *"Stopped the worker on node B"* has an unclassified leading word, routes as ordinary
CHAT, is delivered, and the only remaining barrier is a control this repo neither owns nor reads — which
invariant 29 says never to trust. Naming it is now mandatory in three places (the bridge docstring,
`REAL_CAPTURE_OWED.routing_limits`, the `.close` receipt's "does not claim" list) and asserted by test.
Fix direction: classify the whole utterance against the verb tables (escalation-only, as today) rather
than its first word, and/or bind a permission profile to the conductor session. State: OPEN.

### U145 — production cannot prove delivery INTEGRITY from a ConPTY repaint stream

**Opened:** 2026-07-27 (`.close`; the residue of spec-audit BLOCKING-2's fix). **Owner:** shell.
The submit key waits on an observed echo, which is what makes it impossible for a bare `\r` to answer the
live CLI's own permission prompt. But the only thing main can read is the repaint stream, and a screen-diff
repaint is not a transcript of the screen: **measured on this host, a freshly-written 62-character
utterance comes back as 2 of its 5 ten-character runs** (`first_missing:"withonlyth"`) while the rendered
screen shows the whole sentence. So the gate's threshold is "this utterance's text came back", not "all of
it did". **Failure scenario:** a delivery truncated inside the CLI's own ingest echoes its head, passes the
gate, is submitted, and the conductor answers a question the operator did not ask — with the chrome
reading "Delivered to conductor". The in-Electron receipt catches this class (it anchors on the WHOLE
transcript from the rendered buffer, and a partial echo cannot anchor), so it is a production-only blind
spot. Fix direction: a real screen model in main, or an authenticated echo confirmation from the renderer
(which invariant 29 currently forbids as the authority for a keystroke). State: OPEN.

### U146 — the spoken utterance becomes durable text in the vendor CLI's own session store

**Opened:** 2026-07-27 (`.close`; spec-audit MINOR-12). **Owner:** voice/privacy.
Invariant 26 governs AUDIO, and the audio is discarded (filesystem-measured). But the transcript is now
written into a live `claude` session, which persists its own conversation outside this workspace and
outside `.voice-captures`. This is the same exposure typing already has — and the spoken half of it starts
with this unit, on a surface whose whole selling point is "transcribe then discard". **Failure scenario:**
an operator who believes speaking leaves nothing behind dictates something sensitive; the audio is gone
and the text is in the vendor's session history, where no Sovereign retention policy reaches it. Disclosed
in the receipt's `scope_note`; not a violation, and not something this build can unilaterally change.
State: OPEN (disclosure-level).

### U147 — 17A's answer matcher cannot see a reply that ends a sentence

**Opened:** 2026-07-27 (`.close`). **Owner:** self-check harness.
`apps/desktop/conductor/roundtrip-probe.hasStandaloneNumber` disqualifies a trailing `.` or `,`
unconditionally (`(?![\d.,])`), an exclusion written for "0.68"/"1,168". **Failure scenario:** a 17A
`.roundtrip` re-run where the model replies "The sum is 91." reads as no answer, fails the receipt, and
spends a live session to report a green path as broken. Fail-closed, so it can never fabricate a pass.
`.close` uses a corrected matcher (`spoken-probe.carriesDigits`, which disqualifies a separator only when
a digit follows); 17A's is left as gated rather than re-running its live receipt to change a comment.
State: OPEN.

### U148 — `deliverConductorChat`'s orchestration has no headless test

**Opened:** 2026-07-27 (`.close`; same shape as U143). **Owner:** shell.
The matching rule was extracted to `apps/desktop/voice/echo-confirm.js` and has 12 unit tests, but the
function that sequences it — the TERMINAL-state refusal, the newline flattening, the body write, the echo
poll, the submit, the mid-wait session-end re-check — lives in `main.js`, which exports nothing and cannot
be required. Its only coverage is in-Electron receipt legs. **Failure scenario:** a refactor reorders the
guards (e.g. moves the `isTerminal` check after the write, or drops the post-wait re-check) and every
headless suite still passes; it is caught only by a live receipt run, which costs a session. State: OPEN.

---

## Register update 2026-07-27 (`phase-17c.close-revalidate`, CHECKPOINT — no gate)

No tag. The mandatory validator and auditor both withheld approval, and the current managed context
could not generate a packaged current-tree D-P16 receipt. Evidence:
`docs/evidence/PHASE17C_CLOSE_REVALIDATE_CHECKPOINT.md`.

### U144 — NARROWED: deterministic classification is bounded; production direct CHAT is disabled

**Corrects, does not erase, the 2026-07-27 U144 opening above.** The leading-word defect is fixed:
protected/destructive verbs, synonyms, and common inflections are scanned across the whole normalized
utterance. Arbitrary semantic paraphrases remain outside deterministic intent classification. The
spec-auditor correctly rejected vendor `plan mode on` chrome as authority under invariant 29.
Production therefore supplies `authorityBound:false` and refuses all direct CHAT before the body write;
the footer parser is only a secondary interaction-state guard. **Failure scenario still carried:** if
direct CHAT is re-enabled from vendor/model text rather than a supervisor-owned non-executing boundary,
an unclassified paraphrase can reach a tool-capable conductor. State: OPEN, narrowed and fail-closed;
owner voice/supervisor.

### U149 — physical typed input bypasses the conductor voice router

**Opened:** 2026-07-27 (`.close-revalidate`; spec-auditor MAJOR). **Owner:** 17D assembled operator
surface. The Python `type_message()` test surface and voice `speak()` share `_route`, but physical xterm
typing flows directly through `pane:input` to `SessionManager.write`. **Failure scenario:** an operator
types a protected phrase into the conductor and it bypasses the same propose/approve classification
that voice uses, so §13.5's typed/voice command-path equivalence is true only of the synthetic API, not
the assembled product. Resolve by routing the intended typed conductor command surface through the
same broker without breaking raw terminal control input. State: OPEN.

### U150 — current-tree Phase 17C packaged receipt cannot run in this managed context

**Opened:** 2026-07-27 (`.close-revalidate`; validator/spec-auditor gate blocker). **Owner:** next 17C
close revalidation. Only Python 3.14 is exposed here while the packaged gateway/emitter requires 3.12,
and Electron cannot write its profile/cache in this sandbox. The foreground self-check exited 1 and
the checked-in receipt stayed byte-identical. **Failure scenario:** headless suites pass while the
packaged shell cannot recognize the real plan-mode footer or complete PCM→Parakeet→live-conductor
delivery, yet the phase is tagged from stale evidence. Required action: regenerate the receipt on an
accessible host context from the exact committed tree, then re-run both mandatory reviews. State: OPEN.

---

## Register update 2026-07-27 (`phase-17c.close-revalidate2`, CHECKPOINT — gate FAIL)

Work `98800f9`, mandatory-review safe response `98525f3`, evidence
`docs/evidence/PHASE17C_CLOSE_REVALIDATE2_EVIDENCE_REPORT.md`. **No tag.** Both mandatory reviewers
withheld the Phase 17C gate. The final checkpoint is safe-direction: production direct voice CHAT
refuses before writing because the available hook policy truthfully reports
`enforced_by_supervisor_process:false`.

### U150 — CORRECTED/NARROWED: packaged runtime is accessible; exact-commit passing evidence is absent

**Corrects, does not erase, the context-specific opening above.** This iteration had Python 3.12 and a
writable Electron profile and ran the packaged self-check twice. The second run reached real Parakeet,
the bridge, and the live Claude conductor, then the provider rendered its weekly quota screen (recorded
reset: 2026-07-30 12:00 America/Chicago). The receipt is `ok:false` and was generated before the work
commits; it contains no source-tree identity. **Failure scenario:** a failed or pre-commit receipt is
presented as proof that the exact gated tree produced a live answer/tool denial/disarm. Required action:
after provider availability returns and U151 is resolved, generate one receipt that records the exact
source commit/tree and passes every gate leg. State: OPEN; owner next 17C revalidation.

### U151 — vendor hook dispatch is not supervisor-process voice authority

**Opened:** 2026-07-27 (`.close-revalidate2`; mandatory spec-auditor BLOCKING 1–3).
**Owner:** supervisor/voice. The Node Runtime can own and hash-pin a Claude hook policy, but Claude's
own dispatcher executes it. Dispatcher timeout/failure, missing state, overlapping unmarked
`UserPromptSubmit`, user interruption, and `StopFailure` create states the original session-scoped
arm/Stop implementation did not contain. **Failure scenario:** a marked spoken turn is armed, an
overlapping typed submit or state loss clears/bypasses that arm, and the still-running spoken turn calls
a tool; or the arm hook times out and the prompt reaches the model unarmed. `98525f3` prevents the
failure in production by requiring `enforced_by_supervisor_process:true` while every real ticket is
pinned to false, so no direct voice body is written. Resolve only with actual supervisor-process
enforcement or an explicit canonical ruling changing the trust boundary, then adversarially test
timeouts, state loss, overlapping input, interruption, and API failure. State: OPEN, fail-closed.

### U144 — RE-NARROWED: whole-utterance broker remains; direct CHAT is again disabled

The deterministic whole-utterance protected/destructive scan remains fixed. Arbitrary semantic
paraphrases remain outside that lexicon, and hook-only containment cannot safely close that gap.
`98525f3` therefore disables production direct CHAT before the body write. The authority-expansion
failure is contained, but the positive Phase 17C ordinary-chat criterion is unmet. State: OPEN,
fail-closed; owner voice/supervisor.

### U149 — CARRIED: assembled physical typed input still bypasses the broker

The mandatory spec audit re-confirmed that `ConductorVoiceBridge.type_message()` is a synthetic
equivalence surface while physical xterm input travels directly from `pane:input` to
`SessionManager.write`. This checkpoint does not change it. State: OPEN; owner 17D/assembled input.

### Temporary Claude weekly quota — NOT a directive section 8 terminal blocker

The provider reports an automatic reset on 2026-07-30 at 12:00 America/Chicago. No credential,
purchase, or hardware action is required, no upgrade was attempted, and no alternate provider is
authorized for the conductor criterion. Per the mandatory validator and existing loop precedent,
LOOP_STATE remains RUNNING rather than BLOCKED.

---

## Register update 2026-07-28 (`phase-17c.close-revalidate2`, iteration 88 — gate FAIL)

Evidence:
`docs/evidence/PHASE17C_CLOSE_REVALIDATE2_ITER88_EVIDENCE_REPORT.md`. Work
`b395a3f`, `c687380`, `cf96229`, `268dae6`. Exact receipt SHA-256
`A7CD59264D5113AA50C2D54996DCFB0754DDCAB19BB3B30CD861CD6C3ACE916D`.
Mandatory gate validator: FAIL. Mandatory spec auditor: FINDINGS. **No tag.**

### U150 — CORRECTED: exact-source packaged evidence exists but the gate still fails

**Corrects, does not erase, the prior U150 note.** The packaged shell ran from exact source
commit `268dae6`; real PCM reached real WSL Parakeet, the bridge, and the governed live conductor,
with capture/process/lease cleanup. The receipt is nevertheless `ok:false`: Claude Max displayed
its weekly limit (reset Jul 30 12:00 America/Chicago), so no live answer or attempted tool denial
was observable. State: OPEN; rerun once provider service returns.

### U151 — NARROWED: supervisor-process authority landed; lifecycle identity remains incomplete

Electron main now owns exact-turn state and deny decisions over authenticated loopback transport.
The child-bearer cannot disarm with forged vendor lifecycle events, and transport loss fails closed.
The final reviewers found that process-exit identity is still pane-ID-only (U152), so authority
release is not yet safe across replacement generations. State: OPEN; fail-closed gate.

### U152 — delayed old PTY exit can corrupt a replacement session

**Opened:** 2026-07-28; both mandatory reviewers, dynamically reproduced. `SessionManager` deletes
the killed handle before confirmed exit and permits the pane ID to be reused. The old retained
`onExit` callback then looks up the replacement record by the same ID, exits it, deletes its handle,
and emits an exit that can release the replacement voice authority and I-X3 lease. Required:
generation/PID-bound PTY ownership plus kill -> forget/relaunch -> delayed-old-exit regression.
State: OPEN, CRITICAL; owner terminal/supervisor.

### U153 — worker kill intent releases I-X3 before matching process exit

**Opened:** 2026-07-28; both mandatory reviewers. Worker lifecycle treats
`processExited:false` kill intent as an ended session and releases immediately; quit teardown also
releases held worker leases after signaling. A delayed child may therefore remain live but
uncounted. Required: retain the lease until the matching PTY exit generation or dead-holder reaping.
State: OPEN, MAJOR; owner worker/supervisor.

### U154 — capture names and owned cleanup collide across shell instances

**Opened:** 2026-07-28; both mandatory reviewers, dynamically reproduced. Capture filenames use
only millisecond time plus an instance-local sequence. Two stores can overwrite the same path and
each then considers it owned. Required: per-instance cryptographic identity/UUID, exclusive create,
same-timestamp adversarial test, and owned cleanup that cannot cross instance boundaries.
State: OPEN, MAJOR; owner voice/capture.

### U155 — operator voice-turn recovery depends on renderer-controlled focus

**Opened:** 2026-07-28; both mandatory reviewers. Electron main observes a physical
`before-input-event`, but the release predicate also consumes `panes.focusedId`, which renderer IPC
may set; the receipt does not exercise this composition. Required: an explicit main-process-owned
operator resume gesture with no renderer-supplied authority input and an Electron-runtime check.
State: OPEN, MAJOR; owner voice/UI.

### U156 — quit/evidence lifecycle claims need exact identity

**Opened:** 2026-07-28; spec auditor. The quit path retains an unimported sync-release call behind a
swallowing catch. The receipt's exit-release check matches reason text, not a matching process
generation, and prose overstates a denial that the failed check says was not observed. Required:
remove the dead branch, correlate audit/PTY exit/lease release by exact identity and order, and make
receipt wording conditional on measured facts. State: OPEN, MINOR; owner shell/evidence.

### Temporary Claude weekly quota — still not a directive section 8 terminal blocker

The automatic reset remains 2026-07-30 12:00 America/Chicago. No credential, purchase, hardware, or
canonical contradiction blocks implementation of U152-U156. LOOP_STATE therefore remains RUNNING.

---

## Register update 2026-07-28 (`phase-17c.close-revalidate2`, iteration 89 — gate FAIL)

Evidence:
`docs/evidence/PHASE17C_CLOSE_REVALIDATE2_ITER89_EVIDENCE_REPORT.md`. Final exact-source
work `7d465c1`; receipt SHA-256
`2069B47807B1A4C8461BF06ECA0445C937A17FBBA128752CD41EEABC494F1019`.
Mandatory gate-validator: FAIL solely on the red live receipt. Mandatory spec-auditor:
CLEAN for source. **No tag.**

### U150 — CARRIED: exact-source receipt remains red under provider quota

The final receipt is exact to `7d465c1`, product-clean, and proves real PCM -> WSL
Parakeet -> bridge -> governed live conductor input plus complete audio/process/lease
cleanup. It is `ok:false`, 40/42: the weekly-limit screen prevented both a conductor
answer and a tool attempt whose denial could be observed. State: OPEN; rerun after the
provider's automatic reset.

### U151-U156 — RESOLVED in iteration 89

Supervisor-process authority now releases only on exact pane/session/PID/generation exit.
Denied admission and post-birth rollback retain their PTY handle and I-X3 terminal until
confirmed exit. Worker and conductor releases—including undelivered/pre-birth failures—
remain observable and retry until reconciled; independent session timers cannot suppress
one another, and pre-birth target states cannot be mislabeled as process exits.
`session_terminating` reconstructs interrupted. Capture creation is UUID/exclusive and a
janitor bounds cross-crash residue. Operator recovery is main-owned and measured in the
Electron receipt. Exit correlation and receipt wording are exact and conditional.
Mandatory final source audit: CLEAN. State: RESOLVED.

### U149 — CARRIED: assembled physical typed input equivalence remains a later-surface debt

This unit did not change the raw physical xterm input route. The existing typed/voice
synthetic command-path equivalence debt remains assigned to the assembled operator surface;
it was not represented as closed by the Phase 17C receipt. State: OPEN.

### Temporary Claude weekly quota — not a directive section 8 terminal blocker

The provider reports automatic reset on 2026-07-30 at 12:00 America/Chicago. No credential,
purchase, hardware action, operator decision, or canonical ruling is needed. LOOP_STATE
therefore remains RUNNING rather than BLOCKED.

---

## Register update 2026-07-28 (`phase-17c.close-revalidate2`, iteration 90 — gate FAIL)

Evidence:
`docs/evidence/PHASE17C_CLOSE_REVALIDATE2_ITER90_EVIDENCE_REPORT.md`. Exact work
`66c2bf3`; receipt SHA-256
`4CD02AAA68DE4E4685D6106C840AEE555C22CE3DCDF2CE5567AA68783255CCDD`.
Mandatory gate-validator: FAIL. Mandatory spec-auditor: FINDINGS. **No tag.**

### U150 — CARRIED: exact-source receipt remains red under provider quota

The exact `66c2bf3` packaged receipt is `ok:false`, 40/42. It proves real PCM → real WSL
Parakeet → bridge → governed live conductor input and complete measured-run cleanup, but
the provider weekly-limit screen produced no answer and no tool attempt. Therefore neither
the conductor-answer leg nor the live deny-before-execution leg can pass. State: OPEN;
retry once after the provider's automatic reset.

### U157 — self-check ownership misses a child reparented before first inventory

**Opened:** 2026-07-28 iteration 90, mandatory gate-validator and spec-auditor.
`WorkspaceProcessTree` learns descendants from periodic parent-PID snapshots. The new
`waitForWorkspaceExit()` repair works only for already-observed descendants; a child that
reparents before the first asynchronous snapshot is not tracked, and the launcher can
report completion while it remains alive. The validator reproduced this dynamically.
Required: authoritative run ownership (for example a Windows Job Object) or an equivalent
pre-first-inventory ownership mechanism, plus the adversarial regression. State: OPEN,
MAJOR; owner Phase 17C self-check lifecycle.

### U158 — Python-to-WSL voice timeout containment is not process-tree authoritative

**Opened:** 2026-07-28 iteration 90, mandatory spec-auditor. The renderer-side timeout
kills the Python emitter root, while the WSL grandchild is not held by an independently
verified process-tree boundary. Killing the Python timeout enforcer can leave `wsl.exe`
outside the measured root on a hang/quit path. Required: supervisor-owned whole-tree
containment and an induced-hang teardown regression for probe and transcription. State:
OPEN, MAJOR; owner voice process containment.

### U159 — loop-runner backend contract contradicts the binding execution directive

**Opened:** 2026-07-28 iteration 90, mandatory spec-auditor. Commit `7bb1ff6` changed
`tools/loop/run_loop.ps1` to Codex-only while the autonomous directive and generated
driver prompt still state Claude Code / `claude -p`. No recorded operator amendment
authorizes that execution-contract rewrite. Required: restore the previously authorized
dual/Claude contract or record an explicit operator amendment; the prompt must state the
actual foreground process truth. State: OPEN, MAJOR; owner loop runner.

### U160 — main-process teardown message overstates Electron-child coverage

**Opened:** 2026-07-28 iteration 90, mandatory spec-auditor. The main process logs
`zero tracked Electron children`, but its local check covers SessionManager PTYs and the
gateway root, not renderer/helper Electron children. Repair evidence cites the message as
broader proof. Required: narrow the message/evidence to what was measured or extend the
measurement to the full run-owned tree. State: OPEN, MINOR; owner shell evidence.

### U161 — exact-tree receipt check name overstates an explicit exclusion

**Opened:** 2026-07-28 iteration 90, mandatory spec-auditor.
`receipt_matches_committed_product_tree` excludes the pre-existing untracked
`apps/desktop/package-lock.json`. The exclusion is disclosed, but the boolean name implies
no product-path difference. Required: rename/narrow the check or remove the product-path
exclusion through a separately authorized disposition of the pre-existing file. State:
OPEN, MINOR; owner Phase 17C receipt.

### Temporary Claude weekly quota — still not a directive section 8 terminal blocker

The provider again reported automatic reset on 2026-07-30 at 12:00 America/Chicago. The
gate also has local lifecycle/evidence work in U157–U161. No credential, purchase,
hardware action, operator decision, or irreconcilable canonical contradiction is required,
so LOOP_STATE remains RUNNING rather than BLOCKED.

---

## Register update 2026-07-28 (`phase-17c.close-revalidate2`, iteration 91 — gate FAIL)

Evidence:
`docs/evidence/PHASE17C_CLOSE_REVALIDATE2_ITER91_EVIDENCE_REPORT.md`. Final work
`514d9fc` (work chain `cb27f86`, `af818fb`, `b8df384`, `514d9fc`). Mandatory
gate-validator: FAIL solely for absent passing exact-source packaged live evidence.
Mandatory spec-auditor final verdict: CLEAN. **No tag.**

### U157 — RESOLVED: packaged Electron checks have pre-spawn OS ownership

The Windows launcher now starts a Job host which assigns a gated member before that member
may spawn Electron. The host waits for the job to become empty; kill-on-close handles
outer-launcher loss. A detached descendant that reparents before external inventory was
independently reproduced, awaited, and reaped. State: RESOLVED in `cb27f86`, independently
confirmed at `514d9fc`.

### U158 — RESOLVED: WSL probe/transcription has assignment-before-target containment

The generic Windows managed runner now assigns a GO-gated member to its Job before the
real target can spawn. Its raw four-byte `GO\r\n` read does not prefetch the supported
ASCII/LF program payload. Evidence includes induced probe/transcription hangs, preservation
at the supported text seam, real `wsl.exe → python3 -` program execution, and killing the
outer Python emitter followed by zero marked `wsl.exe` processes. State: RESOLVED in
`af818fb`/`b8df384`, independently confirmed at `514d9fc`.

### U159 — RESOLVED IN SOURCE: loop runner is Claude print-mode only

`tools/loop/run_loop.ps1` now permits only `Builder=claude`, invokes only `claude -p`, and
generates the matching D-LOOP-2 prompt. The already-running outer iteration was observed
to have been invoked by the superseded Codex runner; it predated this repair and was not
spawned or killed by the unit. Future committed runner invocations are internally
consistent. State: RESOLVED in `af818fb`, independently confirmed at `514d9fc`.

### U160 — RESOLVED: teardown wording is limited to measured resources

Main now reports zero managed terminal sessions and gateway exit; it no longer claims to
have measured every Electron helper. State: RESOLVED in `cb27f86`, independently
confirmed at `514d9fc`.

### U161 — RESOLVED: receipt check names its disclosed exclusion

The receipt check is now
`receipt_matches_committed_tracked_product_tree_with_disclosed_exclusions`, and the source
record names `apps/desktop/package-lock.json` as the preserved pre-existing untracked
exclusion. State: RESOLVED in `cb27f86`, independently confirmed at `514d9fc`.

### U150 — CARRIED: one passing exact-source packaged live receipt remains

No iteration-91 live exchange was spent under the already-recorded weekly-limit window.
The unchanged receipt SHA-256
`4CD02AAA68DE4E4685D6106C840AEE555C22CE3DCDF2CE5567AA68783255CCDD`
sources `66c2bf3`, is `ok:false` 40/42, and cannot gate `514d9fc`. Required: after
provider availability, run one minimal exact-source packaged receipt proving the conductor
answer and live deny-before-execution legs, then rerun both mandatory reviews. State:
OPEN; owner `phase-17c.close-revalidate2`.

### Temporary Claude weekly quota — still not a directive section 8 terminal blocker

Automatic reset remains recorded for 2026-07-30 at 12:00 America/Chicago. No credential,
purchase, hardware action, operator decision, or irreconcilable canonical contradiction
is required, so status remains RUNNING.

---

## Iteration 92 — phase-17c.close-revalidate2 (2026-07-30)

Four issue IDs were cited in iteration-92 source comments, commit messages and the packaged
receipt before they were ever entered here. Both mandatory reviewers found the omission
independently (gate-validator D-3, spec-auditor B3). They are recorded now, at the first
opportunity this loop had to write the register, and the ambiguity in one of them is resolved.

### U162 — RESOLVED: the pinned voice-turn hook is runnable by the vendor's dispatcher

Claude Code dispatches a hook `command` through PowerShell on Windows, and PowerShell reads a
line whose FIRST token is quoted as an EXPRESSION. `subprocess.list2cmdline([node, hook])` —
correct CreateProcess quoting — therefore never parsed: the CLI reported a non-blocking hook
error and ran the tool anyway. A hook that does not parse fails OPEN for tool denial while
every field that pins it still looks right. The profile now renders the command for the
dispatcher the host actually has, and REFUSES TO BUILD unless the pinned command, run through
that dispatcher with a real `PreToolUse` probe, answers `deny`. State: RESOLVED in `e231b17`,
independently confirmed by the iteration-92 gate-validator (reservation R5: the `--settings`
metacharacter exemption is safe because the boundary pins that value's bytes).

### U163 — RESOLVED: a pytest run cannot spend a subscription call

Measured 2026-07-30: `pytest tests/` spent real `claude` calls. The frontier adapter had moved
its spawn from `subprocess.run` (which three `test_live_debate_flow` cases patched) to
`run_managed_process` (which nothing patched) on 2026-07-28; nothing failed, the calls simply
became REAL, and the case whose whole purpose is proving a `live` leg is unreachable in a
mock-first suite duly reported `live`. A process-boundary guard now refuses billable provider
spawns at all three seams, autouse for every test. State: RESOLVED in `e231b17`, narrowed by
U165; both reviewers confirmed the U163 case is still caught.

### U164 — RESOLVED: the voice-turn tool denial is measured, not inferred

The self-check previously recorded the denial leg from the absence of a tool call. It now
dispatches a real `PreToolUse` payload through the EXACT pinned hook command, by this host's
real hook dispatcher, against the same authenticated loopback service, while a live voice turn
is armed — and dispatches the same payload with a corrupted capability token, which must fall
back to the transport's own deny. That control is what separates "the supervisor decided" from
"nothing answered". State: RESOLVED in `bc8532a`. Scope limit, disclosed in the receipt and
sharpened by both reviewers (validator R1, auditor M3): this measures the SUPERVISOR denying a
tool call it is asked about, NOT a vendor-originated call being honoured.
`vendor_tool_attempt_observed` records that gap. Vendor honouring rests on the vendor hook
contract plus OS containment (U25). The leg name should be narrowed to say so.

### U165 — RESOLVED: a version probe is not a subscription call

*(ID disambiguation: `apps/desktop/voice/pane-state.js` also cited U165, for the vendor
usage-notice pane-state refusal fixed in `dfe6631`. That defect is hereby renumbered **U167**
below; U165 is this one. The double-use was found by spec-auditor B3.)*

The U163 guard refused by executable NAME, so it also refused `codex --version`,
`codex login status` and `codex exec --help` — the Phase 15C `.detect` probes, which reach no
model and cost nothing — turning nine pre-existing tests red the moment it landed
(`test_codex_detect_live`, and every test reaching `build_host_picker`). The guard now refuses
by BILLABLE invocation: an enumerated whole-argv allowlist, matched whole and never as a
prefix. State: RESOLVED in `d963ffd`; suite 1430 pass/9 fail → 1441 pass. Both reviewers
scrutinised the loosening at length and accepted it. Carried sub-issues, neither introduced by
this change: **U168** and **U169** below.

### U166 — OPEN, BLOCKING: an admitted voice turn never disarms

**This is why `gate/phase-17c` was NOT tagged at iteration 92.** Found by the spec-auditor (B2)
and confirmed against source by the builder before it was accepted.

`apps/desktop/voice/turn-authority.js:250-261` treats `Stop`/`StopFailure`/`SessionEnd` as
OBSERVATION ONLY — correctly, and deliberately: the supervised child holds the transport bearer,
so a vendor lifecycle event is not authority, and treating `SessionEnd` as authoritative produced
a reproducible deny → forged `SessionEnd` → allow bypass (fixed at iteration 88). But nothing was
put in its place. `_active` is cleared ONLY by `reset()` from the observed OS-process exit
(`main.js:840`) or the operator chord (`main.js:1763`). Consequently, after the FIRST voice
utterance of a session:

* every subsequent `UserPromptSubmit` — including the operator physically TYPING into pane 1 —
  is blocked (`turn-authority.js:198-207`, "a supervisor-owned voice turn is still pending or
  active");
* every `PreToolUse` and `PermissionRequest` is denied for the remaining life of the session
  (`:212-238`).

The conductor pane is therefore mute to the keyboard and incapable of tool use until the session
is killed or the operator presses `Ctrl+Shift+Escape` — a chord that appears in no renderer
string, no pane chrome and no operator document (spec-auditor M2), and which on Windows is also
the OS Task Manager shortcut. This directly contradicts directive §13 (OP-8) item 2, "converse
back-and-forth continuously", and §16's DEFINITION OF DONE legs (a) and (b), which require typed
AND spoken input to reach the SAME live conductor session.

Two gate artifacts additionally STATE the behaviour the code does not have —
`turn-authority.js:193-194` tells the model "denied until the turn stops", and
`node_runtime/supervisor/conductor_permission_profile.py:171` pins "Stop/StopFailure/SessionEnd
notify the supervisor process to disarm" into the launch ticket's `authority_boundary`
(spec-auditor M4). Those strings must become true or go.

Why the iteration-92 receipt still passed 41/41: its single voice turn was the LAST act before
teardown, so nothing followed it that the restriction could block. The receipt is honest about
what it ran; it simply never exercises a second turn.

Required (next unit, `phase-17c.disarm`): a SUPERVISOR-OWNED disarm. The vendor must not regain
authority, so the turn window has to be bounded by something Electron main measures itself — a
supervisor-side deadline is the only such signal identified so far; an unmarked
`UserPromptSubmit` is forgeable by the bearer-holding child and is NOT a candidate. Plus: the
armed state must be visible to the operator (invariant 27) and the recovery control
discoverable; the two artifact strings above corrected; and a receipt leg that arms a turn,
disarms it, and then proves a SECOND typed prompt is accepted and answered in the same session.
State: OPEN; owner `phase-17c.disarm`.

### U167 — RESOLVED: a vendor usage notice is not an unknown pane state

Renumbered from the second, conflicting use of U165 (see above). The pane-state reader treated
the CLI's "You've used …/session limit resets…" status line as an unrecognised pane state and
refused delivery fail-closed. Those notices are now stripped as status chrome. State: RESOLVED
in `dfe6631`. The gate-validator verified (R4) that this is safe ONLY because `PROMPT_MARKERS`
and `UNSAFE_MODE_MARKERS` are evaluated on the UNMODIFIED text (`pane-state.js:141-142`) before
any stripping (`:164`) — that ordering must never be reversed; the notice pattern otherwise
consumes up to 30 arbitrary characters.

### U168 — OPEN: the live-call guard fails open on shell-string and wrapper argv forms

`tests/live_call_guard.py:63-75` resolves a `str`/`Path` command by `Path(cmd).stem`, so
`subprocess.run("claude -p hi", shell=True)` yields stem `"claude -p hi"` and is not refused;
wrapper argv (`["cmd","/c","claude",…]`, `["node","claude",…]`), `os.system`, `os.popen` and
asyncio subprocess are likewise uncovered, and `from subprocess import run` copies are not
rebound the way `run_managed_process` copies are (`:116-118`). Pre-existing, not introduced by
`d963ffd`, and not reachable today: no product Python path uses any of those forms. Found
independently by both reviewers (validator R2, auditor m1). State: OPEN, non-blocking.

### U169 — OPEN: the metadata allowlist is wider than its callers establish

`tests/live_call_guard.py:51-56` admits `-V`, `--help`, `-h`, `exec -h`, none of which has a
caller — the real `.detect` probes are exactly `--version`, `login status`, `exec --help`
(`adapters/frontier/codex.py:219,234,247`). The module's own stated rule is that a form stays
refused "until someone establishes it is free and adds it". `login status` is established free
of credential leakage for `codex`; the same allowance silently extends to `claude`
(auditor m2/m3). State: OPEN, non-blocking.

### U144 — SUPERSEDED: production direct voice CHAT is re-enabled behind the supervisor boundary

The register's previous last word on U144 ("direct CHAT is again disabled … State: OPEN,
fail-closed") was written at iteration 86, when no supervisor-owned authority boundary existed.
It no longer describes the tree: `apps/desktop/voice/conductor-write.js:83-90` re-enables
production direct CHAT behind the now-enforced boundary, and the iteration-92 receipt exercises
that path end to end. Registers are append-only, so this entry supersedes rather than edits.
Flagged by the spec-auditor (M5). State: SUPERSEDED by this entry; the narrowed-lexicon limit
recorded at iteration 86 stands unchanged.

### U150 — RESOLVED: the exact-source packaged live receipt passed

Receipt SHA-256 `C88DD12F49F6B64DDC67C6E9EECF070D4E9744D8BC585E36889C239D5BCE831B`,
`docs/evidence/receipts/PHASE17C_CLOSE_SELFCHECK.json`, sources `dfe6631`, `ok:true`, 41 legs
passed / 0 failed, produced 2026-07-30T18:54Z after the weekly-limit reset. It reached real PCM
→ real WSL Parakeet → real bridge → the LIVE governed Fable-5 conductor, which ANSWERED (`77`,
5039 ms), armed the turn before the model, measured the supervisor's tool denial with its
corrupted-token control, queued a protected utterance without pane delivery, discarded the
audio, killed the session and returned I-X3 to 0. The gate-validator verified independently —
by `git diff` over the receipt's seven declared product paths, by the two-file `tests/`-only
`dfe6631..HEAD` delta, and by recomputing the receipt's `hook_sha256` and `settings_sha256`
against the current tree — that the bytes which ran are the bytes at HEAD. State: RESOLVED.
The gate nevertheless does not close: see U166.

### Substitutions in the iteration-92 receipt beyond the microphone (spec-auditor M1)

`apps/desktop/selfcheck/voice-conductor-selfcheck.js:34` and the receipt's `substitution` field
call the fixture-WAV microphone seam "the only one". It is not. Also substituted, and to be
disclosed as such in the next receipt: the operator-recovery leg is driven by a SYNTHESISED
input event (`apps/desktop/main.js:1991-2002`), not an observed keystroke — note that U155's
resolution ("operator recovery is main-owned and measured") rests on that synthetic gesture;
the tool-denial leg dispatches a SELF-AUTHORED `PreToolUse` payload with a fabricated
`session_id` (`voice-conductor-selfcheck.js:588-592`), disclosed at length in `scope_note` but
not labelled a substitution; and the "physical typed path" is `term.input(data, true)`
(`renderer.js:863`), not OS key delivery. State: OPEN, disclosure debt; owner
`phase-17c.disarm`.

### U166 — RESOLVED: an admitted voice turn now ends, on operator authority

Resolved in `3790a11` (`phase-17c.disarm`), proved by receipt
`A21BF4D60EA677D97089A7FD802CBF1ADA25DFAC870D39B9366D44864A8FC3D5` (sources `82923eb`,
`ok:true`, 53 legs / 0 failed) and by the falsification recorded in
`docs/evidence/receipts/PHASE17C_DISARM_FALSIFICATION.json`.

The restriction is bounded by the OPERATOR, on the OS input path Electron main observes for
itself (`before-input-event`, which fires before the page does): everything the CLI does between
an admitted spoken prompt and the operator's next keystroke is treated as voice-originated and
non-executing, and taking the keyboard back ends the window. The explicit `Ctrl+Shift+Escape`
chord and the observed `node_pty_exit` remain the other two release paths. `disarm()` accepts
ONLY those enumerated sources; any other string is refused and recorded as
`voice_turn_disarm_refused`.

**The supervisor-side DEADLINE named in U166's "required" clause was rejected on inspection, not
implemented:** a deadline returns authority for the mere passage of time, which a bearer-holding
child need only wait out. The report for this unit (§2) records the reasoning.

**A candidate that was implemented and then removed before the work commit:** operator bytes on
the `pane:input` IPC channel. xterm.js also emits `onData` for terminal replies the pane's own
process elicits (cursor-position / device-attribute queries), and the supervised CLI prints into
that pane — so it could have produced an "operator" byte on demand and disarmed itself. It is now
an explicitly refused source with a test pinning the refusal.

Visibility (spec-auditor M2, invariant 27) shipped with it: the conductor pane draws
`⛔ voice turn active — tool use denied` from a pure render model (`voiceTurnIndicator`,
`terminal/compositor/voice-indicator.js`), tooltipped with the recovery main actually implements
("type in the conductor pane — your next keystroke ends the voice turn; or press
Ctrl+Shift+Escape"). The receipt reads that badge off the PAINTED chrome, armed and after.

Both artifacts that asserted a disarm the code did not have (M4) are corrected: the admitted-turn
`additionalContext` and the launch ticket's `transport_contract`. State: RESOLVED.

### U170 — OPEN, ACCEPTED LIMIT: the disarm is bounded by operator PRESENCE, not by pane focus

The signal that ends a voice turn is any non-modifier keystroke Electron main observes — not
"a keystroke aimed at the conductor pane". Focus is renderer-derived, and U155 already moved
operator recovery OFF renderer-derived facts for exactly that reason, so re-introducing focus
here would trade a real property for a weaker one.

The consequence, stated rather than buried: if the operator types into a DIFFERENT pane while
the conductor is still answering a spoken prompt, the voice window ends there, and a tool call
the model makes after that point is governed by the ordinary typed path (the vendor CLI's own
permission prompt, the CommandBroker for anything the shell itself performs) rather than by the
voice restriction. The operator is at the keyboard in that scenario by construction, which is
the authority the bound rests on.

Narrowing it would need a main-owned notion of "which pane the keystroke was for" that does not
come from the renderer. State: OPEN, accepted limit; disclosed in the receipt's `scope_note`.

### Substitutions in the receipt (spec-auditor M1) — RESOLVED as disclosure debt

`receipt.substitutions[]` now enumerates all five with `of` / `why` / `what_ran_instead`: the
microphone seam, OS key delivery (typed path AND the disarming keystroke), the operator-recovery
chord gesture, the self-authored `PreToolUse` payload, and the supervisor-side turn armed by the
check so the process-exit release path has something to release. The "the only one" wording is
gone from both the module header and the receipt. State: RESOLVED in `3790a11`.

### U164 / R1 — RESOLVED: the tool-denial leg is named for what it measures

`voice_tool_call_denied_before_execution` → `supervisor_denied_a_tool_call_through_the_pinned_hook_while_armed`.
It measures the SUPERVISOR's decision on a real `PreToolUse` payload carried by the exact pinned
hook command while a real voice turn is armed. It does not observe a vendor tool call stopped
before it ran, and whether the CLI HONOURS the deny it is handed still rests on the vendor's hook
contract plus the OS containment owed as U25 — both stated in `scope_note`. In the same pass
`voice_restriction_released_only_after_supervised_process_exit` — the U166 defect stated as a
virtue — became two legs: `a_live_turn_is_released_by_the_exact_supervised_process_exit` and
`every_release_carried_a_main_owned_provenance`. State: RESOLVED in `3790a11`.

### R3 — RESOLVED: `make_voice_fixture.py`'s "outside every product path" clause

The file no longer claims to be outside every product path: the packaged Electron main requires
the self-checks, which spawn it under `SHELL_SELFCHECK`. What enforces I-V2 is that the
synthesizer's only sink is a file, verified present before `Speak` is called — and that is what
the header now says. State: RESOLVED in `3790a11`.

### Corrections to the entries above, after the mandatory reviews of `phase-17c.disarm`

Registers are append-only, so these correct rather than edit.

**U166's citation is superseded.** The receipt named there (`A21BF4D6…`, sources `82923eb`) was
green and is no longer the tree's evidence: closing the gate-validator's reservations changed the
product tree it was bound to, so the packaged check was re-run. The gating receipt is
**`D6BACF7C437BC4329DD0AC9970EB5C07355F6870C66B0C7C38092EA7EC0E1E53`, sources `2ee81c0`**,
`ok:true`, 53 legs / 0 failed — spoken `33 plus 24` → **57**, typed `forty-five plus thirty-eight`
→ **83**, `exit_release_turn_phase: "pending"`. U166 stays RESOLVED (spec-auditor M-1).

**The substitution count is six, not five.** The M1 entry above says "all five" and lists five; the
receipt carries six. The one missing from the prose is the validator's R-1: the blocked/admitted
pair either side of the disarm dispatches a **self-authored, unmarked `UserPromptSubmit`** with the
check's own session id — it measures the supervisor's decision on a typed prompt, not the live
session's own prompt. The live half of that claim is the second typed prompt, which the operator's
real path submitted and the model answered (spec-auditor B-2).

**The renamed leg.** `a_live_turn_is_released_by_the_exact_supervised_process_exit` was renamed
again at R-4 and is `the_turn_live_at_process_exit_is_released_by_that_exact_process_exit` in the
receipt (spec-auditor m-2).

### U170 — restated: what governs a tool call after the window ends

The earlier U170 text said a post-keystroke tool call is "governed by the ordinary typed path (the
vendor CLI's own permission prompt…)". **That asserts something this build does not pin.** The
supervisor profile (`node_runtime/supervisor/conductor_permission_profile.py`) sets hooks only —
no `permissions` block, no permission mode — and once a turn is disarmed the hook returns no
decision. What governs is therefore whatever mode the operator's CLI happens to be in, which this
repo neither sets nor reads. Correct statement of the residual: **a spoken utterance can reach
tool execution if the operator's keystroke ends the window while the model is still working on it,
gated by an unpinned vendor setting rather than by anything Sovereign enforces.** The operator is
at the keyboard by construction in that scenario, and U25 (OS containment) is the other half.
State: OPEN, accepted limit, restated (spec-auditor M-5).

### U171 — RESOLVED: an operator keystroke mid-delivery voided an utterance the badge called delivered

Found by the spec-auditor (M-6) in this unit's own work — the defect `.disarm` introduced. A voice
turn is armed before the body write and only becomes ACTIVE when the CLI's `UserPromptSubmit`
presents the payload back. `.disarm` gave the operator's keystroke the power to clear a PENDING
turn, so an operator who released push-to-talk and immediately touched the keyboard cleared it; the
marked prompt was then correctly blocked and the model never saw the utterance — while
`deliverChat` had already returned `{written:true, submitted:true}` and the badge rendered
**"Delivered to conductor"**. That is exactly the fabrication `.close` added the write record to
end, reintroduced through the new path, in an ≤8 s window with the operator's hands on the keys.

Fixed in the delivery orchestration: after the submit key, `deliverChat` polls what the supervisor
still holds for THAT turn (`turnFate`, bounded at 4 s because a healthy admit is a loopback round
trip). `admitted` and `pending` are deliveries; **`ended` is reported as NOT delivered**, with the
reason naming what happened and where the text is, and a residue record so the next utterance
cannot be spliced onto it. A binding that cannot ask at all reports `unavailable` → UNCONFIRMED,
never delivered. Four headless tests pin it. State: RESOLVED.

### U172 — OPEN, owed: the receipt's reply matcher is coupled to one vendor's TUI

`answerAfterAnchor` anchors the model's reply on the `●` glyph and the receipt gates on
`/claude\s*code/i` for "the pane ran the vendor CLI". The conductor is by invariants 3/4 an
interface with interchangeable backends; the round-trip evidence for it is wired to Claude Code's
chrome. It degrades fail-closed (no `●` ⇒ `replied:false`), so a different backend produces a red
receipt rather than a false green — but the receipt proves "reached a Claude-Code-shaped TUI",
which is narrower than "reached a live conductor". Owner: whichever unit first runs this evidence
against a second backend (spec-auditor m-4). State: OPEN.

### U173 — OPEN, cosmetic: the supervisor's turn marker is painted into the operator's pane

Every spoken turn leaves `❯ [[SOVEREIGN_VOICE_CHAT_V2:<turn-id>]] <utterance>` visible in pane 1
(receipt `typed_second_answer_excerpt`). The marker is the mechanism that binds an utterance to a
supervisor-armed turn and it must reach the CLI, so this is not a defect in the boundary — it is
noise in the operator's transcript, and it discloses a turn id that is not a secret. Owner:
post-17 polish (spec-auditor m-5). State: OPEN.

### On the falsification artifact (spec-auditor m-3)

`docs/evidence/receipts/PHASE17C_DISARM_FALSIFICATION.json` is a **hand-assembled extract** of the
falsification run's receipt, not the receipt itself: `schema phase17c_disarm_falsification@1.0`,
and it omits `source`, `checks`, `substitutions` and `authority_audit`. Its independently checkable
claim is the restore hash; everything else is a transcription made by the builder. Recorded here so
it is not read as the artifact the check wrote.

### Second-round review corrections (`phase-17c.disarm`, after the re-audit)

**The gating receipt, again.** The correction above named `D6BACF7C…` @ `2ee81c0`; that receipt was
itself superseded when the auditor's findings changed the tree. Each fix round has moved it, which is
the honest cost of fixing things a review found. **The receipt this unit finally lands is named in
`docs/evidence/PHASE17C_EVIDENCE_REPORT.md`'s header and nowhere else** — pointing register prose at
a hash that a later round supersedes is what produced this correction twice (spec-audit BL-3). U166,
U171 and the M1 disclosure remain RESOLVED; only the citation moves.

### U171 — RE-OPENED then RESOLVED again: `pending` was reported as a delivery

The first fix polled the supervisor for the turn's fate after the submit key and treated a turn still
PENDING at the deadline as submitted. The re-audit (M-A) was right that this is fail-OPEN on an
*answered negative*: `pending` is the supervisor saying "the CLI has NOT presented this payload back
to me", and it was being treated as better news than `unavailable`, which knows strictly less.
Buildout §4 says fail closed on ambiguity, and the badge reads `submitted` alone.

Now **only `admitted` is a delivery.** `pending` and `unavailable` are UNCONFIRMED, each with its own
reason; every non-delivery marks the residue, so the next utterance cannot be spliced onto whatever
is in the input (m-C); the pending turn is deliberately NOT cancelled, because it may still be
admitted. Two more from the same pass:

* **M-C** — `ended` collapsed four causes while the operator was told one of them. `turnFate` now
  distinguishes `ended_by_operator` / `ended_by_process_exit` / `ended_by_cancel`, and the reason
  follows: the conductor process dying is not the operator changing their mind.
* **M-D** — a turn ADMITTED and then ended inside one 120 ms poll interval read as voided: a
  delivery the model *did* receive would have been reported as not delivered, blocked the next
  utterance, and blamed the operator's keystroke. `turnFate` reads the AUDIT (`voice_turn_armed` for
  that turn id) rather than only the live state, so an admission that happened is a delivery.
* **M-B** — the reason said "the text is sitting in the input box". What a vendor CLI does with a
  prompt its own hook blocked is pinned by nothing in this repo, so the operator is now pointed at
  the pane instead of told what it contains. Pinned by test.

State: RESOLVED. `SUBMIT_ADMIT_TIMEOUT_MS` is exported so a test can name the bound (m-D).

### U174 — RESOLVED: the capture fold dropped the delivery's fate

Found by the builder while reading the live receipt, which recorded `turn_fate: null` for a delivery
whose fate the delivery module knew. `buildCaptureResult` is an explicit whitelist, so the new field
was silently dropped at the process seam: the badge stayed honest (it keys off `submitted`), but
neither the receipt nor the Inspector could see WHY a delivery failed — the half the operator needs.
The fold now carries `turn_fate`, and reports `null` only when the write record genuinely has none.
State: RESOLVED, pinned by test.

### The gating receipt of `phase-17c.disarm`, named once, at the end

The two corrections above each named a receipt that a later fix round superseded, which is how the
same defect kept re-opening. This unit is finished, so the citation can finally be stable:

**`18C6FC3AFA10BF77C125E18B1164E3CE6A3A429EC61D26D69508504093A4EB98`**,
`docs/evidence/receipts/PHASE17C_CLOSE_SELFCHECK.json`, sourcing commit **`a8a5d83`**, `ok:true`,
53 legs / 0 failed. Spoken `33 plus 41` → live answer **74**; the operator's typed prompt blocked
while the turn was armed, admitted after their keystroke ended it; typed
`twenty-eight plus twenty-five` → live answer **53**, same session. It carries
`write.turn_fate: "admitted"` — the live evidence that U171's admit-poll ran and answered.
U166, U171, U174 and the M1 disclosure are RESOLVED on this artifact.

Its predecessors (`A21BF4D6…` @ `82923eb`, `D6BACF7C…` @ `2ee81c0`, `09E86E3C…` @ `13bba33`) were
each green and each superseded by the next round of review fixes; only one file exists on disk, so
those hashes are recorded history rather than artifacts a reader can open.

### U175 — OPEN: the disarm call-site test is narrowed, not closed

The gate-validator re-ran its `pane:input` mutation against `voice-disarm-wiring.test.js` and the
suite now goes red, as intended. It then found the residual: an INDIRECT call —
`handleOperatorResumeInput({type:"keyDown",key:"a"}, …)` inserted into the same handler — leaves the
suite green, because the handler body contains no `.disarm(` and every disarm call site is still
inside `handleOperatorResumeInput`. The class is narrowed (the direct bypass is pinned), not closed.
Owner: `phase-17c.disarm-revalidate`; the fix is to assert the handler body invokes no operator-
authority function at all, not merely `disarm`. State: OPEN (validator R-2a).

### On `E83DBCC1…` (this unit's first receipt)

It is a measurement, not an artifact: produced from the `3790a11` tree and superseded in the working
tree by the re-run before any evidence commit, so no committed file carries that hash. The evidence
report §5 records it as an honest negative — a green receipt whose typed leg read `10` against an
expected `70` — and does not offer it as evidence (validator R-7 fallout).

---

## `phase-17c.disarm-revalidate` — the third review pass (iteration 95, 2026-07-31)

Both mandatory reviewers ran foreground against `9fd33b0`, the tree the previous unit landed. The
validator returned **NO** with three blockers; the spec-auditor returned **FINDINGS**, twelve of
them. This section records all of it: what is closed here, what is owed, and — for the one finding
that is a live invariant contradiction — that accepting it was never the loop's to accept.

### U175 — RESOLVED: the call-site guard is closed against every static form

Closed in `44d1c46` / `eb89450` / `9fd33b0` (the callee allow-list, then transitively) and finished
in `666ce1c` with the two classes the third pass falsified:

* **A release needs no call at all** (validator BLOCKER-3). `_pending` and `_active` are plain
  writable fields (`apps/desktop/voice/turn-authority.js:147-148`), so
  `conductorVoiceAuthority._active = null` in the `pane:input` handler — also `delete`, a computed
  member, or a local alias — clears the restriction with **no audit row**, which `RELEASE_SINK`
  (a `.method(` scan) cannot see and which the receipt leg
  `every_release_carried_a_main_owned_provenance` structurally cannot see either. Now pinned twice:
  nothing on the `pane:input` path may NAME the service, and file-wide every use of it in `main.js`
  must be a method call on it — never an alias, a destructuring, a value passed out, a computed
  member, a `delete` or a write — bound exactly once.
* **The channel next door** (validator RESERVATION-1). The property was per-CHANNEL, so the same
  relay moved into `pane:focus` left the suite and all 522 desktop tests green. Every
  `ipcMain.handle` channel is walked now; only `voice:capture` may reach a release and only `cancel`
  (the turn its own dispatch minted, before admission). Reaching that honestly required the walk to
  see NESTED declarations — `main.js` declares three functions inside `registerIpc`, so a relay
  declared beside them was not a node of the graph (auditor F1, caught on `pane:input` by that
  channel's closed callee list and nowhere else).

Falsified, not asserted: `tools/mutation/pane_input_bypass_mutations.js` runs **36** mutations, all
CAUGHT, `main.js` restored byte-identically to
`0265634BA19C092651A4E18DFFF1E0249FC8508EA312D645F4A9E4C06F17A148`. The ten new ones were all GREEN
before `666ce1c`. State: **RESOLVED** for every form a source reading can reach; the dynamic
residual is U177, below.

### U176 — OPEN: `stop()` releases both turns with no provenance row

`apps/desktop/voice/turn-authority.js:501-510` clears `_pending` and `_active` and records only
`supervisor_authority_stopped` — no `voice_turn_disarmed`/`_reset`/`_cancelled`. So a release by
this path is invisible to the receipt leg that enumerates provenance rows (invariant 27), and the
wiring test's `RELEASE_OWNER` pins it by source text alone. It is reached only from
`teardownSelfCheck` today, which is why this is narrow. **This item was cited by
`voice-disarm-wiring.test.js:102` before it existed** — the validator's BLOCKER-1 and the auditor's
F6, correctly charged: a citation to a register row that does not exist is the same artifact-honesty
failure as a hash no file matches. Fix: emit a `voice_turn_*` row per released turn, or refuse to
release from `stop()` and let the process-exit path do it. Owner: `phase-17c.disarm-authority`.

### U177 — OPEN: the DYNAMIC cross-channel release, which no source reading can see

After U175 the static forms are closed: no channel handler, and nothing reachable by name from one,
calls a release or names the authority service (except `voice:capture`, audited). What source
reading cannot see is a callee reached through a getter or a Proxy trap, or a reference stored on
one channel and invoked from another. The wider property — **no renderer IPC channel may release an
ADMITTED turn** — is therefore a RUNTIME assertion and is owed as one: arm a turn in the packaged
check, drive every renderer channel, assert the turn is still admitted. Recorded now with an owner
rather than deferred inside a code comment (validator BLOCKER-1, second half).
Owner: `phase-17c.disarm-authority`.

### U178 — OPEN, and NOT the loop's to accept: after the disarm, the spoken turn's tool calls execute

The spec-auditor's F1, and the sharpest finding of the pass. `disarm()`
(`apps/desktop/voice/turn-authority.js:206-211`) clears `_active` unconditionally on any
non-modifier keyDown anywhere in the window. The model is frequently **still generating the answer
to the spoken prompt** at that moment. After the clear, `handle()` returns `_hook(event, null)` —
the deny path at `:352-381` never runs — so tool calls belonging to the VOICE-originated turn are no
longer denied by the supervisor. That is I-V3 / invariant 25 negated: actions derived from
transcribed voice must be subject to the same broker path as any other action.

The previous unit disclosed this shape (U170) and recorded it as an ACCEPTED LIMIT. The auditor is
right that this was not the builder's call: accepting a residual that contradicts a frozen invariant
is operator-reserved, and the directive's delegation (§1) covers phase sign-off, not invariant
waivers. **So it is reclassified here from accepted to OPEN, owned, and to be FIXED** — the smallest
correct shape is a terminal `ended` state that keeps denying `PreToolUse` for the turn id that was
active until the vendor reports a NEW `UserPromptSubmit`, which leaves U166's fix intact (the
operator's own next prompt is what lifts it) while never handing the in-flight spoken turn an
execution capability. Owner: `phase-17c.disarm-authority`, as its first act. If it proves
unachievable it is escalated to the operator — never re-accepted here.

### U179 — OPEN: `supervisorBoundary: true` is hard-coded, so vendor chrome becomes the authority to type

Auditor F2. `apps/desktop/voice/conductor-write.js:110` passes `{ supervisorBoundary: true }`
unconditionally into `paneAcceptsTypedText`, whose `INPUT_MARKERS`
(`apps/desktop/voice/pane-state.js:80-83`) are read out of the pane's own ring buffer — bytes the
supervised process printed. `pane-state.js:144-148` holds the one refusal that says vendor chrome
alone is not authority, and the hard-coded flag means it never fires. Invariant 29: the harness is
not a boundary. The supervisor restriction makes the TURN non-executing; it does not make the pane's
self-reported mode true. Owner: `phase-17c.disarm-authority`.

### U180 — OPEN: "Delivered to conductor" rests on a claim the untrusted child makes about itself

Auditor F3. `UserPromptSubmit` flips `_pending → _active`, writes the `voice_turn_armed` row, and is
the sole basis for `turnFate() === "admitted"` → `submitted: true` → the operator-facing label. The
child holds the payload and the bearer token, so it can present the marked payload back without the
prompt reaching the model; the echo corroboration is also its own output. For the RESTRICTION,
trusting a forged admission is the safe direction; for the DELIVERY CLAIM it is the unsafe one, and
it is the fabrication class U171 exists to close. Fix: rename the fate to what it measures
(`vendor_reported_submission`) and weaken the badge, or require a second fact main measures itself.
Owner: `phase-17c.disarm-authority`.

### U181 — OPEN: the boundary's own code sits inside the supervised child's writable workspace

Auditor F4. `node_runtime/supervisor/conductor_permission_profile.py:20` points the hook at
`tools/live/voice_turn_boundary.js`, inside the repo — which is the conductor's `cwd`. `hook_sha256`
is computed once at launch (`:127-128`) and nothing re-verifies it at dispatch, and the hook
`require`s `apps/desktop/voice/turn-authority`, also writable. During any unrestricted typed turn
the CLI can rewrite either file and neuter every subsequent voice turn. U25 records the absence of
OS confinement; it does not record that the POLICY TRANSPORT is inside the contained process's write
set. Fix: re-hash at dispatch and fail closed, or stage the hook outside the workspace per launch.
Owner: `phase-17c.disarm-authority`.

### U182 — OPEN: the child can grow the supervisor's audit without bound

Auditor F5. `_record` (`turn-authority.js:154-166`) appends with no cap and logs a line per event;
the child holds the bearer token and can dispatch hook events at will, and `turnFate` deep-copies
the whole array every 120 ms (`main.js:1185`). Every other renderer-facing surface in `main.js` is
explicitly bounded for exactly this reason — the more-trusted surface got the bound and the
less-trusted one did not. Fix: ring-bound the audit; have `turnFate` read a set of admitted turn
ids. Owner: `phase-17c.disarm-authority`.

### U183 — OPEN: `handle()` accepts any `session_id` the child supplies

Auditor F12. `turn-authority.js:296,312-317` takes `input.session_id` verbatim with no comparison
against `conductorLaunch.sessionId`; only non-emptiness is required. Impact is on the
trustworthiness of the `active_session_id` / `reported_session_id` fields a receipt reads, not on
authority. Fix: compare, and record a mismatch through the existing `vendor_lifecycle_observed` row.
Owner: `phase-17c.disarm-authority`.

### U184 — OPEN: the module header claims more than the mechanism delivers

Auditor F8. `turn-authority.js:39-42` says taking the keyboard back is an act the vendor process
"cannot perform through any channel this shell gives it — not the pane it prints into". It cannot
SYNTHESISE the keystroke; it can ELICIT one, because it controls what the pane displays ("Press
Enter to continue"). That is the same elicitation argument used two paragraphs later to refuse
`pane:input`, applied one level down and then dropped. It is load-bearing for U178's disclosure.
Fix: narrow the claim to what holds. Owner: `phase-17c.disarm-authority`.

### U185 — OPEN: the fixture synthesizer's refusal is in one of its two callers

Auditor F9. `docs/evidence/PHASE17C_EVIDENCE_REPORT.md:103` attributes a `SHELL_SELFCHECK` refusal to
`tools/live/make_voice_fixture.py`, which contains no such reference; the guard lives in one caller
(`apps/desktop/selfcheck/voice-conductor-selfcheck.js:241-244`) and the other
(`apps/desktop/selfcheck/voice-mic-selfcheck.js:101-106`) has none. Invariant 24 is not breached —
no product path holds a synthesizer and `speechOut:false`/`tts:false` are structural — but the
report asserted a property one entry point does not have. Corrected in §10 of the report; the guard
itself belongs in the second caller. Owner: `phase-17c.disarm-authority`.

### U186 — OPEN: nothing runs the falsification harness

Auditor F11 + validator RESERVATION-5. `tools/mutation/pane_input_bypass_mutations.js` is the only
artifact that FALSIFIES the wiring guard, and it is out-of-band: `apps/desktop/package.json:9` runs
`node --test test/*.test.js` only, and `PINNED_BASELINE` must be updated by hand the next time
`main.js` legitimately changes — at which point the harness refuses to run (exit 3, fail-closed) and
the evidence goes stale silently. The gate must require a harness re-run whenever `main.js` moves.
Owner: `phase-17c.disarm-authority`.

### U187 — OPEN: the documented test command does not run on this host

Validator RESERVATIONS 2-3, both measured. `CLAUDE.md` documents `python -m pytest tests/ -q`; the
`python` on PATH here is 3.14 (`C:\Python314`) and the suite aborts with 75 collection errors
(`ModuleNotFoundError: jsonschema`). The command that works is **`py -3.12 -m pytest tests/ -q`**
(1441 passed). Likewise `terminal/` has no `package.json`, so `npm test` there is an ENOENT; the
working command is **`node --test test/*.test.js`** (206 pass). Recorded rather than edited:
`CLAUDE.md` is the operator's instruction file. Owner: operator-optional; the loop uses the working
commands and names them in every evidence report.

### Two validator findings answered in the evidence report rather than here

BLOCKER-2 (the report described `a8a5d83`, not the tree being tagged) and its component parts — the
work-commit list, §9's suite counts, and the fact that HEAD has moved INSIDE a declared product path
since the gating receipt was produced — are answered in §10 of
`docs/evidence/PHASE17C_EVIDENCE_REPORT.md`. The validator's RESERVATION-4 (the harness lock was
released after the first mutation, not at the end) is fixed in `666ce1c`; RESERVATION-6 lists
already-disclosed carry-overs, re-verified as still true.

---

## Phase 17C `.disarm-authority` (iteration 96) — the supervisor-authority findings closed

Every item below was opened by the third review pass of `.disarm-revalidate` and is answered in this
unit's work commit. Each fix is FALSIFIED by `tools/mutation/disarm_authority_mutations.js`
(`npm run test:falsify:authority` from `apps/desktop`): 11 mutations, all CAUGHT, every touched file
restored byte-identically. Nothing here is closed by assertion.

### U178 — RESOLVED: the ended turn keeps denying its own answer's tools

The sharpest finding of the pass, and the one this unit exists for. `disarm()` cleared `_active`
unconditionally while the model was frequently still generating the answer to the spoken prompt, so
that turn's tool calls stopped being denied — I-V3 / invariant 25 negated by the fix for U166.

A disarmed **ACTIVE** turn now moves to a terminal `ended` state
(`apps/desktop/voice/turn-authority.js`): `PreToolUse`/`PermissionRequest` stay denied for that turn
id, with their own reason and an audit row carrying `phase: "ended"`. The denial is lifted by the
operator's **next prompt** (an unmarked `UserPromptSubmit`, which records `voice_turn_ended_released`)
or by a release — the observed process exit, or `stop()`. A disarmed **PENDING** turn ends outright:
it was never presented to the model, so no answer is in flight, and its payload can no longer be
admitted at all. A new spoken turn supersedes whatever the last one left denying.

Why the operator's next prompt is a safe bound even though the child reports it: a forged
`UserPromptSubmit` lifts a restriction the operator had **already ended**, while the restriction on
the child's own ACTIVE turn stays unreachable from that socket — that one ends only at a signal
Electron main measures for itself. U166's fix is intact: the operator's typing is admitted, not
blocked.

The operator sees it (invariant 27). `turnState()` splits the two facts that were one:
`restricted` (a turn is holding this session against them — false after their keystroke) and
`tools_denied` (a denial is still running — true until their next prompt), and
`voiceTurnIndicator` renders a third `ended` state rather than going blank. A blank badge there
would report a live denial as over, which is the understating direction: nobody re-checks a
restriction they were told had ended.

### U176 — RESOLVED: `stop()` releases through the provenance path

`stop()` now calls `reset(…, { source: "supervisor_authority_stopped" })`, so the one release that
wrote no `voice_turn_*` row writes one, and `supervisor_authority_stopped` joins `node_pty_exit` in
`PROCESS_RELEASE_SOURCES` — both are facts Electron main measures for itself. The receipt leg that
enumerates provenance rows can now see this path.

### U179 — NARROWED (not closed): the manual-mode acceptance is conditioned, and the residual is named

`supervisorBoundary` is no longer the literal `true`. `conductor-write.js` derives it from
`supervisorEnforcedBoundary(readBoundary())` — the same predicate guard 1 uses, **re-read at the pane
read**, so the authority service stopping between the two guards now refuses a `manual mode on` pane
instead of typing into it. The refusal at `pane-state.js:144-148` can fire; a mutation restoring the
literal is caught.

**The residual, stated rather than implied away:** the pane's MODE is still reported by vendor chrome
and nothing in this repo observes it independently — `build_interactive_command` pins the model, not
the permission mode, so main has no launch-record fact to compare against (checked, not assumed).
What the fix buys is that accepting that chrome is conditioned on a live supervisor-owned restriction.
Carried as **U188** below.

### U180 — RESOLVED: the delivery claim is named for the fact that measured it

The fate vocabulary's `admitted` is now `vendor_reported_submission` end to end (authority → main →
`conductor-write` → badge). The delivery result carries `submission_basis: "vendor_reported"`, the
operator's badge reads **"Delivered to conductor (CLI reported)"**, and the success reason says the
conductor CLI reported the prompt as submitted. The second fact main measures for itself — the submit
key taken by a live ConPTY handle — is necessary and not sufficient, and the code says so.

### U181 — RESOLVED: the policy bytes are re-verified at dispatch, fail closed

New `apps/desktop/voice/policy-bytes.js` (`ConductorPolicyBytes`, headlessly tested over injected
I/O). Main pins `tools/live/voice_turn_boundary.js` **and** the module it requires
(`apps/desktop/voice/turn-authority.js`) when a governed launch is authorized — cross-checked against
the ticket's own `hook_sha256`, so a swap between ticket emission and spawn refuses the launch rather
than being adopted as the baseline — and the authority service re-reads both on EVERY dispatch. A
changed or unreadable file blocks/denies the event with `policy_bytes_unverified` in the audit; a
verifier that throws is a refusal, not consent. The pin is cleared when the session exits.
**Not claimed:** this is a hash comparison, not confinement. A rewrite reverted between two dispatches
is invisible and nothing here stops the write — U25 remains the item for that.

### U182 — RESOLVED: the audit is bounded and no decision reads it

`_record` keeps a ring of 2000 rows and counts what it dropped (`snapshot().audit_dropped`);
per-turn fates live in a bounded `Map` (200 turns) and `fateOf()` answers from the state machine, so
`turnFate` no longer deep-copies a child-floodable array every 120 ms — and a fate survives its own
audit row being dropped, which the old audit scan did not.

### U183 — RESOLVED as far as this system can honestly check it

`handle()` compares `input.session_id` against the id the turn was **admitted under** and records
`vendor_session_id_mismatch` (admitted vs reported, by event) — observability, never authority, which
is where the auditor placed the impact. The comparison the finding literally asked for is not
available: `conductorLaunch.sessionId` is main's own key (`pane-1#<pid>.<seq>`), a different namespace
from the vendor CLI's session id, so comparing them would report a mismatch on every healthy event.
Recorded here rather than faked.

### U184 — RESOLVED: the header claims what the mechanism delivers

The module header now says the vendor process cannot **synthesise** the keystroke and explicitly adds
that it CAN elicit one (it controls what the pane prints) — the same elicitation argument used two
paragraphs later to refuse `pane:input`, no longer dropped one level down.

### U185 — RESOLVED: both callers of the fixture synthesizer refuse outside a self-check

`voice-mic-selfcheck.js` gains the `SHELL_SELFCHECK` guard `voice-conductor-selfcheck.js` had, and
`apps/desktop/test/selfcheck-guards.test.js` asserts it for EVERY module that spawns
`make_voice_fixture.py` — the property, not the instance (I-V2/D-VOICE-02).

### U186 — RESOLVED: the ordinary suite now fails when a harness goes stale

`selfcheck-guards.test.js` compares `main.js`'s hash to `PINNED_BASELINE` and fails with the exact
recovery procedure, so a legitimate `main.js` change turns the desktop suite red until the harness is
re-run and re-pinned (instead of the harness silently refusing to run, exit 3, weeks later). Both
harnesses have npm scripts (`test:falsify`, `test:falsify:authority`) and the test refuses any
harness in `tools/mutation/` that no script runs. Re-pinned this unit to
`E80723ECDBE7C64E3611AC56B3D83420C3F6DEBB019ED2BD9C3E90BD794C9261`; 36/36 pane:input mutations still
CAUGHT on it.

### U188 — OPEN: the pane's interaction mode is still the vendor's own report

Carved out of U179, which is otherwise closed. `INPUT_MARKERS` are read from bytes the supervised
process printed, so a future vendor modal that exactly impersonates the input footer is
indistinguishable, and this shell has no independent fact about the CLI's permission mode to compare
against (the launch argv pins the model only). The delivery is conditioned on a live supervisor-owned
non-executing boundary re-read at the write, which bounds the DAMAGE of being wrong (the turn cannot
execute) without making the reading true. A fix would require either a vendor-side mode assertion this
repo can verify or OS-level observation of the child — neither exists today. Owner: post-17 hardening
backlog; disclosed in the evidence report and the final report, never presented as closed.

### U189 — OPEN: the `.disarm-authority` tree has no packaged receipt yet

This unit changed product modules (`turn-authority.js`, `conductor-write.js`, `policy-bytes.js`,
`main.js`, `voice-indicator.js`, the renderer chrome and two self-checks), so the gating in-Electron
receipt `18C6FC3A` no longer measures the shipped runtime. The gate cannot close on it. Owed, in
order, to the next unit: regenerate ONE exact-source packaged receipt against a live conductor
(schema `phase17c_close_selfcheck@1.2`, which now carries
`ended_voice_turn_still_denies_its_own_answers_tools` and
`chrome_shows_the_turn_ended_with_its_answer_still_denied`), add the U177 runtime assertion (arm a
turn, drive every renderer channel, assert still admitted), then re-run BOTH mandatory reviewers
against that exact tree. Owner: `phase-17c.receipt`.

### U177 — RESOLVED: the cross-channel property is now asserted at RUNTIME, and the residual is U190

Closed by `phase-17c.receipt`. The instrument is the one this row prescribed: with the operator's
spoken turn ADMITTED, the packaged in-Electron receipt drives EVERY intent the preload bridge exposes
(`apps/desktop/renderer/channel-sweep.js`), then asks the supervisor — from its own state, not from
the absence of an audit row — whether it still holds that exact turn
(`apps/desktop/voice/turn-survival.js`), and re-dispatches a real `PreToolUse` through the pinned hook
command to show the restriction is still ENFORCED rather than merely recorded. Receipt
`PHASE17C_CLOSE_SELFCHECK.json` (schema `phase17c_close_selfcheck@1.4`), legs
`every_renderer_channel_was_driven_while_a_turn_was_admitted`,
`no_renderer_channel_released_the_admitted_voice_turn`,
`the_restriction_was_still_enforced_after_the_channel_sweep`,
`channel_sweep_left_no_session_behind`,
`channel_sweep_wrote_no_prompt_text_into_the_live_conductor`.

Coverage is fail-closed in three directions, because a sweep that quietly skipped the one channel
somebody just added would be worse than no sweep: a bridge method no entry names, an entry the bridge
does not answer, and — at runtime, against the shipped `main.js` — a channel main registers that was
never driven. The parser reads one registration shape, so it also REFUSES when the count it could name
differs from the count of registrations present, or when any one-way `ipcMain.on` exists (validator
RESERVATION-4). Falsified headlessly in `apps/desktop/test/channel-sweep.test.js` (20 tests): each
failure mode of the driver and of the verdict has its own red case.

### U189 — RESOLVED: the tree has its packaged receipt, and it is this one

Closed by `phase-17c.receipt`. One exact-source packaged run against a live conductor on the tree
being tagged (`source.commit` == the work commit, `tracked_product_tree_clean: true`, no unexpected
untracked product files), with the U177 runtime assertion in it. The first `@1.3` run of this unit was
reviewed and FAILED by the gate-validator; its findings are fixed in the work commit and carried in
U190/U191, and the receipt was regenerated as `@1.4`.

Both mandatory reviewers then ran in the FOREGROUND against `f9dc5e5` and **have returned** — this
sentence is written after their verdicts, not before, because the earlier draft of this row asserted
the review in the past tense while it was still in flight (spec-audit M4, and it was right).
Gate-validator: **PASS_WITH_RESERVATIONS**, one BLOCKING precondition on the tag (no evidence-report
section for this unit; §11.7's standing last word disclaimed the gate) + 1 MAJOR + 8 MINOR.
Spec-auditor: **PROHIBITED DRIFT: NONE**, "do not tag as it stands" on evidence honesty — 4 MAJOR
(three of them this row and U191's wording) + 8 MINOR. Both prescribed the same docs-only
remediation, which is what closed it: §12 of `PHASE17C_EVIDENCE_REPORT.md`, this row and U191
rewritten before commit, and U192–U204 opened with owners. No product file moved after the review, so
the receipt is still exact-source and the falsifications still measure the tagged tree.

### U190 — OPEN: the sweep drives each channel ONCE, with one set of arguments

Carved out of U177, which is otherwise closed. Every renderer channel is invoked, but each with a
single governed, non-destructive argument set. A dynamic release (a getter, a Proxy trap, a reference
stored on one channel and invoked from another) that fires only under argument values the sweep does
not supply is therefore not excluded by the runtime assertion. The STATIC guard
(`voice-disarm-wiring.test.js`) covers that shape wherever a callee can be named, whatever its
arguments — so what neither instrument reaches is the intersection: an unnameable callee reached only
under specific arguments. Closing it would need either argument fuzzing with a release oracle, or a
runtime proxy over the authority service that records every reach. Owner: post-17 hardening backlog;
disclosed in the receipt's `scope_note` and the evidence report, never presented as closed.

### U191 — OPEN (bounded by scope): the sweep's governed writes are attributed to the operator

The sweep's arguments are non-destructive but they are not no-ops. Main writes three
operator-attributed lines for them — `main.js:1322` (`approvals: operator <decision> of …`),
`main.js:1302` (`conductor: operator requested Resume→Select`), and `main.js:1475`
(`voice: operator push-to-talk (audio …) → proposed_action`, which the first draft of this row did not
even enumerate). From main's side that is exactly what an operator click looks like, and the renderer
must never be allowed to label its own actions as machine-driven (invariant 29).

Three corrections to the first draft of this row, all from spec-audit M2/M3, all of which made the
disclosure less accurate than the thing it was disclosing:

1. **"Queues a real protected-verb proposal" overstates it.** `tools/live/emit_conductor_voice.py`
   persists nothing — it prints the feed. Nothing durable is enqueued anywhere by the sweep.
2. **`RECOVERY_DIR` is the wrong bound.** That isolation (`main.js:259`) covers the layout/session
   log only. The approval queue is not isolated by `SHELL_SELFCHECK` at all: it is ephemeral **for
   everyone**, because `tools/live/emit_approval_decision.py:53-55` rebuilds the queue inside a
   `tempfile.TemporaryDirectory`, and the shared long-lived queue is itself OWED to 16F
   (`approvals/drawer-source.js:41-45`). So the real trip-wire is not "a second consumer of the
   driver" — it is **16F landing the shared long-lived queue**, at which point a machine-driven
   `approvals:decide` reaches a durable operator-visible queue and nothing in code or register
   notices. That trip-wire is recorded here so it is not discovered by surprise.
3. **"Which is why this is not fixed by adding a flag to the IPC" was a false dichotomy.** The
   premise (never trust the renderer's self-label) is right; the conclusion is not. Main knows
   `process.env.SHELL_SELFCHECK` from its OWN environment, never from the renderer, and already
   branches on it (`main.js:259, 1891, 2019`) — so it could annotate these three log lines' provenance
   from its own knowledge without trusting the harness at all. It simply was not done. That is the
   honest reason, and it is now the fix this row owns.

What bounds it today is scope: the sweep is reachable only from `window.__sovereignSelfCheck`, which
exists only under `?selfcheck=1`, which main sets only under `SHELL_SELFCHECK`, whose layout/recovery
store is isolated and whose run is not the operator's. Owner: post-17 hardening backlog, and BEFORE
16F's shared queue lands (spec-audit F6/F9, M2, M3).

### U192 — OPEN: a receipt with no `source` block cannot be bound to any tree

`docs/evidence/receipts/PHASE17C_VOICE_PROBE_SELFCHECK.json` (the in-Electron evidence for track
17C's first criterion, the U74 probe fix) carries **no `source` block at all** — no `commit`, no
`tracked_product_tree_clean` — and was run `2026-07-26T20:52:07Z`. `main.js`, which hosts the
`voice:probe` handler, `ensureVoiceProbe()` and the `shell:voice` push, has changed in every unit
since. `probe.js` itself has not, and this tree's `.close` receipt does exercise the probe
in-Electron (`probe_at_capture`: real WSL engine, `state: available`, `probes: 1`, `elapsed_ms 37947`),
so criterion 1 is not unevidenced — but the >=60 s budget, the forced re-probe and the `SOW_*`
overrides are evidenced on THIS tree only by headless tests. Failure scenario (gate-validator M1): a
regression that re-pins the cached probe answer in main's wiring leaves that receipt green forever,
because it names no tree. Fix: make `source` mandatory in the receipt schema family, and regenerate
`.probe` on a tree it names. Owner: post-17 hardening backlog.

### U193 — OPEN: the "no prompt text" leg checks one string, and the protected verb is not re-checked after the sweep

`channel_sweep_wrote_no_prompt_text_into_the_live_conductor`
(`selfcheck/voice-conductor-selfcheck.js:832-833`) asserts only that `SWEEP_PROBE` is absent from the
pane. The sweep also calls `captureVoice("audio:terminate-node-b")` (`renderer/channel-sweep.js:118`).
If that verb were ever classified CHAT instead of `proposed_action`, its transcript would be written
into pane 1 and this leg would still pass, because `protected_verb_reached_no_live_pane` runs BEFORE
the sweep (`:729-746`) and nothing re-checks after it. Not reachable today (the classifier queues it,
and the receipt shows `write.written:false`), so this is a gap in the instrument, not a live defect.
Fix: assert pane text is unchanged across the sweep window, not that one probe string is absent.
Owner: post-17 hardening backlog (gate-validator m2).

### U194 — OPEN: `submit_key_was_echo_confirmed` accepts one segment; the product gate requires two

The leg (`voice-conductor-selfcheck.js:570-571`) passes on `echo.total > 0 && echo.matched > 0`. The
shipped gate is `MIN_ECHO_SEGMENTS = 2` (`voice/echo-confirm.js:65`, applied at `:109`). This run
observed 9 of 12 segments, so nothing here is wrong — but a run that matched exactly ONE segment would
FAIL the product gate and PASS this leg, which is the wrong direction for a receipt to be lenient in.
Fix: the leg reads the product constant instead of restating a weaker one. Owner: post-17 hardening
backlog (gate-validator m3).

### U195 — OPEN: the release scan says "every" and covers three of five release events

`every_release_carried_a_main_owned_provenance` (`voice-conductor-selfcheck.js:1069-1074`) filters
`voice_turn_disarmed | voice_turn_reset`, and `turn-survival.js:37` (`RELEASE_EVENTS`) covers
`voice_turn_disarmed | _reset | _cancelled`. The authority also emits `voice_turn_superseded`
(`voice/turn-authority.js:468`) and `voice_turn_ended_released` (`:506`), both of which end an
admitted turn's restriction. Neither is fail-open — the survival verdict reads the authority's own
`snapshot()` (`turn-survival.js:88-95`), so a supersede or ended-release still fails criterion 3, and
`voice_turn_ended_released` is the deliberate safe-forgery direction recorded at U178. What is wrong
is the reporting: `released_during_sweep` would print `[]` in a run where a supersede or
ended-release occurred, and a leg named "every" scans a subset. Fix: one release vocabulary shared by
the authority, the survival check and the leg; rename or widen. Owner: post-17 hardening backlog
(gate-validator m4 + spec-audit m7).

### U196 — OPEN: the coverage counters refuse an unknown registration SHAPE but not an unknown registration API, and read one file

`renderer/channel-sweep.js:145-152` counts `ipcMain.handle(` and `ipcMain.on(`, and the receipt
refuses unless `parsed === handle_total && one_way_total === 0`. `ipcMain.handleOnce(` or
`ipcMain.once(` would be neither parsed nor counted, so the equality would still hold and that channel
would escape the sweep silently — the exact class of miss the counters exist to refuse. Separately,
`voice-conductor-selfcheck.js:787-789` reads `../main.js` and nothing else; `ipcMain` appears only in
`main.js` today (verified), and the runtime `uncovered` scan over the bridge's own keys
(`channel-sweep.js:210-214`) closes the renderer-reachable side regardless of file — so this is an
unstated assumption, not a hole. Both are verified-absent today and neither is covered by U190. Fix:
count every `ipcMain.*` registration form, and glob the shell's sources rather than one path. Owner:
post-17 hardening backlog (gate-validator m5 + spec-audit m10).

### U197 — OPEN: leg names and `scope_note` prose that claim more than the assertion behind them

None of these is fail-open; each is a reader being told something slightly stronger than what ran, and
they are recorded rather than quietly left:

- `physical_typed_path_reaches_same_conductor_input` uses `term.input()`, not a key event
  (substitution 2 discloses this at length; the NAME does not).
- `typed_prompt_is_blocked_while_the_voice_turn_is_armed` and
  `typed_prompt_is_admitted_once_the_operator_disarms` measure the supervisor's decision on a
  synthetic `UserPromptSubmit` carrying the check's own session id, not the live session's own prompt
  (substitution 5).
- `scope_note` says "THREE legs pin CONTRACT FIELDS" and then names four (`no_tts`,
  `self_authorized_false`, and the TWO `owed_record_*` legs).
- The post-sweep denial row is selected by `findLast(event === "tool_denied" && session_id === ...)`
  (`:843-848`), which can match the PRE-sweep row; only the `voice turns are non-executing` reason
  regex separates a real denial from the transport fallback (`authority unavailable`), so the identity
  clause contributes nothing it appears to.

Fixing the `scope_note` and the leg names means editing `selfcheck/voice-conductor-selfcheck.js`,
which would make the receipt no longer exact-source and cost another live exchange for wording — so it
is carried here, deliberately, per the spec-auditor's own recommendation. Owner: the next unit that
regenerates this receipt for a substantive reason (gate-validator m6/m7 + spec-audit m11).

### U198 — OPEN: `main_owned_operator_recovery` arms the turn it then disarms

`main.js:2069` (inside the `SHELL_SELFCHECK` block) calls `conductorVoiceAuthority.arm(...)` so the
synthesized Ctrl+Shift+Escape chord has something to disarm. Substitution 3 discloses the synthesized
chord but not that the check supplied its own subject. The property under test (main, not the
renderer, owns the recovery path) is unaffected — but the disclosure should say both halves. Fix:
extend substitution 3's text at the next regeneration. Owner: post-17 hardening backlog
(gate-validator m8).

### U199 — OPEN: the sweep discards every handler's outcome, so a governed answer and a fail-closed error read alike

`runChannelSweep` keeps `{method, channel, pane, invoked, error}` and throws the return value away
(`renderer/channel-sweep.js:217, 234-246`); all 24 receipt rows carry `error: null` and no result. Yet
`channel-sweep.js:23-25` ("a refusal is a governed answer — it means the channel ran"),
`voice-conductor-selfcheck.js:1187-1190` and U191 all assert what those handlers DID. They cannot be
read off this evidence.

Measured on this host while writing this row, because "the receipt cannot say" deserves a number: one
spawn-per-call governed emitter round trip (`py -3.12 tools/live/emit_approval_decision.py
--emit-approval-decision ...`, refused item) costs **~0.96-1.01 s** (four runs: 1007, 961, 961, 967 ms;
bare `py -3.12 -c pass` is 48 ms). The audit window that contains the whole sweep is **4.08 s**
(`05:55:38.706` -> `05:55:42.786`), and it also contains a forged `PreToolUse` dispatch. So that window
comfortably fits two-to-three spawn-per-call emitters plus socket-backed or JS-short-circuited
handlers, and does NOT fit six. Which of the emitter-backed channels (`approvals:fetch`,
`approvals:decide`, `inspector:fetch`, `statusbar:fetch`, `picker:fetch`, `voice:capture`) did a full
governed round trip and which returned early is exactly what the rows do not record. **The sweep's
load-bearing property — nothing released the admitted turn — is unaffected**, because that is read
from the authority's own state, not from the rows. The overclaim is about EFFECTS. Fix (cheap, next
regeneration): record per-row outcome kind (`sourced` / `refused` / `unavailable`) and `duration_ms`,
and correct the two comments and U191 to whatever the rows then show. Owner: post-17 hardening
backlog (spec-audit M1). Invariant 27 / Buildout Directive section 4.

### U200 — OPEN: an `args()` that throws is recorded as `invoked: true`

`renderer/channel-sweep.js:234-240` evaluates the argument builder INSIDE the try that wraps the call,
then sets `row.invoked = true` unconditionally after the catch. If `entry.args(state)` threw, the
method was never called, the row still says invoked, and `out.ok` stays true — the "silently skipped
the one channel somebody just added" outcome the module's own header calls worse than no sweep.
Today's `args` closures are pure property reads and cannot throw, and `test/channel-sweep.test.js` has
no case for this shape. Fix: build the arguments outside the try, and add the red test. Owner: post-17
hardening backlog (spec-audit m5).

### U201 — OPEN: the sweep's `voice:probe` comment promises a cached answer it may not get

`renderer/channel-sweep.js:119-120` says "unforced: the cached answer, not a fresh WSL NeMo import".
`main.js:1352` calls `p.start()`, which `voice/probe.js:204-205` documents as starting a probe when
none is in flight **and the last answer is stale**. On a host with a stale answer the sweep does
trigger a WSL NeMo import — which is also what the launcher's new worst-case arithmetic
(`selfcheck/run.js:91-95`) has to absorb. Fix: pass the non-forcing option explicitly or correct the
comment. Owner: post-17 hardening backlog (spec-audit m6).

### U202 — OPEN: the cancel exemption checks the mint window, not the provenance

`voice/turn-survival.js:79-81` exempts any `voice_turn_cancelled` whose turn was minted inside the
sweep window, without inspecting `row.source`. The header (`:18-23`) justifies the exemption
specifically as `voice:capture` voiding a turn it minted and nobody else has seen — so any path that
mints then cancels inside the window inherits a pass it was not argued for.
`test/channel-sweep.test.js:268-280` exercises only the minted / not-minted axis. Fix: require the
mint and the cancel to carry the same expected source; add the red case. Owner: post-17 hardening
backlog (spec-audit m8).

### U203 — OPEN: the sweep payload's safety rests on an undocumented coupling to the residue predicate

The sweep's conductor payload is `0x15` (`renderer/channel-sweep.js:67`). Its safety against
`main.js:1247-1251` — where bytes on `pane:input` to the conductor pane can clear the operator's
input-residue block — rests on `operatorInputResolvesResidue` matching only `/[\r\n\x03]/`
(`voice/conductor-write.js:65-68`). `test/channel-sweep.test.js:138-142` happens to exclude exactly
CR, LF and ETX, but for the stated reason "must not submit, must not be ETX" — the residue predicate
is named nowhere in the new code or its tests. Two consequences, neither reachable in this run
(`write.submitted: true`, `residue: null`): widening the predicate later would silently let a
machine-driven sweep lift the operator's residue guard under operator provenance; and if residue IS
pending when a sweep runs, Ctrl-U erases the operator-visible text while main's `conductorInputResidue`
stays set, so main's model and the pane diverge (invariant 27). Fix: name the coupling in both files
and pin it with a test that fails if the predicate widens. Owner: post-17 hardening backlog
(spec-audit m9).

### U204 — OPEN: `preload.js`'s `spawnFromSelection` comment has been false since 17B

`apps/desktop/preload.js:33-37` still says the channel "starts no session (invariant 2): the live
governed spawn is operator-run/16F". Since `phase-17b.spawn`, `main.js:1680` calls
`workerLauncher().launchWorkerPane` — the channel DOES spawn, through the supervisor and the governor,
which is the whole point of U70's closure. Pre-existing and not introduced by this unit, but this unit
drives that channel from a machine sweep, so the stale comment now sits one line from a safety
argument that depends on knowing the truth. Fix: correct the comment. Owner: post-17 hardening backlog
(spec-audit m12).


---

## PHASE 17D `.events` (2026-07-31) — the drawer stopped showing work nobody asked for, and what that left open

Finding **F2** (directive §16, operator first use 2026-07-25) is CLOSED: the approval drawer no longer
renders Phase 16D's canned trio. It is folded from the session's own recorded events, and an empty
session shows an empty drawer (in-Electron receipt `PHASE17D_APPROVALS_SELFCHECK.json`, 21/21). The
rows below are what the gate-validator and the spec-auditor measured on the way, opened rather than
argued away.

### U205 — OPEN: a well-made forgery in the event log still produces a drawer row

`control_plane/orchestration/session_approvals.py` re-derives every row with the real classifiers, so
the shell cannot promote an ordinary sentence into a protected action, demote a protected verb into a
question, or mint a row with no utterance behind it — the gate-validator reproduced all three refusals
against hand-written logs. What re-derivation does NOT give is provenance: a log line carrying a
*plausible* utterance ("spawn a worker"), or a FULLY-FORMED `gate@1.0` record with
`decided_by:"gate_engine"`, is accepted, and the validator demonstrated the latter producing an
approvable plan row for the objective "delete the production database". The checks refuse malformed
forgeries, not well-made ones. This is narrower than the trio it replaced (every row now corresponds
to something a real classifier accepts) and is bounded by the integrity of the shell process and its
per-run file, which the supervisor owns — but it is not the unforgeable binding. FIX (owed): a
producer-minted stamp (the IPC envelope's hmac machinery is the obvious donor) that the drawer builder
verifies before re-deriving. State: OPEN. Owner: 17E / post-17 hardening. Disclosed in the module's
HONEST RESIDUAL and asserted by a test.

### U206 — OPEN: a forged `decision` event can DISPOSE of an approvable row

The authority-adjacent half of U205, opened by the spec-auditor and pinned by
`test_a_forged_decision_CAN_dispose_of_an_approvable_row_and_that_is_recorded_as_owed`. Replay
re-governs a recorded decision through `ApprovalQueue.resolve`, so it can never approve a
non-approvable item and never resolve as a non-operator — but a well-formed decision over an
APPROVABLE row IS honored, so anything that can write the log can make a pending approval vanish from
the operator's drawer. `recordGovernedDecision` binds the shell's honest path (it refuses anything the
Python authority did not mint); it cannot bind the file. The claims in `session-events.js` and
`emit_approval_decision.py` were corrected to say exactly that. FIX (owed): same stamp as U205, plus
(cheaper, partial) an append-only integrity chain over the log. State: OPEN. Owner: 17E / post-17.

### U207 — OPEN: the decide path's invariant-1 half is a presumption, and now says so on the wire

Carried unchanged from 16D and made visible here: `route_session_decision` constructs
`Identity(role="operator")` when no identity is supplied, and the emitter never supplies one, so
`ApprovalQueue.resolve`'s role check cannot fail on the product path. The invariant-16 half of the
feed's `authority` string is real (a non-approvable item is refused, here and on every replay); the
invariant-1 half is a presumption about who is at the keyboard. The feed now carries
`operator_identity_presumed` beside that string so a reader is not told more than was proven. FIX
(owed): the authenticated per-node identity binding on the real IPC surface (U25's neighbourhood).
State: OPEN. Owner: 17E / the IPC credential broker unit.

### U208 — OPEN: the session-approval log has no transcript TTL and no disposal at quit

`apps/desktop/approvals/session-events.js` holds the operator's TRANSCRIPTS (never audio — invariant
26 belongs to the capture store, which deletes). The file is truncated at the next launch, so a
transcript written today survives until the app is next started, with no TTL and no disposal at quit.
This is the same "the purge only runs when they next use the feature" shape that was already found and
fixed for captured audio (`main.js`, capture store constructed at startup). Stated in the module
header, not implied. FIX (owed): dispose on quit and bound retention by TTL, mirroring the capture
store's policy. State: OPEN. Owner: post-17 hardening.

### U209 — OPEN: the three new cross-process envelopes have no file in `schemas/`

`session_approval_event@1.0`, `approval_drawer_feed@1.1` and `approval_decision_feed@1.1` are pinned
as constants in code and validated by shape predicates, not by a schema in `schemas/` — the same debt
the register already tracks for the other shell feeds, extended by this unit rather than reduced. The
gate-validator raised it as R6. State: OPEN. Owner: the schema unit already registered for 17D's
close / post-17.

### 17D `.events` — resolved or superseded by this unit

* **U66 (the drawer's shared long-lived queue)** — the persistence half is now real: a resolve is
  recorded as an event and replayed through the authority, so a decided item stops appearing on every
  later fetch, with no component holding a mutable queue. The remaining half is the downstream SIDE
  EFFECT (broker execute / `ObjectiveIntake` assign), carried on every feed as `side_effects_owed`
  (17E) and now shown to the operator in the drawer itself rather than only in the shell log.
* **A defect found while building, not reported by the operator:** a low-confidence or blank utterance
  was refused correctly and then dropped — it never reached the one drawer OP-7 §12.5 put
  clarifications in. `ConductorVoiceBridge._clarify` now routes those through the same broker + mirror
  the proposed action uses.
* **A hole the spec-audit found in that fix:** a bridge clarifying at a HIGHER confidence than its
  broker would hand a mid-confidence SAFE verb to a broker that finds it confident enough — rule 4,
  EXECUTED, a control event minted before the branch's own guard could refuse it. Unreachable from the
  shipped shell (every product constructor uses defaults), reachable via
  `run_conductor_voice(confidence_threshold=…)`. The pairing is now refused at construction.
* **A regression this unit introduced and fixed before the gate:** `assembled-selfcheck.js` (the
  already-tagged 16F receipt) waited for `source === "emitter"`, which the new feed can never emit. It
  now CAUSES the event it approves — a spoken protected verb — and additionally proves the empty-at-
  launch property, the persisted resolve, and the refused re-decide. Re-run green on this host.

---

## ADDENDUM 2026-07-31 — `phase-17d.close` (U73 resolved, U69 narrowed, audit R4 discharged)

Work commits **d742743** (the guard, the receipt, the R4 checker) and **85342c8** (the review fixes).
In-Electron receipt `docs/evidence/receipts/PHASE17D_CLOSE_SELFCHECK.json` (`ok:true`, Electron
31.7.7, `node selfcheck/run.js pane-guards`). Evidence:
`docs/evidence/PHASE17D_CLOSE_EVIDENCE_REPORT.md`.

**U73 — RESOLVED.** The `pane:resize` handler no longer dereferences anything. The decision moved to
`apps/desktop/panes/resize-intent.js`, which refuses when there is no `SessionManager` yet (the
renderer's first fit can beat supervision into existence — the operator's actual `TypeError`), when
the registry does not hold the pane (the sessionless CONDUCTOR placeholder, invariant 2), when the
geometry is not a positive integer within a ConPTY `COORD` (invariant 29 — the renderer is the
least-trusted surface), and when the SessionManager reports that no live handle took it. `main.js`
delegates; `apps/desktop/test/pane-resize.test.js` (10 tests) pins each rule, and the in-Electron
receipt drives the REAL preload bridge at the REAL handler against the REAL placeholder: refused with
a reason, an admitted session still resized, a made-up geometry refused with the live session
surviving it. Falsified by re-inlining the pre-U73 dereference (receipt `ok:false`, exit 1,
`{"resized": true}` for a pane with no session) and restored byte-identically; the gate-validator
reproduced that falsification independently. Owner: —.

**U69 — OPEN, NARROWED (not resolved). Owner: 17E / the operator's own keyboard.** The receipt's
`u69` block is recorded and never asserted (`receipt.ok` excludes every field of it but the 16A
control leg). What is now machine-proven on this host: with the window focused and the xterm helper
textarea holding DOM focus, text input on that textarea plus a delivered `Return` keydown becomes
`xterm.onData` → `pane:input` → PTY → echo. That is one layer above 16A, whose `term.input()` starts
below the DOM entirely. What is NOT exercised: a real OS key event and Chromium's handling of it —
28 synthetic keydowns arrived at the textarea trusted, focus was still there afterwards, one
text-input event was counted, and no terminal data resulted. **The run isolated no mechanism for that
and the receipt does not claim one** (the first draft of this unit did; spec-audit F5 and
gate-validator R3 both charged it). The remaining layer is the operator's keyboard, which is where
directive §16 puts it.

**Audit item R4 — DISCHARGED.** The `wsl_present` fixtures in `tests/integration/test_wsl_parakeet.py`
and `test_voice_mic.py` pin `shutil.which` instead of inheriting the host PATH, and
`tools/mutation/wsl_path_hermeticity_check.py` now measures that: the same files run with no `wsl.exe`
on PATH (54 pass, 3 skip) and are compared with the normal-PATH run (57 pass), requiring the same
collection, every skip reason readable, and every skip declared by a `skipif` host requirement. The
gate-validator falsified it by removing the fixture's `monkeypatch.setattr` — 7 failed, checker red.

### Opened by this unit

### U210 — OPEN: `resized:true` is a handle-level fact, not a proof the terminal repainted

`SessionManager.resize` now returns whether a live pty handle of the matching generation accepted the
call (`terminal/conpty/session-manager.js`), and the shell reports that answer. Between a process
dying and `onExit` firing, that handle still exists and the call still returns true — the same
handle-level caveat 17C wrote into `write()`. Nothing downstream consumes the answer today
(`renderer.js` discards it; only the log and the self-check read it), so the exposure is a log line
that could say "resized" fractionally after the process died. FIX (owed, non-blocking): if a consumer
ever depends on it, confirm by observed repaint the way `voice/conductor-write.js` confirms delivery
by echo. Owner: post-17 / whoever first depends on the return value.

### U211 — OPEN: the delegation test is a drift alarm, not containment

`apps/desktop/test/pane-resize.test.js` pins that `main.js`'s `pane:resize` handler calls
`resizePane(...)` and contains no `manager.resize(` of its own, by reading the source slice between
two handler registrations. The gate-validator proved it goes red for a literal re-inline (R5) and
named what it cannot see: an inline guard written through an alias (`const r = manager; r.resize(…)`),
or a reordering that moves `pane:close` above `pane:resize`. The same class as the `pane:input`
source-scan residual U177 answered with a runtime sweep. FIX (owed): if the handler grows further
rules, drive them from the receipt rather than from a source match. Owner: post-17 shell hardening.

### U212 — OPEN: the R4 checker's allow-list is two literal strings over two files

`tools/mutation/wsl_path_hermeticity_check.py` names its permitted skip reasons as literals rather
than deriving them from the `skipif` conditions, so a future test could go quiet legitimately by
reusing one of those reason strings, and it covers only the two probe files (gate-validator R6). The
arithmetic guard (the pass count must equal the baseline minus exactly the counted skips) bounds this
but does not remove it. FIX (owed): derive the allow-list from the collected `skipif` markers if a
third file joins. Owner: post-17.

### Answered here without a new row

* **spec-audit N1** — `resizePane` will resize any session id the renderer can name, including the
  conductor's. Contained (one window, a Map lookup, no cross-node reach) and unchanged by this unit;
  the pane→session ownership question belongs to the pane model, not to the resize decision.
* **spec-audit N3 / validator R7** — a self-check whose receipt WRITE fails still reports `ok:true`
  in-process; that is the convention in all 18 checks and a systemic note, not a regression here. The
  R4 checker's baseline leg does run the host-gated proofs that spawn `wsl.exe` and `node`: its
  docstring now says so.
* **validator R4** — regenerating `docs/PHASE0_FREEZE_MANIFEST.json` is not a no-op: it reorders
  `canonical_documents`, bumps `generated_ts` + `freeze_integrity_sha256`, and adds ~40 accumulated
  `mutable_audit_files.evidence_reports` entries. No frozen canonical hash moves. The regeneration
  was reverted and the 11 canonical hashes verified directly instead, rather than re-signing a
  Phase-0 operator-signed attestation from inside a 17D unit.

---

## Phase 17E `.review-fixes` (2026-07-31) — the composition's own reviewers

The first fully-live composition receipt (`ok:true`, run at `f470533`) went to the mandatory
gate-validator and the spec-auditor before the gate was closed. Both returned findings against the
mechanism 17E exists to certify, so the receipt is **superseded** and the gate stays open: the
verdict rules, the disclosures and the I-X3 governor were changed, and the composition re-runs
against the fixed tree in the next unit. Verdicts as received: gate-validator
**PASS_WITH_RESERVATIONS** (3 must-fix, 4 minor); spec-auditor **FINDINGS (14)** — 1 high, 5
moderate, 8 minor.

### U111 — NARROWED (was OPEN, owner 17E): the diagnostic ledger now counts the durable one

The hole as the spec-auditor restated it (F1): the fully-live run holds **two** live frontier
terminals on the operator's subscription while `SOW_TERMINAL_LEASE_LEDGER` points at a per-pid
scratch file, so the enforcing governor counted **zero** for that window — and an operator shell
already at its own allowance of 2 could have made the true total 4. Worse, the receipt had inverted
the redirection into a pure safety property ("it can never touch the operator's terminals"), which is
true in one direction only.

**FIXED as U111 asked** (`node_runtime/supervisor/terminal_lease.py`): a ledger whose path comes from
the env override is a **DIAGNOSTIC** scope. It still writes only its own records — a check must never
adopt or release a terminal the operator's shell holds — and it now counts the durable ledger's live
leases as a **read-only baseline** in `in_use`, in every `acquire` admission decision (the refusal
names the baseline holders), and in `seed_governor`, so a bounded emitter's in-process gate chain
inherits the same refusal. `snapshot()` separates the two classes (`own_in_use` / `baseline_in_use` /
per-holder `scope`), because an unattributable total is no more readable than the dishonest zero. A
corrupt/unreadable durable ledger raises rather than counting a reassuring zero. Nine tests in
`tests/unit/test_terminal_lease.py`; product (non-redirected) behaviour is unchanged by construction
and pinned by a test.

### Opened by this unit

### U213 — OPEN: approval-row ids do not distinguish real events from the demonstration trio

The event-sourced queue mints `ap-1` for its FIRST real row, and the demo trio's first item is also
`ap-1`. No id-based rule can separate them in either direction: it fails real events (the first 17E
run did exactly that) and it would pass canned ones the moment a fixture renumbered. The 17E drawer
leg is decided on PROVENANCE instead and reports the collision (`demo_ids_present`), but **17D's own
`launch_no_demo_trio` leg still tests by id** and inherits the weakness. FIX (owed): re-express that
leg as "no row lacking a recorded event id", the same rule 17E now uses. Owner: post-17.

### U214 — OPEN: the OWED list is authored, not derived

`owedMarkersAreComplete` enforces that every leg we KNOW is unevidenced is named with a reference a
reader can look up. It cannot discover a leg nobody wrote down, so the check name it feeds is now
`every_known_unevidenced_leg_is_named_with_its_reference` rather than "every unevidenced leg"
(spec-audit F5 — the old name claimed a completeness the code could not deliver, and F1/F3/F4 were
three unevidenced legs in the same run that it passed over). FIX (owed): no mechanical one exists —
finding the unnamed leg is the reviewers' job, which is why both are mandatory at this gate. Owner:
standing.

### U215 — OPEN: the diagnostic baseline is read before the lock, not inside it

U111's fix reads the durable ledger's live leases **before** taking the scratch ledger's own lock (a
diagnostic scope never holds two lock files at once). A terminal the operator's shell acquires inside
that window is not in the count that admits ours. Strictly closer to the cap than the zero it
replaces, and bounded by one bounded session per check run. FIX (owed): a shared lock ordering across
both files, or a single ledger with a holder-class column. Owner: post-17 governor hardening.

### U216 — OPEN: `synthesized_by` names an adapter class, never a backend

`live_succession.py` hard-codes `"conductor_fable5"` for every `ConductorAdapter`, so the field is
identical on a mock feed and a live one, and `liveDispatchIsHonest`'s non-empty check on it can never
fail (gate-validator D3). The 17E receipt now records `dispatch.synthesized_by_note` naming
`legs.conductor` (which DOES discriminate, and says `mock` for the conductor side of the dispatch)
and the scope note says a reader beside a live Fable-5 pane must not read the literal as Fable 5.
FIX (owed): carry the executing checkpoint's model ref into the synthesis record the way the worker
legs already do. Owner: post-17 / whoever makes the conductor side of a dispatch live.

### U217 — OPEN: the answer-detection anchor is one vendor's glyph

`voice/spoken-probe.js` credits a reply only after the Claude CLI's `●` model marker. The failure
direction is closed (a missing glyph means "no answer seen", never a false positive), but the
receipt's wording is generic — "the live conductor answered" — where the mechanism can only answer
that question for one vendor's chrome (spec-audit F8, invariant 4 / I-SC1). FIX (owed): a per-adapter
reply anchor in the capability descriptor when a second interactive backend gets a conductor pane.
Owner: post-17.

### U218 — OPEN: probe modules for checks live in product trees

`apps/desktop/voice/spoken-probe.js` and `apps/desktop/conductor/roundtrip-probe.js` are required
only by `selfcheck/` and `test/`, yet sit in directories the receipt enumerates as
`source.product_paths` (spec-audit F10). They grant no authority and do nothing at import, so this is
hygiene rather than a violation — but it is the category the prohibited-drift list names. FIX (owed):
move them under `selfcheck/` when nothing else is touching those files. Owner: post-17.

### Answered here without a new row

* **gate-validator D1 / D4, spec-audit F6 — FIXED, not deferred.** The drawer rule read ONE row and
  the whole 16D trio could render behind a genuine one with the leg green (17D's F2 with an honest
  row in front of it); every row now needs provenance and the reproduction is a test. A worker row
  the pool labels `live` that does not itself carry the label is refused. The launch-path guard
  anchored on the FIRST `if (process.env.SHELL_SELFCHECK)` in `main.js` — the renderer logging block
  — which put the product conductor auto-launch inside the "self-check only" region; it now anchors
  on the unique dispatcher and asserts the boundary contains that launch path. Falsified: adding
  `liveWorkers: true` to the auto-launch turns it red, and `main.js` was restored byte-identically.
* **gate-validator D2 / spec-audit F3 — FIXED by disclosure.** The protected-verb utterance is a
  scripted stand-in routed through the visible mock engine (a protected verb must be refused before
  anything is delivered — that needs no microphone). 17D recorded the engine; the composition had
  dropped the field. It is back, with a substitution entry, because the same receipt says
  `mock:false` about the SPOKEN leg and a reader must not carry that across.
* **spec-audit F2 — FIXED.** 17B gated `scratch_ledger_removed` + `real_ledger_unchanged` as
  conjuncts of `ok` and the composition had dropped both; a removal whose result is never read is not
  a teardown. Both are checks again, measured by digest across the run.
* **spec-audit F4, F7, F13, F9, F12 — FIXED.** The pinned VRAM budget is disclosed in the receipt
  (`worker.budget_source`) and not only in the code above it; `model_available`'s third state
  (unprobed) is recorded rather than folded into `false`, and the run may assert a `--model` slug
  only where the probe confirmed it; the I-X3 leg no longer hard-codes `allowance === 2` (a config
  that narrows to 1 is legitimate — `live_authorization` says so); the session-approval log is
  isolated under `SHELL_SELFCHECK` exactly as `RECOVERY_DIR` is, so a diagnostic run cannot truncate
  an operator session's drawer log; `dispatch-source.js`'s owed note no longer says the live worker
  leg is owed to 16F, which happened.
* **gate-validator D5 — FIXED.** `feed.live_run` (the emitter's own dating/bounding of its live call)
  is carried into the receipt, so the live dispatch is datable from the receipt alone.
* **spec-audit F11.** `no_tts_on_any_path` and `shell_self_authorized_nothing` do read boolean
  literals, and are kept for continuity — but I-V2 is proven structurally elsewhere and the auditor
  re-confirmed it independently (`selfcheck-guards.test.js` refuses a reachable `System.Speech`;
  `test_conductor_voice.py` asserts the bridge exposes no synthesize/speak/tts surface). No row: the
  invariant is enforced, the checks are simply weaker than their names.
* **spec-audit F14.** The allowance of 2 is operator-ordered (OP-6), not R8-verified-at-2, and
  `control_plane/profiles/live_authorization.py` says so in its own header. The receipt now states
  the allowance it read rather than asserting the constant. The canonical default-1 stance is
  unchanged and the governor cap is unmoved.

---

## Phase 17E `.close` — the second review round (2026-07-31, iteration 102)

The composition was re-run against the fixed tree (`676362b`) and came back `ok:true`, 36/36. Both
mandatory reviewers ran again in the foreground, on that receipt and that tree, and they split:
**gate-validator PASS_WITH_RESERVATIONS** ("may be tagged, conditional on four bookkeeping items"),
**spec-auditor FINDINGS — "do not tag as it stands"** (2 HIGH, 5 MAJOR, 5 MINOR, 4 NIT), with
*prohibited drift: NONE* and *no invariant violated by the code*. The auditor's blocking findings are
about what the receipt and the published feeds **claim**, and three of them required product-code
changes — which void the receipt's exact-source and force another re-run. **The gate did not close in
this unit. `gate/phase-17e` and `product/fully-live` do not exist.**

### U219 — OPEN: the live worker's brief is delivered through the graded artifact, not through MCP

`tools/live/emit_conductor_dispatch.py`'s `LIVE_WORKER_OBJECTIVE` was described as scoped context in
the Plan §9 sense, but `adapters/model_adapter.py` embeds the objective verbatim into the published
bytes, so the brief becomes ~600 characters of dispatcher-authored, deliberately gate-safe prose
**inside the artifact the STAGE gate scans** (spec-audit M4). It survives `no_placeholders` partly by
an accident of English: `"no_placeholders"` escapes the blocklist regex only because its trailing `s`
defeats a `(?![a-z])` boundary — rename the criterion to the singular and every live dispatch fails
on the text of its own instruction. A test pins the current outcome; nothing pins the fragility.
Not a gate violation (the verdict is still computed from the bytes by a node that did not author
them, and the REJECTED transition is untouched), but the delivery channel was misdescribed and the
brief inflates the artifact it is judged inside. The description is corrected in this unit; the
channel is not. FIX (owed): route the definition-of-done as a context entry the adapter does not
concatenate into the body, or make the criterion name unquotable. Owner: post-17.

### U220 — OPEN: `the_ix3_count_is_the_governing_one` measures a label, not the governing

The check reads `scope === "diagnostic" && Number.isFinite(baseline_in_use)`
(`apps/desktop/selfcheck/fully-live-selfcheck.js`). It never exercises an admission refusal, and with
`baseline_in_use: 0` it cannot distinguish "read the durable ledger and found nothing live" from
"found nothing to read" (spec-audit m2). The mechanism IS unit-tested in
`tests/unit/test_terminal_lease.py`; the in-Electron check named for it is not the thing that tests
it. FIX (owed): have the composition seed a baseline holder and assert the refusal names it.

### U221 — OPEN: the check writes a file into a product path it has already sampled

`sourceIdentity()` samples the tracked product tree at t=0, then the run writes
`tools/live/_voice_fixture_fully_live.wav` into `tools/live` — a `source.product_paths` member — and
deletes it at teardown. Nothing leaks and no receipt is wrong, but a product-tree file the check
itself creates is structurally invisible to the check named for the product tree.

### U222 — OPEN (tooling hazard, outside 17E): `compute_manifest.py` destroys the operator signature

The command `CLAUDE.md` advertises for the freeze manifest rewrites
`docs/PHASE0_FREEZE_MANIFEST.json` in place: it resets `operator_signature` from
`SATISFIED_BY_OPERATOR_RULING` to `PENDING`, re-computes `freeze_integrity_sha256`, and re-orders
`canonical_documents`. The gate-validator hit it while verifying the freeze and had to `git checkout`
the file. There is no read-only `verify_manifest.py`, so the honest verification path (hash the 11
canonical files against the manifest) is the one nobody documented. This is the second unit to work
around it — 17D `.close` §8 reverted the same regeneration. FIX (owed): add the read-only verifier and
make regeneration refuse to touch `operator_signature`.

### U223 — OPEN: `approval_drawer_was_empty_until_this_run_caused_something` is partly self-guaranteed

`main.js` isolates the approvals log under `SHELL_SELFCHECK` (the F9 fix, which was correct — a
diagnostic run must not truncate an operator session's drawer log) and `session-events.js` truncates
it at `begin()`. So the leg's "empty before" is guaranteed by the isolation as much as observed
(spec-audit m11, gate-validator m11). What it genuinely refutes is the canned 16D producer, whose
badge would be ≥2. It is not evidence about staleness, and the name suggests it is.

### U224 — OPEN: a relocated durable ledger becomes its own baseline

`node_runtime/supervisor/terminal_lease.py` treats *any* `SOW_TERMINAL_LEASE_LEDGER` value other than
the default as a DIAGNOSTIC scope, overlaying the default file as a read-only baseline. An operator
who legitimately relocates their durable ledger therefore gets the default counted too, and an
unresolved or case-variant path to the same file would make a ledger its own baseline. Both
directions **over-count**, so the failure is fail-closed and safe — but "product behaviour is
unchanged" is narrower than it sounds. FIX (owed): resolve paths before comparing, and let the
operator declare a durable relocation explicitly.

### U215 — RESTATED (the earlier statement was the flattering half again)

U215 was written as a *read-to-write window* — "a terminal the operator's shell acquires between our
baseline read and our own write is uncounted". The spec-auditor (M5) showed the residual is larger
and simpler: the overlay is **one-way by construction**. A durable ledger has no baseline path, so the
operator's own shell never counts a diagnostic run's leases **at any moment**, not merely inside a
window — for the whole ~3.5 minutes an operator shell could take its full allowance and the true total
would be 4, which is verbatim the scenario U111 named. What `8919a1f` fixed is that the **check** can
no longer be the party that overshoots. The receipt's `scope_note` and `owed.diagnostic_ledger_scope`
now say this in the present tense.

### U146 — RESTATED (was OPEN, disclosure-level): the composition had dropped it, and that is the point

17C's receipt disclosed that a delivered utterance becomes durable text in the vendor CLI's **own**
session store, outside this workspace; the 17E composition asserted
`audio_was_transcribed_then_discarded` and disclosed nothing (spec-audit M1). True of our capture
store, and not the whole story: a reader of the composition receipt alone would conclude that speaking
to the shell leaves nothing behind. `vendor_session_store_retention` is now a **required** OWED key,
so the receipt cannot drop it again. This is also the clearest demonstration of U214's residual — the
OWED list is authored, and finding a leg nobody wrote down is the reviewers' job, which is exactly
what happened here.

### Fixed in this unit, without a new row

* **spec-audit H2 — a published evidence artifact carried a sentence its own data falsified.**
  `LIVE_WORKERS_MET["note"]` read "…the real gate engine accepted it" and `live_workers_record` emits
  it whenever the aggregate leg is live and a checkpoint is verified — **never consulting the gate**.
  It is therefore present, and false, in `PHASE17E_DISPATCH_GATE_REFUSAL_20260731T1513Z.json`, whose
  `acceptance_verdict` is FAIL. Structurally the D3/U216 defect again, and worse, because the literal
  is not merely uninformative but wrong on the exact run this track publishes as its honesty exhibit.
  The record's subject is the WORKER leg (U58); it now says so and points at `gate_summary` /
  `acceptance_verdict` / `accepted_count` for the gate's own verdict. Pinned by
  `test_the_u58_record_never_narrates_the_gate`.
* **spec-audit M2 — two checks were renamed *upward* onto hard-coded literals.**
  `no_tts_on_any_path` and `shell_self_authorized_nothing` read `deliver.js`'s `tts: false` and
  `main.js`'s `selfAuthorized: false`; neither can go red under any input. 17C/17D named them
  honestly (`no_tts`, `self_authorized_false`); the composition promoted them into whole-program
  claims in the same unit that renamed the OWED check *downward* for exactly this reason (F5/U214).
  They are now `the_capture_result_asserts_no_tts` and
  `the_capture_result_asserts_no_self_authorization`. The invariants remain enforced and
  adversarially tested elsewhere (the disarm-authority mutation harness catches a reachable
  `System.Speech`; `selfcheck-guards.test.js` refuses one; `test_conductor_voice.py` asserts the
  bridge exposes no synthesize/speak/tts surface). **This supersedes the F11 note in the previous
  round, which chose continuity over accuracy.**
* **spec-audit M3 — the "not a softened gate" defence cited evidence from the pre-change path.** The
  15:13Z refusal run used the BARE objective. It is evidence about the gate FUNCTION, not about the
  briefed path; under the briefed configuration there is exactly one live run and it is green. Said
  plainly now in the code comment, in the checkpoint, and in a test that fails if that file is ever
  re-labelled as evidence about the briefed configuration.
* **spec-audit m1 — the brief described a criterion the node cannot affect.** "every claim you make
  must be one the surrounding text supports" pointed at `claims_cite_evidence`, which evaluates the
  ADAPTER's generated claim records. Removed; the brief now says one criterion binds its wording, and
  a test holds the claim records fixed while varying the prose to prove the verdict does not move.
* **spec-audit m3 — the protected-verb engine record gave the wrong cause.** It reported the cold
  probe ("the real engine may still be available") in a receipt whose capture leg had transcribed real
  PCM on the real engine 90 s earlier. The operative cause is the stand-in: it carries no PCM, so no
  real engine could have transcribed it whatever the probe says. Cause first, engine state as context.
* **gate-validator m2 — the drawer rule refused three of the four real row kinds.** `ref` was required
  of every row, but `operator_surface` builds genuine plan and clarification rows with `ref: None` by
  design. The failure direction was closed (never a false pass) and the name was still wrong. A broker
  ref is now required of protected actions only; event id and channel stay required of every row.
* **gate-validator m4 / m3 / m6.** The receipt records `dispatch.objective`, so a reader can see which
  brief produced the judged artifact; the drawer leg's `"ONLY"` now states that this run causes one
  row of one kind and that provenance is a shape check; the demo-trio fixture carries `ref: null` for
  the plan and clarification rows, as the real builders do (it had been *easier* to reject than
  reality — the wrong direction for that test).

### Answered without a row

* **gate-validator r3 — `product/fully-live` must not be read as "the owed register is closed."**
  Directive §16's premise ("Phase 17 closes the ENTIRE remaining owed register") is **not met**: this
  track opened U213–U224, U215 is U111's residual, and U116–U119 / U210–U212 carry forward. The tag
  names a composition — every machine-checkable leg of the operator's DEFINITION OF DONE holding at
  once, with the un-evidenced halves named — and nothing more. The final report must say so, and the
  operator must be told it in the one message they get.
* **gate-validator m1** is spec-audit H2, fixed above. **m8** — U217 (the answer anchor is one
  vendor's glyph) is in the register but not in the receipt; a receipt-only reader is directed to the
  register by `scope_note`.
* **m10 — "packaged Electron".** The run is `electron.exe` from `node_modules` driving `main.js`; no
  electron-builder distributable is exercised. Established phrasing since 16A, kept for continuity,
  and D-P16-0's actual requirement — "inside the Electron runtime on this host" — is met.
* **NIT — `mcp_server/protocol.py`'s disclosed reconnect dependency** (a 420 s worker bound against a
  60 s server handler timeout means every live dispatch is reaped at least once) is recorded in code
  and nowhere in the receipt. Transport only, no authorization logic; invariant 7 clean, confirmed
  independently by both reviewers.

## Phase 17E `.close` — the third review round, and the gate closes (2026-07-31, iteration 103)

The composition was re-run against **this** tree (`fa3e1a1`) and came back `ok:true`, 36/36,
`failed_checks: []`, `tracked_product_tree_clean: true`. Both mandatory reviewers ran again in the
foreground, on that receipt and that tree — neither previous verdict carried over. **gate-validator:
PASS_WITH_RESERVATIONS** (5 must-fix, all documentation-level). **spec-auditor: FINDINGS** (1 MAJOR,
5 MINOR, 4 NIT), *no invariant violated*, *prohibited drift NONE*, tag blocked on two items only.

**What made this round different from the previous two: every blocking remedy was in `docs/`, outside
`source.product_paths`** — both reviewers said so independently. A documentation fix does not void the
falsifications a validation rests on, so the receipt survived and **`gate/phase-17e` and
`product/fully-live` are tagged on the evidence commit.** Full disposition table:
`docs/evidence/PHASE17E_EVIDENCE_REPORT.md` §5.

### Discharged in this unit

* **spec-audit F1 / gate-validator MF-C — the published refusal exhibit still asserted the H2
  falsehood.** `docs/evidence/live/PHASE17E_DISPATCH_GATE_REFUSAL_20260731T1513Z.json` still reads
  *"the real gate engine accepted it"* in an object whose own `gate_summary` is `stage_pass 0/1`,
  `acceptance FAIL`, `accepted_count 0` — on the one artifact this track publishes to prove the gate
  **refuses** live work. Fixing the generator (`a64779d`) is prospective and cannot un-publish a run.
  A sibling correction note now sits beside it —
  `PHASE17E_DISPATCH_GATE_REFUSAL_20260731T1513Z.CORRECTION.md` — carrying the false sentence, the
  data that falsifies it, what in the exhibit **remains** true and is still evidence, and the lesson.
  **The artifact is not rewritten** (inv 12): an exhibit that is quietly corrected is worth nothing.
  `PHASE17B_LEGS_DISPATCH_FEED.json` carries the same literal, where it happens to be true
  (stage 1/1, PASS) — named in the note, deliberately untouched.

### Raised and disproved — recorded because a high-stakes gate's provenance must show its own audit

* **spec-audit F2 — "commit attribution contradicts the log".** The auditor (read-only, no shell,
  and it said so, asking for `git show --stat`) reported that `676362b` and `a64779d` were attributed
  backwards, which would have undermined the exact-sourcing proof. Run: `git show --stat 676362b`
  adds the four diagnostic fields (`dispatch.failed_count`/`node_refusals`/`gate_summary`/
  `worker_legs`) and the gate-criteria brief — the **reviewed** tree; `git show --stat a64779d`
  changes `control_plane/orchestration/conductor_dispatch.py`, deleting `"gate engine accepted it"` —
  the **H2 fix**. The two hashes were swapped in the reading, not in the record. **The checkpoint's
  attribution and the exact-sourcing proof stand.** A disproved finding is kept in the register on
  purpose: the alternative is a trail in which only findings that survived are visible.

### U225 — OPEN: the composition's synthesizing conductor is the mock adapter, and the check name says otherwise

Raised as **MF-A + MF-B (gate-validator)** and **F6 (spec-auditor)** — the same root, three ways in.
The check `a_live_worker_published_a_candidate_that_the_gate_accepted_and_the_conductor_synthesized`
is green while `dispatch.legs.conductor` is **`"mock"`**. The `…and_the_conductor_synthesized` clause
is backed solely by `nonEmpty(feed.synthesized_by)`, and `synthesized_by` is the fixed literal
`"conductor_fable5"` (`adapters/conductor/adapter.py:51`) emitted by every `ConductorAdapter` ever
built — **not a measurement of which backend folded the accepted set**. Compounding it,
`receipt.owed.conductor_initiated_dispatch` lists *"the synthesis"* among things that "are real",
without the qualifier: the flattering half again, and in the block the check *enforces*. The
substitution is also missing from the six-entry `substitutions` array whose stated purpose is exactly
that. Corrected in words in the evidence report §5 and §1 (leg d), and in the FINAL addendum. **The
rename and the `substitutions` entry are deferred to the next unit that already forces a re-run** —
renaming a check edits `source.product_paths` and would void a green receipt for a wording change,
which is the trade this track has already paid twice. Same defect family as **U216**.

### U226 — OPEN (process, not code): a mandatory reviewer's must-fix list was compressed to a count, and one item is now unrecoverable

Raised as **MF-D**. The round-2 gate-validator returned four must-fix items; the checkpoint recorded
them as *"MF1–MF4 must-fix (all documentation/state)"* and then accounted for **MF1/MF3/MF4** only.
`grep -rn "MF2" docs/` returns nothing: **MF2's text does not exist anywhere in this repository.** It
is plausible it was "write the evidence report" — the fourth bookkeeping item, since MF1/MF3/MF4 were
the FINAL addendum, `LOOP_STATE` and the decision-register row — but that is an **inference and is not
recorded as fact**. All five analogous items of the third round are enumerated with individual
dispositions in the evidence report. **The rule this row exists to set: a mandatory reviewer's
findings are preserved verbatim in the evidence, never compressed to a count.** A summary of a review
is not a record of a review, and the gap is invisible precisely until someone audits it.

### Accepted, non-blocking, carried forward

* **spec-audit F3 → folded into U219.** `tools/live/emit_conductor_dispatch.py:66` says the objective
  "is NOT scoped context routed over MCP". It **is**: `live_flow.py:841-846` publishes it as a
  `shared_project` MCP entry and `model_adapter.py:75-76` reads it back. The true statement is the
  second clause only — `model_adapter.py:94-95` *also* concatenates it into the graded body. The
  comment errs in the **fail-safe** direction (it understates the system) and the register already
  states it correctly. Deferred with the U225 renames, for the same receipt-voiding reason.
* **spec-audit F4 / gate-validator R1 → folded into U214/U216.** Three or four of the 36 checks
  cannot go red at runtime: `the_capture_result_asserts_no_tts` and
  `the_capture_result_asserts_no_self_authorization` read constants (`deliver.js:112`,
  `main.js:1557`); `every_known_unevidenced_leg_is_named_with_its_reference` is literal-vs-literal;
  `the_protected_verb_leg_names_the_engine_that_produced_it` is near-tautological. The names are
  honest ("asserts", "known") and the invariants behind them are enforced by the mutation harnesses
  and `selfcheck-guards.test.js` — but **a receipt-only reader sees "36/36" and is not told the
  denominator contains static assertions.** Stated in the evidence report §5 instead, because saying
  it *in* the receipt requires a product edit.
* **spec-audit F5 → U220 stands.** `the_ix3_count_is_the_governing_one` measures a label plus "a
  number was read"; the M2 remedy (rename to what it measures) was not applied here. Deferred with
  the other renames.
* **gate-validator R2** — `composeVerdict` has no expected-key manifest, so a silently dropped check
  would shrink the denominator with `ok` still true. Did not manifest: all 35 `receipt.checks.X =`
  assignments were verified present in the receipt. **R3** leg (e)'s "ONLY" is exercised over n=1.
  **R4** drawer provenance is a *shape* check. **R7** leg (c) evidences a spawn, not a usable model —
  no prompt is sent to `qwen3:8b`, and only the source comment says so. **R8** `scope_note`'s topic
  sentence is stronger than the body that follows it. **R9** the receipt records `dispatch.verdict`
  and `drawer_verdict` as conclusions a receipt-only reader cannot re-derive.
* **NITs.** N1 `SOW_VRAM_BUDGET_MB` is set process-wide (1 TB) before being pinned, and the dispatch
  child inherits it — no practical effect (the dispatch worker is frontier, not VRAM-gated), but the
  disclosed scope is narrower than the actual one. N2 `both_governed_terminals_were_handed_back`
  reads a diagnostic `in_use` that includes the durable baseline — fail-safe, but the name says
  "both [of ours]". N3 a code comment says the bridge exposes no `speak` surface; `bridge.speak()`
  exists as the STT **input** entry — the assertion it cites covers `synthesize/speak_out/say/tts/
  answer_voice`, so the guarantee is intact and the comment's wording is loose. N4/m4
  `PHASE17B_SPAWN_SELFCHECK.json` carries no `source.commit` (older receipt format) yet is cited as
  the frontier-spawn evidence. **m2** — U222 stands: the manifest command `CLAUDE.md` advertises
  destroys the operator signature; `--check` was used, a read-only verifier is still owed. **m3** —
  U217, the answer anchor is one vendor's glyph. **m5** — U221, the fixture WAV is written into a
  product path after the tree is sampled (nothing leaked; the file is deleted and the tree is clean).

### What `product/fully-live` does NOT mean — stated once more, because the tag now exists

Directive §16's premise that *"Phase 17 closes the ENTIRE remaining owed register"* is **not met**.
This track opened **U213–U226**; U215 is U111's residual; U116–U119 and U210–U212 carry forward. The
tag names **a composition** — every machine-checkable leg of the operator's DEFINITION OF DONE
holding at once in one Electron process, with the un-evidenced halves named — and nothing more. Both
reviewers required this sentence; the final report carries it and so does the operator's one message.


## Phase 18A (OP-12) — Grok Build / Gemini·Antigravity reconnaissance + runner

Opened 2026-07-31 by the 18A work unit and its two review rounds. None blocks 18A; each names an
owner. Full context: `docs/evidence/PHASE18A_REVIEW_ROUNDS.md`.

### U227 — OPEN (BLOCKS 18B design): the frozen node schema has no enum member for either provider

`schemas/node.schema.json` `properties.adapter.enum` is frozen `@1.0` (Phase 0 freeze manifest,
canonical set) and contains `claude_code, openai_codex_cli, opencode_local, gemini_cli, aider,
ollama_direct, nvidia_parakeet, mock`. Neither `grok_build` nor `google_antigravity` is a member,
so a node record for either provider cannot validate. Directive §17 lists canonical schemas in the
untouchable set, and operator directive §8 forbids a parallel registry — so 18B cannot solve this
by editing the schema OR by routing around it. The three candidate resolutions (an operator-ruled
schema amendment; reusing the existing `gemini_cli` member for the Antigravity path with the
display name still "Gemini · Antigravity" per §14; or an adapter-id indirection layer) are an
**operator-reserved decision, not a builder's**. 18A records it rather than pre-empting it.
Owner: 18B entry.

### U228 — OPEN: Antigravity authentication cannot be established without spending a live call

`agy` has no `login`, no `auth`, and no status subcommand (verified against the installed
`agy --help`; the capture is in `docs/evidence/live/phase18a_host_recon.json`). `agy models`
returns an inventory at exit 0 whether or not the operator is signed in, so there is no offline
evidence of auth state. Status therefore reports `auth_state: UNVERIFIED` with an
`AVAILABLE`-plus-caveat state, and `auth_confirmed: false`, permanently, until the one live probe
at 18C. This is the honest answer, not a gap to close — but 18B's picker must not read
`AVAILABLE` as "signed in". Owner: 18C (the probe resolves it).

### U229 — OPEN: the Grok subscription enumerates exactly one model

`grok models` on this host reports `grok-4.5` as both the default and the only available model.
The picker will therefore offer one Grok entry. Nothing is fabricated to fill the list (operator
directive §8), and a future subscription/CLI change will simply enumerate more. Recorded because
"Grok Build" reads like a family and the operator may expect several. Owner: 18B (surface it as
what it is).

### U230 — OPEN: `_AUTHORIZED_PROVIDERS` is read through a private name

`tools/providers/frontier_provider_recon.py:provider_registration` reads
`live_authorization._AUTHORIZED_PROVIDERS` via `getattr(..., frozenset())`. A rename degrades
CLOSED (empty set implies NOT_REGISTERED), so the hazard has no teeth, but the coupling is private
and undeclared. FIX (owed): a public accessor on the live-authorization module, used by both call
sites. Owner: 18B.

### U231 — OPEN: identity minimisation is applied to one evidence field and not the adjacent one

`account_hint` withholds anything that is not service-shaped, on the stated principle that an
account identity must not enter committed evidence — while the same artifacts record the
operator's OS account name inside the resolved executable path, four times, in tracked files.
Operator directive §6 *requires* reporting the resolved executable path, so the field stays and
the inconsistency is recorded rather than silently resolved. FIX (owed, if the operator wants it):
a home-directory placeholder in evidence rendering, applied everywhere or nowhere. Owner: post-18.

### U232 — OPEN: provider facts are declared twice (descriptor + PowerShell switch)

`ProviderSpec` in the engine holds provider id, display, subscription resource, allowance, and
capability booleans; `run_frontier_providers.ps1` re-keys the same providers by literal id in
three `switch` blocks, and the install path PRINTS the descriptor's `install_command` while
EXECUTING a separately hardcoded one — change the descriptor and the runner announces one thing
and installs another. Not a parallel registry in the prohibited sense (the runner registers
nothing and defers every registry fact to 18B), but the two copies can drift. FIX (owed): drive
the runner's per-provider branches from the engine's report. Owner: 18B.

### U233 — OPEN: `terminal_allowance = 1` is declared but nothing enforces it yet

The engine declares `grok_build_subscription` and `google_antigravity_subscription` at allowance 1
each (operator directive §12, never merged), and the status surface prints them — but the existing
`live_authorization` expresses a single global `terminals_per_subscription` capped at 2 (OP-6), and
no governor knows either resource. Until 18B registers them, the printed allowance is a DECLARED
intent, which is why the same line reports `lease not_registered`. FIX (owed): per-provider
allowances in the governor, refusing a second concurrent session per new subscription. Owner: 18B.

### U234 — OPEN: the 18C live probe would spawn an unsupervised, unleased frontier CLI

`frontier_provider_recon.run_probe` executes the provider CLI through a bare `subprocess.run`
(`subprocess_runner`): no ConPTY, no SessionManager, no node identity, no I-X3 subscription lease,
no job object, no teardown accounting. In 18A this is inert — the live gate denies both providers
and `test_a_denied_gate_spends_nothing` proves nothing spawns — and the module's framing of the
absence ("it spawns no supervised node, holds no lease") read as a virtue rather than as the gap
it becomes the moment the switch opens. Same class as U121 (17B). Invariants 2 and 21/22.
FIX (owed **before the first live probe at 18C**, which is an entry condition on that track, not a
caveat): route the probe child through the existing supervised launch-ticket path, or do not run
it. Recorded in the module docstring and in `run_probe`'s own docstring. Owner: 18B/18C.
Raised by: round-3 spec-audit MAJOR-3.

### U235 — OPEN: instruction-injection flags are out of scope of the permission guard, by decision

`grok --help` documents `--system-prompt-override` and `--rules`. Neither is in
`_FORBIDDEN_PROVIDER_ARGS` and neither should be: they are node-controlled untrusted INPUT (T2),
not permission widening, and conflating the two would make the guard's name inaccurate in the
other direction. 18A never emits either. FIX (owed): 18B's adapter contract treats provider config
(`AGENTS.md`-class files, rules files, system-prompt overrides) as untrusted input on the same
footing as the existing Codex handling. Pinned by
`test_instruction_injection_flags_are_deliberately_not_in_the_permission_list` so it stays a
decision rather than becoming a gap. Owner: 18B. Raised by: round-3 spec-audit MEDIUM-4.

### U236 — OPEN: `-Action status` makes authenticated vendor calls outside the live-operation gate

The live gate governs the probe — the only path that spends tokens. `-Action status` (the DEFAULT
action) invokes each CLI's `--version` and `models`, and `grok models` returns
`You are logged in with grok.com`: an authenticated call under the operator's subscription, gated
only by this tool's own deployment-profile air-gap switch, whose default is open. It is
operator-directed (§2/§6), token-free, and the sequence is already documented as "NOT purely
local" — but the asymmetry with the probe was implied away rather than stated.
FIX (owed, decision-shaped): either bring metadata calls under a named policy in 18B or record
permanently that metadata ≠ inference for gating purposes. Now stated in `live_probe_gate`.
Owner: 18B. Raised by: round-3 spec-audit MEDIUM-8.

### U237 — OPEN (documentation corrected; code owed): "extend `config/live_operation.json`" was an impossible instruction

Four artifacts told the operator that opening a new provider at 18C means extending
`config/live_operation.json`. `live_authorization._AUTHORIZED_PROVIDERS` is code-pinned to the
OP-6 pair and `_validate_providers` **raises** on any other id, so an operator who followed that
instruction would have got a `LiveAuthorizationError` from `load_live_authorization` — denying not
only grok/antigravity but `claude_code` and `openai_codex_cli` too, i.e. every live path in the
build. The failure direction is safe and invariant 1 is upheld (config cannot widen a code-pinned
scope); the *instruction* was wrong. CORRECTED IN 18A: the runner's printed gate reason, the
`live_probe_gate` docstring, the 18A evidence report, and the directive §17 clarification now say
the real mechanism — the operator's register row PLUS a scope extension in
`control_plane/profiles/live_authorization.py`. FIX (owed): that scope extension, with the OP-12
row as its authorizing basis, written in 18B so 18C's entry condition is achievable. NOTE: the
DECISION_REGISTER OP-12 row and directive §17's 18C line are append-only history and are NOT
edited; this row is their correction. Owner: 18B. Raised by: round-3 spec-audit MAJOR-2.

### U238 — OPEN: probe acceptance has two narrow holes that decide a LIVE verdict at 18C

Both found in round 3 and left to 18C on purpose — each changes acceptance semantics, and the
place to change them is the track that spends the call, with fresh review.
1. **Echo normalisation is whitespace+case only** (`_token_answered`). Verified refusals: verbatim,
   re-cased, re-wrapped, expanded-spacing, prefixed, doubled. Verified ACCEPTED and should not be:
   `Reply with exactly:GROK_PROVIDER_OK` (space deleted), `Reply with exactly - GROK_PROVIDER_OK`,
   quoted, letter-spaced. Round 2's claim that "any re-wrap, re-case or re-space" was caught
   slightly overstates it: whitespace *deletion* is a re-spacing and is not caught. FIX (owed):
   normalise by removing every non-alphanumeric character on both sides before subtraction.
2. **`extract_probe_text` falls back to the whole JSON document** when none of the six recognised
   response keys is present, so the token counts wherever it appears —
   `{"status":"done","debug":"GROK_PROVIDER_OK"}` is ACCEPTED. FIX (owed): the acceptance path
   should see a recognised response field or nothing.
Real-world risk in 18A is nil (nothing runs); at 18C both decide a live verdict. Owner: 18C.
Raised by: round-3 gate-validator A-3 / A-4.

### U239 — OPEN: the credential scrub's generic substring net still removes non-secrets

`_CREDENTIAL_KEY_SUBSTRINGS` includes bare `KEY` and `AUTH`, so `KEYBOARD_LAYOUT`, `MONKEY_*` and
`SSH_AUTH_SOCK` leave the child environment. Same class as N-1 (which deleted `GROK_SANDBOX`); the
enumerated `_PRESERVED_PROVIDER_CONFIG_KEYS` allowlist fixes the provider-prefixed cases but not
the generic rule. Harmless for these two CLIs on Windows, and the direction of error is safe.
FIX (owed): word-boundary matching, or extend the allowlist as real cases appear. Owner: 18B.
Raised by: round-3 gate-validator A-5.

### U240 — OPEN: an air-gapped probe refusal renders as a broken provider

`run_probe` reports `"executed": true` under an air-gap refusal and the runner prints only the
reason, which renders as `process outcome NOT_SPAWNABLE (spawn-error)` — a policy refusal reading
as a technical fault. `probe_status` was fixed for exactly this in round 2 (N-13) and the probe
path was not. Air-gapped `probe_status` also reports `command found: False` / `executable: (none)`
for a CLI that IS installed; the caveat covers it, the fields do not. FIX (owed): the refusal
carries its own outcome kind, distinct from a spawn error. Owner: 18B.
Raised by: round-3 gate-validator A-6.

### U241 — OPEN: two 18A acceptances have no durable fence beyond an evidence document

`-Action login -Provider gemini` starts the vendor TUI unsupervised (operator directive §5.2 —
`agy` has no login subcommand; invariant-2 tension, disclosed in the console and in-line), and the
Antigravity installer is remote code executed with no published checksum (§4.2, gated behind
`-InstallMissing`, announced as unverified-integrity before it runs). Both were accepted with
record in `PHASE18A_REVIEW_ROUNDS.md`, including the sentence that matters —
**neither may become the pattern for 18B panes**, which go through the existing supervised ConPTY
+ launch-ticket path (§9). Every other accepted item got a register row; these two did not, so the
fence lived only in a document nobody is required to read. FIX (owed): 18B's pane path enforces
supervision structurally; this row is the traceable statement of the constraint until it does.
Owner: 18B. Raised by: round-3 spec-audit MEDIUM-9.

### U242 — CORRECTION to U231: the identity-in-path count is at least ten, not four

U231 records the operator's OS account name appearing in tracked evidence "four times" — the count
in `phase18a_host_recon.json` (lines 19, 68, 188, 262). The tracked receipt
`PHASE18A_RUNNER_STATUS.txt` carries six more (14, 28, 75, 76, 86, 100), the round-3 receipt
carries its own, and `run_probe` records an unredacted argv whose `argv[0]` is the same resolved
path. An undercount in a row whose whole subject is what evidence discloses is a softening, even
an accidental one. U231's disposition is unchanged (operator directive §6 REQUIRES the resolved
path; the fix, if the operator wants it, is a home-directory placeholder applied everywhere or
nowhere). Owner: post-18. Raised by: round-3 spec-audit MINOR-12 / NIT-20.

### U243 — OPEN: two runner details that are inert rather than delivered

(a) `$env:SOVEREIGN_GROK_COMMAND` / `SOVEREIGN_ANTIGRAVITY_COMMAND` are exported on launch and
**nothing in the repository reads either name** — operator directive §15 says "if the app needs
them", and the app does not yet. Recorded as inert, not as a delivered capability; 18B either
consumes them or they go. (b) The runner accepts any Python 3, while the engine's
`RunResult` type alias is a runtime expression needing ≥3.10 — on 3.9 the engine dies at import
and the runner reports the generic "Recon engine produced no report" with exit 6: fail-closed but
misdiagnosed. FIX (owed): read the minimum from one place and say so. Owner: 18B.
Raised by: round-3 spec-audit MINOR-15 / MINOR-17.

### U244 — OPEN: `SOVEREIGN_DEPLOYMENT_PROFILE` is a tool-local switch with a workspace-wide name

The air-gap guard reads `SOVEREIGN_DEPLOYMENT_PROFILE`, which exists nowhere else in the
repository. The code is explicit that it is this tool's own opt-in switch and that its default is
open, and it validates the value through the canonical `DeploymentProfile` (unknown ⇒ fails
closed), so nothing is hidden. The name still implies a governance surface that does not exist,
which is how invented layers start (invariant 30). FIX (owed): either the loader owns a real
profile setting that every path reads, or the variable is renamed to something tool-local.
Owner: 18B. Raised by: round-3 spec-audit MINOR-18 (watch-item).

### U245 — OPEN: `_assert_no_forbidden` raises rather than refusing, on an operator-supplied value

An operator `-Model` or `-Prompt` whose value is exactly a forbidden token reaches
`_assert_no_forbidden` and produces an uncaught `ValueError` through `run_probe`/`main` — a
traceback and exit 6, where a governed refusal (exit 3, named reason) is the right answer. Very
narrow, fail-closed in direction. FIX (owed): catch at the probe boundary and report as a refusal.
Owner: 18B. Raised by: round-3 spec-audit NIT-21.

### U246 — OPEN: the Antigravity subscription's inventory contains two OTHER vendors' models

`agy models` on this host returns `claude-sonnet-4-6`, `claude-opus-4-6-thinking` and
`gpt-oss-120b-medium` alongside the Gemini slugs, and 18A's committed capture records all eleven
under `subscription_resource: google_antigravity_subscription`, `terminal_allowance: 1`. Recording
them is CORRECT 18A behaviour (operator directive §8: enumerate what the CLI offers, fabricate
nothing, hardcode nothing) and this row is not a defect claim. It is an unrecorded governance fact
with three consequences the next track owns: (a) I-21 accounting — Anthropic models are now
reachable through a *second* subscription resource while `claude_code` sits at allowance 2 (OP-6);
per-resource capping stays well-defined, but the cost and concurrency picture is not; (b) §14 UI
honesty — the picker will show `claude-sonnet-4-6` under the label "Gemini · Antigravity", and
"never print one provider's error text for another" is harder when one provider proxies another;
(c) I-SC1 — this is exactly the case where the capability descriptor, not the vendor name, must
carry the routing fact. FIX (owed): 18B decides descriptor/label/accounting; anything that changes
what the operator is charged for is operator-reserved. Owner: 18B.
Raised by: round-4 spec-audit finding 10.

### U247 — OPEN: `& npm` is unguarded, so a Node-less host gets the undocumented exit 1

Round-3's A-9 fix wrapped the Antigravity vendor-installer branch in `try/catch` (a throw becomes
"install command FAILED", exit 5). The grok branch (`run_frontier_providers.ps1`, `& npm install
-g @vibe-kit/grok-cli`, and `& npm start` on the launch path) did not get the same treatment.
Under `Set-StrictMode` + `$ErrorActionPreference='Stop'` a missing `npm` raises
`CommandNotFoundException` and terminates the script with exit **1**, which the documented table
does not carry. The scenario is not exotic — no Node is a very good reason for the grok CLI to be
missing, and `-Action install -InstallMissing -Provider grok` is exactly what the operator would
run next. The existing test shadows `npm` with a PowerShell function, so it cannot reach this.
FIX (owed): same `try/catch` shape as the Antigravity branch, plus `1 = unhandled PowerShell
terminating error (should not occur)` in `.NOTES`. Owner: 18B. Raised by: round-4 spec-audit
finding 7.

### U248 — OPEN (attaches to U232): `Invoke-LoginAction` has no `default` branch

`Invoke-LoginAction` announces "starting the provider's OWN authentication flow" *before*
dispatching on two literal provider ids, and — unlike `Invoke-InstallAction`, which has a default
returning exit 6 — has no default branch. A third id from the engine would print a claim that a
browser sign-in is starting, do nothing, and exit 0: a false statement plus a fail-open code.
Unreachable today (the `-Provider` parameter is a `ValidateSet` of `all|grok|gemini`), which is
why it is carried rather than blocking; it is U232's descriptor-vs-`switch` duplication turning
into a behaviour. FIX (owed): a `default` that fails closed, and the announcement moved inside the
matched branches. Owner: 18B. Raised by: round-4 spec-audit finding 8.

### U249 — OPEN: single-dash flag spellings pass `_assert_no_forbidden` untouched

`agy --help` is Go `flag`-package output — single- and double-dash spellings are interchangeable
on that CLI (`-p`, `-c`, `-i`, and `-h`/`--help` both listed). `_FORBIDDEN_PROVIDER_ARGS` and
`_MODE_FLAGS` are all double-dash, and the guard normalises `--flag=value` (round-3 N-9) but not
the leading dashes, so `-dangerously-skip-permissions` or `-mode accept-edits` would pass. 18A
exposure is nil: nothing in 18A emits either form and no operator-supplied value reaches a
position where `agy` parses it as a flag. The docstring's word "structurally" is nonetheless one
alias-form short of true, and 18B builds worker argv from model- and operator-supplied values
through this same function. FIX (owed): `lstrip("-")` both sides before comparison; extend the
`=`-bypass test with the single-dash cases. Owner: 18B. Raised by: round-4 spec-audit finding 11.

### U250 — OPEN: the widening denylist's residue, and an endpoint policy that holds on one surface only

Flags documented in the recorded capture that are in neither `_FORBIDDEN_PROVIDER_ARGS` nor U235:
grok `--agent`, `--agent-profile`, `--system-prompt`, `--worktree`, `--worktree-ref`,
`--xai-api-base-url`, `--cli-chat-proxy-base-url`, `--grok-ws-url`, `--grok-ws-origin`; agy
`--add-dir`, `--agent`, `--project`, `--new-project`. Two of these are more than residue:
(a) `--agent`/`--agent-profile` widen *who acts*, which is the module's own stated rationale for
guarding `--agents`; (b) the four endpoint overrides are the argv twins of `XAI_API_BASE_URL`,
which the env scrub DOES remove — so the module's claim that "no endpoint override can redirect a
call" is true of the environment surface and stated as if true of both. Non-blocking because this
is an *emission* guard over argv this module builds, and 18A emits none of them; the list no
longer claims exhaustiveness (round-3 fix). FIX (owed): add the endpoint and agent-identity flags
so the two policies agree, or state the boundary as U235 does for instruction injection. Note that
`--worktree`/`--project` may be legitimately needed by 18B's isolation path — that decision is
18B's, not a blanket ban. Owner: 18B. Raised by: round-4 spec-audit finding 12 / gate-validator
finding 2.

### U251 — OPEN: `probe_status` calls `models` after judging the version unsupported

The `UNSUPPORTED_VERSION` branch sets the state and then falls through to
`_guarded_run(run, [exe, *spec.models_command])` — an authenticated vendor call (U236) made
against a CLI the function has already declared unverifiable. Nothing fails open (the final-state
ordering refuses to upgrade the verdict), and gathering the inventory anyway is defensible
evidence-collection. Recorded so the choice is explicit rather than implicit. Owner: 18B.
Raised by: round-4 spec-audit finding 13.

### U252 — OPEN: three install-path fences that no test can falsify

Round-4 gate-validator, mutation-testing the install path: (a) exit **4** — the branch that makes
the strongest claim the install path can make, "installed" — has no positive test; the validator
ran it by hand (`EXIT CODE: 4`, correct text) and it is fenced only indirectly, via the
`$installVerifiable` mutation landing a different case there. (b) Deleting
`$global:LASTEXITCODE = 0` before the vendor installer changes nothing under test; it fails closed
in production (a stale nonzero reports a false FAILURE, never a false success) but it is
unfalsifiable as written. (c) Two `_guarded_run` call sites in `probe_status` are unreachable
under an air-gapped profile because the function early-returns first, so their mutations survive:
the enforcement on that path is the early return, not the choke point the docstring credits.
FIX (owed): one `@needs_powershell` test asserting exit 4 with a zero-exit `npm` stub and an
unresolvable command; a test planting a nonzero `$LASTEXITCODE`; and either drop the early return
or say in the docstring which mechanism actually refuses. Owner: 18B.
Raised by: round-4 gate-validator findings 4, 5, 6.

### U253 — OPEN: `ruff` is not installed on this host, so CLAUDE.md's "ruff-clean" bar is unverified

`py -3.12 -m ruff --version` → `No module named ruff`. CLAUDE.md sets a ruff-clean bar for Python;
for the 18A files that bar is **unverified**, not met and not failed. `pyflakes` over all three
18A Python files is clean. Pre-existing and repo-wide, not an 18A regression — recorded now
because it was carried as an unnumbered "F10" through three review rounds. FIX (owed): install
ruff on the host and run it repo-wide, or state the bar as aspirational in CLAUDE.md.
Owner: post-18. Raised by: rounds 1–4 spec-audit F10 / round-4 gate-validator finding 9.


## Phase 18B `.scope` (OP-12) — live scope, per-provider allowance, node vocabulary

Opened 2026-08-01 by the 18B `.scope` work unit and its gate-validator + spec-auditor round.
Full findings and dispositions: `docs/evidence/PHASE18B_SCOPE_CHECKPOINT.md`.

### U227 — STILL OPEN, owner moves to **OPERATOR** (was "18B entry"); now FENCED in code

Unchanged in substance: `schemas/node.schema.json`'s `adapter` enum is frozen (Phase-0 manifest) AND
written into Architecture Plan §9.1, and has no member for `grok_build` or `google_antigravity`.
18B `.scope` did NOT resolve it — it proceeded at the product layer and recorded the decision as
**D-P18-1**. What changed is that the claim which the decision leans on is now enforced rather than
asserted: `control_plane/nodes/registry.py:register` refuses an `adapter` that is neither a node@1.0
enum member nor a listed exemption (`ADAPTER_EXEMPTIONS`, currently `{ollama_local}` only), and logs
the refusal. Neither OP-12 provider is exempted. The spec-auditor named this as the honest option the
first cut had passed over: *"until that guard exists, 'no schema-valid node RECORD can name this
provider' is a sentence, not a fence — and it is the sentence the entire U227 judgment rests on."*
**Consequence for the track, stated plainly: 18C cannot spawn a supervised pane as a registered
Sovereign node for either provider until the operator rules**, because the node event log is
append-only (invariant 12) and a record written under an unadmitted adapter could never be
un-written. The three candidate resolutions are unchanged. Owner: OPERATOR.

### U254 — OPEN: `ollama_local` is a product-layer adapter id that no schema admits

The frozen enum spells the local adapter `ollama_direct`; every product path has used `ollama_local`
since Phase 15E (`adapters/local/ollama_session.py`, `control_plane/nodes/pane_picker.py`,
`node_runtime/supervisor/{pane_node_spawn,worker_pane_spawn}.py`). This was never recorded, and 18B
`.scope` cited it as the precedent for proceeding with the OP-12 ids — drawing authority from an
unrecorded defect, which both reviewers flagged (the first cut of that comment even cited "U254"
before this row existed, spec-audit MEDIUM-1 / validator MF-1). Recording it now, with the honest
caveats: the precedent is SMALLER IN KIND (a local, credential-free, un-counted node type versus two
subscription-backed frontier providers that hold I-X3 leases and the operator's money), and citing a
pre-existing deviation as licence for a new one is a drift pattern in its own right. `ollama_local`
is the sole member of `ADAPTER_EXEMPTIONS`, so it is now grandfathered explicitly instead of
tolerated silently. FIX (owed): fold it into the operator's U227 ruling — either the amendment names
it too, or the local path is renamed to `ollama_direct`. Owner: operator (with U227).

### U255 — OPEN: the status bar's display ceiling is a single global number

`terminal/statusbar/statusbar-model.js` `SUBSCRIPTION_CAP = 2` is the display ceiling for any row the
governor gave no allowance for. It is correct for the OP-6 pair and would OVERSTATE both OP-12
subscriptions (real cap 1) the moment the picker sub-step adds them to `LIVE_PROVIDERS` — in exactly
the surface operator directive §14 governs. Not reachable today (the pin keeps the bar at the two
selectable providers, and the feed now carries `allowance_by_provider` beside the global number).
FIX (owed **before** the picker sub-step wires either provider): a per-provider display ceiling
sourced from the feed. Owner: 18B `.picker`. Raised by: gate-validator MED-3.

### U256 — OPEN: `provider_registration` can now be forged by editing one hand-written literal

18B `.scope` re-based the recon engine's second gating source from the frozen node@1.0 enum (a
manifest-pinned artifact that could not be edited without `FREEZE DRIFT DETECTED`) to
`pane_picker.registered_providers()` (ordinary repo code). The move is correct — the enum check could
never pass and never will, so it masked the actionable cause — but the replacement is weaker
evidence: adding an id to the picker's provider table makes the diagnostic answer REGISTERED whether
or not anything can be spawned. Mitigated in-unit by deriving BOTH accessors and the rendered group
list from one `_PROVIDER_TABLE`, so the picker cannot claim a provider it does not render. FIX
(owed): intersect with the `pane_node_spawn` dispatch table, which is what "can actually be spawned"
means. Owner: 18B `.picker`. Raised by: gate-validator MED-1 / spec-audit MEDIUM-6.

### U257 — OPEN: pre-OP-12 subscription refs are still free-form

`assert_resource_binding` binds ref↔provider for the two OPERATOR-NAMED resources only. The older
refs are free-form by long standing (`sub-anthropic`, `sub-anthropic-01`, `sub-claude_code` all
appear in tracked code and fixtures), so the U76 two-bucket hazard remains open for the OP-6 pair —
narrowed only by the convention that callers use `canonical_subscription_ref`. Tightening it is a
separate change with its own blast radius. FIX (owed): one canonical ref per provider, enforced.
Owner: post-18. Raised by: spec-audit MEDIUM-3.

### U234 — NARROWED and now ENFORCED (was: "owed before the first live probe at 18C")

The row stands, and its status changed in a way worth recording. Through 18A the unsupervised probe
path was inert *because the live gate could never open* — neither provider id was in any code-pinned
scope. 18B `.scope` removed that impossibility (which is precisely what U237 needed), so for the
length of one commit an operator config was the only thing between `-Action probe` and a bare
`subprocess.run` of a frontier CLI with no node identity, no I-X3 lease and no teardown accounting.
The spec-auditor caught it as MAJOR-2. The entry condition is now enforced in code:
`_SUPERVISED_PROBE_PATH = False` makes `run_probe` refuse AFTER an allowed gate, with its own
`refused_by: "supervision"` outcome (distinct from a gate denial and from U240's spawn-error
confusion), pinned by a test that asserts a gate-allowed probe still spawns nothing. The flag flips
only in the commit that routes the child through the supervised launch-ticket path. Owner: 18B/18C.

### U258 — OPEN: four `.example`-adjacent surfaces were fixed only because a test now executes them

The published `config/live_operation.example.json` was, for one commit, an instruction that broke the
thing it configured: `tools/live/emit_subscription_status.py` registered every scoped provider at the
GLOBAL allowance, the governor refused 2 for a 1-terminal subscription, the emitter exited nonzero,
and the shell degraded the WHOLE status bar to the em-dash — re-opening the "concurrency count
unavailable (fail-closed)" symptom OP-10/16D exists to have fixed, for claude and codex too. Found
independently by both reviewers (validator MF-2, spec-audit MAJOR-1). Fixed, and a test now loads the
published file VERBATIM and asserts a readable feed. The sweep that followed found four more live
emitters and one shell path passing the global number (`emit_worker_launch`, `emit_conductor_launch`
×2, `emit_conductor_dispatch`, `probe_conductor_model`, `apps/desktop/main.js`); all now use the
per-provider allowance. Recorded as a standing rule rather than a closed defect: **any surface that
renders or registers an allowance must read it per provider.** Owner: 18B `.picker` to hold the line.

### U235 — CLOSED at 18B `.adapter` (was: instruction-injection flags out of the permission guard)

The decision is unchanged and the owed half is built. `--system-prompt-override`, its compat alias
`--system-prompt`, and `--rules` remain OUT of `FORBIDDEN_PROVIDER_ARGS` — they are node-controlled
untrusted INPUT (T2), not permission widening, and conflating them would make that guard's name
inaccurate in the other direction. They now have their own guard,
`provider_cli_common.assert_no_untrusted_instruction_args`, named for what it does, and both OP-12
adapters call it from `build_command` on the flags they emit. Fenced, not asserted: deleting either
guard call from `FrontierProviderCliBackend._guard` turns the suite RED (proved by mutation, this
unit) — the first cut of this work had both calls present and NEITHER fenced, which the
gate-validator caught by deleting them and watching 1803 tests pass. Closed by: 18B `.adapter`.

### U249 — CLOSED at 18B `.adapter` (was: single-dash flag spellings pass `_assert_no_forbidden`)

`_normalise_flag` strips leading dashes on both sides before comparison and `_flag_pairs` splits
`--flag=value`, so `-dangerously-skip-permissions`, `-mode accept-edits` and `-mode=accept-edits`
are refused exactly like their double-dash twins. Mutation-proved red. One consequence the fix
surfaced and the same unit repaired: the 18A probe builders guarded AFTER appending the prompt, so
dash-normalisation made an operator `-Prompt agents` collide with `--agents` and the probe refused
its own benign prompt. Both builders now guard the flags and then append, as the adapters do
(gate-validator finding 8). Closed by: 18B `.adapter`.

### U250 — CLOSED at 18B `.adapter` (was: the widening denylist's residue; endpoint policy on one surface)

The two policies agree now. Added to `FORBIDDEN_PROVIDER_ARGS`, every one of them present in the
recorded capture: the endpoint overrides `--xai-api-base-url`, `--cli-chat-proxy-base-url`,
`--grok-ws-url`, `--grok-ws-origin` (argv twins of the scrubbed `XAI_API_BASE_URL`) and
`--leader-socket` (which points the agent at an arbitrary leader process rather than the child this
build spawns); the identity flags `--agent` and `--agent-profile`; `--reauth`, which starts an
authentication flow inside a headless child when authentication is an explicit operator action; and
`--worktree` / `--worktree-ref` / `--new-project`, which create git or project state behind the
supervisor that is supposed to own it. NOT banned, decided rather than left ambiguous: `--cwd` and
`--add-dir` bind a workspace and this build emits them itself. `--project` is also unbanned but for
a different reason — see U266. Closed by: 18B `.adapter`.

### U259 — OPEN: provider config this build reads but cannot pin (T2 residue)

Both CLIs read configuration the operator's tree or home directory may contain (`~/.grok/config.toml`,
agy's project config, rules files). What a flag on the surface the adapter uses can pin, it pins
explicitly — permission mode, model, workspace, and `--no-memory`. What no flag on that surface can
override is residue and is recorded rather than claimed away: MCP servers and hooks declared in host
config, and plugin scopes already installed. Same class as the Codex adapter's U32. FIX (owed):
measure the real precedence at 18C on live evidence, and decide then whether a relocated config dir
is possible without severing the host OAuth the §2.2 path depends on. Owner: 18C. Raised by: 18B
`.adapter` self-check; the row exists because both reviewers found the code CITING it before it was
written (validator BLOCKING-1 / spec-audit MAJOR-1) — a residue recorded only in the docstring that
says it is recorded is an invisible gap wearing a record's number.

### U260 — OPEN: the OP-12 adapters ship a reasoning role only, and a coding role has no honest form yet

Neither provider gets a coding worker. A coding role needs write access, and the only ways to express
it are an auto-approving permission mode (`acceptEdits`/`auto`/`dontAsk` — exactly what operator
directive §11 forbids) or a sandbox profile value neither CLI documents (`grok --sandbox <PROFILE>`
enumerates none; `agy --sandbox` says only "terminal restrictions"). Inventing one is the fabrication
this build refuses, so `FrontierProviderCliBackend` raises on `role="coding"` with the reason in the
message. Directive §11's own description of initial provider behaviour — read assigned context,
reason, respond, publish CANDIDATE, request protected actions through existing mechanisms — IS the
reasoning role, so this is the specified starting point rather than a shortfall against it. FIX
(owed): revisit at/after 18C on live evidence of what `--sandbox` actually restricts. Owner: 18C.

### U261 — OPEN: `agy --sandbox` is not emitted, because nothing says what it restricts

The flag exists; its whole documented meaning is "Run in a sandbox with terminal restrictions
enabled". 18A recorded that an unverified containment claim is worse than none, and that holds for
the adapter: enabling a flag whose behaviour this build cannot describe would put an unfalsifiable
safety claim into the evidence. Same for `grok --sandbox <PROFILE>`, whose help enumerates no values
(and whose env form `GROK_SANDBOX` is the one variable the credential scrub deliberately preserves).
FIX (owed): observe the real effect at 18C and either emit it with a described effect or record why
not. Owner: 18C.

### U262 — OPEN: `grok agent stdio` (ACP) is not used, and the reason is a repository fact

Operator directive §10 permits the ACP transport "only if the repository already contains a fitting
client/JSON-RPC transport — do not implement a new general ACP framework unless it is demonstrably
the smallest correct integration". It does not; the headless integration therefore uses the CLI's
documented single-turn `-p/--single` mode with `--output-format json`. Recorded because "we did not
use the transport the directive mentioned" is a decision an auditor should find written down, not
infer from absence. Owner: 18C/`.picker` (which may want `--output-format streaming-json` for a live
pane and would face the same question). Raised by: 18B `.adapter`.

### U263 — OPEN: four refused flags are on neither captured CLI surface

`--yolo`, `--dangerously-bypass-approvals-and-sandbox`, `--api-key` and `--with-api-key` are in
`FORBIDDEN_PROVIDER_ARGS` and appear nowhere in `docs/evidence/live/phase18a_host_recon.json`. They
are Claude-Code/Codex spellings carried over from 18A. Refusing a flag a CLI does not have costs
nothing; the defect was the sentence around them, which claimed every flag in the list "was read off
THIS host's captured help, never from memory" — the exact direction operator directive §2 exists to
prevent, found by both reviewers. They are now DECLARED in `CAPTURE_ABSENT_SUPERSET_ARGS`, and a test
reads the capture and requires every OTHER entry to appear in it, so adding a remembered flag without
evidence goes red. Kept rather than removed because a superset in the fail-closed direction is worth
more than a tidy list. Owner: 18B (holds); revisit if either CLI adds one for real.

### U264 — OPEN: a host proxy remains an environment route the scrub does not close

The credential scrub now also drops `NODE_OPTIONS` (which can inject a `--require` module into an
npm-installed Node CLI — and `grok` is installed with `npm install -g`) and `NODE_EXTRA_CA_CERTS`
(which can make an interception proxy's certificate trusted); neither name carried a prefix or
substring the nets caught. `HTTP_PROXY`/`HTTPS_PROXY` are deliberately NOT scrubbed: removing an
operator's proxy breaks the CLI on a network that requires one. So a host-level proxy is still an
environment route this build does not close, and the claim in the code is narrowed to say so instead
of asserting "the subscription path is the only one left". Note for fairness: that sentence was
inherited from `adapters/frontier/codex.py`, which still carries it. FIX (owed): decide whether the
proxy variables should be operator-visible on the launch surface rather than silently inherited.
Owner: post-18. Raised by: spec-audit MAJOR-2.

### U265 — CLOSED-BY-NARROWING at 18B `.adapter`: four config-dir pointers left the scrub allowlist

`GROK_CONFIG_DIR`, `GROK_HOME`, `ANTIGRAVITY_HOME` and `ANTIGRAVITY_CONFIG_DIR` were exempted from
the fail-closed credential classifier as "documented CONFIG pointers". Nothing in the capture
documents them — the exemption was an analogy to `codex.py`'s `CODEX_HOME`, and the analogy does not
hold: `CODEX_HOME` survives PASSIVELY (its name carries no marker the nets catch), whereas these four
were actively lifted over the classifier, on the config/auth-directory surface the same module calls
untrusted. They are scrubbed again. `GROK_SANDBOX` is the sole remaining member and the only one with
capture evidence (`[env: GROK_SANDBOX=]`), and the allowlist's membership is now pinned by a test
rather than merely honoured by one. Raised by: spec-audit MEDIUM-2.

### U266 — OPEN: `--project` is unbanned for a different reason than the flags it was grouped with

`--cwd` and `--add-dir` are unbanned because they BIND a workspace and this build emits them itself.
`--project` was written into the same sentence, but the capture describes it as "Project ID for the
current CLI session" — a session selector, not a directory bind — and nothing here emits it. It stays
unbanned because U250 left the call to 18B and banning a selector nothing emits is noise, but the
warrant recorded for it was false of it, on the one surface §2 makes authoritative. Warrant corrected
and split; the "nothing emits it" half is pinned by a test. FIX (owed): decide at `.picker`, when an
Antigravity pane may legitimately want a project, whether it becomes an operator-visible choice.
Owner: 18B `.picker`. Raised by: spec-audit MEDIUM-3 / gate-validator finding 7.

### U267 — OPEN: grok leader mode is config-decided and cannot be pinned from the surface this build uses

The capture records `--leader` as "Connect to a shared leader process instead of starting a new
agent … Defaults to `[cli] use_leader` in config.toml", and `--no-leader` exists ONLY on the
`grok agent` surface — not on the top-level `grok -p` surface the headless adapter uses. A node- or
host-controlled config can therefore route the work into a shared leader process that is not the
child this build spawns, that outlives its timeout, holds no I-X3 lease, and appears in no teardown
accounting. `--leader-socket` IS refused (U250), so an arbitrary socket cannot be named, but the
config default is not something an argv on this surface can override. Not claimed away: the T2
paragraph's pinning claim now carries the qualifier "on the surface this build uses". FIX (owed):
either move the headless call to `grok agent` (where `--no-leader` exists) after checking its output
shape, or account for leader processes in teardown. Owner: 18C. Raised by: spec-audit MAJOR-3.

### U268 — OPEN: the OP-12 backends refuse to spawn until a supervised launch path exists

`FrontierProviderCliBackend.generate` raises while `_LIVE_SPAWN_PATH_WIRED` is False — before the
call counter, so a refusal can never be mistaken for a spent attempt. The row exists because the
first cut claimed `generate` was "reachable only from a governed live path" on the strength of U227:
true in fact, but `NodeRegistry.register` gates node RECORDS, not backend construction, and
`AdapterContext.spawned_by_supervisor` is a caller-set bool — so the protection was the absence of a
caller, which is not a mechanism. This is the same fence `frontier_provider_recon._SUPERVISED_PROBE_PATH`
already is for the 18A probe. The flag flips in the commit that routes these children through the
supervised launch-ticket path with an I-X3 lease on the provider's own subscription — never before,
never by config. Owner: 18B `.picker` / 18C. Raised by: spec-audit MEDIUM-5.

### U269 — OPEN: two probe orchestrations over one set of parsers

`provider_cli_common.probe_provider_cli` (product-layer, picker-facing) and
`frontier_provider_recon.probe_status` (operator-facing, carries diagnostics/registration/lease)
sequence the same metadata calls. They share the parsers, the classifier and the auth vocabulary —
which is where a divergence would actually hurt — but the sequencing is written twice, and the
adapter-side probe currently has no product consumer (only tests). The "one policy, not two copies"
claim is narrowed in the code to say exactly this. FIX (owed): consolidate when `.picker` gives the
adapter-side probe a real consumer, or record why two shapes are right. Owner: 18B `.picker`. Raised
by: gate-validator finding 6.

### U270 — OPEN: grok's login line is not guaranteed on every `models` invocation

Observed once during 18B `.adapter` self-check: a `grok models` call returned exit 0 with a parseable
inventory but WITHOUT the "You are logged in with <service>." line, so the status layer reported
`UNVERIFIED` where three consecutive later invocations in the same session reported `AUTHENTICATED`.
Not reproduced; recorded with that caveat rather than as a characterised behaviour. The direction is
safe — silence is UNVERIFIED, never AUTHENTICATED, which is the fail-closed answer 18A chose
deliberately — but it has a consequence for the sub-step that renders it: **the picker must not read
UNVERIFIED as "signed out"**, because it can mean "this invocation did not say". Owner: 18B
`.picker`. Raised by: 18B `.adapter` self-check.


### U255 - CLOSED at 18B `.picker` (was: the status bar's display ceiling is a single global number)

Closed in the sub-step that made it reachable, which is what the row asked for. `terminal/statusbar/
statusbar-model.js` now carries `PROVIDER_ALLOWANCE` (claude 2, codex 2, grok 1, antigravity 1) and
`capForProvider`, applied to every row the governor gave no allowance for - idle rows, unknown
(em-dash) rows, and malformed-record rows alike. The global `SUBSCRIPTION_CAP` survives only as the
fallback for a provider with no recorded cap. Pinned to the Python authority
(`live_authorization._PROVIDER_TERMINAL_CAP`, read through the public `provider_terminal_cap`) by
`tests/unit/test_statusbar_constants_pinned.py`, so an operator amendment that changes an allowance
cannot leave the bar overstating it. Proved in the running shell, not only headlessly: the
in-Electron receipt records `grok_build 0/1`, `google_antigravity 0/1`, `claude_code 0/2`,
`openai_codex_cli 0/2`. Closed by: 18B `.picker`.

### U256 - CLOSED at 18B `.picker` (was: `provider_registration` can be forged by editing one literal)

`pane_picker.registered_providers()` is now the INTERSECTION of the picker's provider table with what
the pane authorizer will actually dispatch (`worker_pane_spawn.FRONTIER_PANE_ADAPTERS` plus the local
adapter id, both read from the authorizer). Adding an id to the table no longer makes the recon
engine answer REGISTERED: it must also be a provider a selection can carry into a governed launch
path. `registered_frontier_providers()` derives from the same set, so the status bar cannot render an
n/allowance counter for a provider no pane can hold. One consequence surfaced immediately and was
fixed with it: the recon report's `lease_state` said the bare word "registered", which a reader could
hear as "a terminal is held" - it now states that this diagnostic reads no lease ledger and holds no
terminal. Closed by: 18B `.picker`.

### U269 - NARROWED at 18B `.picker` (was: two probe orchestrations over one set of parsers)

The row's actionable half is discharged: `provider_cli_common.probe_provider_cli` now HAS a product
consumer - `tools/live/enumerate_pane_picker` calls `probe_grok`/`probe_antigravity` to build the
picker's option set, which is the shell's own path. The remaining half stands and is deliberately
left open: two orchestrations still sequence the same metadata calls (the operator-facing recon adds
diagnostics, registration and lease lines the picker has no use for). They share the parsers, the
classifier and the auth vocabulary, which is where a divergence would hurt. FIX (owed): consolidate
or record why two shapes are right. Owner: post-18. Raised by: gate-validator finding 6 (`.adapter`).

### U271 - OPEN: the picker's option set is enumerated on every open, uncached, at real host cost

D-P18-5 records the decision; this records what it costs and what has not been measured. Opening the
picker now spawns up to four bounded provider metadata calls (6 s each) in addition to the Ollama
probe, inside the shell's 20 s enumeration budget. On the 2026-08-01 in-Electron run the whole
enumeration completed well inside it (receipt: picker rendered 61 options in 5 groups), but that is
ONE observation on a warm host with both CLIs installed, and the cold or degraded case is unmeasured.
If a provider CLI hangs, the operator sees the picker take up to its budget and then render the other
providers with that one greyed - honest, but slow. FIX (owed): measure the cold path, and revisit
caching only under the directive's own condition (§8: cache only if the architecture already does).
Owner: 18C / post-18. Raised by: 18B `.picker` self-review.

### U272 - OPEN: `verified: true` now means three different provenances in one field

The picker's `verified` flag reaches the pane chrome as `model_verified` and is rendered as a badge.
It now carries three distinct provenances: a live-smoke-probed claude slug, a local Ollama tag, and
(new) an id read from a frontier CLI's own `models` listing. All three are "the runtime confirmed it
accepts this id" and none is "a live session answered on it", which is what an operator may well read
a verified badge to mean. The notes distinguish them; the FIELD does not. Direction is safe (nothing
was upgraded - the OP-12 options could have claimed less but not more), and no code branches on the
distinction today. FIX (owed): either a provenance enum beside the flag, or a chrome tooltip that
shows the note. Owner: 18C (the sub-step that first renders a LIVE badge for these providers). Raised
by: 18B `.picker` self-review.

### U273 - OPEN: the shell can now validate a Grok/Antigravity ticket it has never executed

`apps/desktop/picker/launch-source.js` learned both adapters (executable allowlist, frontier set,
canonical subscription refs, frontier-token denial for local tickets) so a well-formed OP-12 ticket
validates instead of being refused as an unknown adapter. What has NOT been exercised end-to-end is
the spawn itself: no Grok or Antigravity ConPTY session has ever been started by this build, because
the live switch denies both providers and 18C owns the first live pane. The in-Electron receipt
proves the refusal path in the wired UI, which is the honest half available today. FIX (owed): the
first governed OP-12 pane, its teardown, and lease return to zero. Owner: 18C. Raised by: 18B
`.picker` self-review.

### U273 — AMENDED at 18B `.picker` review round 1: the four validator facts were also UNTESTED

The row said the shell "learned both adapters" and listed the four changes. What it did not say — and
what the gate-validator found — is that `apps/desktop/test/worker-launch-source.test.js` contained no
occurrence of `grok`, `agy` or `antigravity` at all, so each of the four could be reverted with all
640 desktop tests green. One of them is fail-open when reverted: without `grok|agy` in
`FRONTIER_TOKENS`, a LOCAL ticket may name a frontier CLI anywhere in its argv, i.e. a `grok` session
running as an uncounted, lease-free local terminal (invariant 21 / §12). The OP-12 arm added at round
1 covers all four (a well-formed ticket accepted; the derived subscription ref refused; the other
provider's ref refused; a cross-provider binary refused, executable and argv[0] separately; a
relabelled-local frontier ticket refused; six wrapped forms of a local ticket naming grok/agy
refused, while `magyar-7b` still passes). Each goes red on the single-line revert — measured, not
assumed. The row's own FIX line (the first governed OP-12 pane) is unchanged and still owned by 18C.
Raised by: gate-validator BLOCKING-2 / MAJOR-2.

### U246 — DECIDED at 18B `.picker` review round 1 (was: OPEN, owner 18B)

The row asked 18B to decide descriptor / label / accounting for the three non-Google models the
Antigravity subscription lists. Decision, recorded rather than left implicit — the `.picker` sub-step
made them operator-VISIBLE (the receipt shows `claude-sonnet-4-6`, `claude-opus-4-6-thinking` and
`gpt-oss-120b-medium` rendered under the label "Gemini · Antigravity") and then said nothing about
them, which the spec-auditor caught:

  * **Accounting: unchanged, and that is the point.** A model reached through the Antigravity CLI is
    leased against `google_antigravity_subscription` (allowance 1), because that is the subscription
    the session actually consumes. It is NOT counted against `claude_code`'s allowance 2: the
    operator holds two distinct subscriptions, and a session on one is not a session on the other.
    Per-resource capping stays well-defined; nothing is merged (operator directive §12).
  * **Label: the group stays "Gemini · Antigravity" and the option keeps the id the CLI published.**
    Renaming `claude-sonnet-4-6` to conceal who serves it would be the §14 defect in the other
    direction. What was missing is the DISCLOSURE, and that is what changed: an option whose id is
    not this provider's own model line now states in its note that it is served THROUGH this
    subscription and counted against it.
  * **Descriptor (I-SC1): unchanged.** Routing reads the capability descriptor, not the vendor name;
    a proxied model is just a roster entry under a provider adapter.
  * **Cost: untouched and operator-reserved.** Nothing here changes what the operator is charged for;
    this build has made no live call to either provider.

Owner: closed. Raised by: round-4 spec-audit finding 10; decided at `.picker` review round 1
(spec-audit Md-3).

### U268 — RE-DISPOSITIONED at 18B `.picker` review round 1 (still OPEN, owner 18C alone)

`_LIVE_SPAWN_PATH_WIRED` stayed False through `.picker`, which is correct — but the row's own sentence
("the flag flips in the commit that routes these children through the supervised launch path") became
ambiguous the moment `.picker` wired the supervised INTERACTIVE pane path, which never calls
`generate`. Two paths now exist and the flag guards ONE: the HEADLESS worker path. Restated: it flips
in the commit that wires the headless supervised path with an I-X3 lease on the provider's own
subscription — never before, never by config, and never because the interactive path exists. The
`provider_cli_common` docstring carried the same ambiguity and was corrected with this row.
Owner: 18C. Raised by: spec-audit N-3 / Md-3.

### U270 — NARROWED at 18B `.picker` (the consequence it named is discharged)

The observation stands and is NOT closed: one `grok models` call returned exit 0 with a parseable
inventory and no login line, unreproduced. What the row required of `.picker` is done and pinned:
`authenticated is None` blocks NOTHING (`_op12_options` greys only on an observed `AUTH_REQUIRED`),
and the option note says the auth state is UNVERIFIED here rather than implying either answer. A
mutation that makes `None` grey the provider goes red. The unreproduced CLI behaviour itself remains
open for whoever sees it again. Owner: 18C (first live session). Raised by: 18B `.adapter`
self-check; narrowed at `.picker` review round 1 (spec-audit Md-3 — the closure row was claimed in
the checkpoint and never written here).

### U106 — WIDENED at 18B `.picker` (still OPEN): two more adapters in the shell's binary map

The row records that `apps/desktop/picker/launch-source.js` holds a second source of truth for each
adapter's binary name. `.picker` grew that map from three entries to five — `grok_build` → `grok`,
`google_antigravity` → `agy` — without noting it here. Noted now. The neighbouring
`ADAPTER_SUBSCRIPTION_REF` map IS pinned cross-language
(`tests/unit/test_statusbar_constants_pinned.py`); `ADAPTER_EXECUTABLE` is not, and the checkpoint's
claim that "both" were pinned was wrong (corrected by an appended note there). Since round 1 the two
new entries are at least exercised by the desktop suite's OP-12 arm — a cross-provider executable is
refused — but that tests the RULE, not the map's agreement with `adapters.detect`. FIX (owed,
unchanged): pin the executable map to the Python authority, or derive it. Owner: post-18. Raised by:
14A; widened at `.picker` review round 1 (spec-audit Md-2).

### U227 — clarified at 18B `.picker` review round 1 (disposition unchanged: OPEN, owner OPERATOR)

One sentence, because the record could be read as claiming more protection than exists. The registry
fence gates node RECORDS: `NodeRegistry.register` refuses both adapter ids, so no Sovereign node
record can exist for either provider until the operator rules. It does NOT gate the pane launch path
— `emit_worker_launch` mints an identity through `worker_pane_spawn.worker_identity` and calls no
`register`. What actually stops an 18C pane today is the live-authorization gate plus the I-X3 lease,
both fail-closed, both controlled by the operator through the never-committed live switch. 18C must
not read "the registry refuses it" as the reason its pane did not spawn. Raised by: spec-audit Md-5.

### U274 — OPEN: a CRLF working copy is invisible to `git status` and breaks the mutation harnesses

`.gitattributes` pins `* text=auto eol=lf`, so git normalises before comparing: a tool that rewrites a
tracked file with CRLF leaves `git status` clean while the bytes on disk differ from the committed
blob. That happened to `apps/desktop/main.js` in the `.picker` work commit, with two effects — the
U186 pin test went red (the pin is a hash of the WORKTREE file), and
`tools/mutation/pane_input_bypass_mutations.js` could not run at all, because every splice anchor in
it is written with `\n` and all forty "disappeared" from a CRLF file. The direction is safe (the
harness refuses rather than mutating blind) but the diagnosis cost part of a review round, and 43
tracked files currently carry CRLF in the worktree for the same reason. FIX (owed): a cheap check
comparing each text file's worktree bytes to its blob and reporting EOL-only divergence, so this is
found by a test rather than by a broken harness. Owner: post-18. Raised by: 18B `.picker` review
round 1.

### U275 — OPEN: a whole class of surface had no test until the round that looked for it

Recorded as a pattern, not a defect. At `.picker` the gate-validator found that the shell-side ticket
validator's four OP-12 facts, the emitter's entire OP-12 branch, and both per-provider executable
resolvers could each be reverted with the FULL 1858-test suite green — six of them mutated at once
still passed. All are covered now, each re-run red at review round 1. The pattern worth carrying: this
sub-step's Python core was mutation-tested by construction, while its SHELL surface and its
cross-module dispatch tables were tested only through whatever code happened to call them, and a
dispatch table's dangerous failure is a WRONG entry, not a missing one (the missing one raises).
FIX (owed): when a sub-step adds a provider to a dispatch table, the "wrong entry" test lands with it.
Owner: 18C onward. Raised by: 18B `.picker` gate-validator BLOCKING-2/3/4.

### U276 — CLOSED at the 18B close: the launch path enumerated every provider, including for a purely local pane

`tools/live/emit_worker_launch._assert_option_offered` verifies a caller's selection against the host's
own enumeration (fail closed), and until this gate it built that enumeration by calling
`build_host_picker()` bare — which probes BOTH OP-12 CLIs unconditionally. So selecting a local
`qwen3:8b` pane, with no subscription, no credential and no frontier involvement of any kind, emitted a
`grok --version` + `grok models` metadata request to grok.com under the operator's SuperGrok session
before the pane opened. D-P18-7 recorded that cost honestly for the PICKER drawer, where the operator
has asked to see every provider; the launch path is a second site and was never disclosed, and on a
local selection the call is not merely undisclosed but UNOWED (invariant 19 — locality is per node;
invariant 20 — an offline-profile pane should not reach the network to be verified). FIX (landed):
`_host_offered_options` now takes the selection's provider and uses the host-free `no_op12_probes()`
stand-in unless the selection is itself for an OP-12 provider; the OP-12 groups then render as
not-probed, which cannot affect the match because an option's identity carries its own provider. Three
mutations go red (the rule, the provider set, the product-path threading). Owner: closed. Raised by:
18B `.close` gate-validator MAJOR-3.

### U277 — CLOSED at the 18B close (RECORDED REVERSAL): the status bar's ceiling trusted the feed upward

`terminal/statusbar/statusbar-model.capForProvider` preferred the feed's `allowance_by_provider` with no
ceiling, and a test pinned that behaviour deliberately, reasoning that "the FEED is authoritative about
the operator's authorization". That is right downward and wrong upward. The feed is
`auth.terminals_for(p)` = `min(config, code cap)`, and the CODE cap is what the governor actually
enforces — so a feed number ABOVE it cannot be authorization; it can only be a fault or a forgery, and
painting it advertises concurrency every other surface will refuse (invariant 21 / I-X3, and invariant
27's "visible" has to mean visibly TRUE). Unreachable through the product path today, which is why it is
cheap to close and why the direction is the whole point. FIX (landed): the feed value is clamped to
`PROVIDER_ALLOWANCE`; narrowing is still honoured in full, which is what U255 asked for. The reversal is
recorded rather than made silently, and the test that pinned the old behaviour now states why it
changed. Owner: closed. Raised by: 18B `.close` spec-auditor MINOR-1.

### U278 — OPEN: `compute_manifest.py` regenerated on Windows reorders one canonical entry

Running `python tools/manifest/compute_manifest.py` on this host produces a manifest that differs from
the committed one by the POSITION of one `docs/canonical/` entry (same `sha256`, same `bytes`), plus the
mutable audit files and `operator_signature` resetting to PENDING. Root cause: `collect()` uses
`sorted(Path…)`, and `WindowsPath.__lt__` case-folds while `PosixPath.__lt__` does not — the committed
manifest was generated in the Linux sandbox. **There is no frozen-content drift**: `schemas`,
`conductor_files` and `repo_governance_files` diff to zero and `--check` reports `freeze check OK`.
Pre-existing, not introduced by Phase 18. Recorded because the naive regenerate command produces an
alarming-looking `freeze_integrity_sha256` change that a future reviewer will have to re-diagnose. FIX
(owed): sort on a normalized key (e.g. `as_posix()`), or state the platform the manifest was generated
on. Owner: post-18. Raised by: 18B `.close` gate-validator MEDIUM-3.

### U279 — OPEN: `git status` reports `M apps/desktop/main.js` on a byte-identical file

At the 18B close both reviewers saw ` M apps/desktop/main.js` in `git status --short` while
`git diff` was empty. Verified independently by both the builder and the gate-validator: the worktree
blob hashes to `b422eda4df4fa1e17ef07118e59408a19b4d58b1`, byte-for-byte the index and HEAD entry
(147916 bytes, zero CR bytes — so it is NOT the U274 CRLF case either). It is a stale index stat cache,
cleared by `git update-index --refresh`. Recorded rather than waved away because operator directive
§18–20 requires `git status --short` in the final report, and a reviewer with no shell reasonably read
the `M` as a real uncommitted product edit and graded it MAJOR — the ambiguity is the defect. FIX
(owed): refresh the index before capturing the status line in any receipt or report, and say which was
run. Owner: 18C. Raised by: 18B `.close` spec-auditor MAJOR-1 (re-graded to this after measurement).

### U280 — DISCHARGED at 18C `.probe-path`: the supervised probe path exists, and `_SUPERVISED_PROBE_PATH` is now `True`

Correcting sibling to the two earlier U234 rows, which are left exactly as written (invariant 12). Both
are now false OF THE CODE and true of the history: the 18A row said "the 18C live probe would spawn an
unsupervised, unleased frontier CLI ... through a bare `subprocess.run`", and the 18B `.scope` row said
"the entry condition is now enforced in code: `_SUPERVISED_PROBE_PATH = False` makes `run_probe` refuse
AFTER an allowed gate ... pinned by a test that asserts a gate-allowed probe still spawns nothing."
As of 18C `.probe-path` the flag is `True` and an allowed gate DOES reach a child — inside
`node_runtime/supervisor/provider_probe_session.governed_probe_session`, which runs the pane path's five
gates in the pane path's order, mints a governed identity, holds ONE durable I-X3 lease on that
provider's own subscription (allowance 1, never merged) for exactly the child's lifetime, runs it inside
the managed-process boundary with the credential-bearing environment removed by NAME and argv[0] pinned
to the executable the gate resolved, and releases on every exit path with the release MEASURED into
`teardown_record`. Fifteen mutations in `tools/mutation/_op18c_probe_path_mutations.py` go red, restores
byte-identical. STILL NOT CLAIMED: no Sovereign node RECORD for either provider (U227, operator-reserved
— `NodeRegistry.register` refuses both adapter ids), and no live call has been made (the operator's
switch cites OP-6, so both providers are DENIED today; the probe path is exercised against its refusal
and its injected-child paths only). Owner: closed. Raised by: 18A round-4 gate-validator; discharged at
18C `.probe-path`.

### U281 — OPEN: `process_tree._run_windows` accepts a `stdin` argument and never uses it

`adapters/frontier/process_tree._run_windows(cmd, *, timeout, env, stdin, ...)` takes `stdin` and never
references it: the job-member shim always opens `stdin=subprocess.PIPE` (it needs the pipe for its own
`GO` admission handshake) and hands `sys.stdin` to the real target. `_run_posix` honours the argument
directly. The BEHAVIOUR on Windows is equivalent for the probe's purposes — `communicate()` closes the
pipe, so the child reads EOF — but three call sites pass `stdin=subprocess.DEVNULL` believing it is
load-bearing, and one test asserts the ARGUMENT against a monkeypatched `run_managed_process`, so it
pins a value the real implementation discards. `provider_probe_session`'s docstring now states the
mechanism honestly rather than claiming a closed handle. FIX (owed): either close the member's stdin
explicitly after the GO handshake and honour the parameter, or drop the parameter on the Windows path so
no caller can believe in it. Whether a real `grok`/`agy` TUI would block on this stdin is unverified — it
needs a live run on the Windows host. Owner: post-18. Raised by: 18C `.probe-path` spec-auditor MINOR-9.

### U282 — OPEN: `test_concurrent_writers_yield_conflict_never_silent_overwrite` failed once under full-suite load

Recorded because it happened, not because it is understood. During the 18C `.probe-path` remediation the
full Python suite reported `1 failed, 1936 passed` with
`tests/integration/test_mcp_server.py::test_concurrent_writers_yield_conflict_never_silent_overwrite` as
the single failure; the same test then passed 6/6 in isolation and the whole suite passed on the next run
(1937 passed / 1 skipped). It is a concurrency test with real threads, and nothing in this unit touches
`mcp_server/` or `persistence/`, so the suspicion is timing sensitivity under load rather than a
regression — but a suspicion is not a diagnosis, and a CAS-conflict test that can be green by luck is
worth more scrutiny than a green run gives it. FIX (owed): re-run it under deliberate load, and if it is
timing-dependent make the interleaving deterministic rather than widening a timeout. Owner: post-18.
Raised by: 18C `.probe-path` builder self-check.

### U283 — NARROWED at 18C `.probe-path`: U91's and U98's shapes reached the supervisor layer, and were refused there

Sibling row to U91 (a `probe_conductor_model.py` surface claiming "the SAME live-gate chain the conductor
launch runs" while hardcoding `ProfileLoader(DeploymentProfile("cloud"))`, making the air-gap branch
structurally unreachable) and U98 (`operator_terms_confirmed=True` as a default no production caller
overrides, so `LiveTermsNotConfirmed` is unreachable outside tests). The first cut of
`provider_probe_session` reproduced BOTH, in `node_runtime/supervisor/` — a layer neither row had reached
— under a docstring asserting parity with the pane path. The gate-validator settled the first by
execution rather than argument: under `SOVEREIGN_DEPLOYMENT_PROFILE=offline_airgapped` the module opened
a session and wrote a durable `grok_build_subscription` lease. Both are now REQUIRED keywords on
`governed_probe_session`, matching `worker_pane_spawn._authorize_frontier`; the sole production caller
passes a loader built from the host's real profile via `profile_loader_from_host()` and passes the terms
flag with its authorizing artifact named at the call site (`AUTONOMOUS_BUILD_DIRECTIVE.md` §17). Four
mutations cover it, plus `test_the_gate_chain_matches_the_pane_paths_gate_chain`, which compares the
ordered gate calls in both functions so the parity CLAIM cannot drift from the code again. This does NOT
close U91 or U98 — their own surfaces are untouched, and the mechanism half (a revocable operator
artifact for the terms determination; a single sourced deployment profile) belongs to them. Owner: U91
and U98 keep theirs. Raised by: 18C `.probe-path` gate-validator MAJOR-1/MAJOR-2 and spec-auditor
MAJOR-1/MEDIUM-2/MEDIUM-3, found independently.

### U284 — CLOSED at 18C `.probe-path`: the line that discharged U234 could be swapped for the naked spawn, suite green

`run_probe`'s `run = runner if runner is not None else _supervised_runner(session)` is the ONE production
line that routes the probe child through supervision. The gate-validator replaced `_supervised_runner`
with `subprocess_runner()` — the exact bare `subprocess.run` U234 forbids — and got `382 passed`: every
test in the tree passed `runner=`, so the `runner is None` wiring had never executed. Three further
GREENs sat in the same blind spot: argv built from the bare command NAME instead of the resolved
executable, argv truncated to one element, and `executable=None` passed into the gate (falling back to a
real host PATH lookup inside a deterministic test). This is U275's pattern — the dangerous failure of a
selection point is a WRONG entry, not a missing one — at the selection point the whole sub-step exists
for. FIX (landed): `test_the_UNINJECTED_runner_is_the_supervised_one` drives `run_probe` with
`runner=None` against the real `_supervised_runner`, seaming only `run_managed_process`, and asserts the
child was the gated file, bound to the authorized workspace, credential-scrubbed, bounded by the default
timeout, with the measured teardown recorded; and `supervised_probe_runner` now refuses any argv whose
first element is not `session.executable`. Owner: closed. Raised by: 18C `.probe-path` gate-validator
MAJOR-3/MAJOR-4 and spec-auditor MEDIUM-7.

### U285 — CLOSED at 18C `.probe-path`: the mutation harness scored its own breakage as evidence of safety

`tools/mutation/_op18c_probe_path_mutations.py.run()` returned `proc.returncode == 0` and treated
everything else as "RED (guarded)". pytest exits 2 on a collection error and 5 when no tests are
collected, so a mutation that produced a SyntaxError, or a selector naming a file that does not exist,
was recorded as a caught mutation. The validator demonstrated all three outcomes. Compounding it, shipped
mutation #9 injected an undefined name (`_NEVER`) and so tested "a NameError propagates" rather than the
downgrade-instead-of-refuse property its docstring named. FIX (landed): exit 0 ⇒ GREEN, exit 1 ⇒ RED,
anything else ⇒ SETUP-FAIL (counted as broken, never as evidence); mutation #9 rewritten as a faithful
downgrade. The original ten were re-run under the corrected scoring and each produced a genuine
`N failed, M passed`, so no previously-reported RED depended on the defect. Owner: closed. Raised by:
18C `.probe-path` gate-validator MEDIUM-6/MEDIUM-7.

### U286 — CLOSED at 18C `.probe-path`: the runner measured the governed record and showed the operator none of it

Operator directive §17 requires the live receipt to confirm the lease returned to zero. The engine built
the whole record — subscription, allowance, in-use, lease id and key, spawned pids, supervised execution,
node registration, and the measured teardown — and `run_frontier_providers.ps1` then sent engine stdout
to `Out-Null`, deleted the report temp file in its `finally`, and printed five fields (display, gate,
executed, accepted, reason). Its own header meanwhile promised "holds ONE I-X3 lease ... releases the
lease on every exit path". Invariant 27's "visible" cannot mean "computed". FIX (landed):
`Invoke-ProbeAction` prints the subscription line, the lease, supervised execution + node_registered +
pids, and the full teardown including `in_use_after` and `process_tree_clean`; a refused probe prints
"no session was opened (refused before any lease was taken)", which is the case where the ABSENCE of a
lease is the fact worth seeing. Two PowerShell tests drive the real runner against a stub engine (no
provider contacted). The refusal test found a second defect while being written: under
`Set-StrictMode -Version Latest` reading a property an object lacks is a TERMINATING error, so
`$null -ne $p.governed` threw on the only input that branch exists for — now `Test-HasProperty`. Owner:
closed. Raised by: 18C `.probe-path` spec-auditor MEDIUM-6.

### U287 — CLOSED at 18C `.probe-path`: a containment failure reached the operator as a broken tool

`run_managed_process` raises `ProcessTreeCleanupError` when descendants survive the boundary — the ONE
signal that boundary exists to produce (invariant 29). `supervised_probe_runner` caught `TimeoutExpired`,
`FileNotFoundError` and `OSError` only, so it escaped `run_probe` and `main()`, no report file was
written, and the PowerShell runner reported either "Recon engine produced no report" or "provider engine
failed with exit N (this is a tool failure, not a governed refusal)" — at the exact moment (§17 live
acceptance) the operator is trusting the report. FIX (landed): the runner catches it, returns it as a
`spawn_error` (so a leaked-process run can never be `accepted`), and records
`session.process_tree_clean = False`, which the context manager carries into `teardown_record`. The field
is TRI-STATE: `None` while no child has run, because "nothing was left behind" and "nothing was checked"
are different facts and an injected runner never entered the boundary at all. Owner: closed. Raised by:
18C `.probe-path` spec-auditor MEDIUM-8.

### U288 — CLOSED at 18C `.probe-path`: small claims that outran their code, each now with a red-able test

Collected rather than spread across seven rows, because they are one habit. (a) `PROBE_LEASE_PURPOSE`'s
test imported the constant it compared against, so a BLANK purpose satisfied "an operator reading the
ledger can tell a probe from a pane" — now asserted against literals too. (b) `GATE_PROBE_IDENTITY`
could be renamed to the pane path's gate id with the suite green, defeating the exact confusion its own
comment forbids — the identity tests now assert `.gate`. (c) `seeded_from_ledger` was dead
observability: replacing `seed_governor` with a bare `register_subscription` was green — a test now
proves a foreign holder's terminal is projected into this process's governor. (d) `governor_released`
could be hardcoded `True` — a stuck-governor test now requires the record to report `False`. (e)
`DEFAULT_PROBE_TIMEOUT_S` could be `None` (an unbounded child holding the subscription's single
terminal) because every runner test passed `timeout_s` explicitly. (f) an `OSError` from
`TerminalLeaseLedger.release` escaped the `finally` BEFORE `gov.release`, leaking an in-process terminal
for the life of the process — the durable release is now wrapped so the governor release is
unconditional. (g) `run_probe`'s docstring carried TWO "Order is deliberate and fail-closed" paragraphs,
the first being the pre-18C one that omits the governed session entirely, and `subprocess_runner`'s
docstring — itself a correction of an earlier stale-caller claim — had become a stale-caller claim in the
opposite direction; both fixed, the second pinned by
`test_the_metadata_runner_is_NOT_the_probes_runner`. (h) `_resolve_executable` and `which_provider`
answer the same question and could disagree forever, since the product path always supplies the
executable — a fabricated-PATH test now requires them to agree. Owner: closed. Raised by: 18C
`.probe-path` gate-validator MEDIUM-2/3/5, MINOR-1/2/3/4/6 and spec-auditor MEDIUM-4/5, MINOR-10/11.

### U237 — CLOSED at 18B `.scope` (closure recorded here, at 18C `.close`)

The row above stands as written. This is its closure, appended rather than edited (invariant 12).
U237 said the printed 18C entry-condition instruction — "the operator has extended
`config/live_operation.json` to include both providers" — could not be followed, because
`live_authorization._AUTHORIZED_PROVIDERS` was pinned to the OP-6 pair and the loader RAISES on any
other id, so naming `grok_build` would have denied every live provider. **The code-pinned scope
extension shipped at 18B `.scope`** (`_PROVIDER_SCOPE_BY_ROW` gained the OP-12 row; evidence
`docs/evidence/PHASE18B_EVIDENCE_REPORT.md`), so the operator's own file edit is now the only
remaining half — which is exactly what `frontier_provider_recon._how_to_open` and
`PHASE18C_PROBE_ENGINE_REPORT.json` now tell them. A reader who followed the citation from that text
landed on a row still saying "OPEN, code owed": the opposite. Owner: closed. Raised by: 18C `.close`
spec-auditor MINOR-9.

### U238 — RE-OWNED at 18C `.close` (still OPEN): the probe-acceptance holes move to the live run

U238's row assigns owner **18C** to two narrow holes that decide a LIVE probe verdict: whitespace-
deleting echoes accepted by `_token_answered`, and `extract_probe_text` falling back to the whole JSON
document, so a token appearing in any field (`{"debug": "GROK_PROVIDER_OK"}`) is ACCEPTED. 18C closed
as **skip-with-record** — the operator's entry conditions are unmet and **no probe has ever
executed** — so neither hole can fire in the world this gate evidences, and neither was fixed. Left
OPEN and re-owned to **the operator's live acceptance run** (18D per OP-12.1, or the first run under
an extended live switch, whichever comes first). It is named in the 18C receipt's OWED block
(`probe_acceptance_holes`) so a reader of a green 18C receipt cannot miss it. Owner: 18D / the live
acceptance run. Raised by: 18C `.close` spec-auditor MEDIUM-6.

### U289 — CLOSED at 18C `.close`: the operator's one instruction named a prerequisite that had already shipped

`live_probe_gate`'s denial is the single text an operator reads when 18C blocks, and it was a fixed
sentence rather than a reading of the state: *"editing that file is NOT sufficient and NOT safe on its
own … it takes the operator's register row plus the 18B scope extension in
`control_plane/profiles/live_authorization.py` (U237)"*. Exactly true when U237 was written; **false
the moment 18B `.scope` shipped that extension** — so the surface the operator consults in order to
satisfy 18C's entry condition told them a code change was still owed that had already landed.
Invariant 1 is about INFORMED final authority, which is the whole warrant for the sentence existing.
FIX (landed): `_how_to_open()` DERIVES the instruction from the code-pinned scope — covered by a
recorded row ⇒ the remaining step is the operator's own file edit, named with the row; covered by
none ⇒ the original warning, which is then true. Round 2 found two more branches: the loader returns
DENIED (not an exception) for an **absent** file and for `live_operation_authorized: false`, and in
both of those worlds the affirmative "add it to `scope.providers`" is also false — those now carry the
loader's own reason and point at `config/live_operation.example.json`. And the covered branch stopped
claiming 18B provenance for `claude_code`/`openai_codex_cli`, scoped since OP-6, and stopped saying
"that row" when two are listed. Four tests; one mutation. Owner: closed. Raised by: the builder at
18C `.close`, extended by the spec-auditor MEDIUM-5 / MINOR-10.

### U290 — CLOSED at 18C `.close`: verifying one frontier selection probed the OTHER provider's CLI

`emit_worker_launch._host_offered_options` substituted the host-free stand-in only when the selection
was **not** an OP-12 provider, so an OP-12 selection asked `build_host_picker` for the real probe —
which runs BOTH CLIs unconditionally. Authorizing a Gemini/Antigravity pane therefore emitted
`grok --version` + `grok models` to grok.com under the operator's SuperGrok session, and vice versa.
This is the cross-provider half of the very egress **U276** closed for a LOCAL selection at the 18B
close; that fix scoped the *local* case and left the two frontier providers probing each other. It
also made the 18C acceptance receipt's cost disclosure wrong twice over — it claimed "exactly the two
OP-12 selections it verifies, scoped per selection" against a measured five enumerations per provider.
FIX (landed): `enumerate_pane_picker.only_op12_probe(provider)` probes exactly one CLI and reports the
other as the honest not-probed stand-in (an option's identity carries its own provider, so the other
group's absence cannot affect the match — the same argument `_host_offered_options` already made for
a non-OP-12 selection); `_host_offered_options` uses it; the receipt's disclosure now COUNTS three
enumerations per provider and says what it was before. Two tests, injectable seam, no host call.
Owner: closed. Raised by: 18C `.close` spec-auditor MAJOR-1.

### U291 — CLOSED at 18C `.close`: the whole self-check directory was outside every syntax check this repo runs

The 18C remediation commit shipped a **SyntaxError** — two `catch` clauses on one `try` — in
`apps/desktop/selfcheck/op12-acceptance-selfcheck.js`. The full Python suite, the desktop suite, the
terminal suite, pyflakes and both falsification harnesses were all green. It was found only when the
packaged Electron run hard-timed-out at 600 s with **no receipt written**. Cause: nothing headless
loads these modules. They are required by `main.js`, which calls `app.whenReady()` at load and
therefore cannot be required in a test — so `apps/desktop/selfcheck/*.js` had no syntax check, no
load check, and no coverage of any kind outside a real Electron run. That is precisely **D-P16-0**'s
binding lesson (headless tests alone closed 14A while shipping a runtime that failed at first launch),
reproduced inside the files that exist to enforce it — and the failure mode is not loud: a broken
module takes the shell down at startup or wedges the launcher until its hard timeout. FIX (landed):
`apps/desktop/test/selfcheck-guards.test.js` PARSES every `.js` in the directory with `vm.Script` (no
execution, so `run.js` — which spawns Electron at load — is safe to include) and LOADS every
module-shaped one, which is what `main.js` does at startup. Reverting the syntax fix turns the
ordinary suite red. Owner: closed. Raised by: the builder at 18C `.close`, from the failure itself.

### U292 — OPEN: the 18C review MINORs deliberately carried, named so they are not lost

Each was graded MINOR/NIT by a reviewer, none makes an 18C claim false, and each is recorded rather
than fixed inside a high-stakes gate's remediation window. (a) `tools/live/emit_worker_launch.py`'s
`build_worker_launch_ticket` still carries `operator_terms_confirmed: bool = True` with no production
caller injecting it — U91's shape, closed in `provider_probe_session.py` at 18C `.probe-path` (U283)
and still open on the pane/worker emitter; the 18C receipt DISCLOSES that the gate it publishes is a
parameter default (`scope_note_gate_map`) and its verdict does not rest on it. (b)
`tools/mutation/_op18c_probe_path_mutations.py` still lacks the lock + pinned-baseline +
signal-handler contract `pane_input_bypass_mutations.js` documents and `_op18c_close_mutations.py`
now has; it mutates product files, so a hard kill can leave one mutated. (c)
`PHASE18C_PROBE_ENGINE_REPORT.json` carries `"phase": "18A"` — the recon engine stamps its own origin
phase into every report it builds. (d) `op12-acceptance-verdict.leasesAreZero` maps an absent ledger
bucket to `0`, so the receipt's `lease_status` reads as a measurement where it is partly an inference
(the status-bar leg covers the same fact from the other side). (e) `_op18c_close_mutations.py` has no
mutation for `uxGuardRefused`'s own three rules, the OWED missing-key branch, the U255 allowance rule,
or `noCredentialMaterial`'s no-sink branch — each is covered by a test, so this is coverage of the
harness, not of the code. Owner: 18D or the next unit touching each surface. Raised by: 18C `.close`
gate-validator MINOR-10 and spec-auditor MINOR-13/15, NIT-17/20.
### U227 — **RESOLVED 2026-08-01 by operator ruling OP-12.1: successor schema `node@1.1`** (executed at `phase-18d.amendment`)

The operator ruled the decision this register carried as OPERATOR-owned since the 18B close. The
resolution is the additive one: `schemas/node.schema@1.1.json` exists beside the frozen
`node.schema.json`, whose bytes are unchanged and still match the Phase-0 manifest hash, and whose
`adapter` enum still has no member for either provider. `@1.1`'s enum is that frozen list plus
`grok_build`, `google_antigravity` and `ollama_local`. `NodeRegistry.register` admits an adapter
that ANY node schema version admits, so a schema-valid Sovereign node record CAN now name both
OP-12 providers; the refusal path is unchanged for an id in neither version, still logs
`registration_refused`, and now names the versions it consulted. The append-only spawn event carries
`adapter_schema_version`, so a `@1.1` node is distinguishable from a `@1.0` node in the log forever.

**Resolved does not mean done, and the distinction is the honest part.** The VOCABULARY is open; no
record has been created. Nothing in `provider_probe_session` or the pane path calls `register()` for
these providers yet (`GovernedProbeSession.node_registered` is still `False`, now a fact about that
module rather than about the schema), and the 18C legs that were skipped on this fence are still
skipped. Those are `phase-18d.close`. Live legs remain gated where they always were: the operator's
own `config/live_operation.json`, the OP-9-class terms determination, and an I-X3 lease at
allowance 1 per OP-12 subscription. Admitting a vocabulary authorized nothing.

### U254 — **ADMITTED 2026-08-01 (not fixed) by the same ruling, OP-12.1**

`ollama_local` is now an `adapter` enum member of `node@1.1`, so it registers on the schema's
authority rather than on the grandfather clause that carried it — `ADAPTER_EXEMPTIONS` is empty and
the vocabulary has no exceptions at all. Recorded precisely: this is ADMITTED, not fixed. The two
spellings still coexist (`ollama_direct` in the frozen `@1.0`, `ollama_local` in `@1.1` and in every
product path since Phase 15E), which is a wart the ruling permitted rather than removed. The tidier
end state is still a rename to one spelling; it touches every local spawn path and is not this
unit's call. Owner: whoever next has cause to touch the local adapter id.

### U293 — **CLOSED at `phase-18d.amendment` (found and fixed in the same unit): the freeze manifest's integrity hash was PLATFORM-DEPENDENT**

Found by running `tools/manifest/compute_manifest.py` on the operator's Windows host for the first
time since Phase 0. It reordered `contents.canonical_documents` and produced
`freeze_integrity_sha256 = A97DD85C…` instead of the recorded `8E604CA3…` — **with no file on disk
changed**. Cause: `sorted(d.glob(pattern))` sorts `Path` OBJECTS, and `PurePath.__lt__` compares
case-NORMALISED parts, so `SOVEREIGN_PROGRAM_….md` sorts before `Sovereign_Orchestration_….md` on
Linux and after it on Windows. The manifest was generated in the Linux sandbox; the operator's host
is Windows. Because `contents.canonical_documents` is a LIST, that order is inside the hash, and the
tool's signature-preservation branch keys on exactly that hash — so a regeneration on the operator's
own machine would have silently reset `operator_signature` from `SATISFIED_BY_OPERATOR_RULING` to
`PENDING`, and printed `FREEZE DRIFT DETECTED` for eleven canonical documents nobody touched. That
is the U222 failure ("the operator signature must be preserved by hand, never regenerated away")
arriving through the generator itself, and it had been latent since 2026-07-16 — invisible because
this is the first change to touch the tool since the freeze. FIX: `sorted_files()`, an explicit
case-sensitive key on the POSIX repo-relative path string, used by all three collection sites. The
regenerated manifest reproduces `8E604CA3…` byte-identically and the signature survived. Pinned by
`test_the_manifest_is_reproducible_on_this_host` and `test_the_ordering_key_is_platform_independent`.
**Honest scope note:** this makes the hash reproducible across platforms; it does not make the
existing recorded hash independently re-verifiable by anyone who lacks the repo, which was never a
property it had.

### U293 — **CORRECTION appended at `phase-18d.close` (append-only: the row above stands as written)**

One clause of the U293 entry above is **wrong and is retracted here**: *"and printed `FREEZE DRIFT
DETECTED` for eleven canonical documents nobody touched."* The 18D gate-validator measured it
(MEDIUM-2) by reverting `sorted_files()` at the `SETS` call site and running the tool for real on
this Windows host — the result was `freeze check OK: no drift in FROZEN set against recorded
manifest`. `--check` builds its comparison as a DICT keyed by path, so it is order-independent and
can never report drift from an ordering change; only the WRITE path was affected. The other half of
the entry is confirmed and was reproduced independently: regenerating under the reverted ordering
produced `A97DD85C…` and reset `operator_signature.status` to `PENDING`. The retracted clause made a
real defect sound broader than it was, in an append-only register, which is the drift this file
exists to prevent; the correction is appended rather than edited in place for the same reason.

### U294 — **OPEN, structural: the document that authorizes amending the freeze is not itself covered by any hash**

Raised by the 18D gate-validator (MINOR-6) at the first gate where it is load-bearing.
`AUTONOMOUS_BUILD_DIRECTIVE.md` §17.1 is the ENTIRE authorization for widening the canonical node
vocabulary, and that file is in neither `SETS` nor `EXTRA` in `tools/manifest/compute_manifest.py`,
so no recorded hash covers it — while `CLAUDE.md` and `.claude/hooks/guard.py` are covered. The
freeze discipline protects the rules and not the document that authorizes amending them.

Procedurally invariant 1 is intact for OP-12.1: the ruling is in commit `5b19ccb`, which precedes
the amendment commit, and git history is never rewritten (§2.6), so the ruling's provenance is
checkable by `git log -S`. What is missing is a manifest-level guarantee.

**Not fixed here, and the reason is itself the constraint:** adding the directive to `EXTRA` would
put it inside `contents`, which would move `freeze_integrity_sha256` and reset the operator's
recorded signature to `PENDING` — U222, the exact failure the amendment block was designed around.
A correct fix is a THIRD block with the amendment block's shape (computed after the freeze hash,
stored outside `contents`) covering the authorization documents, or an operator signature over the
directive itself. Both are operator-facing decisions about what the operator is signing, not builder
decisions. **Partial mitigation landed in this unit:** `attribution_for()` now requires an
amendment's cited ruling id to be findable in `AUTONOMOUS_BUILD_DIRECTIVE.md` or the
`DECISION_REGISTER`, so an invented ruling fails `--check` closed. That authenticates the CITATION,
not the document. Owner: OPERATOR (what to sign) / next unit touching the manifest tool.

### U295 — **OPEN, narrow: the stale-prose detector is a pattern list, not a semantic check**

`tests/unit/test_u227_prose_is_not_stale.py` mechanises the 18D validator's MAJOR-1 — a live surface
may not describe U227 as unruled without naming OP-12.1 nearby — and it catches all ten pre-fix
sites when run against the pre-fix blobs. It is nevertheless a fixed set of seven regexes over a
±12-line window. A NEW false claim about the same boundary, phrased in words the list does not
contain, passes. **A second limitation was MEASURED rather than reasoned about:** the first
placement of this unit's own mutation M8 injected `U227 is operator-reserved` into
`control_plane/nodes/pane_picker.py` and the detector stayed GREEN, because that file already names
OP-12.1 eleven lines away — the window rule cannot tell "the correction is right here" from "a
correction happens to be nearby". Widening the window makes that worse, not better; requiring the
ruling on the SAME line would reject the multi-line docstring corrections that are the honest form.
The mutation was re-placed in a neutral file and goes RED there. Recorded rather than solved because
the general form ("is this sentence still
true?") is not mechanisable, and because the honest reading of MAJOR-1 is that boundary prose needs
a detector each time a boundary MOVES — the pattern list is the cheap 90%, and the reviewers are the
rest. Owner: whoever next moves a governance boundary described in prose.

### U296 — **OPEN, honesty-surface: shipped OWED/receipt prose is guarded only where a test points at it**

The 18D gate-validator (MEDIUM-3) replaced the shipped `OWED.provider_node_record` value with an
outright over-claim and all three suites stayed green: the OWED rules were enforced only at
in-Electron receipt-emit time, and every test asserted against a synthetic fixture.
`apps/desktop/test/op12-acceptance-owed-shipped.test.js` now points the existing rules at the
shipped object and adds an over-claim rule, which closes that specific constant. The CLASS is not
closed: other shipped honesty constants (OWED-style prose in the recon engine, the runner's status
text, evidence-shaped strings in the selfcheck modules) are still asserted by tests that build their
own inputs. Owner: the next unit that edits any of them — the rule to apply is "assert the shipped
object, not a fixture of its shape".


### U297 — **OPEN, scope: an interactive PANE still mints an identity and no node record**

18D `.close` wired node registration for the governed HEADLESS probe session
(`provider_probe_session` -> `ProviderNodeRegistrar`). The interactive pane path
(`worker_identity` / `worker_pane_spawn` / `pane_node_spawn`) still mints a governed IDENTITY and
creates no record, exactly as it did before OP-12.1 — and so do the `claude_code`,
`openai_codex_cli` and local spawn paths. Invariant 2 ("every terminal is a Sovereign node") is
therefore satisfied in the identity/gating sense everywhere and in the RECORD sense only on the
probe path. This is scope, not regression: OP-12.1 authorized the vocabulary and 18D wired the one
path whose legs 18C owed. Owner: whoever next opens a pane whose history an auditor must be able to
read. The registrar is path-agnostic — it takes a session document — so the work is a call site and
a durable-log owner decision, not a new mechanism.

### U298 — **CLOSED in the unit that found it: a test asserted on a FILENAME, not an outcome**

`tests/unit/test_node_schema_amendment.py::test_manifest_check_reports_amendment_drift_as_hard_failure`
asserted `"AMENDMENT" not in` a clean `--check`'s output. `--check` also prints an INFO line naming
the mutable docs it does not cover, so the moment `docs/evidence/PHASE18D_AMENDMENT_CHECKPOINT.md`
landed — in the very evidence commit of the unit that wrote the test — the baseline went red on a
clean tree. Fixed here by asserting the three DRIFT markers (`AMENDMENT NEW/CHANGED/REMOVED`). The
general lesson is the register-worthy part: a test whose assertion matches a FILENAME fails for
reasons its subject has nothing to do with, and it will do so in some later unit that has no idea
why.

### U299 — **OPEN, carried: the durable node log's lock is per-registrar, not per-append**

18D `.close` gave `.sovereign_store/nodes/node_events.jsonl` an exclusive pid-stamped lock held for
a registrar's lifetime, because two `AppendOnlyEventLog` objects each cache `prev_hash` at open time
and two processes appending would break the chain permanently (an append-only log has no repair, and
a corrupt one cannot be re-opened, so the governed-probe path would be wedged). What that buys is
correctness under contention: the SECOND holder is refused (`gate: node_log_locked`) rather than
allowed to interleave. What it does not buy is concurrency — two governed probes of DIFFERENT
providers cannot hold node records at the same time, even though I-X3 permits them (the allowances
are per-subscription). Not reachable today: the recon loop is single-threaded and probes run one at
a time. Owner: the first unit that needs concurrent governed sessions; the fix is a per-append lock
plus re-reading the tail on each append, which is a change to `AppendOnlyEventLog` (Phase-2 code)
and was out of scope here.

### U300 — **OPEN, carried: `AppendOnlyEventLog` has no reader API, so callers parse the file**

The registrar computes the next incarnation by reading the log file directly (`json.loads` per
line), and both the 18D report and its tests read rows the same way, because the class exposes
`append`, `close` and a module-level `verify_file` and nothing else. Three parsers of one format is
how a format drifts. Owner: whoever next needs to read node history; the fix is a `rows()` iterator
on the log, and the reason it is not here is that `event_log.py` is Phase-2 gated code and this unit
had no other cause to touch it.

### U301 — **OPEN, honesty-surface: `supervised` is a dataclass default, so the I-C1 fence is narrow**

`GovernedProbeSession.supervised` defaults to `True`, and the registrar refuses a session whose
`supervised` is not exactly `True`. Combined with the type check added at this gate (only a real
`GovernedProbeSession` registers, and it must carry a lease id and a subscription ref), the
attestation is far stronger than it was — but the field is still a default rather than a
measurement, so the `unsupervised_session` fence can only refuse a session a caller deliberately
marked false. Found by the spec-auditor (MEDIUM-3 / MINOR-5) and recorded rather than over-claimed:
making it a measurement means the session verifying its own child's parentage, which is a supervisor
change, not a registrar one. Owner: whoever next hardens U10/U25-class containment.

### U302 — **OPEN, carried from the 18D reviews: two guards that only a mutation can keep honest**

Two of this unit's guards were GREEN when first written and are only red now because a specific test
was added: C2 (deleting the schema validation on the registration path changed nothing, because
every record the tests happened to build was valid) and C10 (the emitter's `registered` conjunct was
masked by a fake result missing three other fields). Both are covered now
(`tools/mutation/_op18d_close_mutations.py`, 29/29 RED). The register entry is the pattern: **a
conjunct is only tested if the fixture it is tested against is complete except for the conjunct.**
Owner: whoever adds the next `ok` rule to any receipt in this repo.
---

## Phase 18E `.hardening` (2026-08-02) — U238 and the pane-emitter gate inputs

### U238 — **CLOSED at 18E `.hardening`** (both holes; two narrower limits split out as U304/U305)

Directive §17.2(2) ordered both probe-acceptance holes closed BEFORE the live legs run. Both are.

  * **Hole 1 (echo).** `_token_answered` subtracted the echoed prompt on a whitespace-collapsed
    fold, which is not whitespace DELETION and says nothing about punctuation. Twelve shapes were
    MEASURED as accepted on the pre-fix tree — six pure echoes (`Reply with exactly:GROK_PROVIDER_OK`,
    a dash for the colon, hyphens for spaces, an inserted arrow, markdown emphasis, a letter-spaced
    instruction) and six documents (below). The subtraction now runs on an alphanumeric-only fold.
  * **Hole 2 (whole-document fallback).** Acceptance called the best-effort `extract_probe_text`,
    which falls back to `json.dumps(doc)`, so a token in ANY field — `{"status":"done","debug":
    "GROK_PROVIDER_OK"}` — certified a provider that said nothing. Acceptance now calls a separate
    strict reader, `extract_provider_response_field`: a recognised response field, or the whole
    document when that document IS a bare JSON string, or `""`. The best-effort reader is unchanged
    and still serves display and the worker payload — two names, two jobs.

Evidence: `docs/evidence/PHASE18E_HARDENING_CHECKPOINT.md` (before/after transcript over all twelve
shapes plus controls); guards `tests/unit/test_frontier_provider_recon.py::TestU238EchoNormalisation`
and `::TestU238AcceptanceReadsAResponseFieldOrNothing`; falsified by
`tools/mutation/_op18e_hardening_mutations.py` H1-H4, H8-H9 (10/10 RED).

**What CLOSED does not claim.** The operator's own recon probe of 2026-08-02 was accepted by the
PRE-FIX code; the directive's own framing is "hardening the acceptance, not repairing a result", so
one live verdict does rest on the old reader and no verdict taken from here on does. The two
narrower limits found by the reviewers are recorded as U304 and U305 rather than absorbed.

### U292(a) — **CLOSED at 18E `.hardening`**: the pane/worker emitter's two invented gate inputs

`build_worker_launch_ticket` answered two questions that were not its to answer:
`profile_loader: ProfileLoader | None = None` fell back to `ProfileLoader(DeploymentProfile("cloud"))`
(U91's shape — invariant 20's air-gap half structurally unreachable on the product path, with every
"covering" test injecting the loader the product never passed), and `operator_terms_confirmed: bool
= True` published a measured-looking gate no caller had supplied (U98's shape — the 18C receipt had
to disclose it and exclude the gate from its verdict). Both are now REQUIRED keywords; `main()`, the
sole production caller, supplies the profile through `profile_loader_from_host()` and the terms flag
with OP-9/OP-12 cited at the call site. This is the same closure `provider_probe_session.py` got at
18C `.probe-path` (U283), on the surface U292(a) recorded as still carrying it.

Proved by EXECUTION, not signature: `main()` under `SOVEREIGN_DEPLOYMENT_PROFILE=offline_airgapped`
returns `authorized:false, refused_by:profile_roster`, and under `cloud` still authorizes.
Guard: `tests/unit/test_worker_emitter_gate_inputs.py`; falsified by H5-H7.
**U292(b)** (the 18C mutation harness lacking the lock/pin/signal contract) is UNCHANGED and OPEN.

### U303 — **CLOSED at 18E `.hardening`** (found in this unit's own spec-audit): invariant 20 fired AFTER the egress it forbids

Closing the manufactured `cloud` loader made the air-gap gate reachable, and reachable exposed an
ordering: `_assert_option_offered` runs first, and for an OP-12 selection it enumerates through
`only_op12_probe(provider)` — `grok models` / `agy models`, which leave the host (D-P18-7/U271).
So an air-gapped host emitted provider metadata traffic and THEN refused the pane. The verdict was
right and the ordering was not, which for invariant 20 is the whole point: "excluded from the
offline profile" has to mean the network was never touched. `_assert_profile_permits_verifying` now
raises `ProfileViolation` (same `profile_roster` gate id — it IS that gate) before the enumeration.

Measured, not argued: the guard test replaces `build_host_picker` with a detonator, so moving the
gate back fails with the call it should not have made. Writing that test also measured the egress
one step EARLIER than the audit found it — the cost is paid constructing `only_op12_probe`, before
`build_host_picker` — which the suite's own live-call guard caught. Falsified by H10.

### U304 — **OPEN, narrower successor to U238 hole 1: a PARAPHRASED echo still passes**

The subtraction removes a CONTIGUOUS occurrence of the folded prompt, so an echo that inserts a word
into the instruction — `Reply with exactly the following: GROK_PROVIDER_OK` — survives it and is
accepted. Found by the gate-validator (MINOR-2) while trying to break the new fold. Recorded rather
than claimed closed, and pinned by an ASSERTION OF CURRENT BEHAVIOUR
(`test_a_paraphrased_echo_is_a_known_narrower_hole_u304`) so the row and the code cannot drift: a
unit that closes this turns that test red and has to come here. Owner: whoever needs an acceptance
stronger than "the model did not parrot the instruction verbatim"; the likely fix is a token-set or
edit-distance subtraction, which needs a corpus of real answers to tune against and this unit had
none. Risk today is bounded: the probe prompt is this build's own, and an echo is a degenerate
answer rather than a forged one.

### U305 — **OPEN: neither provider's REAL response document has been read against the strict reader**

`extract_provider_response_field` accepts a STRING under one of six keys. Nothing in the repo
captures what `grok -p --output-format json` or `agy -p --output-format json` actually emits —
`docs/evidence/live/` holds help/version/models captures and no probe-response document — and the
operator's successful 2026-08-02 probe ran under the OLD whole-document reader, so it is unknown
whether the token was in a recognised field or only in the fallback. If either CLI nests its answer
(`{"response": {"text": …}}`) or emits content blocks, acceptance now REFUSES a genuine live answer.
The direction is the safe one and the ordering was ordered by §17.2(2), but it is an assumption, not
a verified fact. Found by the spec-auditor (F4). **Owner: the 18E `.live` unit — this is the first
thing its per-provider leg should capture, and a refusal there is this row, not a provider failure.**

### U306 — **OPEN, honesty-surface: an UNSET deployment profile resolves to the most permissive one**

`profile_loader_from_host` is described in its own docstring, and was newly restated in this unit's
tests, as failing "closed twice over". Only one half does: an UNKNOWN profile id raises; a MISSING
`SOVEREIGN_DEPLOYMENT_PROFILE` resolves to `cloud`, which on the Buildout §4 "fail closed on missing
policy" axis is fail-OPEN. Defensible as a default — this host is a cloud-profile workstation and
every downstream live gate still has to pass — but it is a default, not a refusal, and the claim was
stronger than the code. Found by the gate-validator (F8). The test is now named and documented for
what it measures; the source docstring's claim is the thing still owed. Owner: whoever next touches
`provider_probe_session`; changing the default is a host-behaviour change, not a docstring one.

### U307 — **OPEN: four independent implementations of "does this output parse"**

`frontier_provider_recon.accept_probe` and three sites in `provider_cli_common` each run their own
`json.loads((stdout or "").strip())`. The new reason-selection branch (`if parsed and not response:`)
is only correct while `parsed` and the strict reader agree about what parses. They cannot disagree
today and nothing pins them together. Found by the spec-auditor (F10); the repo's own rule is one
implementation per question. Owner: whoever next edits the acceptance path; the fix is a single
`parse_provider_document` returning the parsed doc or a sentinel.

### U308 — **OPEN: the terms citation is per-provider, the literal that carries it is not**

`main()` passes `operator_terms_confirmed=True` with no provider scoping, while the citation above it
is explicitly per-provider (OP-9 for claude_code/openai_codex_cli, OP-12 for grok_build/
google_antigravity). A fifth adapter added to `FRONTIER_PANE_ADAPTERS` would inherit an operator
terms confirmation no ruling covers. Caught first in practice by `_PROVIDER_SCOPE_BY_ROW`, which is
code-pinned per register row and refuses unknown ids — defence in depth working, not a live hole.
But nothing asserts the coupling, and `test_main_names_the_authorizing_ruling_for_the_terms_flag`
only greps the source for "OP-9"/"OP-12", which a comment satisfies. Found by the spec-auditor
(F11). Owner: the unit that adds a fifth frontier adapter — and it will not be reminded, which is
why this row exists.

### U309 — **OPEN, environmental: `ruff` is not installed, so CLAUDE.md's ruff-clean rule is UNVERIFIED**

CLAUDE.md requires Python to be `ruff`-clean. `ruff` is absent on this host under both interpreters
(`No module named ruff`; not on PATH), which the gate-validator confirmed independently. No unit
since it became a rule has actually checked it — this row stops that being invisible. Installing it
is an npm-registry-only-rule question (PyPI), so it is not a silent fix. Owner: the operator, or the
first unit authorized to add a PyPI dev dependency.

### U305 — **CLOSED BY MEASUREMENT at 18E `.live.shape`** (and not the way it was feared)

Both providers' real `-p --output-format json` documents were read against the strict reader by
governed live probes on 2026-08-02 (`docs/evidence/live/phase18e_probe_document_shape_
20260802T0230Z.json`). The instrument is `describe_provider_document` — structure only, never
values — and its `skeleton` output is kept as a permanent fixture in
`tests/unit/test_provider_document_shape.py::TestU305AnsweredByMeasurement`.

  * **`google_antigravity`: flat, recognised, ACCEPTED.** `{"conversation_id": …, "status": …,
    "response": "GEMINI_PROVIDER_OK
", "duration_seconds": …, "num_turns": …, "usage": {…}}` —
    `response` is one of the six keys, so the strict reader sees it. The feared nesting does not
    exist here and the acceptance is real.
  * **`grok_build`: the reader is RIGHT to refuse, and the refusal is not about the reader.**
    `{"text": "", "stopReason": "cancelled", "sessionId": …, "requestId": …, "thought": "The user
    wants me to reply with exactly \"GROK_PROVIDER_OK\". This is a simple request with no tools
    needed.", "usage": {…}, "modelUsage": {"grok-4.5": {…}}}`. `text` IS a recognised key and it is
    EMPTY; the token appears at exactly one path — `thought`, the reasoning trace, where the model
    is restating the instruction to itself. So this is not a genuine answer the reader cannot see;
    it is a document in which the CLI said nothing. No nested-answer accommodation is owed on this
    evidence, and adding one would have been a widening bought with a misread.

**What is CLOSED and what is closed by narrowing, because they are not the same** (spec-audit
MEDIUM-3). The reader has been checked against both real documents and behaves correctly on both —
that much is answered in full. But U305's actual risk was "does a GENUINE ANSWER from either CLI
land where the strict reader looks", and Grok's document contains **no answer at all**, so it cannot
demonstrate where an answer would go. That `text` is a recognised key sitting empty is an inference,
not an observation. For `google_antigravity` the row is closed outright; for `grok_build` it is
closed only in the sense that the document it produced has been read. **If the `.live.electron`
unit gets a real Grok answer nested in a content block and the reader refuses it, that is this row
returning, not a provider failure** — which is the warning the original row existed to leave.

Three consequences got their own rows rather than being absorbed into the word CLOSED — U310 (why
Grok cancels, still unknown), U311 (a recorded live acceptance that has to be withdrawn) and U312
(this unit spent more live exchanges than the directive's stated cap).

### U310 — **OPEN: Grok's single-turn `-p` run exits ZERO and says nothing (`stopReason: cancelled`)**

Measured twice on this host, 2026-08-02, through the governed supervised probe path. `grok --cwd
<repo> --permission-mode plan --output-format json -p "Reply with exactly: GROK_PROVIDER_OK"` exits
0 with `text: ""` and `stopReason: "cancelled"`, having spent input and output tokens and produced a
`thought` showing the model understood the request and considered it trivial ("no tools needed").

**One hypothesis has been tested and REFUTED, which is the useful half of this row.** The first
reading was that `plan` mode has no approval channel in a single-turn run, so the turn is cancelled
when the agent tries to leave plan mode. A second governed live probe with `--permission-mode
default` — the only other value `FORBIDDEN_PERMISSION_MODES` permits this build to emit — cancelled
IDENTICALLY (`docs/evidence/live/phase18e_probe_grok_default_mode_20260802T0245Z.json`). The mode is
not the cause. The pin was therefore NOT moved: changing it would have been a widening bought with
a refuted hypothesis, and the test `TestThePinnedModeSurvivedALiveTest` now carries that refutation
beside the pin so the next reader does not re-spend the call.

**The leading untested suspect, named so the next unit runs one experiment and not five:**
`supervised_probe_runner` passes `stdin=subprocess.DEVNULL` (deliberately — an inherited non-TTY
stdin lets a TUI-capable CLI block forever, U281), and `grok` is TUI-derived. Immediate EOF on stdin
is a plausible cancel signal for such a runtime. The counter-evidence, which is why this is a
suspect and not a conclusion: `agy` ran through the SAME runner with the SAME stdin disposition and
answered. Two other untested possibilities: the job-object boundary, and something specific to
`-p`/`--output-format json` on grok 0.2.118.

**What was measured is the RECON PROBE's argv**, not the headless adapter's:
`GrokCliBackend.build_command` adds `--no-memory` and `-m <slug>` and has never executed at all
(`_LIVE_SPAWN_PATH_WIRED = False`), so `--no-memory` is absent from the suspect list above and
should not be assumed innocent (spec-audit MINOR-4). The two mode constants are pinned equal by
test, so the pin claim transfers; the measurement claim does not.

**Consequence for the phase, stated plainly:** `grok_build` has not answered in either run this
unit made, and no captured document exists in which it ever did (see U311 for the limit on that
claim). The 18E `.live` in-Electron acceptance leg for Grok cannot pass until this is isolated, and
an interactive ConPTY pane is a genuinely different channel that may not share the defect — so the
pane leg is worth attempting on its own evidence rather than being presumed dead. Owner: the 18E
`.live` unit, before its Grok leg.

**No spend allowance is granted here.** This row's first draft ended with "Budget discipline: one
live exchange per hypothesis", which is an app writing itself a permission over an operator-costed
resource — invariant 1, and invariant 30's bar on invented governance layers. It is removed. The
caps are the directive's (§17: one harmless live probe per provider; OP-12.2: one live exchange per
provider) and U312 carries the fact that this unit already exceeded them.

### U311 — **WITHDRAWN RESULT: the recorded live acceptance of `grok_build` rested on U238 hole 2**

Directive §17.2 records, as the standing at 18E's arming, that the operator's own 2026-08-02 recon
probe "succeeded LIVE for BOTH providers — governed gate PASS, real leases 1/1→0, supervised spawn,
exact tokens (`GROK_PROVIDER_OK` / `GEMINI_PROVIDER_OK`), structured output parsed, repo unchanged".
Every clause of that is true for `google_antigravity` and every clause EXCEPT the token is true for
`grok_build`.

That run predates the U238 fix, so acceptance called `extract_provider_text`, whose documented
fallback is the whole JSON document.
`test_the_pre_U238_reader_would_have_ACCEPTED_the_grok_document` drives `accept_probe` itself with
the strict reader swapped back for the best-effort one: the real captured Grok document is ACCEPTED
by the old path and REFUSED by the current one.

**The honest limit on this row, which is a real one** (spec-audit MEDIUM-5). The operator's own
probe document was **never captured** — `docs/evidence/live/` holds no artifact from it — so the
statement "the token it found was the one in `thought`" is an INFERENCE from two later same-day runs
through the same path, not an observation of that run. Had it produced a non-empty `text`, the
pre-U238 reader would have accepted it validly and the acceptance would stand.

So the correction, at the strength the evidence supports: **`grok_build`'s live acceptance cannot be
relied on** — the document it rested on was not preserved, and two later runs through the same path
cancelled with the token only in the reasoning trace. It is not "disproven"; it is unverifiable, and
the reader that produced it is one that would certify a document in which nothing was said.
`google_antigravity`'s stands and has now been re-earned under the strict reader. This is recorded
rather than quietly superseded
because §17.2's account of the world is what armed this phase, and a later reader comparing the
directive to the evidence must find the discrepancy explained here. It also converts U238 from a
constructed-example fix into one with a live instance: the hole was not hypothetical, it had already
certified a provider that said nothing. Owner: closed as a record; the work it implies is U310's.

### U312 — **OPEN, OPERATOR-RESERVED: this unit spent more live exchanges than the directive's cap**

Directive §17 (18C row): "exactly one harmless live probe per provider". §17.2 (OP-12.2): "ONE live
exchange per provider". Carried constraints, §17 and §11 alike: "live exchanges MINIMAL".

`phase-18e.live.shape` spent **three**: one `agy` probe, and **two** `grok_build` probes — the
second to test whether `--permission-mode plan` caused the cancellation. The second one is the
overrun. Both round-1 reviewers raised it independently (gate-validator MEDIUM-6, spec-auditor
MEDIUM-4) and neither was persuaded by the rationale, correctly.

**What the spend bought, stated because it is the operator's to weigh and not a defence:** the
experiment REFUTED the hypothesis, which prevented the permission-mode pin being widened from `plan`
to `default` on a wrong reading. A widening of an emission guard, bought with a misdiagnosis, would
have been the more expensive mistake. The counter-argument is the one that governs: a cap is not the
app's to reinterpret in its own favour (invariant 1), and reading §17's "exactly one" as a floor for
acceptance rather than a ceiling on diagnostics is exactly the kind of self-serving reading
invariant 30 forbids inventing a rule to license.

The unit's evidence report originally quoted §17's "exactly one harmless live probe per provider"
as its AUTHORIZATION line and then reported three exchanges four sections later. That is now
corrected: the checkpoint states the overrun where it states the authorization.

**Nothing is self-authorized to make this right.** No allowance is written anywhere in the repo (the
one that had been drafted into U310 was removed), and the next unit's budget is the directive's
unchanged: one live exchange per provider for the in-Electron acceptance leg. If isolating U310
needs more, that is a question for the operator, not a rationale for the loop.

Owner: **the operator**. The loop records and does not decide (invariant 1). If the operator rules
that bounded diagnostic probes sit outside the acceptance cap, that ruling belongs in the directive
and this row closes citing it; absent a ruling, the cap stands as written.

---

### U313 — **OPEN: the OP-6 providers' panes hold a durable terminal and are NOT Sovereign node records**

Opened 2026-08-02 at `phase-18e.live.electron.wiring`, by the unit that closed the same gap for the
two OP-12 providers.

Invariant 2 says every terminal is a Sovereign node. As of this sub-step a supervised `grok` or
`agy` worker pane writes a `node@1.1` record on the durable append-only node log at ticket time,
moves it to `READY` with the supervised pid when the ConPTY comes up, and closes it at release.
A supervised **`claude_code` or `openai_codex_cli`** pane does none of that: it takes a durable I-X3
terminal, mints a node identity, renders a governed badge — and leaves no record.

**Why it was not just extended to them.** `provider_node_registration` derives every record fact
(node class, capability descriptors) from the adapter that will run, and it has those facts for
exactly the two OP-12 backends. More importantly, OP-12's own supersession list names "existing
claude/codex/ollama/parakeet behavior" as untouchable, and writing durable records for those panes
is a behaviour change to sessions the operator is running today. So the scope is code-pinned
(`REGISTRABLE_PROVIDERS`, derived from the facts table, never re-spelled) and every ticket that
does not get a record says so with this row's id — `registered:false` plus the reason — rather than
omitting the field.

**Not a silent gap and not a security hole:** those panes are gated, leased, counted and supervised
exactly as before; what is missing is the after-the-fact audit record. Closing it is a small,
mechanical extension (the facts for `claude_code`/`openai_codex_cli`, plus `node@1.0`'s enum already
admitting both ids) that belongs in a unit whose scope covers the OP-6 providers.

Owner: a post-18E unit, or the operator's next scoping ruling. State: **OPEN**.

### U314 — **OPEN: a node record can be attested for LIVENESS, never for parentage**

Opened 2026-08-02 at `phase-18e.live.electron.wiring` (spec-audit MAJOR-1, fixed as far as this
build can fix it).

The shell's post-spawn attestation moves a pane's node record to `READY` carrying the supervised
pid. The first cut checked only `pid > 0` while its docstring claimed to "refuse to record READY for
a process nobody observed"; it now checks liveness through `terminal_lease.pid_is_alive` — the
repo's one implementation of that question — so a fabricated or already-dead pid is refused.

**What is still not established, stated so the record is not read as more than it is:** nothing here
proves the attested pid is the pane's own child, or even a descendant of the shell. A live-but-wrong
pid would be accepted. The mechanism that would close it is the pid→job-object handoff **U25** has
owed since Phase 3 (the IPC write op), not a stronger check inside this module. Until then the
record's `READY` means "a live process existed when the shell said its ConPTY came up", which is
what the transition reason says.

Mitigations that make the gap narrow rather than merely disclosed: the caller is the shell's own
launcher, which passes the pid its supervised spawn returned; the attestation is bound to the
SESSION (U315), so it cannot land on another session's record; and the mode is refused outright for
any pane whose ticket wrote no record.

Owner: **U25** / a containment unit. State: **OPEN**.

### U315 — **CLOSED-BY-FENCE at open: pane ids are reused, so a node key alone identifies nothing**

Opened and closed 2026-08-02 at `phase-18e.live.electron.wiring`. Recorded rather than folded into
the commit message because both mandatory reviewers found it INDEPENDENTLY (gate-validator MAJOR-1,
spec-auditor MAJOR-2) and it is the defect class most likely to come back.

The first cut's `attest_spawned` and `close_session_record` took only the node KEY
(`worker-<paneId>`) and acted on "the latest spawn row for it". A pane id is reused across sessions,
so: a record left open by a crashed shell could be attested `READY` with an unrelated later
process's pid, and a late release for session A could write `TERMINATED` against session B's
still-live record. On an append-only log neither row can ever be corrected (invariant 12).

**Closed by making the existing binding a check.** The record's `node_id` uuid is derived from
`f"{node_key}#{session_id}"` and the incarnation — the binding was already there and simply never
compared. `_adopt_for_session` recomputes it and refuses anything that is not this session's
record. Both post-ticket acts go through it; the shell passes the session key it chose; the CLI mode
requires `--session-id`. Two mutation rows (M14, M15) and three tests hold it.

Two related closures from the same review pass, recorded here because they share the cause: the
shell now attests ONLY when the ticket's own `node_registration.registered` is true (so a pane with
no record of its own can never reach another pane's), and a prior incarnation left open by a DEAD
process is reaped on the next registration while one under a LIVE pid REFUSES it.

State: **CLOSED** (fenced, tested, mutation-covered). One reading stays open and is not absorbed by
the word CLOSED: the reap uses the liveness rule the lease ledger uses, so an unanswerable liveness
question neither reaps nor refuses — and see U314 for what liveness can and cannot establish.

### U316 — **OPEN: a failed node-record close is reported and never retried**

Opened 2026-08-02 at `phase-18e.live.electron.wiring` (gate-validator MEDIUM-2).

The release path closes the pane's node record and reports the outcome, and the shell's release
retry is keyed on the LEASE, not on the record. So a close that refuses — a concurrent holder that
outlasts the bounded wait, an unreadable log — leaves an open record with nothing scheduled to try
again.

**What already narrows it, measured rather than assumed:** the next registration for that pane node
REAPS a prior incarnation whose pid is not alive (`_reap_stale_incarnation`, tested), which is the
same rule the durable lease ledger uses for a dead holder. So the leak self-heals on the pane's next
launch, and what remains is the window between a failed close and that launch — during which the
operator's node history shows a node still open.

What is NOT built: a standalone reaper, and any retry on the shell side. Both were judged out of
scope for a sub-step whose job was the wiring; recorded rather than done quietly.

Owner: a post-18E unit. State: **OPEN**.

### U317 - **OPEN, OPERATOR-ACTION: both OP-12 CLIs raise a directory-trust modal the loop may not answer**

Opened 2026-08-02 at `phase-18e.live.electron`, by the FIRST live in-Electron run of the OP-12
acceptance leg. This is the reason `gate/phase-18e` cannot close on a live typed round trip today.

**Measured, three times, on this host.** Both panes launch, paint, settle - and sit on the CLI's own
first-run workspace-consent modal:

* `grok`: "Grok Build may run or modify contents in this directory, posing security risks.
  Yes, proceed / No, quit"
* `agy`: "Do you trust the contents of this project? Antigravity CLI requires permission to read,
  edit, and execute files here. > Yes, I trust this folder / No, exit"

A modal consumes typed text and does not echo it, so the leg's typed prompt reaches no model. The
receipt's first version reported this as "the keystrokes are not reaching the live session" - a
dead-terminal finding about a session that was alive and waiting for a human. That misreport is
FIXED (`paneConsentGate`); the gate itself is not, and cannot be by this loop.

**Why the loop does not press yes.** Answering grants a frontier CLI directory-scoped authority to
read, edit and execute in the operator's workspace - agy's modal says so verbatim. That is a
protected action, and invariant 1 says the app never self-authorizes one. The OP-12 operator
directive s11 puts tool permission under the launch ticket with "no always-approve, no unsandboxed
defaults" and states that a provider CLI's own always-approve setting is never operator approval.
OP-12 authorized live SESSIONS - a statement about subscription terms - and did not delegate the
operator's filesystem-trust decision over their own repository. Both mandatory reviewers were asked
to attack this reading and both judged it correct rather than over-strict.

**What is NOT the reason.** It is not a permission-mode problem: both panes already launch with the
mode this build pins (`--permission-mode plan` / `--mode plan`) and are asked anyway - it is a
directory-trust question, orthogonal to the tool-permission mode. No PERMITTED argv flag dismisses
it; the two that might (`--always-approve`, `--dangerously-skip-permissions`, both in this repo's own
host reconnaissance) are exactly what s11 forbids, and neither was tried.

**Smallest unblocking action (the operator's, one time, per provider):** run `grok` and `agy` once
each from a terminal in this workspace and answer their trust prompts. Then re-run
`node apps/desktop/selfcheck/run.js op12-live-acceptance`; the leg proceeds to the typed round trip
with the directive's budget intact (this unit spent ZERO live exchanges - a gated leg stops before a
prompt is drawn).

**A product question this leaves open, deliberately not answered here:** whether such a modal should
surface in the shell's approval-queue drawer as a protected action rather than sitting invisible
inside a pane. That is design work with an operator decision in it, not a defect fix.

Owner: the operator, then `phase-18e.close`. State: **OPEN**.

### U318 - **OPEN: the append-only chain check verifies linkage, never a recomputed hash**

Opened 2026-08-02 at `phase-18e.live.electron` (spec-audit m-2). `appendOnlyChainIsIntact` checks
`seq` monotonicity, `prev_hash` linkage and hash non-emptiness. A history that was rewritten AND
re-linked passes it. The module's header claims the log "is still a hash chain"; what is verified is
a self-declared linked list. Recomputing each row's hash needs the log writer's exact canonical
form, which lives in `persistence/`; doing it in the shell would duplicate that form and risk a
second spelling of it - the same defect class the OP12_EXECUTABLE projection avoids. Owner: a
post-18E unit. State: **OPEN**.

### U319 - **OPEN: the observed node-pty spawn is bound to a pane by binary path alone**

Opened 2026-08-02 at `phase-18e.live.electron` (spec-audit m-3, m-4). `ptySpawnObserved()` returns
one global last-spawn record carrying no pid, and `paneRunsExactlyThisSelection` binds it to the
pane by comparing the executable path only. Safe as this leg runs it - two different binaries,
strictly sequential, one session at a time - but "the child environment THIS pane was handed" rests
on "some spawn of the same executable". Related and recorded with it: the launched model id is read
off the ticket's argv (`record.argv`), not off the observed spawn's own args, while the docstring
says the model is verified off what was spawned; `spawned.args` is recorded and never compared.
Owner: a post-18E unit. State: **OPEN**.

### U320 - **OPEN: the live self-check MODULE itself has no test or mutation coverage (U296 residual)**

Opened 2026-08-02 at `phase-18e.live.electron` (gate-validator MINOR-5). Every rule the receipt
rests on lives in the verdict module and is falsifiable (28 mutation rows, all RED). The
ORCHESTRATION around them - where the consent gate is checked, that the transcript is captured at
teardown, the `receipt.ok` conjunction - lives in `op12-live-acceptance-selfcheck.js`, which no test
requires except for its `OWED` constant and which no mutation row targets. Those three pieces were
verified by reading and by the live run's own behaviour, not by anything that can go red. This is
the known U296 shape: a rule that runs only at in-Electron emit time cannot be weakened red by any
suite. Owner: a post-18E unit. State: **OPEN**.

### U321 - **OPEN: honesty residuals in the live receipt's presentation**

Opened 2026-08-02 at `phase-18e.live.electron`. Four small ones, recorded together because each is
presentation rather than measurement, and none was fixed in the unit that found them:

(a) on a consent-gated leg the not-applicable fields render as NEGATIVE facts - `probe_falsifiable:
false`, `answer_absent_before_submit: false`, the second of which literally reads "the answer was not
absent before submit". Disambiguable only via `probe_prompt: null` (gate-validator MINOR-4);
(b) `PREFERRED_MODEL`'s comment calls its choices "the cheapest/most minimal option the host
enumerates" with no pricing data anywhere in the path (spec-audit m-9);
(c) the credential sentinels are planted BEFORE the picker and ticket enumerations run, so
placeholder `*_API_KEY` values are in the Electron environment during those emitter calls. Harmless
- they are placeholders and the emitters scrub - but it is an untested interaction (m-8);
(d) restoring the environment after the run reads any REAL pre-existing credential value into a JS
Map for the run's duration (never logged, never written), and the sentinel scan looks only for
sentinels, so a real pre-existing value would not be scanned for in any sink. The inherited comment
"no real credential is ever read" is not strictly true of the restore path (m-7).

Owner: a post-18E unit. State: **OPEN** — see the dated note below.

**2026-08-02, at 18E `.close` (round-2 spec-audit MEDIUM-5): (d) is CLOSED.** §2.2 and OP-12 §13
forbid READING a credential, not only storing one, so the capture-for-restore path was the
prohibition's own words being broken quietly. `sentinelPlan` now SKIPS any name the host already
sets — never read, never overwritten with a placeholder — and the receipt reports the planted and
skipped names (names are this build's constants; values are the operator's). Test + mutation M34.
(a), (b) and (c) remain **OPEN** with the same owner.


### U322 - **CLOSED-BY-CORRECTION at 18E `.close`: the `.live.electron` checkpoint counted three live runs; the durable node log says four**

Opened and closed 2026-08-02 at `phase-18e.close`, by the mandatory gate-validator (BLOCKING-2),
which read the operator's append-only node log instead of the prose. `PHASE18E_LIVE_ELECTRON_
CHECKPOINT.md` reports "three live in-Electron runs (06:35Z, 06:54Z, 07:19Z)". The log carries FOUR
two-provider pane cycles in that window, each under its own Electron main pid - the unreported one
at **06:52:44Z** (`pane-2#78116.1` / `pane-3#78116.2`). Arithmetic settles it without the pids: 18D
left the log at 15 rows, each pane cycle appends 8, and the checkpoint's own receipt records 39 -> 47
- so 24 rows (three cycles) already existed before its final run.

**Why:** the unit counted the runs it wrote RECEIPTS for, and the target writes to one fixed path, so
a superseded run leaves no artifact while the log keeps it. The durable log is the record of what
happened; a receipt is the record of what was published.

**Disposition:** the checkpoint is NOT edited (evidence is append-only) - the correction lives beside
it at `docs/evidence/PHASE18E_LIVE_ELECTRON_CHECKPOINT.CORRECTION.md`, the repo's own convention, and
`PHASE18E_EVIDENCE_REPORT.md` §3 restates the track totals: EIGHT in-Electron live runs, four in
`.live.electron` and four in `.close`. What does NOT change: `live_exchanges_spent` was 0 on every
one of them (a consent-gated leg stops before a prompt is drawn), so no live budget was spent; the
per-leg measurements and U317 stand. What DOES change: the disclosed host cost (D-P18-7/U271) covers
eight picker enumerations, not four.

**The CAUSE is fixed in code, not merely described.** The round-2 reviewers found the first version
of this row claiming `.close` "responded in code" when all it had added was a `unit` label — while
the same fixed path was about to be handed to the operator as a re-run command that would overwrite
the receipt an already-published checkpoint cites by content. The target now emits
`PHASE18E_LIVE_ACCEPTANCE_SELFCHECK_<unit>_<UTC>.json` per run and **overwrites nothing**, so a
superseded run can no longer vanish. The `unit` label and the node-log-derived count stand as well.
State: **CLOSED-BY-CORRECTION**.

### U323 - **OPEN: `paneConsentGate` cannot separate a modal from a model QUOTING one**

Opened 2026-08-02 at 18E `.close` (gate-validator MEDIUM-3). Requiring ALL of a signature's phrases
raises the bar and does not clear it: the single utterance *"Sure. If you meant: Grok Build may run
or modify contents in this directory, then yes, proceed."* matches `workspace_trust` in full. Text
matching cannot decide whether a sentence is a modal or a model repeating one. The docstring claimed
otherwise and now says this, with a test that PINS the current behaviour so a future reader finds the
limitation rather than the claim.

**What bounds it — stated after the round-2 spec-audit corrected the first version of this
paragraph.** The gate is read BEFORE any prompt is typed, when nothing on that screen is a response
to us. But it is read AGAIN after typing, on a leg whose prompt never echoed, so that sentence alone
was not the whole answer and the first version's claim that the paraphrase route is "not reachable in
this check" was wrong. What actually closes it is the companion rule: **a late gate may explain only
a leg that NEVER TYPED** (M29). A pane where a model paraphrases the modal can therefore still be
labelled gated on the pre-typing read; what it can no longer do is explain away a silence after
keystrokes went in — which is the consequence that mattered. Owner: a post-18E unit, or any unit that
moves when the gate is read. State: **OPEN**.

### U324 - **OPEN: the pane credential sink is an ALTERNATE-SCREEN viewport, not a transcript**

Opened 2026-08-02 at 18E `.close` (spec-audit M-2, half). The §17 credential scan calls one of its
sinks "the pane's PTY transcript"; what it reads is `rec.term.buffer.active` at teardown, and both
OP-12 CLIs are full-screen TUIs on xterm's ALTERNATE buffer, which keeps no scrollback. So that sink
is the SCREEN as rendered at the end, not the session's output: material printed and then repainted
over - `agy`'s sign-in phase is the live example - is outside it.

**Fixed in this unit:** the sink is renamed to what it is ("pane screen as rendered at teardown") in
the code, the receipt and the scope note, and no claim of transcript coverage survives anywhere.
**Still owed:** an actual transcript sink, which needs the ConPTY data stream tee'd where the shell
can scan it (the renderer buffer is structurally the wrong place to ask). Owner: a post-18E unit.
State: **OPEN**.

### U325 - **OPEN: the durable lease ledger cannot see a provider CLI the operator ran BY HAND**

Opened 2026-08-02 at 18E `.close` (spec-audit M-5). The live check asserts §17's
no-simultaneous-same-provider-sessions line from the I-X3 ledger (allowance 1 each, `lease_in_use`
1 -> 0) and `leg.no_other_session_live`, which compares the SHELL's own session count to a baseline.
Neither can see a `grok` or `agy` the operator started in a terminal: an unleased session is
invisible to a ledger that only counts leases. The check's own `operator_steps` asks the operator to
run exactly that, to answer the workspace-trust modal (U317).

**Fixed as far as words can:** the scope note and the module header now say it, and tell the operator
to let that hand-run CLI exit before re-running the check. **NOT fixed:** nothing prevents the
overlap or detects it. The honest fix is host-level (enumerate the provider's own processes before
spawning, and refuse), which is U25/U78(a) territory - the containment work this build has owed since
Phase 3. Owner: a post-18E unit. State: **OPEN**.

### U326 - **OPEN: authorization logic lives inside `mcp_server/`, and the delegation hook was wired then left dead**

Opened 2026-08-06 by the cold audit of the seven untagged post-18E commits (finding B1).
`mcp_server/collaboration_service.py:44-46` accepts a `SovereignPolicy`; `grep -n "_policy"` on that
file returns **exactly one line - 46, the assignment**. There is no read anywhere in the file. In its
place, twelve role and permission decisions are made inline (lines 53, 83, 98, 113, 132, 141, 201, 228,
259, 276, 282, 290). The sibling module in the same package does it correctly: `mcp_server/memory_service.py`
calls `self._policy.authorize_*` on nine write paths, and its header states the contract ("every write
path asks the policy first - I-M2 delegation"). `control_plane/policy.py:140` already exposes
`authorize_debate`; `open_debate` performs its own role check instead of calling it.

This is **invariant 7** - *"MCP is access, not authority - no authorization logic inside `mcp_server/`"* -
and it is violated. Consequence: the operator changes a role's authority in `control_plane/policy.py`;
memory operations honour it, every task/message/debate/candidate/synthesis operation does not, because a
second divergent copy of the rules now lives in the one package the invariant names. Authority has
forked. Note that the access control itself is consistently *applied* - the defect is where it lives, not
that it is missing. Fix is mechanical: route the twelve inline checks through `control_plane/policy.py`.
Owner: Phase 19 (directive §18), unit 2. State: **OPEN**.

### U327 - **OPEN: the Grok permission-mode widening, and the refusal rationale that was deleted with it**

Opened 2026-08-06 by the cold audit (finding B2, second half). `adapters/frontier/grok_build.py:90` moved
`GROK_HEADLESS_PERMISSION_MODE` from `"plan"` to `"default"`, and the same change deleted a comment block
recording the **previous** iteration's explicit refusal to make exactly that change:

> "A second governed live probe with `--permission-mode default` was run to test exactly that, and it
> CANCELLED IDENTICALLY. The mode is not the cause, so the pin does not move: changing it would have been
> a widening bought with a refuted hypothesis. The real cause is open (U310)."

`default` is Grok's ask-first mode, so the security delta is materially smaller than the Antigravity
`accept-edits` change the operator reverted under **OP-13** - this is not the same finding. What is owed
is a decision recorded in the open: either keep `default` with a register row stating why the earlier
refusal no longer applies, or restore `"plan"`. Deleting the reasoning and moving the pin silently is what
must not stand. Related: **U310/U311** (Grok's headless `-p` exits zero having said nothing on this host)
remains the unexplained root cause the deleted comment points at. Owner: Phase 19, unit 1. State: **OPEN**.

### U328 - **OPEN: unattended Enter-keystroke injection into live provider panes, unguarded on three of five paths**

Opened 2026-08-06 by the cold audit (finding B3). `apps/desktop/main.js:2476-2497` (`writePanePrompt`)
writes a prompt, waits, writes `"\r"`, and for Codex waits again and writes a **second** `"\r"`.
`notifyNode` (`main.js:2499-2508`) calls it with no guard beyond "is the pane running". `controlAssignTask`
(`main.js:2458`) *does* check readiness. `runConductorReadiness` does not classify the conductor pane's
screen at all before writing to it, and `notifyNode` - reached from `controlNotifyMessage`,
`controlNotifyDebate`, `controlNotifyDebateTurn`, and both deadline/stall notifications - does not either.

Concrete exposure, using this register's own recorded modal text from **U317**: `grok` and `agy` raise a
directory-trust modal whose affirmative option is *"Yes, proceed"* / *"Do you trust the contents of this
project?"*, and answering it grants read/edit/execute over the workspace. If a pane is showing that modal
- a mid-session re-prompt, a new directory, a CLI upgrade that re-asks - when a peer message arrives, the
injected `\r` selects the highlighted default. **The loop has answered the modal invariant 1 forbids it to
answer**, and D-P18-13 says is the operator's alone. For a Codex pane the second `\r` confirms it.

Not reproduced - this is static reading plus the recorded modal text, not an observed event. The existing
mutation harness `tools/mutation/pane_input_bypass_mutations.js` guards the operator->pane direction;
**nothing guards the system->pane direction this range created.** Owner: Phase 19, unit 3.
State: **OPEN**.

### U329 - **OPEN: live provider state is decided by keyword-matching an unbounded terminal scrollback**

Opened 2026-08-06 by the cold audit (finding B4). `apps/desktop/control/provider-readiness.js:17-46` is six
regexes over scraped screen text. Every state the acceptance run reported - `AUTH_REQUIRED`,
`WORKSPACE_TRUST_REQUIRED`, `MCP_PERMISSION_REQUIRED`, `USAGE_LIMIT`, `AWAITING_PROVIDER_SETUP` - is
produced this way, on a **still-running** process where no exit code exists to consult, from `paneScreen()`
which returns the whole retained ring buffer (`main.js:2225-2228`), and it is checked **before** the MCP
connection check (`main.js:2287` precedes `2295`).

This is the rule at `tools/providers/frontier_provider_recon.py:44-49`, inverted: *"A process that exits 0
is a SUCCESS, full stop. Its transcript is never re-read for the words 'login', 'quota', or 'rate limit'
to demote it... keyword matching on a successful transcript once turned working providers into phantom
auth failures."*

Three failure modes. **Sticky state:** Grok's startup promo overlay matches line 41; once dismissed and
fully functional the text is still in the ring buffer, so every subsequent readiness pass returns
`PROVIDER_SETUP_REQUIRED` and never reaches the connection check - no transition out except a fresh pane.
**Self-inflicted false positive:** Sovereign writes the operator's objective into the pane verbatim
(`main.js:2440`), so an objective reading *"investigate why we keep hitting the usage limit on Grok"* trips
line 33 against Sovereign's own echoed text; line 37 (`/\bplan\b[^\n]{0,80}\bgemini\b/i`) fires on *"plan
the Gemini migration"*. **Instrument disagreement already on the record:**
`FINAL_THREE_NODE_ORCHESTRATION_ACCEPTANCE.json` states the headless exit-code-first probe **passed** for
Gemini while the scraper said `AUTH_REQUIRED`, and adopts the scraper's verdict.

`apps/desktop/test/provider-readiness.test.js` asserts the positive case; there is **no negative control**
asserting that a healthy worker whose transcript merely mentions a usage limit stays READY. Fix: consult
exit codes and structured provider signals first; bound the screen window with the existing fail-closed
`RingBuffer.sliceFrom()` (`terminal/session/ring-buffer.js:45-50`) rather than the whole snapshot; add the
negative control. Owner: Phase 19, unit 4. State: **OPEN**.

### U330 - **OPEN: five of seven orchestration writers bypass the transactional path built alongside them**

Opened 2026-08-06 by the cold audit (finding M2). `persistence/store.py:332` provides
`mutate_operational_task` - `BEGIN IMMEDIATE`, mutator, `UPDATE`, `COMMIT`, `ROLLBACK` on every exception
path - with a docstring naming the exact hazard: *"Gemini and Grok publish candidates concurrently. A
Python-process-local lock cannot stop one candidate from overwriting the other."* Only `record_candidate`
(`collaboration_service.py:255`) and `record_synthesis` (`:270`) use it. `create_task` (`:70`),
`update_task` (`:90`), `open_debate` (`:163`), `post_debate_turn` (`:186`) and `close_debate` (`:223`) all
do an unprotected read-modify-write through `put_operational_task` / `put_operational_debate`, which
rewrite the whole JSON blob. The `threading.Lock` guarding them is process-local and each node runs its own
MCP process, so across nodes it guards nothing.

Consequences: a worker's `publish_progress` can silently erase another worker's just-committed candidate,
after which `publish_synthesis` refuses with *"synthesis requires candidates from every worker"* while the
erased worker's pane says it published. Concurrent `post_debate_turn` calls discard one turn and both
return success, after which `close_debate` refuses **forever** because it requires a turn from every
participant; the round-limit check is computed from the same stale snapshot, so concurrent posts can also
exceed `max_rounds`.

**This is latent, not dormant** - it cannot fire until a collaboration leg actually runs, which is also why
it will fire on the *first* successful three-node run rather than being caught before it. That is the
reason OP-13.1 sequences the fix ahead of Path A. `mutate_operational_task` itself is correct and is one of
the better-built things in the range; the fix is to route the remaining five writers through it and an
equivalent `mutate_operational_debate`. Owner: Phase 19, unit 5. State: **OPEN**.

### U331 - **OPEN: conductor readiness is hard-pinned to one vendor and one model, in the range whose lead commit claims the opposite**

Opened 2026-08-06 by the cold audit (finding M1). `apps/desktop/main.js:2344-2348` fails conductor readiness
unless `provider_id === "openai_codex_cli" && model_id === "gpt-5.6-sol"`, with the reason string
*"conductor readiness requires exact OpenAI/Codex gpt-5.6-sol selection"*. Commit `3587cbd` is titled
*"feat(conductor): generalize provider-agnostic conductor selection"* and the selection layer genuinely was
generalized (`control_plane/conductor/registry.py`, `adapters/conductor/provider_commands.py`,
`tools/live/select_conductor.py`); the Electron readiness layer then re-pins it, and neither the commit
message nor any doc in the range discloses the narrowing.

Compounding: `control_plane/conductor/registry.py:154-162` defaults to `claude_code`/`fable-5` whenever
`config/live_operation.json` is absent or has no `conductor` key - and that file is gitignored. Any clone
without the operator's local switch therefore resolves the default conductor, spawns it successfully, then
fails readiness permanently with a message that reads like a configuration error. This also makes conductor
succession onto a different backend - a **Phase 15D exit criterion** - unreachable, and it conflicts with
**invariant 3** (*"conductor is an interface + runtime selection, never a vendor default"*) and **I-CN1 /
D-COND-03** (current selection = fable-5). Owner: Phase 19, unit 6. State: **OPEN**.

### U332 - **OPEN: the synthesis debate gate is bypassable by omission**

Opened 2026-08-06 by the cold audit (finding M3). `mcp_server/sovereign_tools.py:249-253` iterates
`debate_ids` and rejects any debate that is not `CLOSED`, but `_string_list` (`:311-316`) accepts `[]`
without error - unlike `_nonempty_strings`, used for the sibling fields on `:261` and `:264` - and nothing
cross-checks against `list_debates(task_id)`. A conductor that opens a debate, collects turns, never closes
it (or **cannot** close it, per U330), and then calls `publish_synthesis` with `debate_ids: []` passes every
check; `record_synthesis` sets the task `COMPLETED`. The operator is handed a synthesis presented as gated
on debate closure while the debate is still `OPEN`, and the inspector's `open_debate_count` stays at 1
permanently. This defeats the stated purpose of commit `02639d4` ("gate debate candidates and conductor
synthesis"), whose gating is otherwise substantive. Owner: Phase 19, unit 5. State: **OPEN**.

### U333 - **OPEN: synthesis is structurally vendor-bound to Gemini + Grok**

Opened 2026-08-06 by the cold audit (finding M4). `mcp_server/sovereign_tools.py` builds the synthesis
record with hardcoded `gemini_contribution` and `grok_contribution` fields, both listed in the
`required_text` tuple whose absence raises `ToolError`, and both `required` in the published tool schema. A
task completed by any other worker pair - two Codex workers, a Claude worker and an Ollama worker - cannot
be synthesized at all. This contradicts the range's own provider-agnostic framing and the standing
principle that work is dispatched by **capability descriptor, never by model name** (I-SC1). Fix: name the
contributions by node id or descriptor, not by vendor. Owner: Phase 19, unit 6. State: **OPEN**.

### U334 - **OPEN: the control server's `stop()` is the one unbounded await in the quit path**

Opened 2026-08-06 by the cold audit (finding M5). `apps/desktop/control/sovereign-control-server.js:109-118`
awaits `server.close()` with no timeout and no `closeAllConnections()`/`closeIdleConnections()`.
`http.Server.close()` does not resolve while any connection is open. Every other teardown step is bounded -
`manager.shutdown(15000)`, `waitForSessionReleases(15000)`, `waitForChildExit(gatewayProc)` with a 15 s
timer - and `main.js:3108-3116` calls `event.preventDefault()` before this chain, reaching `app.exit()` only
after it returns. An MCP client holding a request open (client timeout 180 s, `sovereign_tools.py:40`) can
therefore leave Electron never exiting and never logging why. `teardown()` (`main.js:2776-2798`), which
bounds and guards every other resource, does not touch the control server at all. Same class as the async
shutdown race found and fixed during the 18E live run. Owner: Phase 19, unit 7. State: **OPEN**.

### U335 - **OPEN: `connectionState` is a latch, not a liveness check**

Opened 2026-08-06 by the cold audit (finding M6). `sovereign-control-server.js:62-66` derives `connected`
from `_lastSeen`, which is set on every request (`:130`) and removed only by `revokeCredential`/`revokeNode`
(`:46`, `:53`) - i.e. on PTY exit. There is no staleness window. A worker whose Python MCP subprocess dies
while its PTY keeps running reports `connected` forever from a timestamp minutes old;
`operationalNodeStatus` (`main.js:2206-2210`) reports `mcp_state: "connected"`, and `controlAssignTask`
(`:2458`) checks only `state === "running" && operationalState === "READY"` with no MCP freshness. The
conductor then assigns work to a node that cannot make a single tool call, and the only recovery is the
600 s hard deadline. Fix: bound `last_seen` age in `connectionState`. Owner: Phase 19, unit 7.
State: **OPEN**.

### U336 - **OPEN: the inspector renders a read failure as a healthy empty orchestration**

Opened 2026-08-06 by the cold audit (finding M7). `apps/desktop/inspector/operational-source.js:60-69`
returns, on **any** error - emitter crash, non-JSON, 15 s timeout, database lock - a fully-shaped success
object: `tasks: []`, `messages: []`, `debates: []`, `summary: {task_count: 0, message_count: 0,
debate_count: 0, open_debate_count: 0}`, with `ok:false` and `error` alongside. `main.js:1726-1735` then
returns top-level `ok: true` whenever the *legacy* inspector source succeeded, regardless of
`operational.ok`. Unless every consumer checks `operational.ok` before reading `summary`, a locked store
renders as "0 tasks, 0 messages, 0 debates" - a read failure indistinguishable from a clean idle system.
Distinguishing "nothing happened" from "I cannot see" is the discipline `terminal/session/ring-buffer.js:38-44`
argues for elsewhere in this codebase. The child-process wrapper around it (`:15-58`) is otherwise well
built. Owner: Phase 19, unit 7. State: **OPEN**.

### U337 - **OPEN: two files in `docs/evidence/receipts/` are operator testimony shaped like machine receipts**

Opened 2026-08-06 by the cold audit (finding B1 of the claims lens, and §6 of the report).
`FINAL_THREE_NODE_ORCHESTRATION_ACCEPTANCE.json` and `FINAL_TALK_WORKER_SPAWN_ACCEPTANCE.json` declare the
schemas `final_three_node_orchestration_acceptance@1.0` and `final_talk_worker_spawn_acceptance@1.0`. A
bounded grep across `apps/`, `tools/`, `mcp_server/`, `persistence/`, `control_plane/`, `node_runtime/` and
`adapters/` returns **no producer for either**. The fields `mcp_connection_evidence` and
`worker_spawn_result` have no emitter. `apps/desktop/selfcheck/run.js` was not touched by the range and has
no orchestration, collaboration, MCP, debate, candidate or synthesis check kind, so **D-P16-0** - every
shell/UI change exercised by an in-runtime self-check writing a machine-readable receipt - is unmet for
every change in the range. Both files carry the identical `recorded_at_utc` of `2026-08-03T13:59:09.3815283Z`,
to the 100-nanosecond tick, despite documenting two different exercises. Machine-emitted receipts in the
same directory carry `check`, `source.commit`, `tracked_product_tree_clean`, `started`/`finished` and a PID;
these carry none.

Three fields assert more than any code path observes: `process_supervised: true` traces to a literal written
on the spawn success branch (`worker-spawn.js:394`), not a re-observation of the process tree; and six
readiness booleans - `provider_authenticated`, `workspace_accepted`, `mcp_discovered`, `mcp_connected`,
`identity_validated`, `permission_resolved` - are set by literal assignment at `main.js:2310-2313` behind a
gate that tests exactly one thing (`connectionState(...) === "connected"`). `workspace_accepted` and
`permission_resolved` represent the operator's own trust-modal answers.

**Provenance gap, recorded separately because it is unrecoverable.** The receipt states
`starting_head: a6dd83f` and `tested_worktree: "uncommitted final-hardening changes over starting_head"`,
with no tree hash and no file list. `a6dd83f..b109f02` is 27 files, +1,195/-147, including `main.js` +457,
the whole of `provider-readiness.js`, all of `mutate_operational_task`, and the `publish_candidate` /
`publish_synthesis` gates. None of that has runtime evidence of any kind, and what *was* tested cannot be
reconstructed. The classifier whose verdicts the receipt reports was written **after** the run it reports on.

**To the range's credit, and recorded so this row is not read as an accusation:** the receipts are candid -
`result: PARTIAL_ACCEPTANCE`, `requirement_mock_legs_equals_zero: false`,
`external_windows.requirement_equals_zero: false`, `full_python: "timed out ... not counted as passed"`, and
a `collaboration` block null in every field. The defect is the **form** of the evidence, not its honesty.
One claim is genuinely instrument-backed: the conductor's `SUM=117` is producible by
`apps/desktop/conductor/roundtrip-probe.js:40-48` (two random integers in [21,99]; 117 is inside the
reachable range) and `runConductorReadiness` requires both a real tool-call count delta and an observed
answer before declaring READY. Owed: either regenerate both receipts from a real emitter, or relabel them so
measured evidence and operator testimony are distinguishable in that directory. Owner: Phase 19, unit 8.
State: **OPEN**.

### U338 - **OPEN: the range's largest change has no executed test coverage, and the suite cannot tell whether its live tests ran**

Opened 2026-08-06 by the cold audit (§7 of the report). Independently executed by the audit on a Linux
bridge: `node --test apps/desktop/test/*.test.js` -> **836 tests, 808 passed, 28 skipped, 0 failed**;
`node --test terminal/test/*.test.js` -> **216 passed, 0 skipped, 0 failed**. The terminal figure matches the
receipt exactly and the desktop figure reconciles with its "836 passed" (on the Windows host `py -3.12` is
present, so the 28 presumably ran there). **The receipt's numbers are not contradicted.**

What the run demonstrates is that all 28 real-subprocess tests, across 17 files, are gated on
`spawnSync("py", ["-3.12", "--version"]).status === 0` and **skip silently**, with the suite still reporting
zero failures. A green desktop suite cannot distinguish "all live coverage ran" from "none of it did". That
includes the range's only two real-process tests, `sovereign-mcp-stdio.test.js` and
`operational-source.test.js`.

Coverage gaps (reported by the coverage reader; headline claims re-verified by grep, not function by
function): **`apps/desktop/main.js` +846 lines has no executed coverage** - the module cannot be `require`d
under `node --test` because it imports `electron`; 26 of 39 new functions appear in no test file, and the
other 13 appear only inside `fs.readFileSync(main.js)` string matches, which cannot distinguish working code
from a syntax error. **`mcp_server/sovereign_tools.py` (405 lines) is tested only against a two-line echo
fake** - all twelve tool handlers, both new authorization gates and every validator are unexercised, and no
`tools/call` is issued end to end anywhere in the range. **Zero concurrency coverage** on
`operational_tasks`/`operational_messages`/`operational_debates` - `mutate_operational_task` (see U330) has
neither a unit test nor runtime evidence. **Mutation O1 in `tools/mutation/orchestration_mutations.js` is
circular** - it mutates a `main.js` source line and grades it with a test that greps that same line; O2-O5
are genuine falsifications against real HTTP and real SQLite, so the harness's "ALL 5 CAUGHT" banner
overstates by exactly the module with the least coverage.

Counterweight, recorded: `tests/unit/test_mcp_collaboration.py` uses a real SQLite database with no mocks and
is genuinely load-bearing, and `apps/desktop/test/worker-spawn.test.js` is the best test file in the
repository - 36 behavioural tests with recording fakes, several documenting the defect they pin *and* why an
earlier draft could not see it, with an honest declaration of its own limits. Owner: Phase 19, unit 9.
State: **OPEN**.

### U339 - **OPEN: the range is ungated with no evidence report, and the Python suite is unverified at HEAD**

Opened 2026-08-06 by the cold audit (finding M8 and §3/§7 of the report). `git tag --contains` is empty for
all seven commits. `git diff b68a22e b109f02 -- docs/registers/` is **empty** - no decision row, no issue
row - despite the range reversing two recorded decisions (D-P18-13 via the `accept-edits` carve-out, now
ruled on as **OP-13**; and the conductor vendor pin against invariant 3, **U331**). No
`PHASE*_EVIDENCE_REPORT.md` was added. All seven commit messages are subject-only, with no bodies, for 59
files and +3,771/-245. Directive §3.5 mandates evidence report -> work commit -> register/evidence commit ->
tag; §7 says evidence before tag. This row and U326-U338 are the retroactive register entries; the gate and
evidence report remain owed to Phase 19.

**Separately owed: the Python suite.** It was not run by this audit and could not be - the bridge to the
host is a Linux VM with no network, Python 3.10 and no `pytest`, against a repo targeting `py -3.12` on
Windows; running it there would prove nothing about the host. There is also **no committed pytest
configuration** - no `pytest.ini`, `pyproject.toml`, `setup.cfg` or `tox.ini`, and both `conftest.py` files
are `sys.path` anchors only - so the 600 s ceiling is imposed by the operator's invocation, not the
repository, and `"focused_python: 363 passed"` names a subset with no committed definition, not reproducible
by a reviewer. 1,772 Python test functions exist across `tests/unit` (72 files) and `tests/integration`
(40 files). Owed: run it on the host with `--durations=20` and, if it hangs rather than crawls,
`--timeout=120 --timeout-method=thread` to name the stuck test; then commit a pytest configuration so the
ceiling and the "focused" subset are inspectable. Owner: Phase 19, unit 10, and the operator for the host
run. State: **OPEN**.
### U327 - **CLOSED at Phase 19 unit 1 by RESTORING the pin** (and the flag that cancelled it)

The settlement U327 asked for, recorded in the open. `GROK_HEADLESS_PERMISSION_MODE` is `"plan"` again on
both paths (`adapters/frontier/grok_build.py`) and in the 18A probe (`GROK_PROBE_PERMISSION_MODE`), and the
deleted paragraph is back verbatim with a dated Phase-19 note appended below it rather than rewritten around
it. The decision row is **D-P19-1**.

**Why `default` was not kept.** The two live receipts the deleted comment cites are still on disk and still
say what it said: `docs/evidence/live/phase18e_probe_document_shape_20260802T0219Z.json` (`--permission-mode
plan`, `accepted: false`) and `docs/evidence/live/phase18e_probe_grok_default_mode_20260802T0224Z.json`
(`--permission-mode default`, `accepted: false`). The widening buys no measured behaviour on this host, so
the earlier refusal has not been overtaken - nothing new was measured between it and the untagged range. The
justification that replaced the comment (`default` is "the installed CLI's normal execution mode"; `plan`
parks the worker in a planning UI) is **not in the installed `grok --help` capture**
(`docs/evidence/live/phase18a_host_recon.json`), which enumerates `[default, acceptEdits, auto, dontAsk,
bypassPermissions, plan]` without ranking or describing any of them. Stating it would be the
inference-as-evidence that round-3 already corrected once (MINOR-16).

**The half U327 did not name, found while settling it: `--no-plan`.** The same range removed `--no-plan`
from `FORBIDDEN_PROVIDER_ARGS` - where 18A had put it, its own comment reading "undoes the pinned plan mode"
- and emitted it beside `default` on all three Grok builders. The capture defines it as *"--no-plan / Disable
plan mode"*. Restoring the pin while still emitting that flag would have restored a value and left the
widening intact under another name, so both moved together: the flag is forbidden again and emitted nowhere,
and `test_no_plan_is_never_emitted_beside_the_pin_that_it_cancels` asserts both halves on all three builders.

**What is NOT claimed.** This is an argument the harness honours, not containment (invariant 29; U25 still
owed). And the pin is a REASONED choice, not a documented ranking - the enum is unranked, exactly as the
restored comment says. **U310 is unaffected and stays OPEN**: Grok's headless `-p` still exits zero saying
nothing on this host, and the mode is still not the cause. If a governed live run ever shows plan mode
blocking a worker, that is a measurement and the basis for an operator amendment; it is not an assumption
this build may make in advance, and that is the whole content of this finding.

Falsification: `tools/mutation/_op13_permission_mode_mutations.py` rows M5 (the value), M6 (the emission) and
M7 (the policy) - 8/8 RED, restores byte-identical. State: **CLOSED**.

### U340 - **CLOSED at Phase 19 unit 1 by REVERTING it: the `--allow mcp__sovereign__*` rule the untagged range introduced**

Opened 2026-08-09 by this unit while executing OP-13, from reading the range rather than from the cold
audit - **no audit finding covers it**. It was opened as OPEN-and-kept, with a code-read justification. The
**spec-auditor's MAJOR-4 on that draft rejected the justification, and it was right**, so the entry records
both the first call and why it changed: silence about a reversed judgement is the same defect this phase
exists to remediate.

**What the range did.** It removed `--allow` from `FORBIDDEN_PROVIDER_ARGS` (18A had it under "tool / trust
widening"), replaced the flat refusal with a single-value exemption inside `assert_no_forbidden_provider_args`
(`SOVEREIGN_GROK_ALLOW_RULE = "mcp__sovereign__*"`), and emitted it on all three Grok builders - the headless
backend, the interactive pane, and the 18A probe.

**Why keeping it was wrong.** (1) The installed capture calls the flag *"Permission allow rule (compat alias:
--allowedTools)"* - provider tool permission granted by an argv, which is precisely what the guard's own
docstring says never happens; the exemption made that sentence false while it stood (spec-audit MAJOR-2).
(2) `D-P18-13` / `U317` - *"a provider CLI's own always-approve setting is never operator approval"* - is a
statement about the CLASS, not about one mode enum, so OP-13's reasoning transfers to it. (3) The rule's
defence was that the application-control server role-checks every Sovereign operation; that is true of
`spawn_worker`/`stop_worker`/`assign_task` and **not** of the collaboration handlers, whose checks are the
inline ones in `mcp_server/` that **U326 is open about and unit 19.2 has not yet fixed** (spec-audit MAJOR-3).
A widening resting on a fix that has not landed is the ordering OP-13.1 exists to forbid. (4) The symmetric
move was available and cheap - the same treatment `--no-plan` got one file over - and no measurement depended
on it (`_LIVE_SPAWN_PATH_WIRED` is False on the headless path; no live pane leg has run since the range).

**What changed.** `--allow` is back on `FORBIDDEN_PROVIDER_ARGS`, the value exemption and the
`SOVEREIGN_GROK_ALLOW_RULE` constant are deleted, and no builder emits an allow rule. **A Grok pane still
REACHES Sovereign MCP** - `.grok/config.toml` declares the server, which is where MCP attachment has always
come from - it simply no longer arrives with its tool calls pre-approved. That is the fail-closed direction
while the authority path itself is still being restored.

**Related, closed with it (spec-audit MEDIUM-6):** the same range wrote `permission_mode = "default"` into the
repo's own tracked `.grok/config.toml`, i.e. this build shipped the node-controlled config that the restored
`grok_build.py` comment names as the threat the pin defends against. The key is removed - the pin lives in the
argv the launch ticket authorizes, one place - and
`test_the_repo_config_does_not_supply_the_value_the_argv_pins` holds it there.

Falsification: `tools/mutation/_op13_permission_mode_mutations.py` rows M8 (policy), M9 (emission) and M11
(the repo config) - 12/12 RED, restores byte-identical. **If a live Grok worker later needs pre-approval to
function, that is a measurement, and the ruling on whether to re-grant it is the operator's** (invariant 1).
State: **CLOSED**.

### U341 - **OPEN: a launch ticket's note was prose, and the range edited it to match a widening**

Opened 2026-08-09 by Phase 19 unit 1, from the gate-validator's MAJOR-1 and the spec-auditor's MAJOR-1 - found
independently by both, which is what makes it worth a register row rather than a line in a diff.

`node_runtime/supervisor/worker_pane_spawn.py` built each pane's launch-ticket `note` as a hand-written
sentence listing that provider's pins. The untagged range widened the two OP-12 argvs **and edited the
sentences to match** (`--mode accept-edits`; "plan disabled"). Reverting the argv alone left the ticket - which
is what the receipts and the shell chrome show the operator - advertising the mode the operator had just
forbidden. **2262 passing tests could not see it**, because a sentence cannot disagree with a list it was
never derived from.

Fixed in-unit for the two OP-12 providers: `describe_pinned_flags(argv, workspace=...)` renders the note's
flag list FROM the argv it describes, and `tests/unit/test_worker_ticket_honesty.py` asserts that every flag
named in a note is in the argv, that any mode value named matches, that no note or argv carries a forbidden
mode, and that the workspace path is described rather than printed. Mutation row M10 restores the
hand-written prose and goes RED.

**Why this stays OPEN:** the `claude` and `codex` branches still carry hand-written notes (e.g. "read-only
sandbox"), and the derivation was applied only where the finding was. They are not known to be wrong today -
they are simply not derived, which is the property that failed here. Owner: Phase 19, unit 10 (extend the
derivation to the remaining two branches, or record why prose is right for them). State: **OPEN**.
### U342 - **OPEN, OWED MEASUREMENT: nothing has observed that an OP-12 pane's MCP attachment survives without the allow rule**

Opened 2026-08-09 by the round-2 spec-auditor (MEDIUM-2) on this unit's own remediation, and accepted.

U340's revert removed `--allow mcp__sovereign__*` from every Grok builder. The code comment
(`adapters/frontier/grok_build.py`), the U340 entry and a test comment all state that a pane **still
reaches** Sovereign MCP because `.grok/config.toml` declares the server. **Nothing has observed that.**
No Grok pane has ever completed a session - 18E stopped at the CLI's own directory-trust modal with zero
exchanges (U317), and `_LIVE_SPAWN_PATH_WIRED` is False on the headless path - and the installed capture
(`docs/evidence/live/phase18a_host_recon.json`) documents `~/.grok/config.toml` for `[ui]` keys without
saying whether a project-local file's `mcp_servers` block is honoured at all.

The auditor's framing is exact and is worth keeping: this unit **declined** to assume argv-versus-config
precedence in one direction (the `.grok/config.toml` `permission_mode` key was deleted rather than
trusted to lose to the argv, citing invariant 29) while **assuming** config-delivered MCP attachment in
the other. That is the same assumption pointed two ways.

**This is not an argument to restore the allow rule.** The revert stands on invariants 1 and 7 and on
the operator's OP-13 reasoning; a pre-approval is not how attachment is supposed to be established
either way. What is owed is a MEASUREMENT: on the first governed live Grok pane, observe whether the
Sovereign MCP server is reachable from the session, and record what was seen. If it is not, the finding
is that OP-12 pane attachment was never wired (invariant 6), which is a bigger fact than the flag was.

Related: **U328** (system->pane writes while a modal is up, unit 19.3) becomes materially more likely to
matter once the first Sovereign MCP call in a pane raises a permission prompt instead of being
pre-approved - which is the fail-closed direction, and exactly why OP-13.1 sequences the blocking fixes
before the live run. Owner: the first live Grok pane leg (Path A), after unit 19.3. State: **OPEN**.
---

## Phase 19 unit 19.2 (2026-08-10) - U326: authority returns to `control_plane/policy.py`

### U326 - **CLOSED at Phase 19 unit 2**: every collaboration role/scope decision is delegated, and the delegation is falsified

Directive s18 unit 19.2 ordered the twelve inline role/permission checks in
`mcp_server/collaboration_service.py` (lines 53, 83, 98, 113, 132, 141, 201, 228, 259, 276, 282, 290)
routed through the policy object the file already held, "exactly as `mcp_server/memory_service.py` does
on its nine write paths", with `open_debate` using the existing `control_plane/policy.py:140`
`authorize_debate`. Done - and the file carried FIFTEEN decisions of that class, so three more moved
with them (115 the recipient scope, 146 the debate participant scope, 172 the debate turn participant).
The audit's own grep now answers the other way: **no role is read anywhere in that file**, asserted by
PARSING the module rather than grepping it, so `getattr(identity, "role")` and `details["role"]` are
covered too. Its only authority code is `_require(verdict)`, which raises a reason it did not compute.
The new surface is in `control_plane/`, never in `mcp_server/`: `authorize_task_create`,
`authorize_task_read`, `authorize_task_update`, `authorize_send_message`, `authorize_message_read`,
`authorize_read_task_transcript`, `authorize_open_debate`, `authorize_debate_turn`,
`authorize_debate_close`, `authorize_debate_read`, `authorize_publish_candidate`,
`authorize_publish_synthesis` - thirteen entry points counting the pre-existing `authorize_debate`.
The three list/read views are filtered BY the policy rather than by a role literal, so a scope change
reaches the views and not only the write paths.

**Two duplicate gates in the same package, not named by the finding, closed with it.**
`mcp_server/sovereign_tools.py:207,245` carried its own copies of the candidate and synthesis role rules
- a third place authority could fork to, in the package invariant 7 names. Both now call the policy, and
`SovereignToolRuntime` takes that policy as a **required keyword** (the U292(a) closure shape - no
manufactured default), which is what makes the tool layer's delegation falsifiable by BEHAVIOUR rather
than by reading its source. The candidate gate got STRICTER as a side effect: it asked only "is this
node a worker", and now asks the real rule ("an ASSIGNED worker") before the candidate artifact is
written into CAS - `test_an_unassigned_worker_is_refused_before_anything_reaches_cas` asserts the CAS
directory is empty after a refusal.

**Falsification - 37 rows, `tools/mutation/_op19_policy_delegation_mutations.py`, 37/37 RED, restores
byte-identical.** The rows are in three groups and the group is part of each row's claim. **Group A
(P1-P16l except P16):** one rule changed in `control_plane/policy.py`, graded by a test that never
mentions the policy - it calls `CollaborationService`. This is the group the unit spec demands.
**Group B (P16, P17-P19):** clauses the collaboration path cannot reach - the cross-project scope
clauses (the store scopes reads by project before the policy is asked) and the update rule (the read
rule answers first, which is U343). Graded by direct-policy tests, labelled `[direct-policy]` in the
row name so the output says it too. **Group C (P20-P26):** the delegation itself, both directions
(delete the policy call; re-inline the rule beside it) on both layers and both tool-layer gates, all
seven graded behaviourally. The proof that a DUPLICATE cannot hide is
`TestAPermissivePolicyReachesPastEveryRule` - one operation per entry point, each performing something
the shipped policy refuses and requiring it to SUCCEED under an injected policy that allows it - plus
`test_every_policy_call_the_service_makes_is_covered`, which parses both `mcp_server/` modules for the
policy calls they make and asserts none escapes that list.

**Seven behaviour deltas, MEASURED.** `tools/evaluation/u326_before_after.py` (TRACKED, and pinned to
base `b529314`; the first version lived in the gitignored `docs/loop/logs/` and read `HEAD:`, so
committing the fix turned it into a comparison of the new module with itself - both round-2 reviewers
caught that independently) imports the pre-unit module beside the current one and runs 34 scenarios
against both: **19 DIFF, reducing to seven deltas plus two arithmetic consequences.** (1) **`voice`
becomes a scoped role - reads AND writes**: before, a voice identity could read and CANCEL any task in
the project; everywhere else in the policy `worker` and `voice` are already paired. Fail-closed.
(2) **`gate` may now open a debate** - directed by the unit spec's instruction to use
`authorize_debate`, whose role set is `worker/conductor/gate/operator` (I-DS1); `voice` is refused by
both. A widening, recorded as one, with its uncapped-cost consequence at U349. (3) **A malformed role
is refused where it used to be served** - before, an identity with a role outside `ROLES` read and
listed every task and debate in the project. (4) **Read authority now precedes state disclosure on
debates** - a non-participant posting to a CLOSED debate is told it is not a participant rather than
that the debate is shut; existence within the caller's own project is still disclosed by the lookup,
and that is stated rather than claimed closed. (5) A reason-string change on `voice open_debate` (the
canonical rule's sentence now). (6) `open_debate` with an empty participant list against a NONEXISTENT
task reports the participants rule instead of "no such task", because the caller rule is deliberately
asked before the task lookup. (7) A scoped non-owner's `record_synthesis` meets the scope refusal
instead of the role refusal, because the round-2 remediation put `_require_task` in front of the one
write path that skipped read authority. **Everything else in the 34 scenarios is identical**,
including every refusal the fifteen checks existed to produce. Outside the matrix: an unassigned
worker's `publish_candidate` refusal now surfaces as `CollaborationError` rather than `ToolError`,
because the tool layer fetches the task through the service, and the JSON-RPC boundary prints the type
name. `gate` is deliberately NOT in `_SCOPED_ROLES`, so it has project-wide read plus debate-open
authority; what it can and cannot do is asserted rather than named (U349). No `gate` or `voice`
identity reaches this path today - the only production `CollaborationService` constructor is
`sovereign_tools.py:90`, whose identity comes from the application-control channel, which issues
`conductor` (`apps/desktop/main.js:875`) and `worker` (`:1885`), both literal.

Evidence: `docs/evidence/PHASE19_UNIT2_U326_POLICY_DELEGATION_CHECKPOINT.md`, whose s5 records all
review rounds and what each changed. Guards: `tests/unit/test_collaboration_policy_delegation.py`.
**What CLOSED does not claim:** that `mcp_server/` is free of every kind of gate (U344); nor
single-point-of-change across the product - `apps/desktop/main.js` holds a fourth copy for the Electron
control surface (U345); nor that the structural assertions are unevadable (a `getattr(identity,
"ro"+"le")` spelling defeats any static check, which is why the load-bearing proofs are the
permissive-policy suite and the verdict matrix); nor that the rules are RIGHT - they are the rules that
were already being enforced, moved to where the operator can change them once. State: **CLOSED**.

### U343 - **OPEN (assertion-of-current-behaviour): checks that could never fire, found while relocating them**

`update_task` and `send_message` both call `_require_task` first, whose scoped-role clause tests the SAME
condition as the check that followed it. **`worker may update only an assigned task` was
UNCONDITIONALLY dead**: byte-identical condition, same `_scoped()` helper, and widening the read scope
widens both together - so no input and no future scope change can make it live. The round-1 draft kept it
with the justification "the read scope may widen"; the gate-validator proved that false, and it is NOT
carried forward. `authorize_task_update` is a distinct entry point returning the read verdict, and
`TestTheUpdateRuleIsTheReadRule` asserts the two agree for six identities - if update authority ever
diverges from read authority it diverges in `control_plane/`, and that test is where it shows.
**`sender is not a participant in this task` is shadowed on the service path but LIVE for a direct
caller** - deleting it changes an observable verdict - so it stays, marked `SHADOWED (U343)` and pinned
by `test_the_sender_rule_is_live_for_a_direct_caller`. `record_candidate`'s owner half is shadowed the
same way; its role half is reachable. **`record_synthesis`'s `_require_task` call is a third instance**,
found by the round-3 gate-validator: only directing roles pass the synthesis gate and neither is scoped,
so that read can refuse on project/existence and never on authority - live, not decorative, and pinned by
`test_synthesis_asks_task_read_before_it_publishes` and mutation P26. No test could previously have told
a live rule from a dead one here - the same blindness as B1 itself. **A fact about the pre-existing code,
not a defect this unit introduced.** Owner: whoever next changes task read scope. State: **OPEN**.

### U344 - **OPEN: lifecycle-legality rules that are not role checks still live in `mcp_server/`**

Found by the round-1 spec-auditor against this unit's first docstring, which claimed the module "decides
nothing about who may do what" - an absolute the same file falsified. The docstring now makes the narrow
claim (no ROLE OR SCOPE decision) and names the residue: the bounded-debate round limit and the
`max_rounds`/`budget_units` range checks (invariants 14/17); the "a debate may not close without a turn
from every participant" quorum; "synthesis requires candidates from every worker"; the `debate is not
open` state gate; the referential checks that a candidate names only messages and debates that exist; and
the CANDIDATE-status check (`sovereign_tools.py` adds "synthesis requires every considered debate to be
closed"). **The reason they stay is not the untouchable set** - that argument covers the debate rules
and, as the round-2 auditor correctly said, does NOT cover synthesis completeness. The reason is that
none of them asks WHO the caller is: they ask what has already happened. That is lifecycle legality,
which this package has held since Phase 3A - `memory_service.py` calls
`mcp_server/lifecycle.validate_status_transition` for legality and `control_plane.policy` for authority,
in that order. The same reasoning answers the round-1 finding that `control_plane/policy.py` imports
`is_promotion` from `mcp_server/lifecycle`. **The closest call, named by the round-3 spec-auditor and
carried here rather than folded away:** the CANDIDATE-status check is the SHAPE half of a rule whose
*who* half is `control_plane/policy.py:authorize_publish` ("workers may publish only CANDIDATE
entries"), so it can drift from its twin even though it never reads a caller. The round-4 auditor judged
keeping it correct and the disclosure honest. **What is owed:** the boundary is argued here rather than
ratified anywhere. Owner: an operator ruling, or the unit that formalizes the operational task/debate
lifecycle as a state machine. State: **OPEN**.

### U345 - **OPEN: a FOURTH copy of authority, in `apps/desktop/main.js`, and it is stricter than the policy**

Found by the round-1 spec-auditor. `apps/desktop/main.js:2012` defines `requireControlRole` and gates the
control operations by role literal at 2384, 2398, 2429, 2452 and 2552 - inside the Electron main process,
so invariant 7's letter (which names `mcp_server/`) is not violated. But 2452 requires `"conductor"` for
`controlAssignTask`, where `control_plane/policy.py`'s `_DIRECTING_ROLES` admits the **operator** as
well: an operator identity may create an assignment per the authority and be refused delivery by the
shell. That is the fork U326 describes, one layer out, and **no Phase 19 unit owns it** - 19.9 covers
`main.js` TESTABILITY, not authority relocation. The round-4 auditor adds a neighbour: `controlNotifyDebate`
(`main.js:2533-2540`) carries no `requireControlRole` gate at all, only an opener-identity match.
Recorded so the claim "change it once in `control_plane/`" is not read as product-wide. Owner: unowned;
candidate for the unit that extracts `main.js`'s orchestration modules (19.9). State: **OPEN**.

### U346 - **OPEN: an assigned owner can set ANY task state, `ACCEPTED` and `COMPLETED` included**

Found by the round-1 spec-auditor and sharpened at every round since. `authorize_task_update` returns the
read verdict, which admits any assigned owner, and `publish_progress`'s tool schema advertises the whole
`TASK_STATES` enum to worker nodes. So a worker calls `publish_progress(status="COMPLETED")` and the
shared task record says COMPLETED without a synthesis, bypassing `record_synthesis`'s completeness rule -
and `publish_progress(status="ACCEPTED")` puts the task in the ACCEPTED state directly. **`ACCEPTED` is a
reachable state, not a spelling problem**: it is also the promotion vocabulary `mcp_server/lifecycle`
guards for memory entries (where reaching it is gate/operator-only, I-M6), and the two lifecycles being
unrelated is exactly what makes the shared word dangerous to the next reader. **The round-4 auditor
found the half nobody had named: it is not only workers.** A `voice` identity named as a task owner
passes the same read rule, so it may drive a task to COMPLETED while being explicitly refused
`publish_candidate` with "only an assigned worker may publish a candidate" - two rules on the same
surface disagreeing about what a voice identity may do to the same task (invariant 25 adjacent). Not
live today: the control channel issues only `conductor` and `worker` literals. Pre-existing - the rule
moved unchanged - but this unit is what made it the canonical rule in the authority of record.
Owner: whoever specifies the operational task lifecycle as a state machine. State: **OPEN**.

### U347 - **OPEN: `peer_nodes` is advertised to workers but is not in the task authority set**

Found by the round-1 spec-auditor. `_task_participants` is owners + creator, faithfully preserved from the
inline check. But `peer_nodes` is a first-class conductor-settable field, and the assignment prompt
written into a worker pane names it ("Peer nodes: ..."), so a worker told to talk to a peer that is not
also an owner gets `cross-task recipient denied`. Existing coverage could not see it because
`tests/unit/test_mcp_collaboration.py` sets `peer_nodes` equal to the owners; mutation P16d and
`test_a_peer_node_that_is_not_an_owner_is_outside_the_authority_set` now pin the current behaviour so a
widening cannot happen by accident. Either the field is authority-bearing or it should not be advertised;
both are decisions, and neither is this unit's. Owner: the unit that next changes assignment shape.
State: **OPEN**.

### U348 - **OPEN: transcript authority is not task-scoped, and a scoped read is unflagged**

Found by the round-1 spec-auditor. `authorize_read_task_transcript(identity)` takes no task, so any
conductor/operator in the project may read ANY task's full transcript - expressing "the conductor OF THIS
TASK" needs a task-scoped conductor identity the build does not have. And a non-directing caller passing
`include_all=True` is silently downgraded to the filtered view: `read_messages` returns `{messages,
count}` with no signal that scoping occurred, so a model receives a partial transcript believing it is
whole. Invariant 8 is honoured; "everything observable" (Buildout s4) is not. Recorded with it:
`_require_debate` now asks read authority before returning, but the store lookup itself still discloses
that a debate EXISTS in the caller's own project before any rule is consulted - unavoidable without a
second index, and stated rather than claimed closed. State: **OPEN**.

### U349 - **OPEN: the `gate` debate widening is directed, and the collaboration debate path is uncapped**

Opened by the round-3 spec-auditor (MEDIUM-4), confirmed and sharpened by round 4. Directive s18 unit 19.2
ordered `open_debate` onto `authorize_debate`, whose role set is `worker/conductor/gate/operator`
(I-DS1's first clause: any authorized node may REQUEST a debate). That is the widening, and it is
directed. **What was not disclosed is what the widening costs.** I-DS1's second clause - "the
Scheduler/Permission-Broker gate who may request **and enforce budgets**" - and Plan s19.2's
quota/budget requirement are **not implemented on this path**: `budget_units` is range-checked and
written into the debate record and then **never read anywhere in the repo**, and there is no
`CostGovernor`, unlike `debate_service/service.py:74-84` which opens and closes against a global cap, a
per-caller quota and a per-debate budget. The cost is real: `open_debate` reaches
`apps/desktop/main.js controlNotifyDebate`, which writes a prompt into every participant's pane and arms
a turn deadline for each. So a `gate` - deliberately outside `_SCOPED_ROLES`, hence project-wide - can
now compel two workers to spend turns on any task in the project, uncapped. **Invariant 17 is not
honoured on this path**, before or after this unit; the unit added one role to an already-ungoverned
path. A stored budget field that no code consults reads as governance to the next reader, which is the
part that must not stay silent. Owner: the unit that wires the cost governor into the collaboration
debate path (or the operator, if the `gate` role's debate authority should be revoked instead).
State: **OPEN**.

### U350 - **OPEN: a directing role may close a debate it argued in (invariant 18 on the collaboration path)**

Opened by the round-4 spec-auditor (MEDIUM-1). `_task_participants` includes the task's creator, which is
always the conductor, so `open_debate(COND, participants=[W1, COND])` is authorized; `authorize_debate_turn`
then admits COND because it is a participant; `close_debate` REQUIRES a turn from every participant, so the
conductor is *forced* to post a position - and `authorize_debate_close` then admits it on role membership
alone, with no check that the closer is not a participant. The conductor writes `decision`, `agreements`,
`dissent` and `unresolved_points` for a debate it argued in. **Invariant 18 - no node solely judges its own
work - is enforced elsewhere and not here:** `debate_service/service.py:63-68` enforces it explicitly, and
`control_plane/policy.py` denies gate self-judging by name on both the publish and transition paths.
Faithfully preserved pre-unit behaviour, not a regression - and now a property of the authority of record,
which is why it is written down. The neighbouring widening (an opener who is NOT a directing role closing
its own debate) is pinned by mutation P16l/P16k and the verdict matrix; the invariant-18 case above is
current behaviour and is pinned as such in the matrix, not fixed. Owner: the unit that wires invariant 18
into the collaboration debate path, with U349. State: **OPEN**.

### U351 - **OPEN: `mcp_server/server.py` still manufactures its own policy, and the pre-U326 rules are pinned in the deny direction only**

Opened by the round-4 gate-validator (MINOR-2/MINOR-3). Two things this unit's scope did not reach:
(a) `mcp_server/server.py:32` does `self.policy = SovereignPolicy()` - the U292(a) "manufactured default"
shape this unit removed from `SovereignToolRuntime`, where the required-keyword form is what makes the
tool layer's delegation falsifiable by behaviour. Same object, same construction, one file over;
(b) the policy's PRE-U326 memory rules are pinned by their deny statements and not by their membership
sets - dropping `conductor_file` from `_OPERATOR_ONLY_KINDS` survived `tests/unit`. That is the same class
as the four rounds of findings on the collaboration rules, on the Phase-3A half of the same module, and
the verdict-matrix approach (U352) is the shape of the answer if someone extends it there. Neither is
U326's scope; both are recorded because this unit is what established the standard they fall short of.
Owner: unowned. State: **OPEN**.

### U352 - **CLOSED by construction, and recorded as a method: the verdict matrix**

Four consecutive review rounds found the SAME defect class on this unit - a deny statement pinned by a
test while the membership set or scope clause behind it was not, so widening it left the whole suite
green. Round 1: `_SCOPED_ROLES`. Round 2: `_DIRECTING_ROLES` toward `gate`, plus three more. Round 3: five
more (`authorize_message_read`, the debate read scope, the candidate rule's role half, `ROLES` itself,
`record_synthesis`'s task read). Round 4: three more (`_DIRECTING_ROLES` toward `voice` - four authorities
at once, invariant 25; the debate closer's identity; `authorize_open_debate`'s subset absorbing the
caller). Each round pinned what the round before it found, and the next reviewer found the next one.
**One-off tests cannot end that**, and saying "we will be more careful" is not a falsification.

`TestTheWholeVerdictSurfaceIsPinned` is the structural answer: every role the policy admits, driven
through every collaboration operation on a deterministic world, with the exact observed outcome recorded
as a 136-cell table. Any change to any rule - widening or narrowing, statement or membership set - moves
a cell, and a moved cell fails until someone regenerates the table on purpose and justifies it the way
s2 of the evidence justifies the seven behaviour deltas. It goes through `CollaborationService` and never
names the policy. Regeneration is a documented, deliberate act:
`py -3.12 tests/unit/test_collaboration_policy_delegation.py`.

**What it does not do:** it covers the collaboration surface only (not the Phase-3A memory rules - see
U351), it cannot see a rule whose effect is invisible in a verdict string or a list length, and a
sufficiently determined re-inline spelled to defeat static analysis is caught by the permissive-policy
suite rather than by this. Recorded as a method because the next unit that adds an authority surface
should build its table with it. State: **CLOSED (in place; the method is the deliverable)**.
### U353 - **OPEN (recorded limit of the U352 method): the verdict matrix pins ONE world, and a rule whose input that world never presents is invisible to it**

Opened by the round-5 gate-validator, and it CORRECTS U352 above, which the register cannot edit
(append-only, directive s2.6). U352's row says *"Any change to any rule - widening or narrowing,
statement or membership set - moves a cell"*, and its "what it does not do" paragraph names three
limits, none of which is this one. **That sentence is too strong and is superseded by this row.**
The true claim, which round 5 attacked in both directions and could not falsify, is narrower: no
change to `_SCOPED_ROLES` or `_DIRECTING_ROLES` can pass the table. U352's other sentence, *"It goes
through `CollaborationService` and never names the policy"*, is likewise imprecise - the matrix
helper CONSTRUCTS a `SovereignPolicy()` to build the service; what is true, and what the claim was
reaching for, is that no policy METHOD is called by the grader.

Four widenings were demonstrated GREEN against the whole suite (2,331 passed, 1 skipped) on the
round-5 tree, each an input the PRODUCT path can actually produce (2-4), and each widening a read
the policy otherwise refuses (invariant 8). Widening 1 is the exception in both respects and is
labelled as such: it benefits an identity carrying a role outside `ROLES`, which no production path
issues today (`apps/desktop/main.js` hard-codes `conductor` and `worker` - U346). Widening 4's reach
is cross-participant visibility INSIDE a task the caller already reads, not a project-wide read,
because `read_messages` calls `_require_task` first:

  1. `_unknown` admitting one extra name (`identity.role in ROLES or identity.role == "auditor"`).
     `ROLES` itself is pinned - by `test_the_table_covers_every_role_the_policy_admits` and by
     P16i's behavioural grader - but the MATRIX does not pin it, because no identity in the world
     carries the added name and so no cell moves. The class docstring now says this.
  2. `authorize_task_read` returning ALLOW when `task["status"] == "COMPLETED"`. Reachable:
     `publish_progress`'s schema advertises `COMPLETED` to worker nodes
     (`mcp_server/sovereign_tools.py:349`, which is U346's own subject).
  3. `authorize_debate_read` returning ALLOW when `debate["state"] == "CLOSED"`. Reachable: it is
     the ordinary post-`close_debate` state. The world does create one; what it never does is put
     one in front of a policy call: every call that is handed an EXISTING debate (`get_debate`,
     `list_debates`, `post_turn`, `close_debate`) is made while that debate is still OPEN, and the
     debates opened after the close are likewise open when their rules are asked.
  4. `authorize_message_read` returning ALLOW when `message["message_kind"] == "decision"`.
     Reachable: `decision` is an advertised kind (`mcp_server/sovereign_tools.py:347`).

The class is NOT the four rounds' class (a membership set behind a pinned deny statement) - round 5
re-attacked every constant with its own spellings and all went RED, in both the addition and the
removal direction. It is the adjacent one: the INPUT SPACE, not the observation. Effects 2-4 would
be perfectly visible in a verdict string; the input simply never occurs in the single deterministic
world. So the method (U352) stands and the absolute does not. Owner: whoever next extends the matrix
- widen `_matrix_world` before trusting the table with a rule of a new SHAPE, and the four mutations
above are the acceptance test for that widening. Also recorded here:
`docs/loop/logs/_append_register_19_2.py` (untracked generator) holds the superseded U352 text
verbatim; it refuses to append while those rows exist, so it cannot re-emit them, but anyone who
reads or reuses it meets the uncorrected sentence. State: **OPEN**.

### U354 - **OPEN, and it CORRECTS U350: the invariant-18 case is pinned NOWHERE, not "pinned in the matrix"**

Opened by the round-5 spec-auditor (its one MAJOR). U350 above ends *"the invariant-18 case above is
current behaviour and is pinned as such in the matrix, not fixed"*, and s5.4 of the unit's evidence
says the same. **That mitigation does not exist.** `_open_then_close` always opens the debate over
`participant_node_ids=[W1, W2]` and always posts the two turns AS W1 and W2, whoever the closer is.
So for `conductor(creator)` and `operator` the closer opened the debate but never argued in it, and
for `worker(owner)` the closer argued but is refused on role: **no cell has a directing role that
posted a turn and then closed.** Concretely - adding `the closer must not be a participant` to
`authorize_debate_close`, which is exactly the U350 fix, moves ZERO cells when appended after the
`_DIRECTING_ROLES` check - no directing identity is a participant in this world. (Prepended it would
move two cells, and a participation-keyed WIDENING that reaches a worker moves
`worker(owner) | close_debate` to `ok`; the mirror widening that moves nothing is one restricted to
directing participants, which is already the behaviour. The invariant-18 fix is the one that is
invisible.) The neighbouring case (a non-directing OPENER closing its own debate) IS pinned, by P16k
and the matrix; that is the one U350 conflated with this one.

The disposition is unchanged and stays honest: the behaviour is faithfully pre-unit, invariant 18 is
enforced in `debate_service/service.py:63-68` and on the policy's publish/transition paths and never
on this one, and unit 19.2 was not authorized to redesign it. What changes is the collateral: U350's
"recorded rather than fixed" is backed by a record ONLY, not by a pin. Pinning it requires a matrix
world in which a directing role is a debate participant - which moves cells and therefore needs a
deliberate regeneration. Owner: with U349/U350, the unit that wires invariant 18 into the
collaboration debate path. State: **OPEN**.

### U355 - **OPEN: `authorize_debate_turn` has no role clause, so a `voice` participant may post debate turns (invariants 24, 25)**

Opened by the round-5 spec-auditor. `control_plane/policy.py`'s `authorize_debate_turn` admits any
node in `participant_node_ids` with no role test. Nothing forbids a conductor from naming a `voice`
node a task owner (the matrix world itself does) and then a debate participant; that voice node then
posts reasoning turns. It contradicts this module's own stated rationale a few methods up - *"voice
is a transducer, not a reasoning caller"* - which is why `voice` is refused `open_debate`. Invariant
25: voice cannot expand authority.

**Recorded, not patched, deliberately.** Iteration 120's standing rule, set before round 5 ran, is
narrower than this finding and is applied by EXTENSION, not by silently renaming its class: it says
a sixth instance of the *membership-set* class belongs in U352's coverage record, not in a sixth
patch. This is the adjacent class (U353 says so explicitly), and the same reasoning governs it -
patching the rule, or widening `_matrix_world` so a voice identity participates, moves cells. Patching the rule - or widening `_matrix_world` so
a voice identity participates - moves cells, which is a code change, which voids round 5 and buys a
round 6 on the same tread. This is the trap that produced rounds 2, 3, 4 and 5. The register takes it
instead. Pairs with U346's voice-as-owner half. Owner: the unit that wires invariants 18/25 into the
collaboration debate path, with U349/U350/U354. State: **OPEN**.

### U356 - **OPEN: the U326 mutation harness cannot distinguish "the guard caught it" from "the target was already red"**

Opened by the round-5 spec-auditor. `tools/mutation/_op19_policy_delegation_mutations.py` grades a
row RED purely on the selector exiting non-zero UNDER the mutation; no row runs its selector on the
unmutated tree first. A target broken for an unrelated reason would report RED and prove nothing.
The 37/37 result is nonetheless sound TODAY, because the collateral is external and recorded: the
full Python suite is green on the same tree, so every target passes unmutated by construction. What
overstates is the harness's own output, which is why the limit is now written in its docstring.
Fix when someone next touches that file: one baseline pass per distinct target (or a single
pre-flight run of the delegation selector asserting exit 0) before the loop. The same shape applies
to every mutation harness in `tools/mutation/`; this row names the one that was audited.
Owner: unowned. State: **OPEN**.

### U357 - **OPEN: two accuracy corrections to rows this unit wrote (U344, U346)**

Opened by the round-5 spec-auditor and gate-validator; append-only, so the corrections are here.

(a) **U344's residue enumeration is incomplete.** It lists what stays in `mcp_server/` as legality
rather than authority and omits `mcp_server/sovereign_tools.py:223-226`, the check that a claimed
candidate provider/model matches the authenticated node identity. It IS an identity-derived refusal
living in the MCP package. The classification that survives scrutiny is provenance/identity binding
(invariant 11) rather than role authority (invariant 7) - the tool layer is asserting that a node is
who it says it is, not deciding what a role may do - but U344's job is to enumerate the residue so
the boundary is argued in the open, and it did not name this one. The unit's evidence s7 does.

(b) **U346's "Not live today" is true of the voice half only.** The worker half IS live on the
product path: worker identities are issued (`apps/desktop/main.js:1885`), `publish_progress`'s schema
advertises `ACCEPTED`/`COMPLETED` to worker nodes, `update_task` accepts both, and
`apps/desktop/main.js:2137` treats `COMPLETED` as terminal - so an assigned worker can clear its own
deadline today. U346's severity is therefore higher than its own closing sentence implies. Also
imprecise: `publish_progress` advertises 9 of the 11 `TASK_STATES` (it omits `CREATED`/`ASSIGNED`),
not the whole enum; the load-bearing half - `ACCEPTED` and `COMPLETED` are reachable by a worker - is
true. Owner: as U346. State: **OPEN**.

### U358 - **OPEN (process, for the Phase 19 gate): unit 19.2 opened fifteen open rows that Phase 19's exit criteria do not cover**

Opened by the round-5 spec-auditor as a process observation, recorded because it is the difference
between "recorded rather than fixed" and "recorded and orphaned". Unit 19.2 opened U343-U351 (plus
U353-U358 at round 5); Phase 19's exit criteria in directive s18 cover **U326-U339 only**, and several
of the new rows carry `Owner: unowned` or "whoever next touches it". Nothing in the phase plan closes
them, and the phase's own exit sentence ("every one of U326-U339 either closed with evidence or
re-recorded with a reason") will read as satisfied while these sit outside its scope. Action, and it
is small: the `gate/phase-19` evidence report at unit 19.10 must enumerate every row opened DURING
Phase 19 alongside U326-U339, with an owner or an explicit "no owner, carried" for each, so the
operator sees the full ledger the phase produced rather than only the ledger it was handed.
Owner: unit 19.10 (the phase gate). State: **OPEN**.
### U359 - **OPEN: a live integration test is green only when the machine is quiet**

Found at round 5 of unit 19.2 while re-measuring, and recorded because the loop will meet it again.
`tests/integration/test_opencode_candidate_live.py::test_live_drive_then_governed_candidate_and_merge`
FAILED on the first integration run of the corrected tree (1 failed, 477 passed) - a run taken while
a reviewer subagent was working in the same repository. Re-run alone: **478 passed** in 593.98 s. The
test alone: **1 passed** in 68.03 s. It drives a live local harness, so its budget is wall-clock and
its verdict is load-dependent. Nothing in the round-5 change is executable, so the failure cannot be
attributed to it, and the reported numbers are the quiet-machine ones - but *green when nothing else
is running* is a weaker property than green, and this loop routinely runs suites while subagents work
in the same tree (the same collision discarded a set of numbers at iteration 120). Action: give the
test a load-independent budget, or mark it so a run summary reports it separately rather than letting
it turn a whole suite red. Owner: unowned. State: **OPEN**.

### U328 - **CLOSED IN PART at Phase 19 unit 3**: no system write reaches a pane unclassified; the classifier is a denylist (U363)

Directive s18 unit 19.3 ordered `notifyNode` and `runConductorReadiness` gated on
`classifyProviderScreen` returning null before any `writePanePrompt`, as `controlAssignTask`
(`main.js:2458`) already did for assignment, and the mutation harness extended to the SYSTEM->PANE
direction. Done, and the gate was placed one level lower than the order named: on the **write path**
(`apps/desktop/control/pane-writer.js`), not on the two callers. The reason is the acceptance
standard the unit itself sets - invariant 1 and D-P18-13 make it "unable", not "unlikely" - and a
gate on two named callers is a gate a third caller can forget. `main.js` now holds exactly three
`manager.write(` sites (the voice conductor-write binding, the `pane:input` handler that carries the
operator's own keystrokes, and the pane-writer io); a fourth is a new ungated path by construction,
and the wiring suite counts them.

**Every write is classified, the submit keys included.** The provider draws its permission prompt IN
RESPONSE to the body just pasted, so a check before the body alone leaves exactly the window the
modal opens in - and the body is harmless noise while the Enter behind it is the answer. Codex's
second (confirm) Enter is gated too. A withheld submit is reported as `residue_possible`, because the
body is then sitting in the provider's input box and a caller that read it as "nothing happened"
would be wrong.

**Falsification:** `tools/mutation/system_pane_write_mutations.js`, 17 mutations across the two files
(the gate never refuses; unreadable treated as consent; a truthy non-boolean opening it; the submit
key unchecked; the codex confirm Enter unchecked; `notifyNode` reaching the PTY directly; a
sessionless pane called legible; the exclusion blanking the screen or reverting to exact matching or
dropping normalisation; and on the `main.js` side, re-acquiring its own write path, resolving its own
pane, dropping either readiness pre-check, hand-rolling the screen reader, or consulting the refusal
AFTER typing). All CAUGHT, both files restored byte-identical.

**In-runtime evidence (D-P16-0):** `docs/evidence/receipts/PHASE19_3_SYSTEM_PANE_WRITE_SELFCHECK_phase-19.3.close_20260810T111605Z.json`
- four legs inside the packaged Electron runtime against real ConPTY panes, at commit `0f51e8c` with
a clean tracked product tree. It found a real defect on its first run (U360) before it passed.

**What this row does NOT claim.** The gate's only signal is a whole-buffer screen read, so it
inherits U329's weakness (unit 19.4 narrows it); the direction of that error here is a withheld
message, not an answered modal. Residue left by a withheld submit is reported but not tracked
anywhere. And the two panes the receipt drives are PowerShell, not a provider TUI: what is proven is
the gate and its wiring, not the classifier's precision against Grok's or Antigravity's real screens.
**AND THE HALF THAT IS NOT CLOSED, which the first draft of this row asserted away.** The
gate-validator's round-1 probe drove this module directly with ten realistic permission screens:
NINE were allowed through, including "Do you want to proceed? 1. Yes 2. Yes, and do not ask again".
`classifyProviderScreen` is a denylist of six phrase families and returns null for everything else,
and this module writes into whatever it is handed a null for. So the structural half of the unit's
acceptance standard is met - nothing reaches a pane unclassified, and no caller can forget the gate -
while the VERDICT half is not: the shell remains able to answer a modal it does not recognise. That
is U363, and it is not absorbed here.
Owner: the residual is U363 (verdict), U329/unit 19.4 (window), U361 (residue), U365 (reporting).
State: **CLOSED IN PART** - the write path, yes; "unable to answer a modal", no.

### U360 - **CLOSED at Phase 19 unit 3, by the receipt that found it**: the own-echo exclusion did not survive a real ConPTY

The first version of `withoutOwnEcho` split the screen on the EXACT body string. The screen it
searches is `buffer.snapshot()` - the raw PTY stream - so PSReadLine's syntax colouring puts escape
sequences INSIDE the echoed line and the terminal wraps it wherever the column runs out. There was no
exact substring to remove, the pane's echo of our own prompt classified the pane against us, and the
notice withheld its own submit key. Measured, not reasoned: leg B of
`PHASE19_3_SYSTEM_PANE_WRITE_SELFCHECK_phase-19.3.close_20260810T111123Z.json` (`written: false`,
`body_observed_executing: false`) while the other three legs passed. The module header had claimed
only line-wrapping could do this and that the direction was fail-closed; the direction WAS
fail-closed - nothing answered a modal - but a message that never arrives is still a defect, and the
15 headless tests and 15 mutations that existed at the time could not see it because every one of
them fed the gate a screen with no escape sequences in it.

Fixed in `0f51e8c`: normalise with `plainScreen` first (the classifier's own normaliser), then match
the body character by character with whitespace allowed between characters, which covers a wrap
anywhere including mid-token. State the direction correctly, because this row's first draft copied the module's
backwards version: removing MORE text before classification accepts MORE screens, not fewer - leg B
is precisely a screen the exact version refused. The new acceptances are bounded to screens
containing our body's character sequence in order with only whitespace between characters; nothing
confines the deletion to the echo's REGION, so a body equal to a modal's own words erases them
(pinned by a test rather than denied), and short or model-supplied bodies widen that. An unbuildable pattern falls back rather than throwing on the write path.
P8's anchor moved and P10/P11 were added, one per half of the repair.

**The transferable finding, which is the reason this row exists rather than a line in a commit
message:** this is the second time in Phase 19 that a property held against every double the tests
supplied and failed against the world (D-P16-0's founding case was the first). Any guard that reads a
PTY screen must be falsified against RAW terminal bytes - colouring, wrapping, cursor movement - and
not against a hand-written string. Owner: closed. State: **CLOSED**.

### U361 - **OPEN: a withheld submit leaves the body in the input box and nothing tracks it**

`writePrompt` returns `residue_possible: true` when the body went out and the submit key was then
withheld, and `notifyNode` passes it up - but no caller retries, clears, or records it, and the next
notification to that pane appends to whatever is still sitting in the provider's input box. The
current behaviour is safe (the modal is unanswered) and lossy (the message is neither delivered nor
retracted). Related: `clearConductorInputResidue` already exists in `main.js` for the operator path,
so there is a mechanism to reuse. Action: on a `residue_possible` refusal, either clear the input or
record the pending body against the pane so a later delivery is a retry rather than a concatenation.
Owner: unowned - carried into the Phase 19 gate ledger per U358. State: **OPEN**.

### U362 - **OPEN: the 19.3 receipt drives PowerShell panes, so the classifier meets no real provider screen**

The in-Electron receipt proves the gate refuses, the wiring goes through it, and the exclusion
survives a real terminal - all against `powershell.exe` panes printing text the check itself chose.
No leg puts a real Grok/Antigravity/Claude first-run screen in front of `classifyProviderScreen`, so
its patterns are still evidenced only by the two captures U327 cites. This is not a gap in the gate;
it is a gap in what is known about the classifier the gate consults, and it will be closed cheaply
the next time a provider pane comes up for another reason (18E's trust modal is still owed by the
operator, U317). Recorded so the 19.3 receipt is not read as evidence about provider screens. **The first draft of
this row said "this is not a gap in the gate"; the round-1 review was right that it is.** The gap is
not that the patterns may be imprecise - it is that an unrecognised screen is ALLOWED THROUGH, which
is U363. This row is the narrower one: what the receipt evidences about the classifier is nothing.
Owner: unowned - carried into the Phase 19 gate ledger per U358. State: **OPEN**.

### U363 - **OPEN, and it is the unmet half of U328's acceptance standard: the modal gate is a denylist, so an unrecognised screen is written into**

Demonstrated, not theorised. The round-1 gate-validator built a probe against the shipped
`paneWriteRefusal` with `screenReadable: true` and ran ten realistic permission screens past it at
two provider values. **Nine survived at every value:** a claude-code tool-permission modal ("Do you
want to proceed? > 1. Yes 2. Yes, and do not ask again"), a file-edit permission, a generic y/N
confirmation, a codex approval ("Allow command? (y = yes, a = always, n = no)"), an antigravity
apply-change, a remote host-key fingerprint prompt, an elevation password prompt, a bare numbered
menu, and a tool approval that does not use the words "sovereign" or "mcp". Only the workspace-trust
wording refused. The structure, independent of anyone's guess at vendor wording, is
`classifyProviderScreen` (`apps/desktop/control/provider-readiness.js:45`) ending in `return null`
and `pane-writer.js` consuming that verdict as consent.

Reachability is direct: `runConductorReadiness` sends "First call the Sovereign get_worker_status
tool...", i.e. the shell asks the conductor to make exactly the call that raises an MCP
tool-permission modal; the next `notifyNode` then arrives into that screen, classifies null, and
writes body + Enter into pane 1 - the pane the operator converses in (OP-8).

**The repo already contains the fail-closed shape this wants.** `apps/desktop/voice/pane-state.js`
(`paneAcceptsTypedText`) demands POSITIVE evidence that the pane's text input is the most recent
chrome drawn and refuses on `unknown` - "absence is not consent". The operator's own voice is
therefore gated more strictly than a system notice, which is the asymmetry to remove.

**Why this unit did not simply do it, stated as a judgement and not as a fact:** on a whole-buffer
read (U329) a stricter verdict trades an unanswered modal for a permanently mute pane - one delivered
body containing trigger text pins that pane for the life of its scrollback, and task objectives and
debate propositions go into those bodies verbatim. The bounded window is unit 19.4's, and it is the
prerequisite. Doing the verdict first would produce a shell that refuses to talk to its own workers
and no way to tell which half was wrong. **This is the loop's reasoning, not a ruling**: the
acceptance standard for 19.3 as written in directive s18 is NOT MET on unrecognised screens, and it
is recorded here for the Phase 19 gate ledger (U358) rather than absorbed into a green sentence.
Owner: unit 19.4 (window) then a verdict change - carried to the phase gate. State: **OPEN**.

### U364 - **CLOSED at Phase 19 unit 3, round 1**: a half-rendered echo of our own body withheld its own submit key

Found the only way it could be: the same in-Electron leg passed at `0f51e8c` and failed at
`1440b84`, on code that leg does not touch. `withoutOwnEcho` removes a body that is COMPLETELY on
the screen; the submit-key read can catch the pane mid-render, and the visible FRAGMENT of our own
text is not removable by a matcher for the whole of it. The fragment classifies, the Enter is
withheld, the message never arrives - intermittently, which is how it would have been dismissed as
flakiness. Two runs with opposite outcomes on the same code is the evidence that it is a race.

Fixed in `5ec4213`: after the paste settle, when the screen WOULD refuse and the echo is not yet
whole, wait for it - bounded to 8 settle intervals, breaking immediately when the screen is already
clean, and the bound expiring changes no verdict (whatever is on the screen is classified, exactly
as before). `echoIsWhole` asks the exclusion itself whether it has something complete to remove, so
the wait cannot disagree with the check it waits for. Falsified in both directions: P13 deletes the
wait, P14 unbounds it. Owner: closed. State: **CLOSED**.

### U365 - **OPEN: the provider state a refusal carries is discarded by three of the four call sites**

`writePrompt` returns `{written, refused, residue_possible}` and its own docstring used to claim
those facts are "never conflated". `main.js`'s `writePanePrompt` collapses the record to its
boolean, so `controlAssignTask`, `runConductorReadiness` and `waitForWorkerReadinessTurn` report a
generic delivery failure ("conductor readiness prompt was not delivered", stage
`readiness_prompt_delivery`) for what is actually `WORKSPACE_TRUST_REQUIRED` or
`MCP_PERMISSION_REQUIRED`. The pre-check path DOES surface the provider state - that is what unit
19.3 built - but the submit-key path, the one the unit is proudest of, does not. The refusal is in
the main log (invariant 27 survives); the operator's conductor chrome is told "FAILED". Found by the
round-1 spec-auditor; the docstring now says what is true. Action: give the three call sites the
record rather than the boolean. Owner: unowned - carried to the phase gate (U358). State: **OPEN**.

### U366 - **OPEN (four small ones from the round-1 review, kept together so none is lost)**

(a) **The write-site count is a substring count.** `system-pane-write-wiring.test.js` asserts exactly
three `manager.write(` sites, which is true today, but an alias (`const w = manager.write`) or a
module handed the `sessionManager()` ctx binding keeps the count at three. "A fourth is a new ungated
path by construction" is true of the module boundary, not of the counter.
(b) **`PANE_SCREEN_UNREADABLE` is a `terminal_state` outside `PROVIDER_STATES`** and outside what
`provider-readiness.test.js` pins, and it is returned to the conductor model through `notifyNode`. No
frozen schema pins `terminal_state`, so this is hygiene, not a violation.
(c) **A vendor name sits in the one path every system byte now passes**: `provider ===
"openai_codex_cli"` selects the double-Enter submit. That is a provider CAPABILITY and belongs in a
descriptor (invariant 4 / I-SC1). Pre-existing behaviour, but relocating it here made it structural.
(d) **Nothing goes red if a future unit gates the OPERATOR's path.** Invariant 1 cuts both ways and
only one direction has a falsification; the nearest guard still passes if a refusal branch is
inserted before the write. Owner: unowned - carried to the phase gate (U358). State: **OPEN**.

### U367 - **CLOSED at Phase 19 unit 3, round 2**: the fixture that graded the U364 fix never built its own scenario

The round-2 gate-validator and spec-auditor found this independently and traced it identically. The
test named `a HALF-rendered echo of our own body does not withhold its own submit key (U364)` built
its half-rendered screen as `Write-Output 'yes, pro` — one character before `classifyProviderScreen`'s
`/yes,? proceed/i` matches. So the fragment did not classify, the screen was CLEAN, and the race the
test exists for was never constructed. Consequences, both demonstrated rather than argued: the test
passes with the echo-settle wait DELETED, and `echoIsWhole` can be replaced by `return true` — which
nullifies U364's fix exactly — with all 871 desktop tests and all 20 mutations green. Mutation P13 was
graded CAUGHT the whole time, by the codex-confirm test, whose scripted screens `5ec4213` shifted by
one to absorb the loop's extra read: an index offset, not the behaviour.

**The product code was correct throughout, and both reviewers said so** — the gate, the loop and the
predicate all behave as their comments claim; what was false was the sentence *"falsified in both
directions: P13 deletes the wait, P14 unbounds it"* in this register (U364) and in the evidence report.
P14 was genuine. P13 was not.

Fixed by the fixture, not by a patch: the fragment ends at `yes, proceed NOD`, which classifies and
is not removable as a whole, and the test now ASSERTS that its own fragment classifies, so it cannot
quietly stop discriminating again. Per-mutation verification, run singly rather than inferred from a
green harness: on the repaired fixture P13 and P15 each turn the U364 test alone RED, and P15 is
caught by **nothing else in the suite**. Mutation **P15** (echoIsWhole always whole) is added.

The opposite direction — `echoIsWhole` never answering true — is deliberately NOT mutated, and the
reason is a claim about the code rather than an omission: the loop breaks on `refusal === null ||
echoIsWhole(...)`, so a permanently-false predicate changes only how much of the bounded wait a
REFUSED write spends before it refuses. Pinning it would pin latency and report it as safety.

**That claim has one dependency and it is recorded here because the NEXT unit removes it.** The
verdicts coincide only because the signal is a whole-buffer `buffer.snapshot()` (U329), which is
append-only: within the settle window a refusal is MONOTONE, so a later read cannot turn a refusing
screen clean by losing text. Unit 19.4 replaces that window with `RingBuffer.sliceFrom()`. A bounded
window CAN drop a modal out of view, at which point a permanently-false predicate would let the loop
poll on to a clean read and DELIVER where the real predicate would have broken early and withheld —
a verdict, needing a mutation. **Unit 19.4 must re-derive this rather than inherit it.** (Found by
the delta truth-check pass, not by either round; the first draft of this paragraph asserted "every
verdict is identical" flatly.)

**The transferable finding, and it is the third of this class in three units:** a mutation is worth
exactly what the fixture grading it is worth. A harness that reports CAUGHT tells you a suite went
red, not that the test you meant graded it — and a fixture one character away from its own scenario
looks correct in review. **Where a mutation exists to pin ONE behaviour, run it against that test
alone at least once.** Applied in this unit to P13, P15 and M7: P15 reds the U364 test and nothing
else; P13 reds the U364 and codex tests; M7 reds the write-site counter alone. The rule caught its
own first violation immediately — M7's original anchor sat inside `writePanePrompt`, where that
function's own `doesNotMatch` guard also catches it, so it graded "some assertion saw it" rather than
"the counter saw it"; re-anchored into `runConductorReadiness`, which carries no such guard.
State: **CLOSED** (fixture + P15 + the corrected sentence; the false sentence in U364 is corrected
here rather than edited there, per this register's append-only convention).

### U368 - **CLOSED at Phase 19 unit 3, round 2**: two fail-open directions of the write gate that nothing graded

Both found by the round-2 gate-validator with its own mutations, both survivors of all 871 desktop
tests, both product-correct — unpinned, not broken.

(a) **The pre-body call's `null` argument** (`apps/desktop/control/pane-writer.js`, `refusalOn(paneId,
null)`). Changing it to `refusalOn(paneId, prompt)` applies U360's tolerant exclusion to a screen this
shell has not yet written into, so a modal whose words our own body contains would be erased BEFORE
the first byte and body + Enter would both go out. This is the fail-OPEN direction of the U360 repair,
and the erasure it depends on is already pinned as reachable by `withoutOwnEcho`'s own test. Closed by
a behavioural test (a body quoting a trust modal's own words, against a pane already showing it) and
mutation **P16**.

(b) **Fail-closed-on-unreadable at the SUBMIT key.** P2, P3 and P7 pin it before the body and nothing
pinned it after: a live pane whose `buffer.snapshot()` starts throwing between the body and the Enter
is exactly the pane the Enter must not reach. The case could not even be written, because the test
harness's `readable` flag could not change between reads; it now takes an array consumed per read, as
`screen` already did. Closed by a test and mutation **P17**. State: **CLOSED**.

### U369 - **CLOSED IN PART at Phase 19 unit 3, round 2**: the write-site counter matched one spelling, and the claim above it was wider than the counter

U366(a) recorded that the three-site count is a substring count while `system-pane-write-wiring.test.js`
and the 19.3 evidence report both asserted, without qualification, that *"a fourth is a new ungated
path by construction"*. The round-2 gate-validator closed the gap between those two sentences by
demonstration: `manager?.write(paneId, data)` adds a fourth PTY write, keeps the count at three, and
leaves the wiring suite and the writer suite green. What actually caught it was `selfcheck-guards`'
SHA-256 baseline detector — a change detector a builder re-pins on every legitimate `main.js` edit,
which is not a guard against an ungated write.

Closed in part: the counter now matches a write on the `manager` IDENTIFIER (`manager?.write(`,
spacing, and the plain form), mutation **M7** pins that, and the comment above it states what a
substring counter can and cannot know. **Not closed:** a write reached through an alias
(`const m = manager; m.write(...)`) is invisible to any regex over this file and is no longer claimed
to be caught. That residual stays U366(a), and what stands behind it is unit **19.9**'s extraction of
`main.js` into requirable modules — not this assertion. State: **CLOSED IN PART**, residual on U366(a).

### U370 - **CLOSED at Phase 19 unit 3, round 2 (the corrections round 2 made to unit 19.3's own records)**

Round 2 returned 0 BLOCKING, PROHIBITED DRIFT NONE, and no finding requiring a code-behaviour change.
What it did return, again, was **documentation asserting absolutes the code falsifies** — the class
that has now appeared in every review round of units 19.2 and 19.3, including inside the fixes for
itself. Corrected here as new text rather than by editing the rows that carry the errors, which is
this register's convention (see U96 near the top of this file) and which unit 19.3 had itself broken:

1. **"Falsified in both directions" (U364, report section 5.2)** — false for P13. See U367.
2. **"17 mutations across the two files" (the U328 closure row)** — the harness shipped 20 when that
   row was written and ships 24 now. The row's enumeration omits P9 and the three mutations added by
   the round-1 remediation, **including P12**, which carries a round-1 disposition. The evidence
   report's section 4 had the right number; the durable record did not.
3. **"A fourth is a new ungated path by construction"** (report section 1, U328 row) — see U369.
4. **The D-P16-0 receipt the U328 row cites** (`...phase-19.3.close_20260810T111605Z.json`) carries a
   `finding` field asserting *"nothing this shell sends may answer a trust/permission modal"* — the
   pre-remediation absolute, inside a machine artifact that outlives the prose around it. Receipts are
   immutable and are NOT edited: the citation moves to
   **`PHASE19_3_SYSTEM_PANE_WRITE_SELFCHECK_phase-19.3.round2_20260810T131740Z.json`** (commit
   `eada45c`, tree clean, four legs green, honest `finding` string), and the two `phase-19.3.close`
   receipts are hereby recorded as carrying a **retracted** finding string. The failing one keeps its
   evidentiary value for U360 regardless of its header.
5. **A round-2 finding this row's own first draft adopted without checking, and which is FALSE.** The
   round-2 spec-auditor graded MEDIUM that this unit broke the register's correction-by-new-text
   convention — *"`1440b84` edited rows committed at `0f51e8c` in place"* — citing rows that say
   things like "the first draft of this row asserted away". Checked against git rather than believed:
   **neither `0f51e8c` nor `1440b84` touches this file at all**, and every row of this unit landed in
   ONE commit, `7cc2115`, at **181 insertions and 0 deletions**. The self-referential sentences are a
   draft revised before its single commit — which `7cc2115`'s own message states — not a committed row
   rewritten. The convention was not broken. **The register is intact and this row is the correction
   of a correction:** a reviewer's finding is evidence, not a verdict, and the first draft of item 5
   repeated it as fact, which is the same failure it exists to record.
6. **"registers append-only (U328/U360/U361/U362 are new rows)"** — eight rows were added; U363-U366
   were omitted from the list.
7. **"git show --stat on all three work commits" (report section 4)** — the header lists five. The
   underlying claim (zero Python files in the range) was independently confirmed true over all five.
8. **U362's retracted sentence** — *"This is not a gap in the gate; it is a gap in what is known about
   the classifier"* still stands three lines above its own retraction. It is retracted; the row is left
   as written.
9. **`controlAssignTask` is cited at `main.js:2458`**; it is at `:2503`. The directive's own text carries
   the stale number, but the row stated it as present fact rather than as a quotation.
10. **"the common path pays nothing"** (the settle-loop comment) — true of the settle interval, untrue
    of the work: one extra `refusalOn`, i.e. one 256 KB snapshot plus a tolerant-regex pass, and up to
    2 x ECHO_SETTLE_POLLS of them plus the sleeps (~4 s at the 500 ms default) for a refused write.
    Measured by the round-2 validator at 1-14 ms per pass for bodies of 200-20 000 characters, so the
    sleeps dominate. The comment now says that. **No receipt times it** — that remains OPEN and is the
    one item of this row that is not closed.
11. **`echoIsWhole` passed no fallback logger**, so on that path the restored U360 defect happened
    silently thirty lines below a comment saying it may not (invariant 27). Fixed; it cannot change a
    verdict, only spend more of the bounded wait.
12. **`SOVEREIGN_PROVIDER_PASTE_SETTLE_MS` is coerced, not parsed** — real, ATTEMPTED, and
    deliberately REVERTED out of this unit. See **U371**.

State: **CLOSED** except (a) item 10's missing timing measurement, carried to the Phase 19 gate ledger
(U358) as an evidence debt rather than a defect, and (b) item 12, which is now U371.

### U371 - **OPEN: the two settle intervals are coerced rather than parsed, so a malformed override deletes U364's wait**

`apps/desktop/main.js`: `Number(process.env.SOVEREIGN_PROVIDER_PASTE_SETTLE_MS || 500)`. `Number("x")`
is `NaN`, `setTimeout(NaN)` is 0 ms, and U364's echo-settle wait is expressed in POLLS of that
interval — so a malformed override does not merely shorten the settle, it deletes the wait, which is
mutation **P13**. Same for `SOVEREIGN_CODEX_SUBMIT_CONFIRM_MS`. Found by the round-2 gate-validator,
graded MINOR and "pre-existing input; newly load-bearing because of `5ec4213`".

**It was fixed in `fa35797` and the fix was reverted in `eada45c`, on purpose.** The delta truth-check
pass caught the evidence report closing this unit on the sentence *"the product decision path is
byte-identical to what they reviewed apart from a logger argument"* — which that fix falsified. And it
is not a cosmetic falsification: because deleting the wait IS P13, and P13 flips a write from
withheld to delivered, the repair changes a write VERDICT in exactly the configuration it exists for.
A round-2 remediation whose whole argument is "no code-behaviour change was required" is the last
place that may carry one. So the honest options were to keep it and owe a round 3, or to revert it and
keep the closing argument true. Reverted, and recorded here rather than dropped.

**Not a live defect on any configured path:** no `SOVEREIGN_*_SETTLE_MS` override is set anywhere in
the repo, the shell, or any self-check, so both constants take their measured defaults today. The
repair is one helper and two call sites; it belongs to any unit that is already changing `main.js`
with its own falsification behind it — unit **19.4** touches this exact area (the bounded window) and
is the natural owner. Owner: unit 19.4 or later. State: **OPEN**.

### U372 - **OPEN: a byte/line window is not a terminal emulator**

The 19.4 classification window is the pane's tail through `RingBuffer.sliceFrom()`: at most
`TAIL_BYTES` of raw PTY stream, then at most `TAIL_LINES` lines of what survives normalisation. A
provider that repaints with cursor addressing — draws a modal, then overwrites it in place while
emitting fewer bytes than a tail holds — leaves the dismissed overlay's BYTES inside that tail. On a
pane whose MCP session is ALSO down, the run can therefore still name the overlay rather than the
disconnection.

**Bounded in three ways, which is why it is a row and not a defect.** It is a diagnostic imprecision
on an already-failing pane (a connected worker is never classified at all); it is re-derived from
scratch on every poll, so nothing pins; and the run's verdict is a stall either way. The exact answer
exists in the renderer, which holds a real xterm buffer — the main process cannot read it
synchronously, and an IPC round trip inside a 250 ms poll is a different unit's design decision.

Confirmed at the 19.4 gate review: the validator's own probe drew a 16 384-byte cursor-addressed
repaint and the window rendered it as ONE line. Owner: unowned. State: **OPEN**.

### U373 - **OPEN, and it is the unfinished half of U329: the U328 write gate's read is not bounded, and readiness depended on it**

Found INDEPENDENTLY by both mandatory reviewers at the 19.4 gate, each with its own probe and its own
spellings, and confirmed on disk before either was acted on.

`worker-readiness.js`'s first act in a turn was `io.writeRefusal(paneId)`, bound in `main.js` to
`paneWriteRefusalFor` → `pane-writer.js` `refusalFor` → `refusalOn(paneId, null)` →
`buffer.snapshot()`: **the whole 256 KB scrollback**, classified by the provider-independent
`/not signed in/i` rule. The module returned that refusal as `{stage: "provider_setup"}` and `run()`
made it the node's terminal state, labelled `decided_by: "screen_text_bounded_window"` — an
instrument that had read nothing. So the exact defect U329 exists to remove survived the reorder
built to remove it: a healthy, connected worker whose transcript merely MENTIONED an auth failure was
reported `AUTH_REQUIRED`, across runs, until 256 KB of output evicted the words. The unit test named
for that scenario passed because the harness stubbed `writeRefusal` to null.

**Remediated in `a6166e7`, and NOT closed by it.** What the remediation fixes: the gate's answer now
means only *we may not type here yet*; a refusal is waited on and one that clears lets the same turn
proceed to write; a refusal that never clears is `readiness_prompt_withheld` / `write_gate_withheld`
carrying the gate's own words; no `decided_by` claims a bounded window that did not read. What it
does NOT fix, and the reason this row stays open: while the GATE's own read is unbounded, that
healthy worker's prompt is still undeliverable, so it **stalls**. The pin is honest, not gone —
OP-13.1's stated rationale for sequencing 19.4 ahead of Path A ("U329 can pin a healthy worker as
permanently blocked") is therefore only partly discharged, and this row says so rather than leaving
the evidence report to imply otherwise.

**Why the rest is a separate unit.** Bounding the gate's window is [[U363]]'s other half — 19.3
sequenced it here in `pane-writer.js:49-51` ("the window comes first (19.4), then the verdict") — but
it loosens an invariant-1 gate closed at a high-stakes review: it changes which screens are seen
before a keystroke, it interacts with the U360/U364 own-echo machinery whose justification assumes an
append-only whole-buffer read ([[U367]]), and it needs its own falsification and its own in-Electron
receipt. Rushing it into a review remediation is exactly what [[U371]] was reverted for.

The residual is asserted, not narrated: `worker-readiness.test.js`'s production-write-gate test
requires `ready === false` and goes RED the moment the gate reads a bounded window. Owner: the unit
that bounds the U328 gate's read. State: **OPEN**.

### U374 - **OPEN: what the 19.4 harness pins, and four things adjacent to it that it does not**

The gate-validator wrote its own mutations against `worker-readiness.js` and ran the full desktop
suite against each. Four survived all 901 tests (recorded as the validator measured them):
`TAIL_LINES` 24 → 200 and `TAIL_BYTES` → 262 144 (**G1/G2**: the suite asserts `w.bytes <= TAIL_BYTES`
while IMPORTING the constant, so the assertion moves with the mutation — only the `Infinity` ends are
pinned, by R4/R5); `confirmed(observation, 1)` at the call site (**G4**: R9 pins the constant, not the
argument); and `trackObservation(...) || observation` inside `run()` (**G10**: R8 pins the pure
function, the caller that implements the exit path is unguarded). A fifth, **G5**, replaced a
`decided_by` label with a false one and survived — no test pins any label's value.

This is the [[U352]] membership-set class in its window/threshold form: the STATED rule is pinned and
the surface around it is not. The 19.4 remediation added R12–R15 for the write-gate class and did not
address these four, deliberately — a fix here moves test-visible constants and would void the round-1
verdict it is being written under. Owner: unit 19.9 (coverage that can fail). State: **OPEN**.

### U375 - **OPEN: three carried defects that unit 19.4 relocated, and one that belongs to nobody**

(a) **[[U337]]'s literal-assignment readiness booleans moved.** `process_supervised`,
`provider_authenticated`, `workspace_accepted`, `mcp_discovered`, `identity_validated` and
`permission_resolved` are still assigned `true` with no observed signal behind any of them, now at
`worker-readiness.js:316-320` and `:370-375` rather than `main.js:2310-2313`, which is where U337's
row still points. A pane refused at the write gate is additionally stored with
`provider_authenticated: true` beside a failing state. Owner: unit 19.8, whose row this correction
belongs to.

(b) **The `grok_build` `requiredTurns` pin** (`worker-readiness.js:369`) selects behaviour by provider
NAME (invariant 3 / I-SC1). The spec-auditor established that it is pre-existing behaviour MOVED, not
invented — `provider-readiness.test.js:36` already asserted the `second_readiness_response` stage it
produces — and also that unit **19.6 does not own it**: the 19.6 row names the
`openai_codex_cli`/`gpt-5.6-sol` conductor pin and the synthesis fields, and [[U333]] is
synthesis-only. Recorded here so that it belongs to something. Related: the provider-keyed regex
families in `provider-readiness.js:32,37,41`, defensible as a screen dictionary, named in the same
breath.

(c) **[[U371]]'s repair is graded by a source-string match** (`sovereign-control-server.test.js`
asserts `/intervalMs\("SOVEREIGN_PROVIDER_PASTE_SETTLE_MS", 500\)/`) plus the SHA pin in
`selfcheck-guards.test.js` — i.e. by exactly the `fs.readFileSync` mechanism [[U338]] condemns. The
validator demonstrated `if (false)` inside `intervalMs` passing that suite. The code fix is correct
and present; its falsification is owed. Owner: unit 19.9.

(d) **The helper was applied to eight constants**, not the two the U371 row named — including
`MCP_READINESS_TIMEOUT_MS` and both worker deadlines. Same repair, wider blast radius than the row
described. Recorded for accuracy. State: **OPEN**.

### U376 - **OPEN: the desktop suite is not hermetic, so "907 pass" is not reproducible from a clean checkout**

`apps/desktop/test/conductor-source.test.js` reads the operator's LOCAL, untracked conductor-selection
state. The gate-validator, running in its own git worktree, measured 900 pass / 1 fail where the
primary workspace measures a full green, and traced it by running
`py -3.12 tools/live/emit_conductor_selection.py` in both trees: this workspace emits `gpt-5.6-sol`,
a clean worktree emits `fable-5`.

Neither number is wrong; the test asserts against host state. It means every desktop-suite count in
this phase's evidence is a measurement OF THIS HOST, and a reviewer in an isolated tree cannot
reproduce it — which matters for a build whose reviews are deliberately run in isolated trees. Fix
shape (not authorised here): the fixture supplies the selection, or the test skips VISIBLY when the
local state is absent — never silently, per unit 19.9's own rule. Owner: unit 19.9. State: **OPEN**.

### U377 - **CLOSED at Phase 19 unit 19.4 (round-1 remediation), and recorded because of how it was found**

The remediation's own test harness wrapped the production window to COUNT reads:
`read: (paneId) => { st.classificationReads += 1; return window.read(paneId); }`. It dropped the
second argument. The in-turn floor (`{notBefore: mark}`) therefore never reached the real window in
ANY test, the new negative control failed on the clean tree, and — the part worth the row — every
mutation aimed at the floor was graded **CAUGHT**, because a target that is already red catches
everything. That is [[U356]] exactly, in a harness written by the unit that had just read U356.

It was found by RUNNING the clean tree, not by reading the diff: the mutation harness's own
"clean tree: GREEN (expected)" line is what catches this, and it had been hidden behind a `tail -8`.
Closed by forwarding the options and re-running (15/15 CAUGHT on a verified-green tree). The standing
lesson: a counting or logging wrapper around an injected dependency is a re-implementation of that
dependency's SIGNATURE, and a harness must be read against its clean-tree line, not its mutation
column. State: **CLOSED**.

### U378 - **DISPOSITIONS recorded at Phase 19 unit 19.4 for [[U329]] and [[U371]] (the rows above are never edited in place)**

**[[U329]] — CLOSED IN PART.** Delivered and falsified at `716673d` + `a6166e7`: the order
(process exit code → structured provider signal → screen text) expressed once in a requirable module
per `tools/providers/frontier_provider_recon.py:44-49`; the classification window bounded to the
pane's tail through `RingBuffer.sliceFrom()` with `answerable: false` carried rather than widened;
`runWorkerReadiness` reordered so the MCP connection check is never short-circuited by a
classification; every classified state re-derived per poll with a resetting observation, so a
dismissed overlay cannot pin across polls or runs; and the negative control the row demanded — a
healthy, connected, exit-0 worker whose transcript merely mentions "usage limit" or "not signed in"
stays READY — real at the module level, in two forms (immediate answer and delayed answer), each
falsified by a mutation that restores the audited behaviour (R1–R15, all CAUGHT).

**Not closed**, and the residual is [[U373]]: the same worker driven through the PRODUCTION write-gate
binding still does not reach READY, because the U328 gate's own read is the whole scrollback and the
readiness prompt is therefore undeliverable. It is no longer *mislabelled* — no scrollback keyword
becomes a provider verdict, and no `decided_by` names an instrument that did not read — but a stall
is not READY, and the row that closes U329 fully is the one that bounds the gate.

**[[U371]] — CLOSED** at `716673d`. `intervalMs` parses rather than coerces, so a malformed
`SOVEREIGN_*_MS` override falls back to the measured default instead of producing `NaN` → a 0 ms
`setTimeout` → U364's echo-settle wait deleted (mutation P13). Two accuracy notes, both in
[[U375]]: the helper was applied to eight constants rather than the two this row named, and its only
grading today is a source-string assertion plus a SHA pin — the `fs.readFileSync` mechanism [[U338]]
condemns — so a behavioural falsification is owed to unit 19.9. State: **CLOSED, with a test debt
recorded rather than implied**.

### U379 - **the withheld-write loop read a record from BEFORE the turn, so a dead worker was decided by its screen** (found at Phase 19 unit 19.4, review round 2, by BOTH mandatory reviewers independently; CLOSED at `14a3ad1`)

`a6166e7` fixed [[U373]]'s first half by making the U328 gate's refusal something to WAIT on rather
than something that states a worker's condition. The loop it added — `waitForTurn`'s withheld-write
loop — then classified with the `record` the turn began with and never called `io.record`, while the
answer loop twenty lines below refreshes on every poll. Three consequences, each re-verified on disk
before either report was acted on (a reviewer's finding is evidence, not a verdict — 19.3's lesson):

1. **The row's first clause, inverted inside the remediation for its second.** A worker whose process
   EXITED while the gate withheld was still classified by its bounded screen window for the whole
   `PEER_RESPONSE_DEADLINE_MS`, so the strongest signal a process ever emits was not consulted and the
   weakest one decided. The gate-validator's probe: record `exited`/137, pane showing a trust modal →
   `{"state":"WORKSPACE_TRUST_REQUIRED","decided_by":"screen_text_bounded_window","process_state":"running"}`.
2. **A structured failure asserting a field the code did not read.** `failure()` takes `processState`
   from the record it is handed, so every turn failure reported `process_state: "running"` and
   `exit_code: null` for a process that had exited — and on the path that DID observe the exit it
   reported `decided_by: "process_exit"` with a real exit code BESIDE `process_state: "running"`: a
   record contradicting itself (invariant 27, Buildout Directive §4).
3. **A `decided_by` naming a cause that did not occur.** `readiness_prompt_delivery` — the gate
   refusing between the pre-check and the submit key, or a dead PTY handle — fell through the ternary
   to `readiness_deadline`, though no deadline had elapsed.

Mutation R1 does not catch (1): it mutates `orderedProviderSignal`'s own guard, not the caller that
feeds it stale state — the recurring shape of this phase's findings, where the pure function is right
and its call site is not. Closed by reading the record at the top of the withheld loop with the same
`process_exit` early return the sibling loop has, re-reading the process fields before any failure is
written, and giving a refused delivery its own label `write_not_delivered`. Falsified by **R16/R17/R18**
(18/18 CAUGHT, restore byte-identical) and by three tests whose assertion messages name the
contradiction. **What is NOT fixed and stays [[U361]]'s:** the gate's REASON on that delivery path is
still lost, because `writePanePrompt` collapses the refusal record to a boolean. State: **CLOSED**.

### U380 - **the classification window's line bound counts blank lines, and can evict a modal that is genuinely on screen** (found at 19.4 round 2 by the spec-auditor; OPEN, owner: the unit that bounds the U328 gate)

`lastLines()` documented itself as "the last `max` **non-empty** lines" and has never filtered
anything. `plainScreen` strips escape sequences without collapsing what they leave behind, so a
provider that repaints emits blank lines that consume `TAIL_LINES`, and a modal that IS the current
screen can fall outside the only instrument allowed to state a worker's condition — the run then
reports a bare `mcp_readiness_timeout` for a pane whose screen says exactly what is wrong, which is
the failure mode the mark-floored design was abandoned for (module header, `worker-readiness.js`).

Not fixed in the round-2 remediation, deliberately: skipping blanks changes WHAT GETS CLASSIFIED, and
[[U371]] was reverted for exactly a behaviour change smuggled into a remediation whose argument was
"no behaviour change is required". The comment was made true instead. The fix belongs with the unit
that bounds the gate's own read ([[U373]] residual), because both are about what a window may see.
State: **OPEN**.

### U381 - **record corrections owed by the 19.4 round-2 review** (rows are never edited in place, so they are collected here)

- **(a) [[U373]] is wider than its own row says.** `apps/desktop/main.js`'s conductor readiness path
  still takes `paneWriteRefusalFor`'s whole-buffer refusal and makes it the conductor node's
  `operationalState`, pushed to the operator's chrome — the exact thing U373 condemns for workers,
  shipped for the pane the operator converses in (OP-8), and pinned as desired behaviour by mutation
  M3 in `system_pane_write_mutations.js`. `worker-readiness.js`'s header sentence "the gate's answer
  is now used for exactly what it is evidence of" was true of that module and read as global; it is
  scoped in the header now, and U373's residual covers this call site as well as the worker one.
- **(b) [[U375]]'s line citations were taken against `716673d` and committed after `a6166e7` had moved
  them** (+59/+64 lines): the literal booleans and the `grok_build` `requiredTurns` pin are not at the
  lines that row prints, and they have moved again with `14a3ad1`. The findings stand; the offsets do
  not. The lesson is the citation practice, not the numbers — a line number recorded against an
  uncommitted tree is stale before it is read.
- **(c) [[U374]]'s G5 clause — "no test pins any label's value" — was falsified by the tree it was
  committed with.** `worker-readiness.test.js` pinned four `decided_by` values as of `a6166e7`, and
  R15 is a `decided_by` mutation graded CAUGHT. The rest of U374 (four adjacent mutations surviving
  every test) stands.
- **(d) commit `8272f2c`'s message says "all four mutation harnesses were re-pinned to those bytes".**
  Three pin `main.js` and were re-pinned; `readiness_signal_mutations.js` pins only
  `worker-readiness.js` and was re-RUN, not re-pinned — it was re-pinned one commit later, at
  `14a3ad1`, because that commit does change those bytes. Commit messages are immutable; the
  correction lives here.
- **(e) the 19.4 checkpoint report §4 says "four receipts are committed with this unit"; five are**
  (`135311Z`, `135343Z`, `140454Z`, `close_161427Z`, `round1_172223Z`), and its four bullets describe
  all five. The round-2 report supersedes that section.
- **(f) two accuracy notes in `worker-readiness.js` that remain OPEN, not fixed:** for `grok_build`'s
  second turn the recorded `stage` is collapsed to `second_readiness_response`, erasing which stage
  actually occurred while `decided_by` still names its instrument; and `orderedProviderSignal`'s
  `processState = "running"` default parameter is the fail-OPEN direction for an absent process state
  (reachable from tests only today). Owner: unit 19.9's extraction work.

### U382 - **the in-Electron readiness check is not itself in any mutation harness's pin set** (found at 19.4 round 2 by the gate-validator; OPEN)

`readiness_signal_mutations.js` grades `test/worker-readiness.test.js` against
`control/worker-readiness.js`. Neither `selfcheck/readiness-window-selfcheck.js` nor the two test
files added at `8272f2c` are pinned or mutated by any harness, so a leg's `ok` expression could
quietly lose a clause — leg F's `decided_by` check, for instance — and every suite would stay green.
That is [[U374]]'s class applied to the evidence instrument rather than to the product. Related, and
disclosed rather than fixed: the check SEEDS launch records into the production launcher registry of
the throwaway SHELL_SELFCHECK process and does not remove them (contained to that process;
`onWorkerSessionEnded` refuses to act on them for want of a pid/generation match), and the receipt
now carries the seeded values verbatim. State: **OPEN**, owner: unit 19.9 (coverage that can fail).

### U383 - **DISPOSITIONS recorded at 19.4 round 2** (the rows above are never edited in place)

**[[U329]] — still CLOSED IN PART**, unchanged by this round: the order, the bounded window, the
reorder, the exit paths and the module-level negative control are delivered and falsified; the
end-to-end negative control still stalls at the U328 gate's unbounded read, which is [[U373]].
**[[U373]] — widened** by U381(a) to name the conductor call site; its worker half is now evidenced in
the packaged runtime rather than only headlessly (receipt
`PHASE19_4_READINESS_WINDOW_SELFCHECK_phase-19.4.round2_20260810T184046Z.json`, leg F, which REQUIRES
the residual to be present and goes red the day the gate is bounded).
**[[U379]] — CLOSED. [[U380]], [[U381]], [[U382]] — OPEN with owners.**
**Unit 19.4 is NOT closed by this round:** the repairs above changed the tree, so directive §18's
*fix-after-validation voids it* applies, and round 3 of both mandatory reviewers is the next unit's
first act.

### U384 - **the disclosure repair reached the scope note and not the sentence a reader reads first** (found at 19.4 round 3 by BOTH mandatory reviewers independently; CLOSED at `d2e096e`)

Round 2 recorded "three false disclosure sentences" as repaired. Round 3 found the repair had reached
`scope_note_readiness_run` and stopped there: the receipt's headline `finding` still ended "so those
two bindings are simulated and everything else is the shipped object" while six bindings and a seeded
launch record were the check's - the same undercount, one field away from its own correction, in the
field a reader reads first (gate-validator MINOR-1 class / spec-auditor MAJOR-1). Separately,
`seeded_launch_record` published seven constant fields while `driveReadiness` seeded eleven: `nodeId`
and a `chrome` whose `provider` and `model_slug` become the `provider` and `model` of EVERY structured
failure legs F/G/H produce (`control/worker-readiness.js` `failure()`). The complete object was
computed, returned at `driveReadiness`'s last line and read by nothing, and
`readiness-window-selfcheck.test.js` pinned the seven-key list as correct - which is why round 2
passed over it (gate-validator MINOR-3 / spec-auditor MAJOR-2).

**Fix:** `CHECK_OWNED_BINDINGS` is now the single list; the headline sentence is GENERATED from it and
states its count, so sentence and note cannot disagree again without the list itself being wrong. The
per-pane seeded record is published by the function that seeds it, so a future leg cannot add a field
the receipt does not disclose. Both new tests were shown to go red on the exact defect they name
(old sentence spliced back in; per-pane publication suppressed), file restored BYTE-IDENTICAL after
each splice. **State: CLOSED.** No product behaviour changed - this is the evidence instrument's
account of itself.

### U385 - **READY on a repaint: the readiness token count cannot tell a provider's answer from ConPTY redrawing our own prompt** (found at 19.4 round 3 by the RUN, not by a reviewer; OPEN - blocks 19.4)

`control/worker-readiness.js:373` promotes a worker when `toolSucceeded && echoes >= 2`, on the stated
reasoning that "one occurrence is the pane's echo of the prompt; the second is the provider's answer".
On a real ConPTY that reasoning does not hold. The 19.4 round-3 receipt run captured the mechanism in
the pane's own bytes: the prompt is echoed once, then `ESC[8;7;65t` - a terminal RESIZE - arrives and
ConPTY REPAINTS the screen, re-emitting the same line. The readiness token therefore occurs twice from
the echo ALONE. Measured on pane G, whose script answers with `SOVEREIGN_U329_ANSWER`: token
occurrences in the whole buffer **2**, `SOVEREIGN_U329_ANSWER` occurrences **0** - the pane had not
answered, and `run()` returned `READY` with `readiness_responses: 1`.

**This is U329's own subject matter turned on the positive control.** The unit exists because screen
text was consulted before stronger signals; here a screen-DERIVED count is trusted as though it were
the provider speaking, and a redraw satisfies it.

**Scope, honestly bounded.** In PRODUCTION `operationCount` is the real count of `get_worker_status`
MCP tool calls, and a repaint cannot fabricate an MCP tool call, so production promotion still
requires a genuine structured signal and this defect degrades a defence-in-depth confirmation rather
than promoting a silent worker on its own. In the SELF-CHECK `operationCount` is simulated (disclosed:
it counts prompt DELIVERY), so leg G rests entirely on the echo count - which is why leg G, and only
leg G, went red. **The leg is working; the verdict it graded is what is wrong.**

**Why it did not show before.** The repaint is a race between the renderer's fit/resize and the prompt
write. Receipts `...round2_184046Z` and `...close_174627Z` recorded `answer_marks_on_the_real_pane: 2`
on the identical code; three runs on 2026-08-10 recorded `0`. Round 2's green was TIMING, not
evidence - and a green that depends on when a resize lands is exactly the kind this unit may not
accept. Reproduced 3/3 (`round3_193358Z`, `round3-rerun_193502Z`, `diag_193721Z`) and shown NOT to be
caused by the U384 repair by an A/B control that restored the pre-repair file and failed identically
(`ab-pre-repair_193555Z`, `tracked_product_tree_clean: false`, self-disclosed).

**Direction for the fix (not implemented - it is the next unit's work, and it needs its own review
round):** make the expected answer a string the PROMPT ITSELF CANNOT CONTAIN, so no echo or repaint of
the instruction can ever satisfy it - instruct in words rather than by quoting the literal reply - and
grade that with a mutation. Counting occurrences of a token the prompt spells out is unfixable by
tuning the threshold: a second repaint would defeat `>= 3` just as a first defeated `>= 2`.
**State: OPEN. Owner: the next 19.4 unit, BEFORE round 4.**

### U386 - **round-3 reviewer findings carried forward with owners** (19.4 round 3)

- **(a)** `PHASE19_UNIT4_..._CHECKPOINT.ROUND2.md:153-154` says the round-2 receipt is "the only one
  taken on a tree whose check drives the readiness RUN". False: `close_174627Z` carries the same eight
  legs, as section 5 itself says two sentences earlier. The load-bearing clause - the only one whose
  leg H can FAIL on the defect it names - is true and was re-verified by probe. The report is
  append-only, so this row is the correction (gate-validator MINOR-1).
- **(b)** A worker that dies BEFORE a readiness turn is recorded `FAILED`; one that dies DURING a turn
  is recorded `STALLED` with `process_state: "exited"` and a real exit code - the same physical
  condition rendered two ways by timing alone, with no rationale recorded and `worker-readiness.test.js`
  pinning `STALLED` as intended. Invariant 27. Owner: the next 19.4 unit, alongside [[U385]]
  (spec-auditor F3).
- **(c)** `worker-readiness.js:469` selects `requiredTurns` by the vendor NAME `"grok_build"` - I-SC1
  behaviour keyed to a name rather than a descriptor. [[U375]](b) correctly recorded it as relocated
  rather than invented and correctly excluded it from 19.6, then named NO owning unit. **Owner
  assigned here: unit 19.6**, whose row is the descriptor generalization. Note also that leg G uses
  `claude_code`, so the `requiredTurns === 2` branch is the one readiness path never exercised
  in-Electron (spec-auditor F4).
- **(d)** Leg A's `bounded_window_bytes` is `Buffer.length` while `whole_buffer_bytes` is a UTF-16
  string length, and `bound_that_applied` is derived from comparing them. The panes are ASCII so the
  reported `"line_only"` is correct, but a field named `_bytes` that is not bytes should not feed a
  mechanism claim. Owner: the next 19.4 unit (spec-auditor F5).
- **(e)** Leg D injects its keystroke through the renderer's OPERATOR input channel
  (`window.sovereign.input`), not the gated system path - precedented in two other self-checks, no gate
  weakened, pane is a check-spawned `powershell.exe` killed in-unit - but it is the one write in a
  check about the write path that does not use the write path, and no scope note says so. Owner: the
  next 19.4 unit (spec-auditor F6).
- **(f)** `main.js:3042-3044`'s comment says the check "supplies its own MCP session state ... and its
  receipt says so"; it supplies six bindings and a seeded record. The receipt half is CLOSED by
  [[U384]]; the comment is not. Owner: the next 19.4 unit (spec-auditor F7).
- **(g)** `readiness-window-wiring.test.js`'s header claimed its assertions were graded by
  `readiness_signal_mutations.js`, "and by nothing else". That harness's SUITE is
  `worker-readiness.test.js` and it never runs that file; only the `writeRefusal` binding is graded, by
  M8, through a different test. **CLOSED at this iteration** - the header now states exactly what
  grades it and points the ungraded remainder at [[U382]] (gate-validator MINOR-2).

### U387 - **a stale git worktree from an earlier review round sits OUTSIDE the repo root** (found at 19.4 round 3; RECORDED, deliberately not acted on)

`git worktree list` shows `D:/multi model terminal app/gv-19.4` at `716673d`, left by an earlier
round's validator. It is outside the repository root, so **standing prohibition section 2.5 forbids
this loop from deleting it** - recorded rather than cleaned, which is the honest disposition. It is
inert (detached HEAD, no effect on the primary tree). Removal is an operator action:
`git worktree remove` or deleting the directory, then `git worktree prune`.

### U388 - **DISPOSITIONS recorded at 19.4 round 3** (the rows above are never edited in place)

Round 3 of BOTH mandatory reviewers ran FOREGROUND, IN-TURN and SEQUENTIAL on `8272f2c` + `14a3ad1` +
the round-2 report. **gate-validator: PASS** (0 BLOCKING/MAJOR/MEDIUM, 3 MINOR), stating explicitly
that no repair was required for closure. **spec-auditor: PROHIBITED DRIFT: NONE** (0 BLOCKING,
2 MAJOR, 2 MEDIUM, 3 MINOR), the two MAJORs being the disclosure defects above.

**The round did not close the unit, on two independent grounds.** First, the auditor's MAJORs were
verified on disk and repaired at `d2e096e`, and directive section 18's *fix-after-validation voids it*
applies. Second - and this one is not a matter of judgement - the D-P16-0 receipt taken on the
repaired tree came back **RED**: [[U385]], a false READY that only a real run in the packaged runtime
could have produced, in the unit's own positive control.

**[[U329]] - still CLOSED IN PART**, unchanged. **[[U373]]** residual unchanged. **[[U384]]** and
**[[U386]](g)** CLOSED. **[[U385]]**, **[[U386]](a)-(f)**, **[[U387]]** OPEN with owners.
**Unit 19.4 is NOT closed by this round.** The next unit fixes [[U385]] first, then runs **round 4** of
both mandatory reviewers over `d2e096e` + the U385 fix + this report.

### U389 - **[[U385]] CLOSED: the readiness reply is now a string the prompt cannot contain** (19.4, the unit after round 3)

`control/worker-readiness.js` no longer types a prompt that quotes the answer it wants.
`readinessChallenge(nodeId, turn, stamp)` returns two fragments - `SOVEREIGN_READY_<turn>_<stamp>` and
`SOVEREIGN_TAIL_<stamp>` - and INSTRUCTS IN WORDS that they be written joined, with nothing between
them. The expected reply therefore appears NOWHERE in the prompt, so no echo of our keystrokes and no
ConPTY repaint of them can produce it, and **one occurrence is proof**. The threshold moved from
`>= 2` to `>= 1` because the reason for `>= 2` (discounting the pane's own echo) no longer exists;
the structured requirement (`toolSucceeded`) is unchanged, so a pane that composes the answer with no
MCP tool call behind it is still not READY.

**Fail closed, additionally:** `waitForTurn` refuses to write at all when
`challenge.prompt.includes(challenge.expected)` - stage `readiness_challenge_unsound`,
`decided_by: challenge_unsound`. A readiness check that cannot tell an echo from an answer is worse
than none, so it is not run.

**Falsification (all CAUGHT, `worker-readiness.js` restored BYTE-IDENTICAL, SHA-256
`8D565FE3...D75C939`):** **R19** re-quotes the literal reply and is caught by the fail-closed guard;
**R20** re-quotes it AND deletes the guard - U385's shipped defect, whole - and is caught by the new
repaint control; **R10** counts the HEAD fragment (which the prompt does contain) instead of the
joined reply, and is caught the same way; **R21** guards [[U390]]. The behavioural control is
`U385 NEGATIVE CONTROL: a ConPTY REPAINT of our own prompt is not an answer, however many times it
redraws` - it repaints FOUR times, so a mutation that merely raised the old threshold to `>= 3` or
`>= 4` would not survive it either. The in-Electron leg G was rebuilt to match: pane G's script reads
the two fragments out of what was submitted and writes them back joined, the receipt publishes
`expected_answer_absent_from_the_prompt`, `answer_occurrences_on_the_real_pane` and
`prompt_echo_occurrences_on_the_real_pane` side by side, and `readiness-window-selfcheck.test.js`
gains a `paneOnlyRepaints` flaw that must redden leg G.

**Three things this does NOT do, said here so no reader infers them.** (1) It does not make a repaint
harmless everywhere - it makes the readiness COUNT immune to one. Any other site that counts a string
it also typed has the same defect and is not touched by this row. (2) It assumes the provider can
follow a two-fragment instruction. A model that answers with the fragments SEPARATED is a false
negative - a stall we report as one, which is the fail-closed direction and correct; a false positive
would require it to emit exactly `HEADTAIL` contiguously, which the instruction produces only when
obeyed. Neither is measured against a LIVE provider anywhere in this unit: leg G's pane is a
`powershell.exe` this check wrote, so what is evidenced is the MECHANISM, not any model's compliance.
Recorded as the honest bound. (3) The conductor path in `main.js` was already free of this defect and
independently so - `conductor/roundtrip-probe.js` has refused to carry its own answer since 17A
(operands spelled in words, redrawn per run, absence asserted before submit). The worker path was the
outlier; the two now share a principle rather than a mechanism.

**State: CLOSED.** [[U385]] is discharged; its row above stands as written.

### U390 - **[[U386]](b) CLOSED: an exit is an exit, whenever it lands** (19.4, the unit after round 3)

A worker whose process died BEFORE a readiness turn was recorded `FAILED` (the MCP-connection loop,
`worker-readiness.js:434`); one that died DURING a turn was recorded `STALLED` with
`process_state: "exited"` and a real exit code beside it. One physical condition, two renderings,
separated by our own timing, with `worker-readiness.test.js` pinning the second as intended. That is
invariant 27's subject: `STALLED` says *alive and unresponsive* to anyone reading the badge.

The turn's terminal state is now derived - `process_exited_during_readiness` renders `FAILED`,
everything else `STALLED` - so both paths agree, and both the operational state and the structured
failure's `provider_terminal_state` carry it. Graded by **R21** (the divergence spliced back in
reddens the U386(b) test) and by the two updated tests that assert `FAILED` where they previously
asserted `STALLED`; the load-bearing assertions of the older one (`decided_by: process_exit`, the exit
code, and NOT the modal on screen) are unchanged, which is the point - what changed is the word, not
which instrument decided.

Nothing downstream branches on the distinction (searched: `STALLED` reaches chrome, receipts and the
inspector as a label). `main.js`'s CONDUCTOR readiness path has its own hand-written renderings and is
NOT touched by this row - it is [[U381]](a)'s territory, and a change there is a change to the pane the
operator converses in.

**State: CLOSED.**

### U391 - **[[U386]](d), (e), (f) CLOSED; (c) stays with unit 19.6** (19.4, the unit after round 3)

- **(d)** Leg A compared `boundedA.bytes` (a Buffer byte count) with `wholeA.length` (UTF-16 code
  units) and derived `bound_that_applied` from the comparison. The panes are ASCII so the reported
  `line_only` was right, but a mechanism claim may not rest on a field named `_bytes` that is not
  bytes. The whole buffer is now measured with `Buffer.byteLength(..., "utf8")`,
  `whole_buffer_chars_utf16` is published separately, and the comparison is like with like.
- **(e)** `scope_note_leg_d` now says what leg D does: its keystroke goes through the renderer's
  OPERATOR input channel (`window.sovereign.input`), not the gated system path the other legs use.
  No gate is weakened by it - the U328 gate governs SYSTEM writes, and an operator keystroke is the
  operator's own authority (invariant 1) - the pane is a check-spawned `powershell.exe` killed
  in-unit, and what leg D measures (the window's exactness) is independent of how the bytes arrived.
- **(f)** `main.js`'s self-check ctx comment said the check "supplies its own MCP session state ...
  and its receipt says so". It supplies six bindings and a seeded launch record per pane. The comment
  now counts what `check_owned_bindings` and `seeded_launch_record` count. Comment-only change; all
  three harnesses that pin `main.js` were re-pinned to `10DA014F...675970B`, with every anchor
  re-counted as present exactly once and re-run CAUGHT.

**(c) is NOT closed here** and is not this unit's: `requiredTurns` keyed on the vendor name
`"grok_build"` belongs to **unit 19.6** (the descriptor generalization), where [[U386]](c) assigned it.
It remains OPEN with that owner. Note for 19.6, from this unit: leg G uses `claude_code`, so the
`requiredTurns === 2` branch is still the one readiness path never exercised in-Electron.

**State: (d), (e), (f) CLOSED. (c) OPEN, owner 19.6.**

### U392 - **the freshness of the readiness challenge was load-bearing and graded by nothing** (19.4, round 4, gate-validator MAJOR)

**Found by the round-4 gate-validator, not by this builder, and not by any test in the repository.**
It spliced two mutations into the CALL SITE at `apps/desktop/control/worker-readiness.js:512` -
`W1` froze the challenge stamp to a constant, `W2` froze it AND dropped the turn from the head, so
that **every readiness challenge in the process's lifetime is byte-identical** - and ran the whole
desktop suite against each. Both **SURVIVED, 928/928 green**. Neither was in
`readiness_signal_mutations.js` (R1-R21 touched neither the stamp nor the turn).

**Why that is a defect and not a coverage note.** [[U389]] states, and `worker-readiness.js:271`
repeats, that "ONE occurrence is the provider speaking". That is true of the prompt we just typed. It
is **not** true of an EARLIER run's answer, which is still in the 256 KB ring and still on the
visible screen - and readiness runs a SECOND time on a pane when the conductor asks for a worker on
a provider that already has a live one (`main.js:2437`, `controlSpawnWorker`'s duplicate branch; the
first run after launch is the only other caller, and there is no periodic re-run - the first draft of
this row implied a broader trigger, [[U393]] MINOR-3). Run N+1 takes
a fresh mark, types its prompt, and the ConPTY repaint **this whole unit exists for** re-emits what
the screen holds AFTER that mark. If the two challenges are equal, run N's answer satisfies run N+1
and a silent worker is promoted: **[[U385]] one level up**, defeated only by the accident that
`io.now()` had moved. This is unit 19.4's recurring shape for the fourth time - the pure function
right, the caller wrong ([[U373]], [[U379]], the round-2 BLOCKING finding).

**The fix makes non-repetition structural rather than clock-dependent.** A module-level
`challengeStamp(now)` appends a process-incremented sequence to the clock reading, so two challenges
minted in the SAME millisecond still differ. `readinessChallenge` stays pure and its pinned tests
are untouched; the stamp it is handed is what changed. **This row's first draft said that collision
was "reachable in production, since the grok_build two-turn path types both turns without waiting".
The round-4 auditor showed it is not** ([[U393]] MEDIUM-1): turn 2's stamp is minted after turn 1
returns, and the write path awaits a 500 ms paste settle that `intervalMs` will not let an override
zero. The property the fix restores is that freshness does not rest on the CLOCK at all - which the
validator's frozen-stamp probe falsified directly - not a measured production collision. Corrected
here before this row was ever committed, and recorded rather than quietly reworded.

**Falsification (both CAUGHT; `worker-readiness.js` restored BYTE-IDENTICAL, SHA-256 moves from
`8D565FE3...D75C939` to `CA9B0D95...A00F063F` and the harness pin with it):** **R22** is the
validator's own probe kept as a permanent mutation (the stamp frozen), and it reddens exactly one
test and only that one - `U385 round 4: an EARLIER run's answer, repainted into this run's window, is
not this run's answer`, which runs readiness TWICE on one pane, answers run 1, and has the pane merely
redraw run 1's reply four times after run 2's mark. **R23** deletes only the sequence, leaving the
clock, and reddens `U385 round 4: the same instant, twice, still yields two different challenges`.

**Measured honesty about R23, recorded because the first draft of these comments said otherwise:**
R23 reddens the BEHAVIOURAL test as well on this host, because a readiness run returns when its pane
answers rather than when its deadline expires, so both runs fell inside one millisecond. That is this
host's timing, not a property, and it would go green on a slower one - which is precisely why the
same-instant property test exists and is the grader that holds at any speed. Both comments were
corrected to say what was measured.

**Not claimed:** this does not make repaints harmless, and it does not touch the CONDUCTOR readiness
path (`main.js`, [[U381]](a)'s territory). The validator's MEDIUM-1 is answered separately in the
round-4 evidence: `plainScreen` DELETES CSI/OSC sequences without substitution, so two fragments
separated only by cursor addressing become contiguous - meaning "no repaint can contain the joined
string" is exactly true only of repaints that re-emit the intervening text. Not observed in five
in-Electron runs (echo counts reached 2 and 3 while the answer count stayed 1), and defended in
production by the real `get_worker_status` count, which no repaint can fabricate.

**State: CLOSED.** Fixed, graded by two named tests and two mutations, on a tree the round-5 reviewers
must still confirm - the repair changed the tree, so round 4 is voided by *fix-after-validation*.

### U393 - **the round-4 spec-auditor: an absolute in three product files that the register had already retracted** (19.4, round 4)

`PROHIBITED DRIFT: NONE` - 0 BLOCKING, 1 MAJOR, 1 MEDIUM, 4 MINOR, over `b20355e` (the U392
remediation), read-only, foreground, sequential after the gate-validator per [[U359]].

**MAJOR-1, repaired in the tree.** `worker-readiness.js` said "No echo and no repaint of the prompt
can contain the joined string" - an ABSOLUTE - and the same claim appeared at its answer-count site
and twice in `readiness-window-selfcheck.js`. [[U392]]'s own row already states the true bound, so
the tree contradicted its register in the one sentence that licenses the `>= 1` threshold: the
auditor traced why, at `provider-readiness.js:12-14`, where `plainScreen` DELETES CSI/OSC sequences
without substitution while replacing C0 controls with a space. A DIFFERENTIAL repaint re-emitting
`head`, cursor addressing, `tail` - and skipping the 39 instruction characters between them - would
therefore normalize to the joined string. All four comments now state the bound and name what
actually defends the production path: `toolSucceeded`, a real count of `get_worker_status` calls
reaching the MCP server, which no repaint can fabricate. **This is the third time this unit has
graded an overstated sentence as a real finding ([[U384]], [[U386]](g)), and it was repaired the same
way each time - in the bytes, not in a footnote.**

**MEDIUM-1 and MINOR-3, repaired in [[U392]]'s draft before it was committed** (above, both marked
where they were corrected): the same-millisecond collision is NOT reachable on one pane in production
(500 ms paste settle), and readiness re-runs on the conductor's duplicate-worker branch rather than
"any pane that is not READY".

**MINOR-4, repaired in the tree.** The receipt's headline sentence is generated from
`CHECK_OWNED_BINDINGS.length`, and that list collapsed `now/sleep/log` into one entry - so a sentence
whose whole purpose is to count what it counts said SIX where EIGHT bindings are the check's. U384's
finding exactly, at lower amplitude. The list is now one entry per binding, and `operationCount`
discloses the simulation it is (a tool call counted on prompt DELIVERY), so a reader of the receipt
alone can now tell leg G's measured half from its simulated half.

**MINOR-1, recorded and NOT repaired - it is unit 19.6's.** The auditor agrees the `requiredTurns`
deferral is honest (owner named, no new name-keying added), and adds what [[U391]](c) omits: three
further vendor-name branches live in the same call graph - `provider-readiness.js:32/:37/:41`
(provider-keyed classification rules) and `pane-writer.js:237` (`openai_codex_cli` submit-confirm).
**Carried to 19.6 so that unit's descriptor generalization does not stop at the one branch U386(c)
named.** I-SC1.

**MINOR-2, recorded, no change.** `challengeStamp`'s process-lifetime counter fails closed (a
collision would produce a timeout, never a promotion) and is code-determined, so it does not offend
the determinism rule. The auditor's two caveats stand as written: it is the one piece of state in
this module that is neither injected nor factory-scoped (against the module's own stated principle),
and `${now36}${seq36}` is injective only while `Date.now().toString(36)` holds its width - true until
~2059. Neither is a defect today; both are recorded rather than fixed, because scoping it would be a
behaviour change made after a review round.

**The auditor's structural point, which outranks its findings and is the reason this unit does not
close here:** [[U392]]'s repair changed the tree, so **fix-after-validation voids round 4**. The
gate-validator ran on the pre-repair tree; this audit was the only reviewer over `b20355e`; and these
repairs move the tree again. ROUND3 §7 requires a round in which BOTH mandatory reviewers return with
nothing whose repair changes the tree, on the tree the receipt was taken on. **Round 5 is owed, and
it is the next unit's first act.**

**State: MAJOR-1, MEDIUM-1, MINOR-3, MINOR-4 CLOSED. MINOR-1 carried to 19.6. MINOR-2 recorded.**

**Round 4 of unit 19.4 closed nothing and proved a great deal.** Both mandatory reviewers ran
foreground, in-turn, SEQUENTIAL; each returned a MAJOR the other did not have; both were repaired
(`b20355e`, `fedbc4e`); and the unit's D-P16-0 receipt is **GREEN for the first time**
(`round4-final_223425Z`, commit `fedbc4e`, eight legs, `live_exchanges: 0`). Across the round's five
in-Electron runs the pane's echo of our own prompt was counted 2, 3, 2, 3, 3 while the answer count
stayed 1 every time - under the pre-[[U385]] rule every one of those runs would have promoted a silent
pane. **[[U385]], [[U386]](b)/(d)/(e)/(f), [[U392]], [[U393]] CLOSED. [[U386]](c) + [[U393]] MINOR-1
carried to 19.6. [[U373]] residual, [[U363]], [[U380]] to the follow-on unit. [[U387]] is the
operator's.** Unit 19.4 is NOT closed: *fix-after-validation voids round 4*, so no reviewer has yet
seen `fedbc4e`. **ROUND 5 of both reviewers is the next unit's first act.**

### U394 - **round 5: the round that changed nothing, which is the only way this unit could close** (19.4, round 5, BOTH mandatory reviewers over `fedbc4e`)

Both mandatory reviewers ran **foreground, in-turn, SEQUENTIAL** ([[U359]]) over the tree the green
D-P16-0 receipt was taken on (`fedbc4e`; the working tree at HEAD `7b464dd` is byte-identical in
every product path - `git diff --stat fedbc4e HEAD -- apps terminal tools node_runtime adapters
voice_bridge control_plane mcp_server schemas docs/canonical` is EMPTY). This is the round ROUND3 §7
and ROUND4 §7 required and the four preceding rounds could not produce: **neither reviewer returned a
finding whose repair moves the product tree.**

**gate-validator: PASS** (0 BLOCKING, 1 MAJOR, 4 MEDIUM, 3 MINOR - none product-blocking). It wrote
**12 mutations of its own**, spliced each by hand and restored every file byte-identically; 5 caught,
7 survived. It also replicated R22/R23 by hand and confirmed each reddens exactly the test that names
its defect - ROUND4 §4's most specific claim, independently re-derived rather than believed. Its
survivors are coverage gaps over correct, fail-closed shipped code, not defects:

- **F1 (MAJOR, owner 19.9)** - `main.js:2343-2346` binds `mcpState` and `operationCount`, the two
  bindings that carry the structured signal criterion C3 rests on, and `readiness-window-wiring.test.js`
  asserts neither. V10 (`mcpState` -> always connected) and V11 (`operationCount` -> `Date.now()`)
  survive behaviourally: their only red is `selfcheck-guards.test.js:74`, the byte-hash tripwire, which
  a comment-only insertion reddens identically. The shipped bindings fail closed when `sovereignControl`
  is absent. **Owner 19.9 by the directive's own words** ([[U338]]: the +846 lines stop being guarded by
  `fs.readFileSync` string matches) - adding two more string matches here would be 19.9's inadequate
  instrument applied early.
- **F2 (MEDIUM, owner 19.9)** - `main.js:2437` is the ONLY cross-run re-entry into readiness for a
  classified worker, and deleting it (V9) leaves the suite behaviourally green. Criterion C4's
  cross-run half is ungraded.
- **F4/F5 (MINOR, carried)** - the nonce window's `mark` floor (`worker-readiness.js:438`) and
  turn-level challenge freshness (`:487-488` asserts two RUNS differ, not the two TURNS of the
  `grok_build` path) are unasserted; V4, V8 and V14 survive. Both are redundant for the case
  [[U385]] closed and non-redundant for the fail-closed case, which is untested.
- **F3 = [[U382]]** (already OPEN, owner 19.9), **F6 = the [[U373]] residual** (follow-on unit),
  **F7 = [[U335]]** (owner 19.7 - `sovereign-control-server.js:62-66` returns `connected` for any
  `_lastSeen`, so the structured signal this unit elevates above the screen is itself known-unreliable
  until 19.7; it degrades diagnosis, never promotion), **F8 = [[U387]]** (the operator's, §2.5).

**Criterion C5, recorded exactly as the validator graded it and NOT rounded up: MET at module level,
NOT MET end-to-end.** The directive's required negative control - a healthy, connected, exit-0 worker
whose transcript merely MENTIONS "usage limit" or "not signed in" stays READY - is
`worker-readiness.test.js:272-286` and passes. Through the PRODUCTION [[U328]] write gate the same
worker does not stay READY: the gate reads `buffer.snapshot()`, withholds the write, and readiness
reports `STALLED` / `decided_by: write_gate_withheld`. `worker-readiness.test.js:588-617` pins that as
the current truth and receipt leg F carries `residual_u373_worker_stalls_though_connected: true`, so
**the receipt goes red the day the gate is bounded.** Repair is [[U373]]/[[U363]]/[[U380]]'s and 19.3's
gate, not this row's. No reader of this closure can infer the criterion is wholly met.

**spec-auditor: PROHIBITED DRIFT NONE** (0 BLOCKING, 0 MAJOR, 2 MEDIUM, 5 MINOR). It re-verified
invariants 1, 2, 7, 16, 27 and I-SC1 against the bytes, confirmed the untouchable set undisturbed
(`tools/loop/run_loop.ps1`, `docs/canonical/` and `schemas/` carry no reference to this unit; the
newest gate tag is still `gate/phase-18e`, there is no `gate/phase-19`, `product/multi-frontier-v2` is
present and unmoved), and confirmed the register reads as pure append with [[U389]]'s superseded
absolute LEFT STANDING and retracted by new rows. **Every one of its findings was re-verified on disk
by the builder before being recorded here** - none was taken on the reviewer's word:

- **MEDIUM-1 (product file, NOT repaired, carried)** - `apps/desktop/test/worker-readiness.test.js:429`
  still carries the absolute [[U393]] retracted ("ONE occurrence is proof of a provider and not of a
  redraw"). Verified: `grep -rn "ONE occurrence is proof\|no repaint of the prompt can contain"` over
  `apps/desktop tools terminal` returns **exactly one hit, that line**. So the answer to "did the
  retraction reach every file" is **no** - it reached the four comments in the two files [[U393]]
  named and stopped at the test. Comment only; no test, mutation or receipt leg grades differently.
- **MINOR-2 (product file, NOT repaired, carried)** - `worker-readiness.js:279-281` says a
  differential repaint skips "the 39 characters of instruction"; the separator in the template at
  `:324-326` is `" written immediately before the fragment "`, **41** characters (measured, not
  counted by eye). The hazard is named correctly; the number is wrong by the two delimiting spaces.
- **MINOR-4 (product file, NOT repaired, carried)** - the receipt's generated disclosure says "each
  pane's launch record is SEEDED", but only legs F/G/H seed one: verified `panes[] = [A, B, G, H]`
  while `seeded_launch_record.per_pane = {F, G, H}`, with nothing in the receipt mapping leg F to
  pane A. The direction is conservative (it over-discloses simulation) but it is a sentence generated
  from an object it does not match - the [[U384]]/[[U393]] MINOR-4 class again, at the lowest
  amplitude yet.

**Why MEDIUM-1, MINOR-2 and MINOR-4 are NOT repaired, stated plainly because the habit of this unit
has been to repair prose in the bytes:** all three live under `apps/desktop/**`, inside the receipt's
`product_paths`. Repairing any of them flips `tracked_product_tree_clean`, voids
`round4-final_223425Z` - the first green D-P16-0 receipt this unit has produced - and buys a **sixth**
review round for three sentences that change no behaviour, no test result and no verdict. The rule
that closes a unit is "no finding whose repair changes the tree"; changing the tree for cosmetics
after that condition is met would be the fix-after-validation trap chosen on purpose. **They are
carried to the follow-on unit, which already owns `worker-readiness.js` for the [[U373]] residual and
`readiness-window-selfcheck.js` for [[U380]].** The auditor's own recommendation was the same.

**Corrections recorded here as new rows, never edits (the docs/register-only findings):**

- **MEDIUM-2, this unit's strongest measurement was mis-attributed.** ROUND4 §6 and [[U393]]'s closing
  paragraph say "across FIVE in-Electron runs the echo counted 2, 3, 2, 3, 3 while the answer count
  stayed 1". Measured from the receipts on disk, there are **SIX** readiness-window runs carrying
  `prompt_echo_occurrences_on_the_real_pane`, and the true sequence is **2, 3, 2, 3, 3, 3** with
  `answer_occurrences_on_the_real_pane` = **1 in all six**: `round4_201556Z`=2 and
  `round4-rerun_201625Z`=3 (both at `7ca74a9`, and ROUND4 §1 itself assigns these to the PREDECESSOR
  turn that died), then `round4-fresh_212513Z`=2, `validator-r4_214956Z`=3, `round4-remediated_221142Z`=3
  (`b20355e`), `round4-final_223425Z`=3 (`fedbc4e`). **Four runs were this builder's, two were the dead
  turn's; "five" omitted the final run and silently merged two turns.** The substantive claim is
  unharmed and is now stronger, not weaker - the echo is nondeterministic 2-3 across six runs while the
  answer count never moved - but the provenance was wrong, and provenance is what this unit keeps
  getting caught on ([[U384]], [[U386]](g), [[U393]]). ROUND4 is not edited; this row is the
  correction, and ROUND5 §3 states it.
- **MINOR-1, "three product files" was two.** [[U393]]'s row TITLE says three; its own body correctly
  says "All four comments", and those four comments live in **two** files (`worker-readiness.js` x2,
  `readiness-window-selfcheck.js` x2). Verified by grep across the tree: no third file was repaired.
  The title is not edited; this is the correction. (Note the tension with MEDIUM-1: the third file a
  reader might guess - the test - is precisely the one that was NOT repaired.)
- **MINOR-3, [[U393]] MINOR-2's parenthetical named the wrong guard.** It says `challengeStamp`'s
  process-lifetime counter "fails closed (a collision would produce a timeout, never a promotion)";
  [[U392]]'s row twelve lines above states the opposite direction - two equal challenges mean run N's
  repainted answer satisfies run N+1, the FALSE-PROMOTION path, which is the entire reason the
  sequence was added. What actually holds the fail-closed line is `toolSucceeded`
  (`worker-readiness.js:437,446`), a real count of `get_worker_status` calls no repaint can fabricate.
  The parenthetical is retracted here.
- **MINOR-5, resolved by the one command the auditor named, and it is the benign branch.** The auditor
  could not tell whether `pane_input_bypass_mutations.js:139-145`'s `PINNED_BASELINE` was updated at
  `fedbc4e` WITHOUT its required note (branch i) or was stale, in which case both pin-guarded harnesses
  would have refused to run and ROUND4 §4/§5's "25/25 CAUGHT / ALL CAUGHT" would be **false** (branch
  ii, a MAJOR against the measurement claims). Measured:
  `SHA-256(apps/desktop/main.js) = 7184DD8DFF63D81BC3CFD9423D57E9BC531808F91C1C3D969ED92374923B1A06`
  = the pinned value = the value at `system_pane_write_mutations.js:116`. **MATCH -> branch (i).** The
  pin is current for `fedbc4e` and both harnesses genuinely ran: the builder re-ran all four this round
  (25/25, ALL, 23/23, 5/5, every file restored byte-identical). What is short is the docblock's note
  trail, whose last entry stops at [[U386]](f) though `main.js` changed again at `fedbc4e`
  (`main.js:3043-3051` now cites [[U393]] MINOR-4). `tools/mutation/` is OUTSIDE the receipt's
  `product_paths`, so this one COULD have been repaired without voiding the receipt - it is not,
  because editing a file a reviewer read, minutes after it read it, is the same trap at a smaller
  scale. Carried with MEDIUM-1/MINOR-2/MINOR-4.

**Builder's own measurements this round, foreground, on the closing tree:** desktop **930 pass / 0
fail / 0 skipped**, terminal **216 / 0**, readiness-signal **23/23 CAUGHT**, system->pane **25/25
CAUGHT**, pane-input **ALL CAUGHT**, orchestration **5/5 CAUGHT**, every mutated file restored
BYTE-IDENTICAL by SHA-256, `git status --porcelain` empty after all four harnesses. The gate-validator
measured the same six numbers independently. **No Electron run was taken this round and none was
owed**: the tree did not move, so `round4-final_223425Z` describes exactly these bytes - re-running it
would produce a second measurement of the same commit, not a new fact. **D-LOOP-1: no pane, no session
and no live provider call was created this round; `live_exchanges` remains 0 for the unit.** Python
suites not run, and the reason is not that they are slow: no commit in this unit touches a `.py` file -
19.10 owns that run ([[U339]]).

**State: unit 19.4 CLOSES on this round.** [[U329]] closed with graded falsification; [[U384]],
[[U385]], [[U386]](b)/(d)/(e)/(f)/(g), [[U392]], [[U393]] CLOSED; [[U386]](c) + [[U393]] MINOR-1
carried to **19.6**; [[U382]] and gate-validator F1/F2 to **19.9**; [[U335]]/F7 to **19.7**;
[[U373]] residual + [[U363]] verdict half + [[U380]] + this row's MEDIUM-1, MINOR-2, MINOR-4, MINOR-5
and F4/F5 to the **follow-on unit**; [[U387]] is the operator's. **No tag is applied** -
`gate/phase-19` is unit 19.10's and `product/multi-frontier-v2` is never moved.


### U395 - **OPEN: the write gate reads the last 80 non-blank lines of the last 16 KB, which on a tall pane is LESS than the current screen** (measured by the 19.4-followon round-1 gate-validator; owner: the unit that gives the window a row-aware bound)

Bounding the U328 gate ([[U373]]'s residual) is a LOOSENING, and this row is the part of it that is
not the intended effect. The validator built the differential itself - real `RingBuffer`, real
`createScreenWindow`, `HEAD~1`'s whole-buffer reader against `HEAD`'s bounded one - and simulated a
full-screen repaint drawing a live trust modal near the top of the pane:

```
rows=24 -> WORKSPACE_TRUST_REQUIRED    rows=30 -> WRITE-ALLOWED
rows=40 -> WRITE-ALLOWED               rows=50 -> WRITE-ALLOWED
```

`apps/desktop/main.js` spawns panes at `rows: spec.rows || 30` and the renderer then fits them
LARGER, so `TAIL_LINES = 24` made the window structurally smaller than the screen it claimed to
judge. Not a stale modal, not a dismissed overlay ([[U372]] is that, and is a different row): a modal
that is up, on the current screen, in the same repaint frame, WRITABLE where the read it replaced
refused. For `WORKSPACE_TRUST_REQUIRED` and `MCP_PERMISSION_REQUIRED` - families a keystroke really
does answer - that is a regression against invariant 1.

**Narrowed in-unit, not closed.** `TAIL_LINES` is **80** (`apps/desktop/control/worker-readiness.js`),
which covers the spawn default and a maximized pane on this host; the byte bound (16 KB) still bounds
the cost. A pane taller than 80 non-blank lines crops again, and the BYTE budget is spent on the RAW
stream - escape sequences included - so a heavily-repainting TUI buys fewer lines with it than plain
text does (round-1 spec-auditor, MEDIUM-3). Both module headers now state the bound as what it is
rather than as "the pane's CURRENT screen", which is the sentence that was wrong.

**The fix is a row-aware bound** taken from the session's geometry, which needs the pane's rows in
`createScreenWindow` and is this row's work. That closes the geometry half; the byte budget and the
absence of a real terminal emulator in the main process ([[U372]]) are the rest of the gap.
State: **OPEN**.

### U396 - **CLOSED in 19.4-followon round 1: five gate-validator mutations survived all 939 tests, four are now graded**

The validator wrote eight mutations of its own against this unit's new code and ran the full desktop
suite against each. Recorded as it measured them:

- **V7 (the one that mattered): `lastLines` without `.reverse()`** - the window returned in reverse
  screen order, 939 tests green. Order is load-bearing: the numbered-menu affordance
  `/\b[1-9]\.\s*yes\b[\s\S]{0,80}?\b[1-9]\.\s*no\b/i` requires "1. Yes" BEFORE "2. No", so
  reversal turns the antigravity permission screen from refused into written-into. Graded now by
  **R26** and asserted directly (`worker-readiness.test.js`, "U396/V7").
- **V1 / V5: the gate's window narrowed** (`{maxBytes: 512, maxLines: 4}`) and the affordance judged
  on `screen.slice(-200)`. The suite pinned the BINDING (`paneScreenFromWindow(readinessWindow)`,
  textually) and the PATTERNS, and nothing pinned how much screen the gate looks at - so the drift the
  header called structurally impossible was possible in the BOUNDS while impossible in the OBJECT.
  Graded now by **P20/P21** and asserted (`pane-writer.test.js`, "U396/V1", "U396/V5").
- **V8: the modal refusal reporting `state: "BUSY"`** - it still refuses, so this is observability,
  not authority; but `state` is what reaches the conductor's chrome and `write_withheld.state`.
  Graded by **P22** and asserted ("U396/V8").
- **V2: `answerable !== true` -> `=== false`** - an EQUIVALENT mutant against the production window,
  which always returns an explicit boolean. Recorded rather than graded: the defence is against a
  future window shape, and pinning it would pin nothing today.

State: **CLOSED** (V1/V5/V7/V8 graded and asserted; V2 recorded as equivalent).

### U397 - **OPEN: the `echoIsWhole`-always-false direction became a verdict when the gate's window became bounded, and the harness that predicted it did not notice** (found by the 19.4-followon round-1 spec-auditor; owner: the next unit to touch `pane-writer.js`, or 19.9's extraction)

`tools/mutation/system_pane_write_mutations.js` deliberately does not mutate `echoIsWhole` to always
answer FALSE, and it justified that with a claim about the code: the settle loop breaks on
`refusal === null || echoIsWhole(...)`, so with an APPEND-ONLY whole-buffer signal a refusal is
monotone within the settle window and a permanently-false predicate can only spend more of the bound
before refusing - latency, not safety. The note then set its own trigger, in the future tense: *"Unit
19.4 replaces that window with `RingBuffer.sliceFrom()`. When it does, re-derive this... Then it is a
verdict, and it needs a mutation."*

**The trigger fired in this unit** and the note still read as a promise. A bounded window CAN drop a
modal out of view during the wait, at which point a permanently-false predicate polls on to a clean
read and DELIVERS where the real predicate would have broken early and withheld.

Not graded here, and the reason is a missing fixture rather than a judgement: the mutation needs a
scenario in which the modal leaves the window DURING the settle wait, which this unit did not build.
The harness note is rewritten in the present tense and cites this row. **A harness that states an
obligation and then does not notice its own trigger is the [[U367]] class** - which is why this is a
row and not a comment. State: **OPEN**.

### U398 - **CLOSED in 19.4-followon round 2: the one BEHAVIOUR change of the round-1 remediation was ungraded, and deleting it left all 942 tests green** (found by the round-2 gate-validator, MAJOR-1)

The round-1 spec-audit's MEDIUM-13 repair - collapsing the PROVIDER-CONTROLLED affordance excerpt to
one line before it reaches a refusal reason - was the only behaviour change in `6bf3ec0`. The
round-2 validator mutated it two ways (the excerpt verbatim; a space-only collapse that leaves the
newline) and **both survived the whole desktop suite**. No mutation in any of the four harnesses
touched `control/modal-affordance.js`, which was on the invariant-1 decision path with no pin at all.

What made it a MAJOR rather than a MINOR is where the change had been recorded:
`tools/mutation/system_pane_write_mutations.js` **re-pinned both files at that commit and named this
change by name** in its twelfth re-pin note - and added no mutation for it. A harness that records
its own trigger and does not act on it is [[U397]]'s pattern, recurring inside the unit that opened
U397, and it is against this harness's own stated standard (*"a guard that has never been shown to
fail is not a guard"*).

The failure it protects against is concrete: the numbered-menu pattern matches ACROSS a newline, and
`affordance.text` travels into `modalRefusal.reason` -> a single-line shell log -> the
`conductorLaunch.reason` the operator reads in the pane chrome. Un-collapsed, a model's own pane
output forges a second log line and a second chrome line - it writes the record that is watching it.

Closed: `[AFFORDANCE]` (`apps/desktop/control/modal-affordance.js`) is pinned in the harness for the
first time and **P23/P24** grade both directions, with a behavioural assertion beside them
(`pane-writer.test.js`, "a refusal reason is ONE line") covering the newline, the joined excerpt and
the length bound. State: **CLOSED**.

### U399 - **CLOSED in 19.4-followon round 2: the register said OPEN where the unit had closed, and [[U373]]'s row was FALSE at HEAD** (found independently by both round-2 reviewers, MEDIUM-1 each)

Round 1 appended three rows ([[U395]], [[U396]], [[U397]]) and nothing else. But the unit had closed
[[U373]]'s residual and [[U380]], and narrowed [[U363]] - and the checkpoint and `LOOP_STATE.json`
both said so while the ledger a later iteration actually consults still headed both rows **OPEN**.
Worse than stale: U373's row asserted *"the production-write-gate test requires `ready === false` and
goes RED the moment the gate reads a bounded window"* - which inverted in this very unit. A reviewer
or iteration reading the register for what is owed got the wrong answer about the highest-stakes row
the unit touched.

Rows are never edited in place, so the corrections are here:

- **[[U373]]'s residual is CLOSED.** `control/pane-writer.js` no longer calls `buffer.snapshot()`;
  `paneScreenFromWindow` maps `answerable !== true` to UNREADABLE and refuses; `main.js` passes the
  SAME `readinessWindow` object readiness classifies through. The test that required `ready === false`
  now requires `ready === true` (`worker-readiness.test.js`, "THE NEGATIVE CONTROL, END TO END"),
  which is the directive's own 19.4 negative control holding end-to-end rather than at module level.
  The sentence quoted above is retracted.
- **[[U380]] is CLOSED.** The window's line bound keeps the last N NON-BLANK lines; a repainting
  provider's blanks no longer spend the bound on nothing.
- **[[U363]] is NARROWED, not closed.** Seven of the 19.3 validator's ten permission screens refuse
  where one did; the three survivors are asserted as the residual (`pane-writer.test.js`). The
  positive-evidence half is still owed. Nothing in the tree says U363 is closed.

State: **CLOSED**. The lesson is procedural and belongs to the loop, not to a module: a unit that
closes a row appends the closure in the same commit as the code, or the ledger and the evidence
diverge in the one direction nobody re-reads.

### U400 - **OPEN: [[U395]] amended - the byte half bites at the SPAWN DEFAULT, so a row-aware bound does not close it** (measured by the round-2 gate-validator, MEDIUM-2; owner: the unit that takes U395's fix)

U395 recorded the byte budget qualitatively (*"a heavily-repainting TUI buys fewer lines with it"*)
and stated its fix as a row-aware bound taken from the session geometry. The round-2 validator
measured the case, and the fix statement does not survive it:

- A **30-row** full-screen repaint with per-cell SGR colouring is **32,596 raw bytes** - twice
  `TAIL_BYTES` (16,384). The tail then holds the bottom half of ONE frame, and a live trust modal at
  row 5 of a **spawn-default** pane (`main.js`, `rows: spec.rows || 30`) is WRITE-ALLOWED.
- Calibration sweep: at 4-40 SGR runs per line and 100-240 columns a frame stays <=14,580 B and the
  modal is correctly refused. The trigger is DENSE styling - a syntax-highlighted diff view reaches
  it - not an exotic geometry.

So the residual is not only "a pane taller than 80 lines". At the default geometry the ROW bound is
already sufficient and the BYTE budget is what drops the frame, which means a row-aware bound alone
leaves this case exactly where it is. Both module headers and the generated receipt sentence now
state both halves with the measured number. Also corrected here: U395's *"80 covers the spawn default
and a maximized pane on this host"* - the maximized pane's row count was never measured, and the only
measurement in evidence was taken against `TAIL_LINES = 24`. It reads "the 30-row spawn default with
margin" now (round-2 spec-auditor, MEDIUM-3). State: **OPEN**.

### U401 - **OPEN: raising `TAIL_LINES` 24 -> 80 widened two things the change recorded as a one-sided narrowing** (round-2 gate-validator MEDIUM-3 + round-2 spec-auditor MEDIUM-2; owner: 19.6/19.7 as they touch the conductor path)

The raise was reasoned about for the WRITE GATE, where reading more can only refuse more. Two other
consequences went unrecorded:

- **[[U372]]'s window is 3.3x wider.** The readiness classifier reads the same bound, so a dismissed
  overlay stays classifiable across 80 non-blank lines instead of 24. Bounded blast radius - these
  reads only run when the MCP session is NOT connected, i.e. on an already-failing pane, and
  `trackObservation` resets on the first poll that no longer classifies - which is why it is a
  diagnostic imprecision and not a pin. Now stated in `worker-readiness.js`'s own header.
- **[[U381]](a) widened in the other direction.** `main.js`'s conductor readiness promotes the gate's
  refusal straight to the conductor node's operational state, and this unit widened the refusal SET
  (the affordance families). So a conductor pane merely showing `(y/n)`, "press enter to continue" or
  a numbered yes/no now badges the conductor `PROVIDER_SETUP_REQUIRED` and returns not-ready, on a
  single-shot path with no retry, where before it did not. Nothing is typed into that pane either way
  - the gate is doing its job - but the operator reads a provider-setup label for a healthy provider.
  U381(a) is therefore narrowed in one direction and widened in the other, not closed.

State: **OPEN**.

### U402 - **CLOSED in 19.4-followon round 2: four fixtures were written against a literal instead of the bound they exist to exceed** (round-2 spec-auditor, MEDIUM-4)

Round 1 fixed exactly this in one fixture ([[U367]]'s class: the raise to 80 stopped it clearing its
own bound, so it passed with a mutation spliced in and was graded only by its second assertion) and
left three siblings plus the self-check untouched: `worker-readiness.test.js` and
`pane-writer.test.js` each carried a bare `CLEAN.repeat(120)`, `pane-writer.test.js` graded U395 on
`CLEAN.repeat(60)`, and `readiness-window-selfcheck.js` carried `OVERWRITE_LINES = 120` whose
headroom had silently fallen from 5x to 1.5x. One of them wrote the value `80` into a comment - the
same shape as the module headers round 1 had just repaired.

All four now derive from `TAIL_LINES`. A fixture whose job is to sit outside the bound reads the
bound. State: **CLOSED**.

### U403 - **RECORDED, not a defect: `source.product_paths` does not cover `tools/mutation/`, deliberately** (round-2 gate-validator, MINOR-2)

`tracked_product_tree_clean: true` is computed over `apps/desktop`, `terminal`, `tools/live`,
`node_runtime`, `adapters`, `voice_bridge`, `control_plane` - so the four falsification harnesses this
unit modified are outside the claim, which is narrower than the field name suggests to a reader.

It is a design decision, not an oversight, and it is stated at
`tools/mutation/pane_input_bypass_mutations.js`: the harnesses live outside every declared product
path **so that running one changes nothing a packaged receipt covers**. Widening the set would make an
in-flight harness (or a stale `.mutation.lock`, which is not gitignored) dirty the tree of any receipt
taken beside it. The rationale is now stated in the sibling harness too, so it is discoverable from
either. The receipt publishes `product_paths` verbatim, so the scope is disclosed rather than implied.
State: **RECORDED** (no action).

### U404 - **RECORDED: the "MOVED, not rewritten" claim has one byte-level non-identity** (round-2 gate-validator, MINOR-3)

`control/modal-affordance.js` wraps `PROMPT_MARKERS` and `UNSAFE_MODE_MARKERS` in `Object.freeze()`;
`voice/pane-state.js` at `58f9ab6` did not. A strengthening, no caller mutates them, and the
validator's independent differential fuzz (1,620,000 comparisons including Buffer inputs and both
`supervisorBoundary` values) found **0** behavioural differences. Recorded only because the claim
under review was "0 differences" and a claim that is true behaviourally and false byte-for-byte
should say which it is. State: **RECORDED** (no action).

### U405 - **CLOSED in 19.4-followon round 3 by EVIDENCE, not prose: the U328 receipt string was repaired and the U328 receipt was never re-taken** (round-3 spec-auditor, MAJOR-1)

`fe149e5` repaired `system-pane-write-selfcheck.js`'s `finding` and `scope_note_screen_signal` - the
round-2 MAJOR-2 defect, a receipt describing a whole-buffer denylist read and promising in the future
tense that "unit 19.4 narrows it". But the newest PUBLISHED U328 receipt was still
`PHASE19_3_SYSTEM_PANE_WRITE_SELFCHECK_phase-19.3.round2_20260810T131740Z.json`, which carries the
FALSE string. The repair existed only in source, in the unit that changed the write gate, against the
19.4 close's own stated trigger (*"that leg goes RED the day the gate is bounded, and that is the
signal to re-take the D-P16-0 receipt"*). Two guards that hold the sibling claim were both absent:
nothing asserts on this receipt's `finding`, and the check had not run since 19.3.

Discharged the only way a receipt claim can be: the check was re-run in-Electron at HEAD ->
`PHASE19_3_SYSTEM_PANE_WRITE_SELFCHECK_phase-19.4-followon.round3_20260811T024929Z.json`, **ok: true,
4/4 legs**, `source.commit fe149e5`, `tracked_product_tree_clean: true`, `live_exchanges: 0`, both
strings correct at publication. Re-running a check is an EVIDENCE act, not a code change, so it does
not void the round-3 reviewers who had just passed the code.

What is NOT closed and is carried: nothing pins those two strings, and they state the bounds as
hardcoded literals (see [[U406]]). State: **CLOSED**.

### U406 - **OPEN: the U328 self-check's two disclosure strings are ungraded and hardcode the bounds** (round-3 gate-validator MEDIUM-2 + round-3 spec-auditor MEDIUM-2; owner: whoever next changes `TAIL_BYTES`/`TAIL_LINES`, i.e. [[U395]]/[[U400]]'s owner)

In the same commit that derived the SIBLING self-check's disclosure from `TAIL_LINES`/`TAIL_BYTES`
and added a test pinning those values, `system-pane-write-selfcheck.js`'s `finding` and
`scope_note_screen_signal` were rewritten with the literals "80 non-blank lines" and "16 KB", and
neither `system-pane-write-selfcheck.test.js` nor `system-pane-write-wiring.test.js` asserts on
either field.

The failure is dated rather than hypothetical: the moment U395/U400 changes either constant - and
that row's whole point is that one of them must - every test stays green and the D-P18-13 receipt
ships a disclosure stating the wrong bound for what the invariant-1 write gate can see. *"A receipt
outlives the prose around it"*, recurring in the third instrument.

Also carried here, same file, same strings: the `finding` says *"as the screen stood at the last read
before each keystroke"* where `pane-writer.js` is careful that "the pane's CURRENT screen" means the
last `TAIL_LINES` non-blank lines of it, *"which is not the same sentence"* (round-3 spec-auditor,
MEDIUM-2); and the finding qualifies its absolute for U363 and U395 but not for [[U360]] -
`withoutOwnEcho` deletes our body's character sequence before the submit-key judgement and nothing
confines the deletion to our echo's REGION, which is a third way a recognised modal can go unrefused
(round-3 spec-auditor, MINOR-4). State: **OPEN**.

### U407 - **OPEN: the length bound on the provider-controlled excerpt is unreachable today, so nothing grades it** (round-3 gate-validator MEDIUM-1; owner: the unit that next extends `PROMPT_MARKERS`)

[[U398]]'s new assertion grades the newline and the joined excerpt. It does NOT grade
`.slice(0, 120)`: the flood fixture puts its 4,000 characters OUTSIDE the regex match, and
`affordance.text` is the match, not the screen - so the measured reason length is 168 against a bound
of 400, with 232 characters of slack no provider input can consume. The validator deleted the slice
and ran the full desktop suite: **944 pass, 0 fail.** No harness mutation targets it either.

Why it is a row and not a repair: the slice is currently UNREACHABLE, because the longest pattern
(`/\b[1-9]\.\s*yes\b[\s\S]{0,80}?\b[1-9]\.\s*no\b/i`) caps the post-collapse match at ~93 characters.
The exposure is latent - a later unit adds a pattern with a long or unbounded interior, a reader then
removes the "redundant" slice with the suite green, and provider-controlled text of arbitrary length
flows into the shell log, the operator-visible chrome and the IPC envelope. That is the same class as
the MAJOR it was written to repair (an assertion naming a guarantee it does not grade), which is why
it is recorded rather than left to be rediscovered. [[U398]]'s closure text overstates itself by
listing "the length bound" among what it covers; retracted here. State: **OPEN**.

### U408 - **OPEN: four prose corrections the round-3 reviewers found in the round-2 prose repairs** (carried deliberately, NOT repaired in-tree: repairing after round 3 would void it and this unit has spent three rounds in that loop)

Recorded verbatim so the next unit to touch these files can take them without re-deriving:

- **`readiness-window-selfcheck.js`'s `wholeBuffer` JSDoc**, the clause immediately ABOVE the sentence
  written to fix round 2's MAJOR-1: *"computed only as the CONTRAST for legs A and F"*. Wrong twice -
  it is also the banner precondition every pane A/B/G/H/I is gated on, and leg F does not call it at
  all (it reuses `wholeVerdict` from leg A). The scope sentence in an instrument undercounting its own
  use, one line above the repair for that exact shape. **The REPLACEMENT sentence itself was verified
  TRUE and exhaustive** by the auditor: `snapshot()` has exactly one production reader in
  `apps/desktop/`, and "STRICTER, not looser" is correct - `pane-state.js` refuses on absence.
- **`modal-affordance.js` inflates the validator's corpus**: it says "1,620,000 generated screens"
  where [[U404]] and the validator say 1,620,000 COMPARISONS (~405,000 screens x 4 variants). Both
  cannot be right; the register is the accurate one. "re-established" is also stronger than a
  differential fuzz over a generated distribution supports.
- **[[U404]]'s caveat reached the destination file and not the one that makes the claim**:
  `voice/pane-state.js` still says *"The lists are UNCHANGED - they moved, they were not rewritten"*,
  the absolute U404 exists to caveat, in the file a reader of the voice path reaches first.
- **The `TAIL_LINES` note retracted one unmeasured geometry claim and left its twin**: *"the renderer
  then fits them LARGER"* is the same unmeasured shape as the "maximized pane" claim retracted beside
  it. The renderer does refit; the only refit measured anywhere in this repo is SMALLER (`ESC[8;7;65t`
  - 7 rows x 65 columns). The argument does not need the direction, since the byte half bites first
  at the default geometry anyway.
- Lower amplitude, same file family: *"U372's condition, 3.3x wider"* is the ceiling in the LINE
  dimension only and should read "up to 3.3x, where the byte budget does not bind first" ([[U401]] and
  [[U400]] are in mild tension on this); an unqualified "Round 3" at `readiness-window-selfcheck.js`
  refers to 19.4's round 3 and reads as this one's; a previous-pin prefix in
  `readiness_signal_mutations.js` carries 9 hex digits where every sibling uses 8.

State: **OPEN**.

### U409 - **OPEN: a fifth fixture of the [[U402]] class survives, and an anonymous twin of a cited receipt sits in the evidence directory** (round-3 gate-validator MINOR-1 + round-3 spec-auditor MINOR-3)

[[U402]] closed on "four fixtures"; the count is not exhaustive.
`worker-readiness.test.js`'s `q.buffer.push("line A\r\n\r\n".repeat(100))` is 100 non-blank lines
against a bound of 80 - a 1.25x margin, tied to no constant, and if `TAIL_LINES` ever reaches 100 the
fixture stops exceeding the bound and `assert.ok(kept.length <= TAIL_LINES)` becomes vacuous. The
[[U367]] class inside the row that declares it closed.

Separately: `PHASE19_4_READINESS_WINDOW_SELFCHECK_run_20260811T022610Z.json` is an UNLABELLED
(`"unit": null`) run of the same code against the same commit, 27 s before the cited receipt, both
`ok: true`, `finding` byte-identical - the runner's `--unit` flag was passed positionally the first
time and did not take. It is KEPT rather than deleted (evidence is append-only, and a run that
happened is a run that happened) and disclosed here, because the round-3 validator's structural diff
of the two is what establishes it is a twin and not a discrepancy. An evidence directory with an
anonymous twin of a cited receipt invites the wrong one being read. State: **OPEN**.
### U410 - **OPEN: `record_synthesis` reaches COMPLETED with no debate gate at all** (19.5 round-1 gate-validator MEDIUM-3)

The U332 gate this unit built lives at `mcp_server/sovereign_tools.py:_considered_debates`, on the
TOOL path. `mcp_server/collaboration_service.py:record_synthesis` enforces only the completeness rule
(a candidate from every worker) and will move a task to COMPLETED while a debate on it is still OPEN -
the validator's probe P2 did exactly that and got back `'COMPLETED'`. Not exploitable in the product
today: the tool is the only caller and it gates first. But invariant 16 ("failed artifacts cannot
advance") is then enforced at a boundary rather than at the state transition, which is the same shape
as [[U326]] - the rule in one place and the write in another. Related asymmetry from the same probe
run: `record_candidate` accepts an ABORTED debate in `debates_considered` while the conductor is
forbidden from counting that debate in its synthesis (P5). Not repaired in 19.5 because repairing
after validation voids the validation, and the fix belongs with whoever next opens the service's
legality surface. State: **OPEN**.

### U411 - **OPEN: the synthesis gate is only as complete as the caller's debate-read scope** (19.5, disclosed by the builder at the time of writing)

`_considered_debates` reads the task's debates through `CollaborationService.list_debates`, which
filters by `authorize_debate_read`. That is the correct direction - the tool layer must not read past
the authority - and today it is exhaustive, because only the directing roles pass
`authorize_publish_synthesis` and `_SCOPED_ROLES` does not contain them. If debate-read scoping ever
narrows for a directing role, an unreadable debate becomes an INVISIBLE one and the gate weakens with
no test failing. Recorded so the coupling is argued in the open rather than discovered. State: **OPEN**.

### U412 - **OPEN: the Inspector renders an ABORTED debate with the green ACCEPTED chip** (19.5 round-1 gate-validator MEDIUM-5, disposition agreed)

`apps/desktop/renderer/renderer.js:624` maps `d.state === "OPEN" ? "CANDIDATE" : "ACCEPTED"`, and
`apps/desktop/renderer/index.html:121` colours `.st-ACCEPTED` green. The ABORTED state this unit
introduced therefore renders as a concluded deliberation. The label itself is `esc(d.state)`, so the
word "ABORTED" is shown and only the hue lies. The three-line fix (an `OPEN -> CANDIDATE`,
`CLOSED -> ACCEPTED`, else `REJECTED` chip plus an abort-reason line) was written and then REVERTED
out of this unit: D-P16-0 binds every shell/UI change to an automated check inside the packaged
Electron runtime, this unit builds no such receipt, and `renderer.js` has no test of any kind
(the [[U338]] family). Owner: unit **19.8**, which is chartered to add the in-runtime self-check kind
for the orchestration/collaboration path and is therefore the first unit that can grade it. The
Python-side emitter is NOT affected - `tools/live/emit_operational_state.py` counts
`aborted_debate_count` separately and is covered by a test. State: **OPEN**.

### U413 - **OPEN: `tests/integration/test_mcp_server.py::test_concurrent_writers_yield_conflict_never_silent_overwrite` is non-deterministic BY CONSTRUCTION, and [[U282]] now has its diagnosis** (19.5 round-1 gate-validator MEDIUM-1/MEDIUM-2)

The round-1 validator ran the long suites three times at 19.5's work commit and got a single failure
on two of them (`test_mcp_server.py::test_concurrent_writers_...` twice, `test_opencode_candidate_live.py`
once), against 486 passed on the parent twice. Neither test touches this unit's code. The mechanism,
which is what [[U282]] was owed: `mcp_server/memory_service.py:99-119` reads the head, calls
`lifecycle.validate_status_transition` against it, and only THEN reaches the CAS layer. If the losing
racer reads AFTER the winner commits, it is refused by the legality check
(`illegal memory status transition ACCEPTED -> ACCEPTED`) and never reaches the CAS - so the D-MCP-03
mandatory property "the loser receives a conflict record" holds only when both threads read before
either commits. Nothing is silently overwritten and invariant 13 is intact; the mandatory TEST is what
is unsound, not the fence. This also means "2360 passed" in 19.5's work-commit message describes a run
that the validator could not reproduce at HEAD, and the evidence report says so. State: **OPEN**.

### U414 - **OPEN: `ABORTED` is a fourth debate-outcome vocabulary beside the frozen `debate@1.0` enum** (19.5 round-1 gate-validator MINOR-6)

`schemas/debate.schema.json@1.0` pins outcomes `["CONVERGED","DISSENT_PRESERVED","BUDGET_EXHAUSTED","CUT_OFF"]`
for the Phase-7 Debate Service. The operational debate record written by
`mcp_server/collaboration_service.py` is unschematized, so nothing is violated - but ABORTED overlaps
`CUT_OFF` and the abort tool's own description ("a participant's pane died, or its budget is spent")
overlaps `BUDGET_EXHAUSTED` directly. Two debate vocabularies that mean nearly the same thing will be
reconciled by someone eventually; recording it now means that person finds the divergence written
down rather than inferring it. The frozen schema is NEVER edited (Phase-0 freeze); if a reconciliation
is wanted it is a successor-schema question of the [[OP-12.1]] kind. State: **OPEN**.

### U415 - **OPEN: five smaller residues from the 19.5 round-1 review, carried rather than repaired** (round-1 gate-validator MINOR-2/3/4/7/8)

(a) `update_task` now validates `progress must be an object` BEFORE `_require_task`, inverting the
"authority before anything else" ordering `_require_debate` documents - it discloses nothing new (the
message depends on no record) but the ordering is now inconsistent within one module.
(b) `abort_debate` sends no message to the participants it affects, so the peers U331 describes as
waiting are still not TOLD; they must read. `close_debate` has the same silence, so it is at least
consistent.
(c) `post_debate_turn` builds its peer message's recipients and thread from the PRE-transaction
snapshot; safe only because nothing mutates `participant_node_ids` today - the same "safe until the
field becomes mutable" caveat as the in-fence policy re-checks.
(d) `apps/desktop/inspector/operational-source.js:65-67` omits `aborted_debate_count` from its
failure-path summary while the success path now carries it.
(e) A TOCTOU between `_considered_debates` and `record_synthesis`: a debate opened in that window is
not caught, and a debate can be opened on an already-COMPLETED task. Narrow under a single conductor.
All five are MINOR, none changes an observable verdict today, and repairing prose-and-ordering
findings after the reviewers have passed is what cost 19.4 five rounds. State: **OPEN**.
### U416 - **OPEN: the debate-stall defect this unit fixed, and the label collision it was filed under** (19.5 round-2 gate-validator MEDIUM-2)

**The defect (now fixed by unit 19.5, kept OPEN only for the disclosure below).** A bounded debate
could reach no terminal state but CLOSED, and closure requires a turn from every participant. A
participant whose pane died therefore left the debate OPEN permanently: its peers accumulated stall
timers, and the task's synthesis gate - which refuses to publish while a debate on the task is open -
was blocked behind a node that would never answer. Fixed by `abort_debate`
(`mcp_server/collaboration_service.py`), its rule `authorize_debate_abort`
(`control_plane/policy.py`), the `abort_debate` tool, and the ABORTED handling in the synthesis gate
and the operational feed. Graded by mutation rows A1/A1b/A2/A3 and by
`tests/unit/test_operational_write_path.py` §3.

**The collision, which is why this row exists at all.** `AUTONOMOUS_BUILD_DIRECTIVE.md` §18's row for
unit 19.5 calls this defect "**U331 note**". Register **[[U331]]** is a DIFFERENT issue - *"conductor
readiness is hard-pinned to one vendor and one model"*, opened by the same cold audit and owned by
unit **19.6**. The debate-stall defect had no register row of its own. Unit 19.5 initially propagated
the directive's label into sixteen code, test and tool sites, which would have made its evidence read
as closing U331 while U331 itself stayed untouched and owed - against the Phase 19 exit criterion that
every one of U326-U339 is closed with evidence or re-recorded with a reason. Every one of those
citations now reads U416. The directive text is NOT edited: it is the operator-adopted document, and
the correction belongs in the register that the directive's own numbering refers to.

State: **OPEN** - the code defect is closed; the row stays open until 19.10's gate records the
disambiguation alongside U331's separate closure by 19.6.

### U417 - **OPEN: three residues from the 19.5 round-2 review, carried** (round-2 gate-validator MINOR-5/8/9)

(a) No committed mutation row uses `tests/integration/test_operational_concurrent_processes.py` as its
selector - row F7 grades the same defect through the deterministic unit test instead. The two-process
test's own falsifying power is therefore established by the measurements in this unit's evidence
(4/4 spliced, 4/4 clean, 4/4 blind-watcher, plus the round-2 validator's independent 12/12 and 66/66)
and not by anything that re-runs. A duplicate F7 row with the integration selector would make it
permanent for about three seconds of runtime.
(b) Field-level last-write-wins survives the fence: `collaboration_service.py`'s `update_task` writes
`{**current, "status": status}`, so two directing callers racing a status change still resolve
silently with no conflict object - invariant 13's shape at field granularity rather than record
granularity. Narrow under a single conductor, and it is exactly the fix the directive prescribed;
recorded so it is written down rather than discovered.
(c) The integration/security/recovery/evaluation suite runs at 560-573 s against the 600 s budget -
about 5% headroom, with `test_opencode_candidate_live.py::test_live_drive_then_governed_candidate_and_merge`
alone at 155-200 s. That is [[U339]]'s charter (unit 19.10), but this unit's evidence should not present
560 s as roomy. State: **OPEN**.
### U418 - **OPEN: eight findings from the 19.5 round-3 gate-validator and round-1 spec-auditor, carried** (round-3 MEDIUM-1/MEDIUM-2/MINOR-C/D + spec-audit MEDIUM-1/3/4/5)

(a) **D-LOOP-1, the other half.** `tests/integration/test_operational_concurrent_processes.py`'s
`finally` signals and kills the WATCHER, but `Popen.communicate(timeout=...)` does not kill a worker,
so a hung worker survives the test - the round-3 validator demonstrated two live `hang_worker.py`
processes after the test raised. Same file: if the FIRST worker times out the second is never waited
on, `procs` is bound inside the `try` so a mid-comprehension spawn failure leaks what was already
started, and `tests/fixtures/operational_race_worker.py`'s barrier spin is unbounded (the watcher got
a self-deadline; the workers did not). Only fires when product code hangs; the fixed tree runs the
test in 2.6 s.

(b) **The abort precondition is asserted by a model and verified by nothing.** `abort_debate`'s
rationale is "a participant can no longer answer", and the only check is that `reason` is non-empty.
Nothing correlates the abort with node liveness, which the supervisor already tracks
(`apps/desktop/main.js` `debateTurnTimers` / `markWorkerDeadlineFailure`), and no structured field
records WHICH participant was unresponsive. Because an abort unblocks the synthesis gate, a gate
outcome now depends on free-text model output in a way it did not before (Buildout Directive s4:
fail closed on unverified capability). The fail-closed shape is a structured `unresponsive_node_ids`
checked against supervisor state.

(c) **An abort leaves no append-only trace.** Every other governance act on this path emits an
`operational_messages` row; an abort writes mutable fields into a mutable row and emits nothing, so
the record of who ended a live deliberation and why exists nowhere immutable. `close_debate` shares
the silence but produces a `decision` the gate consumes. Supersedes the framing in [[U415]](b),
which called it "peers are not told".

(d) **The synthesis gate's state handling is fail-open in both directions for a THIRD state.**
`mcp_server/sovereign_tools.py` blocks only on the literal `"OPEN"` and buckets everything that is
not OPEN-or-CLOSED as aborted, so a future SUSPENDED/AWAITING_EVIDENCE state would neither block
synthesis nor be reported honestly. This is the concrete consumer whose absence justified NOT
exporting a debate-state tuple (round-1 gate-validator MINOR-1); the auditor found the consumer.

(e) **`record_candidate` does not re-ask its rule in-fence**, though the module docstring says every
writer does. `authorize_publish_candidate` reads `owner_node_ids`, so it is inert only because that
field is never mutated after creation - the same undocumented assumption disclosed for
`participant_node_ids` in [[U415]](c), and undisclosed at this site.

(f) **The long suite's budget headroom is worse on a loaded host than [[U417]](c) states**: the
round-3 validator measured 894 s (with disclosed self-interference from an orphaned `opencode.exe`
competing for Ollama) against runs of 560-573 s clean, on a 600 s budget. [[U339]] / unit 19.10.

(g) **`WATCH_DEADLINE_S` (300 s) equals the workers' `communicate` timeout** and the watcher starts
first, so the watcher's bound is strictly the tighter one; a legitimate ~299 s run would fail as
"the watcher hit its own deadline". 100x margin today.

(h) **Four prose corrections** owed to the code they describe, NOT applied because repairing prose
after validation is what cost unit 19.4 five rounds: `collaboration_service.py` says an abort reason
is "recorded and surfaced" (it is recorded and RETURNED; no UI renders it - [[U412]]);
`emit_operational_state.py` says "and the Inspector says so" (the Inspector reads neither
`aborted_debate_count` nor `open_debate_count`); "deleting one changes no observable refusal" should
read "no observable allow/deny verdict", since the message ORDER it preserves is observable; and
`persistence/store.py`'s two fences run caller-supplied code inside `BEGIN IMMEDIATE` while holding a
NON-REENTRANT lock, which nothing states and `mutator: Any` does not document. State: **OPEN**.

### U419 - **OPEN: the abort rule restricts by ROLE, not by participation - a conductor may abort a debate it is arguing in** (19.5 spec-auditor MAJOR-1; the CLAIM was repaired, the QUESTION is [[U350]]'s)

`control_plane/policy.py:authorize_debate_abort` admits the directing pair on role alone. A task's
participant set includes its creator, so a debate opened between the conductor and a worker admits
the conductor - it can end a deliberation it is arguing in, at any point while OPEN. The first
docstring claimed the opposite ("a node ending a deliberation it is arguing in is deciding its own
case, which is the invariant-18 shape"), which was false for exactly the role most likely to invoke
it. The docstring is corrected, [[U350]] is cited, and the case is now pinned twice - by
`test_the_conductor_may_abort_a_debate_it_is_arguing_in` and by the verdict matrix's new
`abort_own_debate` column, where `conductor(creator)` reads `'ok'` - so U350's eventual answer moves
a cell instead of passing unnoticed. The RULE is deliberately unchanged: refusing every participant
would restore the permanent-OPEN stall [[U416]] exists to end, since the conductor is usually a
participant of its own debates. What keeps this from being the gate override invariant 16 forbids is
downstream (ABORTED is not CLOSED; the synthesis gate refuses to count it), which the spec-auditor
confirmed independently. Owner: whoever answers [[U350]]. State: **OPEN**.

### U420 - **OPEN: who can actually reach the abort rule - no operator-identity path, and no direct shell affordance; the recourse after a conductor death runs through a SUCCESSOR conductor** (19.5 spec-auditor MAJOR-1 at ROUND 2 and again at ROUND 3, in opposite directions)

Two successive drafts of `authorize_debate_abort`'s docstring answered a product question inside an
authority module and got it wrong both times. Draft one claimed "the operator remains reachable as
final authority (invariant 1), including when the conductor is the pane that died" - operator
RECOURSE the product does not provide. Draft two claimed "nothing in the shipped shell can abort its
debates" - an IMPOSSIBILITY the shipped shell refutes. The third draft states the verdict and stops,
citing this row; the RULE was never changed by any of them. What the bytes actually say:

(a) **`operator` is admitted by the rule** (`operator | abort_fresh_debate` reads 'ok' in the verdict
matrix) and **no product path mints an operator identity on a channel carrying debate operations**.
That conclusion rests on the CHANNELS, not on an inventory of mints - deliberately, because two
successive drafts of this row miscounted them (spec-auditor rounds 3 C-2 and 4 MAJOR-1, each finding
operator mints the previous draft had missed). The channels an operator-role identity can speak on
are: `mcp_server/server.py`, which exposes no debate operation at all (grep `debate`: zero matches) -
that is the server every operator-role `McpClient` in `control_plane/orchestration/` connects to
(`conductor_dispatch.py:299`, `live_flow.py:772`, `live_succession.py:578`,
`conductor_prototype.py:48`, and any sibling added later); the IPC gateway, whose op set is
`health`/`read_status` (`control_plane/ipc/gateway.py:118-121`) and which does not forward a per-node
identity to MCP (`:107-113`), so `run_gateway.py:58`'s `"operator"` default cannot reach a
collaboration entry point; and the approval queue, where `session_approvals.py:340,472` mint an
operator `Identity` that never touches `CollaborationService`. A new operator mint changes this
finding only if it is given a debate-carrying channel. The round-2 draft's own cited mechanism was
wrong too: `SOVEREIGN_IPC_ROLE: "shell"` (`apps/desktop/main.js:425`) is the IPC-gateway credential,
and no `"shell"`-role identity ever reaches a collaboration entry point to be refused by `_unknown()`
- spec-auditor round 3, C-1.

(b) **The shell's MCP-tool identities are `conductor` (`apps/desktop/main.js:912`) and `worker`
(`:1922`)**, and `apps/desktop/` carries no `abort_debate` handler (grep: zero matches) - so there is
no direct operator affordance for aborting a debate, and 19.8 owns the abort's UI disclosure
([[U412]]).

(c) **But the [[U416]] stall IS endable after a conductor death**, by a route the round-2 draft
missed and the round-3 audit established BY INSPECTION - three code sites, no test and no receipt
exercises relaunch -> successor conductor -> `abort_debate` end to end (spec-auditor round 4,
CARRIED-3; the exercise is owed wherever [[U350]] is answered): the shell relaunches the conductor
(`ipcMain.handle("conductor:launch")`, `apps/desktop/main.js:1530`), the relaunched pane mints role
`conductor` against the same durable store, and this rule - being role-based, not
participation-based - admits that SUCCESSOR for debates it never argued in. The blocking debate ids
are discoverable through the shipped surface: the synthesis refusal enumerates them verbatim
(`mcp_server/sovereign_tools.py:330-331`) and `abort_debate` is in the tool list (`:108, :408`).

What stays OPEN, therefore, is narrower than either draft: the recourse is the successor conductor's
authority, exercised through the conductor's own tool surface, **not** the operator's - and that is
[[U350]]'s question wearing a different hat (a directing node ending a deliberation on its own
predecessor's behalf), not a hole in the stall fix. Owner: 19.10 for the record; 19.8 for [[U412]]'s
disclosure; whoever answers [[U350]] for the authority question. State: **OPEN**.

### U421 - **OPEN: six of the eight `abort_own_debate` matrix cells never reach the abort rule** (19.5 gate-validator round 4 CARRIED-1; independently spec-auditor round 2 C-2)

`tests/unit/test_collaboration_policy_delegation.py:881-889` opens the debate with
`participant_node_ids=[who.node_id, W1.node_id]`. For `operator`, `gate`, `worker(owner)`,
`worker(outside)`, `voice(outside)` and `malformed` that call fails first - in
`authorize_open_debate`, on the two-task-participants precondition (or by de-duplication to a single
participant) - so those six cells record an `open_debate` refusal under a column named for abort.
The validator proved it by replacing `abort_debate`'s body with an unconditional raise and
re-observing the column: only `conductor(creator)` and `voice(owner)` reported `MUTANT: abort_debate
was reached`. The helper's docstring ("`who` is a PARTICIPANT in the debate it aborts") is false for
the other six. They are not vacuous in the round-1 sense - they pin `open_debate`'s precondition and
would move if it changed - and the two load-bearing cells (the [[U419]] pin and the voice denial) do
assert what the column names, which is why both reviewers graded this MEDIUM. No mutation row grades
the new column: A1b widens the rule to `"gate"`, which moves `gate | abort_fresh_debate`, not an
`abort_own_debate` cell. Carried, not repaired: this unit's stated rule is that MEDIUM-and-below
become rows, after five rounds of prose repairs in 19.4 each produced the next round's prose
findings. Owner: 19.9 (coverage that can fail). State: **OPEN**.

### U422 - **OPEN: five claim defects in 19.5's own evidence and registers, carried by rule** (19.5 spec-auditor round 2 C-1/C-3/C-4/C-5, plus round 4 CARRIED-4 as item (e); the items read (a) (b) (c) (e) (d) because (e) was appended where its subject sits)

(a) **C-1 was REPAIRED, not carried** - the docstring's "the synthesis gate refuses to count it"
was stated unconditionally in the authority module while being true only on the
`sovereign_tools` tool path, because `CollaborationService.record_synthesis` has no debate check of
its own ([[U410]]). It is now scoped in `control_plane/policy.py` and cites U410, because it sits one
sentence from the MAJOR-1 repair and is the same defect class.

(b) **C-3, unrepaired:** `docs/evidence/PHASE19_UNIT5_U330_U332_ONE_WRITE_PATH.md:67-68` attributes
the 66 clean runs and 12/12 spliced detection to the ROUND-3 validator; `:169-171` attributes the
same two figures to ROUND 2. One is wrong, and independent-reproduction provenance is the entire
value of those numbers.

(c) **C-4, corrected HERE by append rather than in place:** `UNRESOLVED_ISSUE_REGISTER.md:8544-8545`
(U415(b)) still reads "the peers U331 describes as waiting". U331 is the vendor pin; the stall is
[[U416]]. That line is the sole surviving 19.5-authored `U331` citation of the stall, so the evidence
report's "All sixteen now cite U416" holds only if U415(b) was not among the sixteen. **Read U415(b)
as citing [[U416]].** The register is append-only, which is why the correction is this sentence and
not an edit.

(e) **Round-4 CARRIED-4, corrected HERE by append:** the round-2 C-1 scoping was repaired in the
docstring only. Two COMMITTED rows still state the synthesis-gate defence unqualified - [[U419]]
("the synthesis gate refuses to count it") and `DECISION_REGISTER.md:189` (D-P19-4, same phrase).
**Read both as scoped to the `sovereign_tools` tool path**, because
`CollaborationService.record_synthesis` has no debate check of its own ([[U410]]). Append-only, so
the correction is this sentence rather than an edit.

(d) **C-5, unrepaired:** [[U419]]'s "U350's eventual answer moves a cell instead of passing
unnoticed" is true for `abort` and false for `close`, which is U350's actual subject: [[U354]]
records that a participation clause on `close_debate` moves ZERO cells because `_open_then_close`
never makes the closer a participant, and no 19.5 row cites U354. Owner: 19.10 (the phase gate reads
the evidence). State: **OPEN**.

### U423 - **OPEN: eight residues from round 4 / round 2 that change no verdict** (19.5 gate-validator CARRIED-3/-4/-5/-6; spec-auditor m-1..m-6)

(a) The evidence report's header says "U410-U417 opened"; the same commit opened [[U418]] and
[[U419]], and this one opens U420-U423. (b) The validator did NOT re-run three §5 rows this round -
the 487-test long suite, the desktop 944/0 run, and the parent-commit pre-fix red - because the
builder's turn owned them; rounds 1-3 verified the pre-fix red independently and round 4 verified the
mechanism it guards by splice instead. (Builder's own fresh runs this turn: long 487 passed in 607.8
s, desktop 944/0.) (c) `tools/mutation/_op19_5_write_path_mutations.py` is unsafe to run in-place
while any OTHER pytest process reads the same tree - `.mutation-run.lock` excludes a second MUTATION
run only - which is why the round-4 validator worked on a byte-copy; a live-pytest check or a
docstring warning would close it. (d) The corrected docstring says the rule "refuses every worker and
voice identity"; it also refuses `gate`. (e) `DECISION_REGISTER.md:189` (D-P19-4) has 3 cells in a
4-column table, so its Evidence column renders empty and the path lives in the narrative cell.
(f) `test_collaboration_policy_delegation.py:164` says "thirteen collaboration entry points";
`_ENTRY_POINTS` now holds fourteen. (g) The evidence report says the new test is described in "§7";
it is §8. (h) `tests/unit/test_operational_write_path.py:395` adds a NEW dependency on the hardcoded
`gemini_contribution`/`grok_contribution` fields that 19.6 is chartered to remove ([[U333]], I-SC1),
and `authorize_debate_abort(self, identity, debate)` never reads `debate` - the signature advertises
record-scoped authority the rule does not exercise, exactly as `authorize_debate_close` does.
Owner: 19.6 for (h)'s first half, 19.10 for the rest. State: **OPEN**.

### U424 - **OPEN: four residues from the round-5 spec-audit, none load-bearing** (19.5 spec-auditor round 5, R5-C3..R5-C6; that round returned PROHIBITED DRIFT: NONE and NO MAJOR)

(a) **R5-C3:** [[U420]](a) says the IPC gateway's op set is `health`/`read_status`. That is
`McpControlSurface`; with no `--mcp-port`, `control_plane/ipc/run_gateway.py:50` installs
`EchoControlSurface`, whose ops are `ping`/`health` (`gateway.py:95-99`). Neither carries a debate
operation, so U420's conclusion is untouched.

(b) **R5-C4:** U420(a)'s "and any sibling added later" scopes to `control_plane/orchestration/`. Four
further operator-role `McpClient` sites live outside it - `tools/live/run_15d_succession_live_smoke.py:125`,
`tools/live/run_15d_flow_live_smoke.py:87`, `tools/assembled/run.py:117`,
`apps/desktop/test/fixtures/serve_seeded_mcp.py:82` - all against the same `SovereignMcpServer`, which
exposes no debate operation. The sentence is under-inclusive, not false; the auditor verified the
conclusion holds across all eight sites.

(c) **R5-C5:** U420(a)'s channel list is exhaustive only when read WITH (b). The one channel that
actually exposes `abort_debate` - the `sovereign_tools` stdio server - is absent from (a) precisely
because (b) shows the product mints only `conductor` (`apps/desktop/main.js:912`) and `worker` (`:1922`)
on it. Sound as written, confusing read alone.

(d) **R5-C6, pre-existing:** `tools/live/emit_operational_state.py:18-24` reads
`list_operational_debates` straight from the store with no `Identity` and no policy - a debate-carrying
READ path outside both the channel list and the authority. It mints nothing and cannot abort, so U420
is unaffected, but "the channels an operator-role identity can speak on" would not lead a reader to it.
Related to [[U411]] (the gate is only as complete as the caller's debate-read scope).

Owner: 19.10 for the record. State: **OPEN**.

### U425 - **OPEN: three findings from the round-5 gate-validator, CARRIED BY THE UNIT'S OWN RULE rather than repaired** (19.5 gate-validator round 5: PASS, 0 BLOCKING / 0 MAJOR)

(a) **CARRIED-A (MEDIUM), and it is mine:** the round-5 docstring repair at
`control_plane/policy.py:334-335` says the store reports ABORTED and CLOSED separately and that "no UI
renders that distinction yet - [[U412]]". U412 says something worse and more precise: the label IS
rendered (`apps/desktop/renderer/renderer.js:624` emits `esc(d.state)`, so the word ABORTED appears)
and only the HUE lies, because the same line maps `d.state === "OPEN" ? "CANDIDATE" : "ACCEPTED"`. The
accurate wording is "no UI renders that distinction FAITHFULLY". This is the same claim-defect class as
spec-auditor rounds 2-4 and it has no executable effect. **It is NOT repaired, deliberately**: MEDIUM
is carried by this unit's stated rule, and a fourth prose repair would void a second validator pass to
change one adverb - the exact spiral that cost unit 19.4 five rounds. Owner: 19.10.

(b) **CARRIED-B (MEDIUM):** the round-2 C-1 scoping repair stopped one file short and [[U422]](e)'s
enumeration missed it. A THIRD site states the synthesis-gate defence unqualified, and unlike the other
two it is live product code: `mcp_server/collaboration_service.py:317-318` ("The synthesis gate refuses
to count an aborted debate as a considered one and discloses it separately"), with the same shape at
`:313-314` - in the very class whose `record_synthesis` (`:369-389`) has no debate check at all
([[U410]]). **Read it as scoped to the `sovereign_tools` tool path.** Owner: 19.6, which will be in
this file, else 19.10.

(c) **CARRIED-G (MINOR) - answered here, since the validator declined to answer it by inference.** Its
round-4 CARRIED-2 (the commit message for `916056e` claimed U415(b)'s stale `U331` label had been
corrected, and it had not) DOES have a home: it is the same finding as the spec-auditor's round-2 C-4,
recorded at [[U422]](c), which carries the append-only correction. The validator could not establish
that because its own reports are not written to disk - the durable-review-record defect the 18A audit
recorded, still open, and now demonstrated a second time. The mapping of every round-4 carried item is:
CARRIED-1 -> [[U421]]; CARRIED-2 -> [[U422]](c); CARRIED-3 -> [[U420]](c); CARRIED-4 -> [[U422]](e);
CARRIED-5 -> [[U423]](c); CARRIED-6 -> [[U423]](d).

Owner: 19.10 for the record. State: **OPEN**.

### U426 - **the orchestration mutation harness had not been runnable since 19.5 closed** (found by 19.6 while re-pinning)

`tools/mutation/orchestration_mutations.js` refuses to run unless every file it mutates hashes to its
pin - the fail-closed rule that stops a mutation being spliced into bytes nobody re-read. At `a43ea9b`
it refused: `control_plane/policy.py` had moved at `44c2abf` (19.5's final spec-audit docstring repair)
and `mcp_server/collaboration_service.py` at `5d56e19`, and **the harness was not re-run in that unit**,
so the pins arrived at this unit stale. Worse than stale: its **O4 anchor was dead**. The bounded-round
ceiling moved INSIDE the `mutate_operational_debate` fence at `5d56e19` (`debate["max_rounds"]` became
`current["max_rounds"]`, one indent deeper), so the mutation that proves the round limit is graded had
nothing to splice into. 19.5's evidence records the write-path mutations
(`_op19_5_write_path_mutations.py`, 20/20 RED) and those genuinely ran; what nobody ran is the harness
whose anchor that same commit broke.

Direction of failure is safe throughout - the harness refuses rather than reporting a false CAUGHT - and
nothing shipped weaker for it. What it cost is a unit's worth of grading on five properties (the
launcher bypass, the bearer check, cross-task recipients, the round ceiling, worker MCP env). Re-pinned
to the current bytes, O4 re-anchored to the same rule in its new place, all five re-run **CAUGHT** and
every file restored byte-identically.  Recorded rather than silently corrected because "the harness was
green" and "the harness could not start" are different facts and only one of them was true.

**The general defect this is an instance of:** a harness that pins the files it mutates must be re-run by
the unit that MOVES those files, and no test says so - `selfcheck-guards.test.js` pins `main.js` for the
pane-input harness only. The three other harnesses' pins are checked by nothing but the harness itself,
which only runs when someone runs it. Owner: **19.9** (the coverage unit), as a guard that fails when a
pinned file's bytes differ from its pin. State: **OPEN** for that guard; the pins themselves are CLOSED.

### U427 - **the 19.6 receipt's keystroke leg was measuring the renderer, not the shell** (found by running it three times)

Leg E of the D-P16-0 receipt (`conductor-descriptor-selfcheck.js`) counted a pane's submitted lines by
its prompt token. The same single submitted line read **0, 1 and 2** across three runs of the check
against a shell that behaved identically each time: a repaint redraws the prompt, and a slow render
hides one. The leg therefore FAILED, PASSED and FAILED on the same code, and its first green run was
luck. Fixed in `a2cee1e`: the criterion is the bytes handed to the session manager, recorded at the
boundary where the writer calls it and only when the manager ACCEPTED the write - two carriage returns
for a provider declaring `submit_confirm_enter`, one for an undeclared provider - with each pane's body
separately observed EXECUTING so the bytes are shown to have reached a live shell and not merely a
function. The pane-side count is kept in the receipt as an observation with its noise stated.

Recorded because the instrument class matters beyond this leg: **`system-pane-write-selfcheck.js` uses
the same prompt-token counting** (`submitCount`, U328's stray-submit check) and its verdict there is an
ABSENCE (`submits_after === submits_before`), which this noise can only push toward a false FAILURE,
never toward a false pass. That is the safe direction and it is why nothing is re-opened - but the same
instrument is doing load-bearing work in a committed receipt, and a reader comparing the two should know
the counter is not exact. Owner: **19.9**, alongside [[U426]]'s guard. State: **OPEN** for the shared
instrument; 19.6's own leg is CLOSED.

### U428 - **[[U331]], [[U333]], [[U386]](c), [[U393]] MINOR-1 and [[U425]](b) CLOSED; the clone case is covered by the suite and not by the receipt** (19.6)

**[[U331]] CLOSED.** `runConductorReadiness` no longer compares a provider id and a model slug; the
verdict is `apps/desktop/control/conductor-admission.js`, which asks the descriptor four questions true
of a conductor of ANY provider and fails closed on each. No refusal names a vendor (asserted in the
suite and measured in the receipt). `exact_model: true` - a literal whose only meaning was the pin
([[U337]] class) - is replaced by what was actually decided. Conductor succession onto a different
backend, a **Phase 15D exit criterion**, is reachable: five provider/model pairs admitted in the
packaged runtime, receipt leg B.

**[[U331]]'s compounding half CLOSED, with its coverage stated exactly.**
`load_runtime_conductor_descriptor` stamps `selection_source` (`live_operation_preference` /
`recorded_default_selection` / `unstated`), so the operator's own selection and the recorded default the
registry resolves when the gitignored switch is absent stop being indistinguishable. It labels; nothing
refuses on it, and a malformed or unregistered preference still fails closed. **The receipt could not
measure the clone case**: this host HAS the operator's switch, so leg A admitted
`openai_codex_cli`/`gpt-5.6-sol` with `live_operation_preference`. The `recorded_default_selection` path
is covered by `tests/unit/test_provider_agnostic_conductor.py` and by nothing in-Electron, because
producing it here would mean moving the operator's own file.

**[[U333]] CLOSED.** `contributions`, keyed by node id, cross-checked against the task's candidates in
both directions - an invented contributor and a dropped one are each refused by name. The tool schema
and description changed with it: a required `gemini_contribution` teaches every conductor that
contributions ARE vendors, whatever the runtime then checks. **[[U423]](h)** discharged - the test that
depended on the two vendor fields is updated, and section 5 of `test_operational_write_path.py` is new
coverage for the replacement, including the single-worker task the old form made unsynthesisable.

**[[U386]](c) and [[U393]] MINOR-1 CLOSED.** Grok's two readiness turns, Codex's confirm Enter and three
provider-scoped screen rules are declared in `apps/desktop/control/provider-traits.js`; `traitsFor`
answers for every provider id and an undeclared one gets generic behaviour that WORKS. Not an
allowlist - nothing there can refuse a provider (invariant 7). The vendor strings did not disappear and
the unit does not claim they did: a Grok overlay's text is a fact about Grok. What disappeared is the
runtime branching on a name. The conductor pane stops being the one place a provider trait did not
apply - its readiness now honours the declared turn count.

**[[U425]](b) CLOSED.** `collaboration_service.abort_debate`'s docstring now scopes the synthesis-gate
defence to `SovereignToolRuntime._considered_debates` - the tool path that provides it - and states that
`record_synthesis` in that class performs no debate check of its own ([[U410]], still open, still
19.10's).

**Left standing, deliberately:** the `spawn_worker` tool description names two vendors as provider
DEFAULTS (descriptive metadata for a live CLI, not a runtime branch); `CONTROL_PROVIDER_ALIASES`, the
picker's provider-to-binary map and the status bar's per-provider allowances are per-provider DATA (a
subscription ceiling is a fact about a subscription). Naming them keeps the "no vendor branches in the
runtime" claim exactly as wide as the work.

State: **CLOSED** for the six items above. Both mandatory reviewers were OWED when this row was written;
a later row records what they found.

### U429 - **the round-1 reviewers: the product passed and the sentences about it did not** (19.6, gate-validator round 1 PASS_WITH_RESERVATIONS 0 BLOCKING / 2 MAJOR; spec-auditor round 1 PROHIBITED DRIFT NONE, 2 MAJOR / 5 MEDIUM / 4 MINOR)

Both mandatory reviewers ran **foreground, in-turn, sequential** ([[U359]]) over `c3e1392`
(gate-validator) and `e674eb8` (spec-auditor). Neither found a BLOCKING defect and neither found
prohibited drift. Between them they found **four claims wider than the code** - the failure mode this
phase keeps returning to - and four guards nothing graded. This row carries the corrections the
append-only rule requires, because two of the wrong sentences are in [[U428]] above and that row cannot
be edited.

**CORRECTION 1 to [[U428]] (both reviewers, MAJOR).** [[U428]] says *"Conductor succession onto a
different backend, a Phase 15D exit criterion, is reachable: five provider/model pairs admitted in the
packaged runtime, receipt leg B."* **That sentence is wrong and is withdrawn.** What leg B measured is
one pure function against five descriptors the check itself wrote. Two layers upstream bound the real
set, and neither is the readiness layer: `control_plane/conductor/registry.py` mints only three
registered pairs (codex/`gpt-5.6-sol`, claude/`fable-5`, claude/`opus-4.8`), and
`apps/desktop/conductor/launch-source.js:136-139` refuses a launch ticket whose provider has no
verified containment profile. The accurate claim, and the only one 19.6 supports: **the readiness layer
no longer refuses a conductor for the name it carries.** Leg B is renamed
`readiness_admits_any_registered_descriptor` and carries its own scope string; the unit test is renamed
to match; the committed receipt that carried the old name is superseded, not rewritten.

**The containment refusal is NOT a vendor pin and was deliberately not removed.**
`isWellFormedAuthorityBoundary` verifies that a conductor's permission boundary has the shape this
shell knows how to check - Claude's pinned hook profile, Codex's read-only sandbox plus untrusted
approval - and refuses what it cannot verify. That is invariant 29 (supervisor-level containment,
never trust the harness) and Buildout §4 (fail closed on unverified capability) working. Deleting it to
make a five-provider claim true would have admitted an unverified permission boundary to get a green
receipt. **What is genuinely missing is a containment profile for `grok_build`, `google_antigravity`
and local conductors** - real work, not a comment. Owner: **19.10** to schedule (it is a new capability,
not a Phase-19 remediation item), recorded here so the gap is visible rather than implied.

**CORRECTION 2 to [[U428]] and to the module (spec-auditor MAJOR-2).** [[U428]] and two drafts of
`conductor-admission.js`'s header said the four admission checks each "fail closed". They do not, and
the second draft got the split wrong a second way. Exactly: no descriptor, an empty/absent
`provider_id`, an empty/absent `model_id` and a WRONG `role` are refused; an **absent** `role` and
absent `registered`/`conductor_capable` are **admitted**. Both absence-admissions are now asserted in
`apps/desktop/test/conductor-admission.test.js`, so the prose can no longer drift from the behaviour
without a test going red.

**CORRECTION 3 (spec-auditor MEDIUM-2), the justification, not the behaviour.** The header said
`conductor/launch-source.js` "takes the stricter reading of those same two keys" on a session "the
ticket path ALREADY admitted". Those are two DIFFERENT objects: `launch-source.js` judges
`ticket.conductor_descriptor`, `conductorAdmission` judges the FEED descriptor
(`main.js:167` <- `load_runtime_conductor_descriptor`), and **nothing verifies the two agree**. Today
both come from `registry.py`, which stamps both `True`, so the divergence is inert - but the reason
given was unfalsifiable and the old one ("a descriptor minted by another path may carry neither") named
a producer that does not exist. Corrected in place. **The unverified agreement between the two
descriptors is a real residual**: owner **19.10**, as a check that the ticket's descriptor and the feed's
describe the same conductor.

**MEDIUM-3 (spec-auditor) - OPEN, NOT FIXED, and it is the strongest finding of the round.** The
`contributions` cross-check runs on a task snapshot read at `sovereign_tools.py:266`, OUTSIDE the
`mutate_operational_task` fence that commits the synthesis. A candidate landing between that read and
the commit produces a COMPLETED task whose synthesis artifact omits a node the task records - the
"dropped work" case the new gate exists to refuse. This is the SAME class as [[U330]], which 19.5
closed for five other writers, and the auditor is right that `test_operational_write_path.py`'s
`racing` fixture exists and section 5 does not use it. It is not fixed here because moving the
cross-check inside the fence is a behaviour change to the write path and this unit has already been
validated twice; fixing it now would void both rounds for a race no test yet demonstrates. Owner:
**19.10**, with the falsification named: a `racing` test that publishes a candidate between the tool
layer's read and its commit.

**MEDIUM-4 (spec-auditor) - the "left standing" enumeration was incomplete, and the missing two are in
the conductor path.** `apps/desktop/main.js:716` (`desc.adapter_id !== "claude_code"` skips the live
model probe and returns `model_available: true, source: "registered-exact-slug"` - a vendor branch AND
an asserted capability where the Claude path measures one, against Buildout §4) and
`apps/desktop/conductor/launch-source.js:138-139`. Both are now named. The first is a genuine
fail-open on capability: owner **19.10**. The four items 19.6 did enumerate (the `spawn_worker`
description, `CONTROL_PROVIDER_ALIASES`, the picker's provider->binary map, the status-bar allowances)
the auditor confirms as data.

**MEDIUM-5 (spec-auditor) CLOSED here.** A FOURTH site of the unqualified synthesis-gate sentence, 250
lines above the one [[U425]](b) fixed, in the same file's module comment
(`mcp_server/collaboration_service.py:64-67`). Scoped, with [[U410]] named. The harness pin for that
file was updated and O1-O5 re-run CAUGHT.

**MINOR-1 (gate-validator) CLOSED.** Two contribution guards - the empty list and the duplicate node -
were graded by nothing: every case exercising them was also refused by the missing-candidate rule, so
splicing either guard out left the suite green. Two cases now isolate each. **MINOR-4 CLOSED**:
`minItems: 1` in the published schema says what the runtime already enforced.

**MEDIUM-3 (gate-validator) CLOSED as far as this unit can.** Two of its mutations survived all 962
tests - the readiness turn bound forced to 1, and `if (false && !admission.ok)`. Both are caught now,
by SOURCE PINS, and the test says so: `main.js` cannot be required until [[U338]]/19.9 extracts it, and
a mutation preserving those strings while changing the meaning would still pass. Re-falsified by hand:
both mutations spliced, both RED, `main.js` restored byte-identically (SHA-256 `EA6A458C...`).

**MINOR-2 (spec-auditor) CLOSED.** Universal-before-scoped classification precedence is now pinned; it
was introduced by construction in this unit and asserted by nothing.

**Carried, recorded, not repaired:** spec-auditor MEDIUM-1 (the evidence report's forward reference to
a section that did not exist yet - section 11 now exists and supersedes it), MINOR-3 (a contribution is
bound to a node id but not to that node's candidate `content_hash`; no regression, since the vendor
fields bound nothing - owner 19.10), MINOR-4 (`readiness_turns` is read from a shell-side table keyed
by the provider string, because `ConductorDescriptor` carries no capability field for it; disclosed in
`provider-traits.js` and one indirection weaker than "behaviour by descriptor" implies - owner 19.10),
and gate-validator MINOR-2 (commit `a2cee1e`'s message says leg E "passed, failed and passed again";
the receipts say **failed, passed, failed**, which is what the evidence report and [[U427]] say. The
commit message is immutable and wrong; this is its correction).

**ROUND 2 OF BOTH REVIEWERS IS OWED.** Every repair above landed AFTER both round-1 reviews, and
fix-after-validation voids them. It is the next unit's first act.

State: corrections above are CLOSED. **OPEN with owners:** the missing containment profiles for
grok/antigravity/local conductors, the unverified ticket-vs-feed descriptor agreement, the
outside-the-fence contributions cross-check, `main.js:716`'s asserted capability, the contribution
content_hash binding, and the descriptor-carried readiness-turn capability - all **19.10** unless it
re-assigns them.

### U430 - **round 2 of both reviewers: the product passed again, and the corrections were wrong about how many corrections there were** (19.6, gate-validator round 2 PASS_WITH_RESERVATIONS 0 BLOCKING / 1 MAJOR / 4 MEDIUM / 4 MINOR; spec-auditor round 2 PROHIBITED DRIFT NONE, 4 MAJOR / 6 MEDIUM / 3 MINOR)

Both mandatory reviewers ran again **foreground, in-turn, sequential** ([[U359]], D-LOOP-2) over
`ce3d5d6` - product bytes identical to `d3c4e6c` - because every repair recorded in [[U429]] postdated
the round-1 reviews and fix-after-validation voids what preceded it. Neither round-2 reviewer relied on
round 1. **Neither found a defect in the product path, and neither found prohibited drift.** Every one
of the five MAJORs across the two reports is again a **claim wider than the code**, and two of them were
introduced *by* the round-1 repairs - the failure mode this phase keeps returning to, now demonstrably
capable of arriving inside the correction for itself.

**Measured independently by the gate-validator** (it re-ran everything rather than reading section 8):
desktop `node --test test/*.test.js` **963 passed / 0 failed / 0 skipped**; `py -3.12 -m pytest tests/unit -q`
**1889 passed / 1 skipped** with the skip NAMED under `-rs` (`tests/unit/test_run_frontier_providers_ps1.py:522`,
host-coupled, `SOW_PROVIDER_HOST_CHECK=1` - which is the shape [[U339]]/19.9 wants for all 28);
`tests/integration/test_claude_code_conductor.py` **47 passed**; all four JS mutation harnesses re-run
**every mutation CAUGHT** with every file restored byte-identically and `git status --porcelain` empty
before, between and after. It also regenerated the freeze manifest and confirmed
`freeze_integrity_sha256 = 8E604CA3...` byte-identical to the committed one ([[U222]]'s operator
signature preserved), then restored it. It wrote **27 mutations of its own: 24 CAUGHT, 3 SURVIVED**.

---

**CORRECTION 1 to [[U429]] and to section 11 of the evidence report - "the one sentence" was at least
three** (both reviewers, MAJOR). Section 11 says *"The one sentence in this report that was wrong,
corrected here rather than in place."* That completeness claim is itself wrong. The enumeration, which
is what should have been written:

1. **The succession claim** (corrected in [[U429]] CORRECTION 1) - stands corrected.
2. **Section 3's "Each fails closed"** (report line 50). Three of the six refusal conditions in
   `apps/desktop/control/conductor-admission.js` admit on ABSENCE, not refuse: `role` undefined
   (`:70`), `registered` absent (`:79` tests `=== false`), `conductor_capable` absent (`:82`). The
   module header and [[U429]] CORRECTION 2 state the split correctly; section 3 does not, and never
   mentions the absent-`role` case at all. **A reader of the evidence report alone gets the wrong model
   of when conductor readiness refuses.**
3. **Section 3's justification for that non-symmetry** - "a descriptor minted by another path carries
   neither" - was WITHDRAWN in `conductor-admission.js:45-48` and [[U429]] CORRECTION 3 as naming a
   producer that does not exist in this product, and still stands unwithdrawn in section 3.

Corrected here, by append, in the register and in section 12 of the evidence report. The report is
append-only and so is this row; neither is rewritten in place.

**CORRECTION 2 - the round-1 rename replaced one over-claim with a subtler one** (spec-auditor MAJOR-2).
Receipt leg B was renamed `readiness_admits_any_registered_descriptor`. Its five descriptors are built
as `{role, provider_id, model_id}` (`apps/desktop/selfcheck/conductor-descriptor-selfcheck.js:236-256`)
and carry **no `registered` and no `conductor_capable` key at all**; three of the five are not pairs
`control_plane/conductor/registry.py:77-102` mints. So the leg's new name asserts registration the
objects do not carry, and what it actually demonstrates is the absent-key admission of CORRECTION 1
item 2. **The accurate statement, and the one this row carries:** leg B shows that admission does not
refuse a conductor descriptor for the provider name it carries. The leg's caption comment at
`conductor-descriptor-selfcheck.js:235` still reads "succession onto a different backend is reachable"
- the withdrawn sentence, twelve lines above a `scope` string that contradicts it (spec-auditor
MEDIUM-5). **Not renamed here**: moving self-check bytes after two completed review rounds would void
both for a string, which is the spiral 19.4 and 19.5 each paid five rounds for ([[U425]](a) is the same
ruling). Owner **19.10**, one commit, both strings together.

**CORRECTION 3 to [[U428]]/[[U429]] MEDIUM-4 - `CONTROL_PROVIDER_ALIASES` is not data**
(spec-auditor MAJOR-3, verified on disk). Both rows call it "per-provider DATA", left standing for that
reason. It is a name-keyed acceptance gate in the shipped conductor path:
`apps/desktop/main.js:2468-2469` looks the conductor's requested provider up in a frozen two-vendor map
and throws `unknown or unauthorized worker provider` on a miss - **before** the governor and the launch
ticket, in the refusal vocabulary of authorization, on the `spawn_worker` path. It is exactly the I-SC1
class 19.6 exists to remove, and it also means the conductor cannot spawn a `claude_code` or
`openai_codex_cli` worker through this path at all: the map contains only gemini/antigravity and grok
aliases. The same correction applies to `CONTROL_DEFAULT_MODELS` (`main.js:2044-2046`, consulted at
`:2477`), a runtime provider-to-model default table the enumeration never named while section 9 called
the `spawn_worker` description's named defaults "descriptive metadata ... not a runtime branch". They
are a runtime branch. Owner **19.10**; the honest scope is "two name-keyed tables on the conductor's
spawn path", not "documentation".

**CORRECTION 4 - the containment refusal is a two-name branch, not a profile lookup** (spec-auditor
MAJOR-4, verified). Four pieces of prose - report section 11, [[U429]] twice, the self-check header, the
receipt `scope` - describe `apps/desktop/conductor/launch-source.js:136-139` as refusing "a launch
ticket whose provider has no verified containment profile". The code at `:137-139` is
`if (d.adapter_id === "claude_code") return isWellFormedVoiceBoundary(...); if (d.adapter_id !== "openai_codex_cli") return false;`
and its own docstring says "Provider-neutral permission-profile validation" two lines above. A
well-formed `conductor_permission_boundary@1.0` for `grok_build` would still be refused, because
nothing looks a profile up. **The refusal is still correct and still must not be deleted** (invariant
29; both reviewers say so independently and the gate-validator states it would have failed the unit had
it been removed). What changes is the owed work: [[U429]] records it as "the missing containment
profiles", which understates it - a profile alone changes nothing. Re-scoped for **19.10**: a
containment-profile table, plus the removal of the adapter-id branch, plus the docstring.

---

**OPEN, with owners - findings neither reviewer considers fixable inside a twice-validated unit:**

**MAJOR (gate-validator) - the `contributions` cross-check outside the write fence, and the condition
the phase gate now carries.** Re-derived independently: `mcp_server/sovereign_tools.py:266` reads the
task, `:273` cross-checks against that snapshot, `:294` commits through `record_synthesis`, whose only
in-fence check is a different one (`mcp_server/collaboration_service.py:392-398`, owners subset of
candidates). Reachable sequence, stated by the validator: task owned by W1+W2, only W1's candidate
present at the read, conductor supplies `contributions=[W1]`, W2's candidate lands, the fence sees no
missing owner, and a COMPLETED task is committed whose synthesis omits W2. The [[U330]] class, for the
sixth writer. The validator accepts the deferral **on the merits** - strictly narrower than the
pre-unit state (the two-slot form had no dropped-work refusal in any window), no authority boundary
touched, and the damage is auditable rather than silent because `synthesis["candidate_node_ids"]` comes
from the same stale read and visibly disagrees with the task record afterwards - and it **explicitly
rejects the builder's stated reason** ("this unit has been validated twice") as a process argument that
expired when round 2 began. Recorded as ruled: **`gate/phase-19` must not be tagged with this open.**
Owner **19.10**, as a gate precondition, not a backlog item. The fix is small: `apply()` already
receives `current`; pass the contributions in and check inside the fence. Falsification named: a test
that publishes a candidate between the tool layer's read and its commit.

**MEDIUM (gate-validator) - the class round 1 patched instance-by-instance was not swept.** Round 1
found two contribution guards that graded nothing and both are isolated now ([[U429]] MINOR-1). Three
more in the SAME function survive the full 1889-test unit suite: `sovereign_tools.py:345` returning
contributions in caller order rather than candidate order (which falsifies the docstring at `:311-312`
claiming CAS-hash stability regardless of caller order - `json.dumps(sort_keys=True)` does not sort list
ELEMENTS, so the `content_hash` genuinely varies if that line changes: **a claim wider than its
evidence, inside the repair for claims wider than their evidence**); `:324` admitting a blank
`node_id`; `:320` admitting a non-dict entry, which degrades a `ToolError` into an `AttributeError`
caught by the catch-all at `:491` (message quality only, no safety loss). **Not fixed here**: three new
test cases are three new bytes in a tree two reviewers have now passed, and the owner exists - 19.9's
charter is literally *coverage that can fail*. Owner **19.9**, with the three mutations named so the
fix is graded against them and not reasoned about.

**MEDIUM (gate-validator) - `main.js` mutation grading is not semantic, and round 1's "survived all 962
tests" cannot be true as stated.** The two round-1 survivors are caught by
`sovereign-control-server.test.js:95-100` (genuine, if string-level regex pins) and
`selfcheck-guards.test.js:74-84`, which is a **whole-file SHA-256 pin of `main.js`**. That pin fires on
any byte change including a comment, so it contributes no semantic grading whatever and makes every
`main.js` mutation trivially "CAUGHT" - and its existence is inconsistent with round 1 reporting two
mutations as surviving all 962 tests (either that run excluded the file or its worktree re-pinned; not
resolvable from the evidence, recorded so it is not treated as settled). This is the strongest argument
yet for [[U338]]/19.9's extraction: until `main.js` is `require`-able, its guards are graded by string
identity. Owner **19.9**.

**MEDIUM (spec-auditor) - the absent-`role` branch is unreachable in the product, and its justification
is unfalsifiable.** `conductor-admission.js:24-27,70` defends admitting an absent `role`; the only
production caller reads `conductorDescriptor()` (`main.js:169`), which is
`d && d.role === "conductor" ? d : null`, so a role-less descriptor arrives as `null` and is refused as
"no descriptor". The branch exists for direct callers (self-check and tests) only. Same shape as
CORRECTION 1 item 3, one field over. Owner **19.10**: state it or refuse an absent `role`.

**MEDIUM (spec-auditor) - a vendor literal inside the rules declared universal.**
`apps/desktop/control/provider-readiness.js:25` matches a `grok login` instruction string inside
`UNIVERSAL_RULES`, whose comment says universal rules are "states of the governed session, not of a
vendor's TUI" and whose trait-table sibling says they "apply to every provider, declared or not". Any
provider's screen carrying that string classifies `AUTH_REQUIRED`. Owner **19.10**: move it into
`GROK_RULES` or qualify the sentence.

**MEDIUM (spec-auditor) - invariant 7 mis-cited to cover shell modules, CORRECTED HERE.**
`provider-traits.js:20` and section 4 of the report cite invariant 7 ("no authorization logic inside
`mcp_server/`") for the claim that refusal belongs to the governor and the launch ticket.
`apps/desktop/control/` is not in invariant 7's scope; the correct citations are invariants 1, 2 and 30.
The sentence is also unqualified where CORRECTION 3 shows the runtime as a whole does not honour it.
No code change; the citation is corrected by this row.

**MEDIUM (spec-auditor) - an invariant-15 asymmetry in the synthesis record, and it PREDATES 19.6.**
`sovereign_tools.py:274` requires at least one `points_of_agreement` (`_nonempty_strings`) while `:275`
allows `points_of_disagreement` to be empty (`_string_list`), so a genuinely dissenting outcome must
have an agreement manufactured for it - against invariant 15 ("concurrence preferred, **not forced** -
dissent preserved"). The auditor could not establish provenance read-only; **verified here**:
`git show a43ea9b:mcp_server/sovereign_tools.py` carries the identical pair at its lines 275-276, so it
predates this unit and 19.6 neither introduced nor widened it. It is a real finding regardless, and
re-enumerating that record without noticing it is fair criticism. Owner **19.10**.

**MINOR, recorded without repair:** `main.js:2440` reports `readiness_responses` from the declared trait
rather than the turns observed (equal by construction today, the [[U337]] class one indirection away -
19.9); `main.js:3074-3076`'s comment about `paneProviderFor` is wider than the receipt's
`production_resolver_answered: null`, which the receipt itself discloses as a non-criterion observation;
`worker-readiness.js:627`'s `requiredTurns === 2` literal gives a provider declaring three turns the
generic stage label, so `provider-traits.js:14`'s "a fifth provider is a row here" is slightly wider
than the code (19.10, one-line fix: `turn === requiredTurns && requiredTurns > 1`);
`mcp_server/collaboration_service.py:328-329` says "the only one of the three" when the round-1 repair
made it four sites in that file - **corrected here**; section 11's "a FRESH receipt is owed" and the
report's line-3 header ("both mandatory reviewers owed") are both superseded by facts committed in
`ce3d5d6` (the `19.6-checkpoint` receipt, `ok: true`, `source.commit d3c4e6c`, clean tree) and by
section 12; `ruff` remains absent from this host, so CLAUDE.md's ruff-clean bar is **not run, not
clean** (carried, not new).

**Invariants: no drift.** The spec-auditor checked 1, 2, 3, 7, 10, 11, 13, 15, 16, 18, 29, I-SC1,
Decimal and Buildout section 4 determinism, each against code rather than prose, and states the
strengthened set: 3 (the readiness pin was the clearest live violation of "never a vendor default" and
it is gone), 11 (provenance on selection and on contributions), 27 (refusals name what failed).
Invariant 7 is intact where it applies: `_contributions` reads no caller identity, no role and no scope
- it compares an argument to `task["candidates"]`, which is completeness validation; authorization is
still asked of `control_plane/policy.py` at `sovereign_tools.py:264`. Invariant 29 was preserved **under
pressure**, which is the finding worth keeping from this unit: the containment refusal that made a
five-provider claim false was not deleted to make the claim true.

**State: 19.6 CLOSES here.** Two full review rounds, no BLOCKING finding in either, no prohibited drift
in either, no product-path defect in either. Every open item above has a named owner, and one of them -
the outside-the-fence cross-check - is recorded as a **precondition on `gate/phase-19`**, which is
19.10's. No tag: Phase 19's gate belongs to 19.10 and `product/multi-frontier-v2` is never moved.

### U431 - **[[U334]], [[U335]] and [[U336]] CLOSED; what closing them cost, and what it opened** (19.7)

Recorded 2026-08-13, unit 19.7. The register is append-only, so the `State: **OPEN**` lines on U334/U335/
U336 above are not edited: **this row is their closure**, and a reader who reaches those rows should read
this one.

**U334 CLOSED.** `apps/desktop/control/sovereign-control-server.js` `stop()` now runs inside a stated
budget (default 5 000 ms): graceful `close()` first, `closeAllConnections()` at the halfway mark, resolve
REGARDLESS at the end, reporting `{closed, forced, timed_out, waited_ms}`. It never rejects, revokes every
credential unconditionally (asserted on a node that had actually called - see [[U433]] for why that
wording matters), is memoised so `teardown()` may start it and `completeNormalQuit()` await the same
promise, and its memo is invalidated by `start()`. It IS now called from `teardown()`, which was the
directive row's second clause. A call arriving mid-shutdown answers **503 "shutting down"** rather than
401: fail-closed either way, but a shutdown reported to a node as a credential problem is this unit's own
failure mode.

**U335 CLOSED, and narrower than it reads.** `connectionState` has a staleness window (default 180 s, the
`AppControlClient` per-call ceiling at `mcp_server/sovereign_tools.py:40`) and a fourth state, `stale`,
meaning UNVERIFIED - never dead. It carries `last_seen_age_ms`, clamps a backwards clock to 0, fails
closed to `stale` on an unparseable stamp, and clears on the node's next gateway call.
`controlAssignTask` consults it through the new `apps/desktop/control/assignment-gate.js`.
**What `_lastSeen` cannot see** is recorded in the module header and repeated here because it bounds the
whole mechanism: only calls that traverse the app-control gateway are stamped, so `read_messages`,
`abort_debate`, `close_debate`, `publish_synthesis` and the artifact publish/read do NOT refresh it. A
worker doing store-only MCP work is working and `stale` at the same time. The proper fix is a node
heartbeat on a cadence shorter than the window; it is [[U434]].

**U336 CLOSED on both halves.** `inspector/operational-source.js` returns `available:false` with
`summary`/`tasks`/`messages`/`debates` **null** - never zeroes - when the emitter cannot run; the live
node list, which is the shell's own observation, survives. `main.js`'s `inspector:fetch` returns `ok` as
the AND of its two reads and nulls the legacy half the same way. The drawer paints per half: "shared
governed state UNREADABLE" / "artifact/gate evidence UNREADABLE" / "this is not a count of zero", with
the READABLE half still printing its own counts. Proven at the pixel in three cases (nothing readable,
live half unreadable, legacy half unreadable) by the in-Electron receipt.

**Falsification.** **Nine** new rows in `tools/mutation/orchestration_mutations.js`, 14 in total, all
CAUGHT. **O6-O10 are the AUDITED behaviour put back** - O6 (any timestamp is a live session again),
O7 (a timed-out stop reported as a clean close), O8 (the halfway destroy removed), O9 (the zero-count
shape restored), O10 (the gate stops consulting the node). **O11-O14 are a weaker claim and are kept
distinct from it**: each restores a state that existed only BETWEEN review rounds of this unit - O11
(main.js calls the gate and ignores the verdict), O12 (the dispatch sentence stops naming MCP-unverified
workers), O13 (an emitter's ok/available overwrite the call's verdict), O14 (O12's clause commented out at
the end of a live line). An earlier version of this paragraph said "six new rows ... O6-O11" while the
harness shipped eight, then nine - the closure record understating its own evidence, which is this unit's
own failure mode pointed the other way (spec-auditor round 3, MEDIUM-3). Evidence:
`docs/evidence/PHASE19_UNIT7_U334_U335_U336_RUNTIME_HONESTY.md`.

### U432 - **OPEN: what the two reviewers found across seven rounds, and what remains** (19.7; gate-validator round 1 FAIL 2 BLOCKING, rounds 2/3/4 PASS_WITH_RESERVATIONS 0 BLOCKING; spec-auditor rounds 1/2/3 PROHIBITED DRIFT NONE)

**Round 1 (FAIL) - both blocking findings were right and both are repaired.**
(a) The staleness window reached into READINESS: `worker-readiness.js` and the two operational status
functions asked `state === "connected"`, so a worker that HAD connected but had been quiet longer than
the window never reached its challenge and was written a durable `STALLED` on a pane nothing had been
typed into - U329's defect class, re-created inside the unit written to remove it. Two questions were
being answered by one comparison; `sessionEstablished()` is now the "has ever had a session" question
(readiness, which exists to PROVOKE - its challenge is answered by a real gateway call) and the gate keeps
"recently verified". (b) The refusal named an exit that does not exist ("re-run readiness"; no re-run is
reachable for a worker already READY). It now names `send_message` -> `controlNotifyMessage` ->
`notifyNode`, which is real - and discloses that the U328 write gate can withhold it.
(c) The two constants PRODUCTION runs on were graded by nothing (every test and every leg injected its
own), and "every credential is revoked" was asserted against a name that had never been a node.

**Round 2 (PASS_WITH_RESERVATIONS, 0 BLOCKING) - four guards that graded nothing.** The second
`sessionEstablished` call site was reachable by no test; the revocation assertion had MOVED its hole
rather than closed it (a node that never called leaves `_lastSeen` empty either way, so deleting
`_lastSeen.clear()` still passed - and `connectionState` reads `_lastSeen` first); the 503 test excused a
direct `_handle` call as "non-deterministic to provoke" and the validator provoked it on the first
attempt; and the new source pin was defeated by wrapping the real line in a block comment. All four are
now driven, each re-run as a mutation and CAUGHT. Its one MAJOR - a false claim in the comment of the
file whose subject is honest self-reporting - is [[U435]].

**Spec-audit round 1: PROHIBITED DRIFT NONE.** No `.py` file is touched in the whole range (verified with
`git diff --stat 71bd348..323e541 -- '*.py'`: empty), so invariant 7 is untouched; nothing self-authorizes
(`assignmentRefusal` can only refuse); no gate override; no vendor name in any new decision. Its four
MAJOR: the two register IDs cited in shipped code did not exist (this row and the next three fix that);
the refusal is not costless system-wide ([[U436]]); no evidence report existed at audit time (written with
this row); and it could not run git, so it read the working tree - the tree was clean at `323e541` apart
from the untracked receipt, which is committed with this row.

**Repaired after the audit, and therefore OWED: round 3 of the gate-validator and round 2 of the
spec-auditor.** Fix-after-validation voids what preceded it. The repairs are: the two register citations
made true (this row), the dispatch summary's SENTENCE carrying the unverified count and not only its legs,
the 503 window comment corrected to what was actually measured on both socket populations, the
`available`/`ok` keys moved after the feed spread so an emitter cannot overwrite the call's verdict about
itself, the assignment-gate claim scoped to the worker record with the BLOCKED consequence named, and the
self-check's drawer-clearing comment.

**Both owed rounds then RAN, in the foreground, over `e29bd7d`** - gate-validator round 3
(PASS_WITH_RESERVATIONS, 0 BLOCKING / 1 MAJOR / 2 MEDIUM / 3 MINOR, with all five mutation harnesses, the
desktop, terminal and `tests/unit` suites and the in-Electron check re-run independently and the delta
itself mutated) and spec-auditor round 2 (PROHIBITED DRIFT: NONE, 3 MAJOR / 4 MEDIUM / 7 MINOR, **every
finding in the evidence layer, none in the code**). Their MAJOR/MEDIUM items are repaired in `65d92e7` -
which moves test code, one mutation harness and one comment, leaving every executable product byte the
reviewers read unchanged - and their residuals are [[U437]] and [[U438]]. **Unit 19.7 is CLOSED**; the
reasoning for closing is stated in the evidence report's §11, where a reader can disagree with it.

**A fourth gate-validator round and a third spec-audit then ran anyway, over `65d92e7`** - because an
earlier draft of that §11 argued a fourth round would be futile, and the argument was worth testing rather
than asserting. It was half wrong. Round 4 (PASS_WITH_RESERVATIONS, 0 BLOCKING) confirmed the delta's
product half BY MEASUREMENT - hashing both blob versions of `sovereign-control-server.js` with every line
comment stripped, and getting identical non-comment hashes - and then **defeated the new pin with a
trailing comment**, because `executableOnly` strips whole-line and block comments only. Spec-audit round 3
(PROHIBITED DRIFT: NONE) found that two round-2 repairs had moved their hole rather than closed it: the
D-LOOP-1 sentence now cited a `finally` that stops a client socket rather than a server, and the receipt
accounting claimed "all five are committed" of a receipt taken after the commit it claimed to be in. All
are repaired in `f324671`; the residuals are [[U437]](g) and [[U439]]. Recorded because the pattern - the
repair for a claim-wider-than-its-evidence being one itself, three rounds running - is more informative
than any single instance of it.

**Recorded without repair, with owners:** `main.js`'s `complete` excludes `controlStop`, so a gateway that
timed out still exits 0 (19.9); `waitForNodeMcp` deliberately still reads `=== "connected"` and nothing
pins the precondition that makes that safe (19.9); `worker-readiness.js`'s literal `mcp_connected: true`
is now reachable for a `stale` session - the booleans themselves are [[U337]]/19.8's charter, the
reachability change is this unit's (19.8); the renderer's green READY chip replaces `mcp_state` and leaves
freshness in the dim sub-line (19.9); `stop()`'s `was_listening` is derived from `Boolean(server)` rather
than an observed listening state and the `close()` callback's error argument is discarded (19.9); the two
conductor-facing surfaces disagree by design (`get_worker_status` reports a stale node `ready`, `assign_task`
refuses it) with nothing bounding the retry loop that follows (19.9, with [[U436]]).

### U433 - **the same assertion hole, twice, in the same unit** (19.7, kept because the pattern is the finding)

Round 1 failed this unit partly because "every credential is revoked" was asserted against
`connectionState("anyone")` - a name that was never a node, which answers `disconnected` before the code
under test has run. The repair asserted against a node that had been ISSUED a credential but had never
called. `connectionState` reads `_lastSeen` first, and `_lastSeen` is empty for a node that never called,
so deleting `_lastSeen.clear()` from `stop()` STILL passed - round 2 found it by mutation. The assertion
is now made against a node that has actually made a request. Recorded because two reviewers in a row
found the same hole in the same three lines, and the second time it was inside the repair for the first.

### U434 - **OPEN: a node cannot be VERIFIED on demand, only provoked** (opened by 19.7)

There is no server->node ping and no node heartbeat, so an idle-but-healthy worker cannot be verified when
a conductor wants to assign to it - it can only be provoked (`send_message`, whose delivery the U328 gate
may withhold), or waited for. Compounding it: `_lastSeen` observes gateway-mediated calls only, so a node
doing store-only MCP work (`read_messages`, `close_debate`, `publish_synthesis`, artifact reads) goes
stale while working. A heartbeat the node makes on a cadence shorter than the staleness window closes both.
Until then the refusal is worded as UNVERIFIED, never as failure, and clears on the node's next gateway
call. Owner: Phase 19, unit 9 or later - it is a protocol addition, not a repair.

### U435 - **OPEN: `voice/turn-authority.js:687` is a second unbounded await on the quit path** (found by the 19.7 gate-validator, round 1 MAJOR-1; confirmed round 2)

`apps/desktop/voice/turn-authority.js:687` is `await new Promise((resolve) => server.close(resolve));` on a
`net.Server` with no budget and no connection teardown, whose per-connection handler returns early until it
sees a newline with no socket idle timeout. It is awaited from `completeNormalQuit` and `teardownSelfCheck`
**one step earlier** than the gateway stop 19.7 bounded. The cooperating client destroys after 2 s, so it
is not trivially reachable - but U334's row and this unit's own comment both called the gateway await "the
one/single unbounded await after `event.preventDefault()`", and that was false at the time it was written.
The word is removed from the code comment; the defect is not fixed here. Owner: Phase 19, unit 9.

### U436 - **OPEN: refusing an assignment is costless for the WORKER and not for the project** (found by the 19.7 spec-auditor, MAJOR-2)

`mcp_server/sovereign_tools.py:126-139` creates the task and then calls the shell; when the call raises it
marks that task `BLOCKED` with the exception text as the blocker. 19.7's staleness refusal is a routine,
self-clearing condition, so it now reaches that path: a conductor that plans for longer than the staleness
window before assigning can create a durable `BLOCKED` row in append-only history for a worker that is
perfectly healthy - and inflate exactly the counts [[U336]] was fixed to keep honest. A second, older
hazard is exposed by the same reading: `controlAssignTask` evaluates the gate INSIDE the delivery loop, so
a two-owner task whose second worker is refused leaves the first already written to, `BUSY`, with a
deadline scheduled. The fail-closed shape is a pre-pass over `owner_node_ids` before any pane is written
to, and ideally a refusal that returns before `create_task`. Not done here: it is a behaviour change to
the assignment path after two completed review rounds. Owner: Phase 19, unit 9.

### U437 - **OPEN: the round-3 residuals - one shape defect and five recorded smalls** (found by the 19.7 gate-validator round 3 and spec-auditor round 2, over `e29bd7d`)

**(a) `stop()`'s no-server early return breaks the shape the rest of it reports.**
`apps/desktop/control/sovereign-control-server.js:233` answers
`{closed: true, was_listening: false, forced: false, timed_out: false}` - no `waited_ms`, no `timeout_ms` -
so the `{closed, forced, timed_out, waited_ms, timeout_ms}` contract the bounded path reports is not
universal, and `closed: true` is asserted for a socket that never existed. Mitigated by `was_listening`,
which the one caller that reads it (`main.js:2957`) does gate on. The fix is `waited_ms: 0,
timeout_ms: null`. NOT done at 19.7's close on purpose: it is a behaviour change to a shutdown path after
three completed review rounds, and the rule this unit is written under says such a change is reviewed, not
slipped in at the close - the same reasoning as [[U436]]. Owner: Phase 19, unit 9.

**(b) The established-state set is duplicated as literals.** `apps/desktop/control/assignment-gate.js:107`
re-encodes `SESSION_ESTABLISHED_STATES` / `sessionEstablished()`
(`apps/desktop/control/sovereign-control-server.js:45-49`) as the strings `"connected"` and `"stale"` - a
second place the state set can drift, inside the module that exists BECAUSE two questions were once
answered by one comparison. Not a violation; a drift hazard whose fix is to import the predicate.
Owner: Phase 19, unit 9.

**(c) A self-check leg paints a payload production cannot emit.** Leg E1 of
`apps/desktop/selfcheck/runtime-honesty-selfcheck.js:261-265` supplies an `operational` key in the
"nothing readable" case; production (`apps/desktop/main.js:1776-1778`) returns `{ok:false, error}` with no
such key. `renderInspector` bails identically for both, so the painted result is unaffected - but the
leg's claim to reproduce the operator's screen is one step removed, and it should send the production
shape.

**(d) The drawer-clearing string** at `apps/desktop/selfcheck/runtime-honesty-selfcheck.js:327` is a
cleanup call after the last assertion and is graded by nothing. Recorded so a later round does not
re-derive it.

**(e) `mcp_connected: true`** written as a literal at `apps/desktop/control/worker-readiness.js:614` is now
reachable for a session nothing has verified, since `sessionEstablished()` accepts `stale`. Already carried
by [[U432]]; re-flagged here as the round-3 reading of it, and it is one of [[U337]]'s booleans.
Owner: Phase 19, unit 8.

**(f) An unverified evidence row, named as one.** The long Python suite row in this unit's evidence
(`487 passed in 636.65 s`) was NOT re-run by the gate-validator - it is outside the delta's blast radius
and no `.py` file is in the range, but it is an unverified row and both the report and this register say
so rather than letting a table imply otherwise.

**(g) Two of the self-check's three servers are stopped outside any guard.** (Added at round 4/3.)
`apps/desktop/selfcheck/runtime-honesty-selfcheck.js` constructs three servers (`:103`, `:147`, `:163`).
Only the third is stopped in a `finally` (`:216-218`); leg A's is stopped inside its `try` (`:116`) and
leg F's at `:151` under no guard at all. All three are stopped on the success path and the check's process
exits either way, so nothing outlives the unit (D-LOOP-1 holds in fact) - but a throwing leg would leak a
listening socket, and the evidence report asserted a `finally` that is not there until this round corrected
it (spec-auditor round 3, MAJOR-2). Owner: Phase 19, unit 9.

### U438 - **OPEN: a `tests/unit` test that fails under concurrent host load** (found by the 19.7 gate-validator, round 3 MINOR-1)

`tests/unit/test_run_frontier_providers_ps1.py::TestExitCodeContract::test_a_refused_probe_exits_three_and_spends_nothing`
failed when `py -3.12 -m pytest tests/unit` ran concurrently with the desktop node suite and an Electron
self-check, and passed in isolation (that file alone: 50 passed, 1 skipped; the whole unit suite alone:
1889 passed, 1 skipped in 60.98 s). Same host-coupling family as [[U339]]'s 600 s ceiling: a suite whose
green depends on what else the host is doing cannot distinguish a slow machine from a broken contract.
Owner: Phase 19, unit 10, with U339's diagnosis (`--durations`, then `--timeout=120
--timeout-method=thread`).

### U439 - **OPEN: a mutation harness cannot tell an assertion failure from a setup failure** (found by the 19.7 gate-validator, round 4 MINOR-2)

`tools/mutation/orchestration_mutations.js:176` grades a row CAUGHT on child exit status `1`. For a
behavioural row that is nearly always an assertion; for a SOURCE-PIN row - and O11/O12/O14 are source-pin
rows - a syntax error introduced by the mutation, a missing file, or a `node --test` startup failure exits
1 as well, so the harness would report CAUGHT for a run that never graded anything. The same class the
whole of Phase 19 keeps finding, in the instrument this unit used to find it. The round-4 validator closed
the gap BY HAND for O12 and O13 (both fail on a named `AssertionError`, quoted in its report) and the O14
run was read the same way, so the rows are known good today - but nothing enforces it. Fix: assert on the
child's stdout naming the expected failing test, or require a `not ok` TAP line, rather than on the exit
code alone. Pre-existing; not introduced by 19.7. Owner: Phase 19, unit 9.

### U440 - **OPEN: the last edit of an evidence report is structurally unreviewable, and 19.7 is where that became explicit** (19.7, recorded at close)

Seven reviewer rounds ran over unit 19.7 (gate-validator 1-4, spec-auditor 1-3). Rounds 3 and 4 found no
product-code defect; every finding they had was in the evidence layer - and each round's repairs to that
layer were then, necessarily, unreviewed, because a review is what produces the text that records it. Two
consecutive rounds found that the PREVIOUS round's evidence repair had inherited the fault it was
repairing ([[U432]]). The regress is real and general: it is not specific to this unit, and no number of
rounds terminates it.

What 19.7 did about it, and what it did not: the unit stopped on a tree whose EXECUTABLE bytes had passed
a round unchanged (`f324671` differs from the reviewed `65d92e7` in comment text, two test files and one
harness), stated that the closing edits are unreviewed in the evidence report's §11 rather than implying
otherwise, and made every claim in those edits either a command output quoted verbatim or a register row.
That is a convention, not a mechanism. The mechanism, if the loop wants one: a final reviewer pass whose
sole object is the diff of the evidence layer since the last review, run with no authority to request code
changes - so it terminates by construction. Owner: whoever writes the Phase 19 gate at 19.10, since that
gate has the same shape and a tag riding on it.

### U441 - **CLOSED: U337 and U437(e) now distinguish testimony from emitted measurement and derive readiness only from observers**

Closed 2026-08-14 by Phase 19 unit 19.8, work commit
`1d151e1fa48fdfbb164a2096014ed2281a06ab4f`. The packaged Electron shell now has an
`orchestration-collaboration` self-check kind. Its emitted receipt names the committed source, clean
tracked product tree, start/finish times and Electron main PID; it runs the production mock-first
governed dispatch/collaboration path, observes descriptor assignment, accepted CANDIDATE artifacts,
synthesis/acceptance, pending operator disposition, renderer output and teardown, and claims zero live
exchanges. A second exact-source packaged readiness receipt records real SessionManager PID/generation
observations for its supervised panes.

`process_supervised` is true only when the shell re-observes the exact spawned PID/generation.
`mcp_connected` is derived from the current gateway state, so `stale` is false rather than promoted to
true. The runtime has no independent observers for `provider_authenticated`, `workspace_accepted`,
`mcp_discovered`, `identity_validated` or `permission_resolved`, so those fields are absent rather than
fabricated. The historical `FINAL_THREE_NODE_ORCHESTRATION_ACCEPTANCE.json` and
`FINAL_TALK_WORKER_SPAWN_ACCEPTANCE.json` remain byte-identical; additive sibling `.PROVENANCE.md` notes
classify them as operator testimony/manual acceptance records and explicitly prevent the new mock-first
receipt from being read as regenerated live acceptance.

Evidence: `docs/evidence/PHASE19_UNIT8_U337_EVIDENCE_PROVENANCE.md` and
`docs/evidence/receipts/PHASE19_8_ORCHESTRATION_COLLABORATION_SELFCHECK_19.8_20260814T233602Z.json`.
U437(a)-(d), (f) and (g) remain OPEN under their recorded Phase 19 unit 9 owners; this row closes only
item (e). State: **CLOSED**.

### U442 - **MIXED DISPOSITION: Phase 19.9 makes orchestration coverage executable and closes U435, U436 and U439**

Closed by work commit `324811be4706a2731f65ab0db7c24069a30a36cf` and evidenced in
`docs/evidence/PHASE19_UNIT9_U338_EXECUTABLE_ORCHESTRATION_COVERAGE.md`:

- **U435 CLOSED.** `SupervisorVoiceTurnAuthority.stop()` is bounded, destroys held sockets halfway,
  reports its outcome, and contributes to the normal-quit verdict. A real held-open loopback socket
  is the negative control.
- **U436 CLOSED.** The application preflights every owner before `create_task` and repeats the same
  check before the first pane write. A real `tools/call` refusal over SQLite leaves the task table
  empty; the two-owner shell test leaves the first pane untouched.
- **U439 CLOSED.** Orchestration mutations require the named intended test in child output as well as
  exit 1. O1/O11/O12/O14 now mutate executable require-able modules and are behaviorally graded.
- **U437(a) and (b) CLOSED in code and tests.** The no-server stop path has universal timing fields,
  and assignment uses the shared `sessionEstablished` predicate.
- **U437(c), (d) and (g) IMPLEMENTED, MEASUREMENT OWED.** The nothing-readable leg uses production's
  exact payload, drawer cleanup is a required boolean, and every check-owned server is stopped in a
  `finally`. OP-13.2 explicitly forbids launching Electron in this session, so no new packaged
  runtime-honesty receipt was emitted; the Phase 19 gate must not describe these as runtime-measured.
- **U437(f) remains OPEN through unit 19.10**, which owns a fresh full-Python result.
- **U432 remains OPEN, narrowed:** quit success now consumes both bounded server outcomes. Remaining
  are observed-listening/error reporting, UI freshness emphasis and heartbeat-linked semantics.
- **U434 remains OPEN:** no heartbeat protocol was invented inside a coverage unit. Owner: next
  orchestration protocol phase, before claiming on-demand node verification.
- **U438 remains OPEN under unit 19.10**, unchanged.

No provider, Electron, MCP, remote or dependency action was used to obtain these results.
State: **MIXED — named closures final; named residuals OPEN with owners.**

### U443 - **CLOSED: Phase 19.10's first pytest ceiling was inherited prose presented as a contract**

The recovery candidate committed `phase19_suite_timeout_seconds = 600` before any whole-suite
measurement completed. The number came from the operator's historical invocation ceiling, even though
iteration 134 already recorded the long non-unit subset alone at 613.71 seconds. Its first execution
therefore failed at 18% after 600 seconds. Nothing hung; alphabetical collection was still inside the
slow integration directory. `pytest-timeout` was absent, the operator denied installing it, and no
package was installed.

A direct `py -3.12 -m pytest tests/ -q --durations=20` run completed in 638.34 seconds and identified
eight stable >15-second host-dependent outlier files, followed by a 7.17-second ninth test. The contract
now records those paths and an 800-second ceiling: the measured 638.34 seconds plus 161.66 seconds
(25.3%) headroom. The corrected wrapper then passed the complete tree: 2382 passed, 1 explicitly named
host-coupled skip, 61 warnings, 608.47 seconds. The failed inherited value and its derivation defect are
comments beside the corrected setting and recorded in
`docs/evidence/PHASE19_UNIT10_U339_SUITE_AND_GATE.md`; they are not rewritten out of history.

The direct run also found a stale negative control: `test_node_schema_amendment.py` used `OP-13.2` as
an invented ruling after OP-13.2 became real. It now asserts its fabricated ruling is absent from both
ruling sources before grading the fail-closed path, and the repaired file passed in isolation and in the
full tree.

Owner: Phase 19 unit 19.10. State: **CLOSED by measured contract and demonstrated wrapper pass.**

### U444 - **MIXED GATE DISPOSITION: Phase 19 carried issues at unit 19.10**

- [[U432]] remains **OPEN**, narrowed by [[U442]] to observed-listening/error reporting, UI freshness
  emphasis, and heartbeat-linked semantics. Owner: next orchestration protocol phase.
- [[U434]] remains **OPEN**: there is no server-to-node ping or periodic node heartbeat. Owner: next
  orchestration protocol phase before any on-demand verification claim.
- [[U435]], [[U436]], and [[U439]] are **CLOSED** by Phase 19.9 / [[U442]].
- [[U437]] items (a), (b), and (e) are **CLOSED**; item (f) closes on the fresh 19.10 full-Python run;
  items (c), (d), and (g) remain **IMPLEMENTED, RUNTIME MEASUREMENT OWED** because OP-13.2 forbids
  launching Electron in this Codex session. Owner: Path A's application run against committed HEAD.
- [[U438]] remains **OPEN** as historical concurrent-host-load coupling. Its named test passed on the
  otherwise idle host (0.57 seconds in the focused run and again in the full tree), but the committed
  wrapper does not claim it can exclude unrelated external workloads. Owner: future test-runner
  isolation work; `tools/loop/run_loop.ps1` remains operator-reserved.
- [[U440]] is addressed for this gate by a terminating evidence-only review over the post-review diff;
  its verdict is recorded verbatim in the 19.10 evidence report before any tag.

This mixed disposition is permitted by the Phase 19 directive: every carried row either closes with
fresh evidence or remains recorded with an owner and a reason. State: **MIXED — named closures final;
named residuals OPEN with owners.**
