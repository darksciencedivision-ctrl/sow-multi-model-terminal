# State of the Sovereign Orchestration Workspace

Snapshot created 2026-08-15 21:06:26.204 -05:00 / 2026-08-16 02:06:26.209 UTC.

## A. Position

The workspace is in Phase 19 (post-18E remediation), with unit 19.10 in progress. HEAD is `bad029e76a0bcc2f57062245ccf67ddf9394e47d` on `main`; `git describe --tags` reported `gate/phase-18e-95-gbad029e`. There are 50 tags. `gate/phase-19` is not set. `product/multi-frontier-v2` remains at `cd08878f6dbf3bcf2a223a03ae0df27be64ad4b8` and is never moved.

Phase 19 exit criteria are unmet. No persisted `PHASE19_GATE_REVIEW_<reviewer>_round<N>.md` reviewer report exists for the phase. By contrast, units 19.4 and 19.6 persisted reviewer-run receipts, and Phase 17E and 18A have persisted review documents. The current `LOOP_STATE.json` records that a spec-auditor round failed with six blockers but was never persisted, while a gate-validator artifact audit was interrupted and produced no verdict. Those reviews must be reproduced or superseded fresh; their narrated totals are not adoptable.

## B. Uncommitted material

HEAD alone does not represent this package. The current worktree includes:

| Worktree entry | SHA-256 | Meaning |
| --- | --- | --- |
| `docs/loop/LOOP_STATE.json` | `981a97f42ae7dccd390eced5036bedb42e87635d07e0d31b4f048932bd5fe97b` | Recovery-provenance position, the six unpersisted review blockers, and the required fresh-review continuation for 19.10. |
| `docs/registers/UNRESOLVED_ISSUE_REGISTER.md` | `687acf7af073d7cd8eb8e213538076c31bca94e825e19770f46c970b0fb18e19` | Append-only rows U443 and U444: the measured pytest ceiling correction and mixed gate disposition. |
| `docs/evidence/PHASE19_UNIT10_U339_SUITE_AND_GATE.md` | `d5b11a5da8e31eb97f2c475a1c0acf90bf67dc1a390b56686c764fbb4dcb1aa7` | Untracked candidate evidence for the measured suite contract, fresh validation, carried-issue disposition, and still-unclosed reviews/gate. |

Under the project's recovery-provenance rule, work left uncommitted by a crashed or stopped iteration is **candidate material**. Its claims and receipts are inputs only and must be re-run fresh before adoption.

## C. Operator rulings in force

- **OP-13:** Antigravity `accept-edits` is not operator approval. `ANTIGRAVITY_HEADLESS_MODE = "plan"` is restored at `adapters/frontier/antigravity.py:78`, and the former `antigravity_execution` carve-out at `adapters/frontier/provider_cli_common.py:310-312` is removed.
- **OP-13.1:** remediation precedes the live run.
- On 2026-08-15, operator direction restored `claude_code` to `scope.providers`. This was not a widening: `control_plane/profiles/live_authorization.py` already binds OP-6 to Claude plus Codex and OP-12 to those two plus Grok and Antigravity, with Claude recorded at the full allowance as operator-reaffirmed at OP-12.

The current operator authorization switch, which is deliberately not packaged, records `register_row: OP-12`, `live_operation_authorized: true`, providers `openai_codex_cli`, `claude_code`, `grok_build`, and `google_antigravity`, and `terminals_per_subscription: 1`. Its conductor is `openai_codex_cli` / `gpt-5.6-sol` (`ChatGPT 5.6 Sol`) with permission profile `pp-conductor-pane`. Its machine-specific workspace value is intentionally not reproduced in package documentation.

## D. Bring-up result, 2026-08-15

- **CODEX / `openai_codex_cli` / `gpt-5.6-sol`:** governed, supervised, lease 1/1, conductor pane. It completed a round-trip: the shell readiness probe asked for a sum and received `SUM=50`. This is the only provider with a demonstrated completed turn.
- **CLAUDE / `claude_code` / CLI-default (`model_slug: null`):** governed, supervised, lease 1/1. Spawn argv carried no `--model`; the CLI selected its own default. Resolution was `source: unprobed`, `model_available: null`, resolved model `null`, which is correct for the null option because Sovereign did not invent an identifier. The prompt reached the CLI; no provider turn completed.
- **GROK / `grok_build` / `grok-4.5`:** governed and supervised; lease reached 1/1, then a clean exit code 0 released it to 0/1. The full governed lifecycle was demonstrated. The prompt reached the CLI; no provider turn completed. It was not live at the end of bring-up.
- **GEMINI / `google_antigravity`:** never entered the picker because of F1. A governed out-of-band probe exited 0 with no observed authentication or quota blocker, which does not establish Electron-pane usability.

Correction: Grok and Claude were initially called usable merely because an interactive prompt was reached. Their accurate readiness state is `OPEN_READY`. Only Codex completed a turn.

## E. Architectural boundary demonstrated three times

**Path A — Model Picker -> Electron IPC -> shell -> governed ConPTY worker: WORKS.** It is independent of MCP and was proven on Grok and Claude.

**Path B — Codex conductor -> sovereign MCP -> worker dispatch: DEAD.** `sovereign.list_mcp_resources` failed with `MCP server 'sovereign' was not ready for this step`. Against a live governed Grok worker, nothing reached Grok and its token counter did not move.

## F. Open findings — four, none repaired and none recorded on disk

### F1 — Antigravity model inventory parser incompatibility

`adapters/frontier/provider_cli_common.py` function `parse_antigravity_models` says it expects a bare newline-separated slug list. Installed `agy` v1.1.13 emits two columns, `slug<TAB>Display Name`, returning 14 models at exit 0. The parser rejects those lines both through its whitespace filter and its fully anchored `MODEL_SLUG_RE`, producing `models: []`, `option_count: 0`, and `available: false`; a healthy provider never reaches the picker.

Repair standard for a future unit: follow `parse_grok_models`, which gates on the `Available models:` section, slug shape, and annotation shape. A naive split-on-tab would wrongly accept a `MODEL<TAB>DISPLAY NAME` header. Add rejected-line reporting to `parse_note` so future drift is visible.

### F2 — Sovereign MCP server fails to initialize at conductor startup

Observed startup text: `MCP startup interrupted. The following servers were not initialized: codex_apps, node_repl, sovereign`. The conductor therefore cannot address any worker, however well governed. This blocks Path B but does not affect Path A.

### F3 — `ModelProbeLedger` is incomplete and fails silently

The excluded live ledger last written 2026-07-26 has exactly one Claude entry: `fable-5`, accepted as `claude-fable-5`. The picker offers `opus-4.8`, for which there is no record. A missing record produces `model: None`, `model_available: None`, `source: unprobed`, while the launch contract uses an unprobed selection's own non-null label as before. Thus a raw explicit label may reach the CLI unverified.

Demonstrated fact: bare `fable-5` was rejected by the Claude CLI, while `claude-fable-5` was accepted. Risk, not demonstrated outcome: an unprobed explicit model such as `opus-4.8` could pass ticket, process, supervision, and lease stages and then exit because the CLI rejects its spelling. The exact `opus-4.8` failure has not been executed. The discriminator is important: `source: unprobed` with a **null** model is correct and injects nothing; `source: unprobed` with a **non-null** model is the trap.

### F4 — `+ Terminal node` creates a pane that cannot accept a model

A new terminal pane starts with a live PowerShell session. `apps/desktop/picker/worker-spawn.js:235` refuses to launch into a pane with a live session, and `main.js:1926` defines occupancy so that this pane remains occupied. The working ritual is `+ Terminal node` -> type `exit` -> the empty pane survives -> picker launch succeeds. Closing the pane with `X` destroys it and leaves no target. A governed worker pane has no shell—the CLI itself is the PTY—so `exit` does not apply there; use the CLI's own quit.

The picker also retains a stale target after its pane is destroyed, and role dropdowns reset to `conductor` on rerender. That combination can produce `_assert_option_offered` refusal because the CLI-default row offers only `reasoning` and `coding`.

## G. Claims to treat as unproven

- **“Fail-closed behavior prevented fake worker responses.”** No product mechanism enforced that claim. On one MCP failure the conductor reported the failure and then answered `2+2=4` itself; on another it declined. Those were model choices after the same failure.
- **The Claude CLI's own default model.** Two readings disagree: a naked session was read as Opus 4.5 and a governed one as Opus 5. One is likely a low-resolution screenshot misread. Build on neither.
- **Grok picker selection versus resolved model.** The final report records selected/resolved `grok-4.5`, but the banner sequence `Model · Grok 4.6` then `Switched to Grok 4.5` was never cleanly reconciled with the persisted chrome record.

## H. What this package does not decide

The shared-JSON orchestration simplification remains an open operator question; neither option is authorized. The cold audit's recorded position remains: SQLite is not the defect, `mutate_operational_task` is sound, and U330 is that five of seven writers bypass it.

## I. Suggested next units

In order: F1 (bring the Antigravity parser to the Grok three-axis standard), F3 (probe offered Claude labels or stop offering unprobed explicit ones), F2 (MCP initialization), then the Phase 19 gate. Each is a separately scoped unit against a known worktree state. This package authorizes none of them.
